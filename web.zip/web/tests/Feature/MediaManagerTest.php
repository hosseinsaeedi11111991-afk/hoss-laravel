<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Services\AttachmentService;

beforeEach(function () {
    $altMapPath = storage_path('app/media-alt.json');
    $GLOBALS['media_manager_alt_map_backup'] = is_file($altMapPath) ? file_get_contents($altMapPath) : null;

    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');

    Schema::create('attachments', function (Blueprint $table) {
        $table->id();
        $table->string('disk', 50)->default('public');
        $table->string('path', 255);
        $table->string('file_name', 100);
        $table->bigInteger('file_size');
        $table->string('file_type');
        $table->string('mime_type', 50);
        $table->string('checksum', 64)->unique();
        $table->timestamps();
    });

    Schema::create('attachment_meta', function (Blueprint $table) {
        $table->id();
        $table->foreignId('attachment_id');
        $table->string('attribute', 50);
        $table->text('value')->nullable();
    });

    Schema::create('attachables', function (Blueprint $table) {
        $table->id();
        $table->foreignId('attachment_id');
        $table->string('attachable_type');
        $table->unsignedBigInteger('attachable_id');
        $table->string('role')->nullable();
        $table->integer('sort_order')->default(0);
        $table->string('status')->default('active');
        $table->timestamps();
    });

    Schema::create('blog_posts', function (Blueprint $table) {
        $table->id();
        $table->string('thumbnail')->nullable();
        $table->string('thumbnail_tag')->nullable();
        $table->string('image')->nullable();
        $table->string('image_tag')->nullable();
        $table->longText('body')->nullable();
    });
});

afterEach(function () {
    $altMapPath = storage_path('app/media-alt.json');

    @unlink(storage_path('app/public/media-manager-test.jpg'));
    @unlink(storage_path('app/public/blog/posts/thumbnail/media-manager-test.jpg'));
    @unlink(storage_path('app/public/blog/posts/body/media-manager-test.jpg'));
    @unlink(resource_path('views/media-manager-alt-test.blade.php'));

    if ($GLOBALS['media_manager_alt_map_backup'] === null) {
        @unlink($altMapPath);
    } else {
        file_put_contents($altMapPath, $GLOBALS['media_manager_alt_map_backup']);
    }

    unset($GLOBALS['media_manager_alt_map_backup']);
});

it('bulk deletes only unused media attachments', function () {
    $unused = Attachment::create([
        'disk' => 'public',
        'path' => 'media/unused.jpg',
        'file_name' => 'unused.jpg',
        'file_size' => 100,
        'file_type' => Attachment::FILE_TYPE_IMAGE,
        'mime_type' => 'image/jpeg',
        'checksum' => hash('sha256', 'unused'),
    ]);

    $used = Attachment::create([
        'disk' => 'public',
        'path' => 'media/used.jpg',
        'file_name' => 'used.jpg',
        'file_size' => 100,
        'file_type' => Attachment::FILE_TYPE_IMAGE,
        'mime_type' => 'image/jpeg',
        'checksum' => hash('sha256', 'used'),
    ]);

    DB::table('attachables')->insert([
        'attachment_id' => $used->id,
        'attachable_type' => 'test',
        'attachable_id' => 1,
        'status' => 'active',
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    $service = Mockery::mock(AttachmentService::class);
    $service->shouldReceive('deleteWithThumbnails')
        ->once()
        ->with(Mockery::on(fn (Attachment $attachment) => $attachment->is($unused)))
        ->andReturn(true);

    app()->instance(AttachmentService::class, $service);

    $this->withoutMiddleware()
        ->delete(route('admin.media.bulkDestroy'), [
            'attachment_ids' => [$unused->id, $used->id],
        ])
        ->assertRedirect(route('admin.media.index'));
});

it('updates alt text for filesystem media images', function () {
    if (! is_dir(storage_path('app/public'))) {
        mkdir(storage_path('app/public'), 0755, true);
    }

    file_put_contents(storage_path('app/public/media-manager-test.jpg'), 'test image');

    $this->withoutMiddleware()
        ->put(route('admin.media.filesystemAlt'), [
            'image_path' => 'storage/media-manager-test.jpg',
            'image_alt' => 'متن جایگزین تست',
        ])
        ->assertRedirect(route('admin.media.index'));

    $altMap = json_decode((string) file_get_contents(storage_path('app/media-alt.json')), true);

    expect($altMap['storage/media-manager-test.jpg'])->toBe('متن جایگزین تست');
});

it('shows existing alt text from blade images for filesystem media', function () {
    if (! is_dir(storage_path('app/public'))) {
        mkdir(storage_path('app/public'), 0755, true);
    }

    file_put_contents(storage_path('app/public/media-manager-test.jpg'), 'test image');
    file_put_contents(
        resource_path('views/media-manager-alt-test.blade.php'),
        '<img src="{{ asset(\'storage/media-manager-test.jpg\') }}" alt="متن قبلی تصویر">'
    );

    $controller = app(\App\Http\Controllers\Admin\MediaController::class);
    $method = (new ReflectionClass($controller))->getMethod('publicImages');
    $images = collect($method->invoke($controller));

    expect($images->firstWhere('relative', 'storage/media-manager-test.jpg')['alt'])->toBe('متن قبلی تصویر');
});

it('shows suggested alt text for filesystem media without existing alt', function () {
    if (! is_dir(storage_path('app/public'))) {
        mkdir(storage_path('app/public'), 0755, true);
    }

    file_put_contents(storage_path('app/public/media-manager-test.jpg'), 'test image');

    $controller = app(\App\Http\Controllers\Admin\MediaController::class);
    $method = (new ReflectionClass($controller))->getMethod('publicImages');
    $images = collect($method->invoke($controller));
    $fallbackAlts = (new ReflectionClass($controller))->getConstant('FALLBACK_IMAGE_ALTS');
    $image = $images->firstWhere('relative', 'storage/media-manager-test.jpg');

    expect($image['alt'])->not->toBe('')
        ->and($image['alt_source'])->toBe('suggested')
        ->and($fallbackAlts)->toContain($image['alt']);
});

it('shows existing alt text from blog post image tags for filesystem media', function () {
    if (! is_dir(storage_path('app/public/blog/posts/thumbnail'))) {
        mkdir(storage_path('app/public/blog/posts/thumbnail'), 0755, true);
    }

    file_put_contents(storage_path('app/public/blog/posts/thumbnail/media-manager-test.jpg'), 'test image');

    DB::table('blog_posts')->insert([
        'thumbnail' => 'blog/posts/thumbnail/media-manager-test.jpg',
        'thumbnail_tag' => 'متن تصویر شاخص قبلی',
        'image' => null,
        'image_tag' => null,
        'body' => null,
    ]);

    $controller = app(\App\Http\Controllers\Admin\MediaController::class);
    $method = (new ReflectionClass($controller))->getMethod('publicImages');
    $images = collect($method->invoke($controller));

    expect($images->firstWhere('relative', 'storage/blog/posts/thumbnail/media-manager-test.jpg')['alt'])->toBe('متن تصویر شاخص قبلی');
});

it('shows existing alt text from blog post body html for filesystem media', function () {
    if (! is_dir(storage_path('app/public/blog/posts/body'))) {
        mkdir(storage_path('app/public/blog/posts/body'), 0755, true);
    }

    file_put_contents(storage_path('app/public/blog/posts/body/media-manager-test.jpg'), 'test image');

    DB::table('blog_posts')->insert([
        'thumbnail' => null,
        'thumbnail_tag' => null,
        'image' => null,
        'image_tag' => null,
        'body' => '<p><img src="'.asset('storage/blog/posts/body/media-manager-test.jpg').'" alt="متن قبلی داخل مقاله"></p>',
    ]);

    $controller = app(\App\Http\Controllers\Admin\MediaController::class);
    $method = (new ReflectionClass($controller))->getMethod('publicImages');
    $images = collect($method->invoke($controller));

    expect($images->firstWhere('relative', 'storage/blog/posts/body/media-manager-test.jpg')['alt'])->toBe('متن قبلی داخل مقاله');
});
