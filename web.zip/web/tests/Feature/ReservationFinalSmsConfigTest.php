<?php

use App\Models\SmsSetting;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\Notification\Services\SmsService;
use Modules\Reservation\Events\ReservationCreated;
use Modules\Reservation\Events\ReservationStatusChanged;
use Modules\Reservation\Listeners\SendReservationNotificationSms;
use Modules\Reservation\Models\Reservation;

beforeEach(function () {
    Schema::dropIfExists('sms_settings');
    Schema::dropIfExists('neshan_locations');
});

afterEach(function () {
    Schema::dropIfExists('sms_settings');
    Schema::dropIfExists('neshan_locations');
});

it('falls back to simple admin sms when final reservation pattern sms fails', function () {
    Schema::create('sms_settings', function (Blueprint $table) {
        $table->id();
        $table->string('sender', 40)->nullable();
        $table->string('reservation_admin_recipient', 40)->nullable();
        $table->string('reservation_admin_pattern', 80)->nullable();
        $table->string('reservation_passenger_pattern', 80)->nullable();
        $table->timestamps();
    });

    SmsSetting::query()->create([
        'reservation_admin_recipient' => '09121111111',
        'reservation_admin_pattern' => 'dashboard-admin-pattern',
        'reservation_passenger_pattern' => 'dashboard-passenger-pattern',
    ]);

    Schema::create('neshan_locations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->string('type', 40)->nullable();
        $table->boolean('is_primary')->default(false);
        $table->decimal('latitude', 10, 7)->nullable();
        $table->decimal('longitude', 10, 7)->nullable();
        $table->text('address_text')->nullable();
        $table->timestamps();
    });

    config()->set('notification.sms.reservation_admin_recipient', '09120983462');
    config()->set('notification.sms.reservation_admin_pattern', 'config-admin-pattern');

    $reservation = new Reservation([
        'status' => Reservation::STATUS_COMPLETED,
        'phone' => '09123456789',
        'origin_address' => 'تهران',
        'destination_address' => 'اصفهان',
        'passengers_count' => 1,
        'is_negotiable' => true,
    ]);
    $reservation->id = 123;
    $reservation->exists = true;

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->once())
        ->method('sendPattern')
        ->with('09120983462', 'config-admin-pattern', $this->isType('array'))
        ->willReturn(false);

    $smsService->expects($this->once())
        ->method('send')
        ->with(
            '09120983462',
            $this->callback(fn (string $message) => str_contains($message, 'رزرو تاکسی ثبت شد')
                && str_contains($message, '09123456789')
                && str_contains($message, '123'))
        )
        ->willReturn(true);

    $listener = new class($smsService) extends SendReservationNotificationSms {
        protected function sendPassengerSms(Reservation $reservation, string $passengerName, string $carCategory, string $priceText): void
        {
        }
    };

    $listener->handle(new ReservationStatusChanged($reservation, Reservation::STATUS_PENDING, Reservation::STATUS_COMPLETED));
});

it('sends admin sms when a pending reservation is created', function () {
    Schema::create('neshan_locations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->string('type', 40)->nullable();
        $table->boolean('is_primary')->default(false);
        $table->decimal('latitude', 10, 7)->nullable();
        $table->decimal('longitude', 10, 7)->nullable();
        $table->text('address_text')->nullable();
        $table->timestamps();
    });

    config()->set('notification.sms.reservation_admin_recipient', '09120983462');
    config()->set('notification.sms.reservation_admin_pattern', 'config-admin-pattern');

    $reservation = new Reservation([
        'status' => Reservation::STATUS_PENDING,
        'phone' => '09123456789',
        'origin_address' => 'تهران',
        'destination_address' => 'اصفهان',
        'passengers_count' => 1,
        'is_negotiable' => true,
    ]);
    $reservation->id = 456;
    $reservation->exists = true;

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->once())
        ->method('sendPattern')
        ->with(
            '09120983462',
            'config-admin-pattern',
            $this->callback(fn (array $variables) => ($variables['passenger_phone'] ?? null) === '09123456789')
        )
        ->willReturn(true);

    $smsService->expects($this->never())->method('send');

    $listener = new class($smsService) extends SendReservationNotificationSms {
        protected function sendPassengerSms(Reservation $reservation, string $passengerName, string $carCategory, string $priceText): void
        {
        }
    };

    $listener->handle(new ReservationCreated($reservation));
});
