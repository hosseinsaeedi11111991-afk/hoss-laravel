<?php

use Illuminate\Support\Facades\Route;
use Modules\Reservation\Http\Controllers\site\PopularRouteSiteController;
use Modules\Reservation\Http\Controllers\site\ReservationSiteController;

it('registers the public reservation routes used by the reservation form', function () {
    expect(Route::has('site.reservation.index'))->toBeTrue()
        ->and(Route::has('site.reservation.preview'))->toBeTrue()
        ->and(Route::has('site.reservation.price-quote'))->toBeTrue()
        ->and(Route::has('site.popular-route.start'))->toBeTrue()
        ->and(route('site.reservation.index', [], false))->toBe('/reservation')
        ->and(route('site.reservation.price-quote', [], false))->toBe('/reservation/price-quote')
        ->and(route('site.reservation.preview', [], false))->toBe('/reservation/preview')
        ->and(route('site.popular-route.start', ['popularRoute' => 10], false))->toBe('/popular-route/10/start');

    $priceQuoteRoute = Route::getRoutes()->getByName('site.reservation.price-quote');
    $previewRoute = Route::getRoutes()->getByName('site.reservation.preview');
    $popularRoute = Route::getRoutes()->getByName('site.popular-route.start');

    expect($priceQuoteRoute)->not->toBeNull()
        ->and($priceQuoteRoute->uri())->toBe('reservation/price-quote')
        ->and($priceQuoteRoute->methods())->toContain('POST')
        ->and($priceQuoteRoute->getActionName())->toBe(ReservationSiteController::class . '@getPriceQuote')
        ->and($previewRoute)->not->toBeNull()
        ->and($previewRoute->uri())->toBe('reservation/preview')
        ->and($previewRoute->methods())->toContain('POST')
        ->and($previewRoute->getActionName())->toBe(ReservationSiteController::class . '@previewSelection')
        ->and($popularRoute)->not->toBeNull()
        ->and($popularRoute->uri())->toBe('popular-route/{popularRoute}/start')
        ->and($popularRoute->methods())->toContain('POST')
        ->and($popularRoute->getActionName())->toBe(PopularRouteSiteController::class . '@start');
});
