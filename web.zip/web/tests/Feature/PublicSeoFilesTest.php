<?php

use Illuminate\Support\Facades\DB;

beforeEach(function () {
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');
});

it('includes reservation and articles pages in sitemap', function () {
    $response = $this->get('/sitemap.xml');

    $response->assertOk();

    $content = $response->getContent();

    expect(rawurldecode($content))->toContain(url('/reservation'))
        ->and(rawurldecode($content))->toContain(url('/مقالات'))
        ->and($content)->not->toContain('?slug=');
});

it('lists public sitemap urls in llms txt', function () {
    $response = $this->get('/llms.txt');

    $response->assertOk();

    $content = $response->getContent();

    expect($content)->toContain('  - /reservation')
        ->and($content)->toContain('  - /مقالات')
        ->and($content)->toContain('  - /sitemap.xml');
});
