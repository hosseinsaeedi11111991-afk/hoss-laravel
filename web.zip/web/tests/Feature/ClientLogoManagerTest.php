<?php

use App\Models\ClientLogo;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Middleware\RoleMiddleware;

beforeEach(function () {
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');

    Schema::create('client_logos', function (Blueprint $table) {
        $table->id();
        $table->string('title', 120);
        $table->string('alt', 255)->nullable();
        $table->string('image_path');
        $table->string('link_url')->nullable();
        $table->unsignedSmallInteger('sort_order')->default(0);
        $table->boolean('is_active')->default(true);
        $table->timestamps();
    });

    Storage::fake('public');
});

it('stores a client logo from admin dashboard', function () {
    $this->withoutMiddleware([
            \App\Http\Middleware\Authenticate::class,
            \Illuminate\Auth\Middleware\Authenticate::class,
            RoleMiddleware::class,
        ])
        ->post(route('admin.client-logos.store'), [
            'title' => 'Datis',
            'alt' => 'لوگوی داتیس',
            'link_url' => 'https://example.com',
            'sort_order' => 2,
            'is_active' => '1',
            'image' => UploadedFile::fake()->image('datis.jpg', 200, 120),
        ])
        ->assertRedirect(route('admin.client-logos.index'));

    $logo = ClientLogo::first();

    expect($logo)->not->toBeNull()
        ->and($logo->title)->toBe('Datis')
        ->and($logo->alt)->toBe('لوگوی داتیس')
        ->and($logo->sort_order)->toBe(2)
        ->and($logo->is_active)->toBeTrue();

    Storage::disk('public')->assertExists($logo->image_path);
});

it('deletes a client logo and its uploaded file', function () {
    $path = UploadedFile::fake()->image('logo.jpg', 200, 120)->store('client-logos', 'public');

    $logo = ClientLogo::create([
        'title' => 'Old logo',
        'alt' => null,
        'image_path' => $path,
        'link_url' => null,
        'sort_order' => 0,
        'is_active' => true,
    ]);

    $this->withoutMiddleware([
            \App\Http\Middleware\Authenticate::class,
            \Illuminate\Auth\Middleware\Authenticate::class,
            RoleMiddleware::class,
        ])
        ->delete(route('admin.client-logos.destroy', $logo))
        ->assertRedirect(route('admin.client-logos.index'));

    expect(ClientLogo::query()->count())->toBe(0);
    Storage::disk('public')->assertMissing($path);
});
