<?php

use App\Http\Controllers\DistanceController;
use Modules\Neshan\Services\NeshanService;
use Modules\Notification\Services\SmsService;
use Modules\Reservation\Models\Reservation;

it('notifies the admin when a price calculation phone number is captured', function () {
    config()->set('notification.sms.farazsms.sender', '3000505');
    config()->set('notification.sms.reservation_admin_recipient', '09120983462');

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->once())
        ->method('send')
        ->with(
            '09120983462',
            $this->callback(fn (string $message) => str_contains($message, '09123456789')
                && str_contains($message, '123'))
        )
        ->willReturn(true);

    app()->instance(SmsService::class, $smsService);

    $reservation = new Reservation([
        'origin_address' => 'تهران، میدان آزادی',
        'destination_address' => 'اصفهان، میدان نقش جهان',
    ]);
    $reservation->id = 123;

    $controller = new DistanceController(new NeshanService());
    $notify = Closure::bind(
        fn (Reservation $reservation, string $phone) => $this->notifyAdminAboutPriceCalculation($reservation, $phone),
        $controller,
        DistanceController::class
    );

    $notify($reservation, '09123456789');
});

it('notifies the admin immediately after the route calculation phone modal continues', function () {
    config()->set('notification.sms.farazsms.sender', '3000505');
    config()->set('notification.sms.reservation_admin_recipient', '09120983462');

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->once())
        ->method('send')
        ->with(
            '09120983462',
            $this->callback(fn (string $message) => str_contains($message, '09123456789')
                && str_contains($message, 'تعداد مسیرها: 1')
                && str_contains($message, '35.7000,51.4000')
                && str_contains($message, '32.6500,51.6700'))
        )
        ->willReturn(true);

    app()->instance(SmsService::class, $smsService);

    $controller = new DistanceController(new NeshanService());
    $notify = Closure::bind(
        fn (string $phone, array $routes) => $this->notifyAdminAboutPriceCalculationPhoneCaptured($phone, $routes),
        $controller,
        DistanceController::class
    );

    $notify('09123456789', [[
        'origin_lat' => '35.7000',
        'origin_lng' => '51.4000',
        'destination_lat' => '32.6500',
        'destination_lng' => '51.6700',
        'origin_index' => 0,
        'destination_index' => 0,
    ]]);
});
