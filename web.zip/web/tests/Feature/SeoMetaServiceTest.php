<?php

use App\Services\SeoMetaService;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

it('builds https canonical without page one or tracking parameters', function () {
    $service = app(SeoMetaService::class);
    $request = Request::create('http://example.test/blog-category?page=1&utm_source=x&b=2&a=1');

    expect($service->canonical($request))->toBe('https://viptaxiiran.com/blog-category?a=1&b=2');
});

it('keeps page two canonical and paginated title unique', function () {
    $service = app(SeoMetaService::class);
    $request = Request::create('http://example.test/blog-category?page=2');
    $posts = new LengthAwarePaginator(new Collection(), 20, 6, 2);
    $posts->setPath('/blog-category');

    $meta = $service->blogCollection('مقالات و اخبار', 'توضیح پایه برای صفحه مقالات سایت', $posts, $request);

    expect($meta['canonical'])->toBe('https://viptaxiiran.com/blog-category?page=2')
        ->and($meta['title'])->toBe('مقالات و اخبار | صفحه 2')
        ->and($meta['description'])->toContain('صفحه 2');
});

it('cleans descriptions and does not cut words when limiting text', function () {
    $service = app(SeoMetaService::class);
    $description = $service->metaDescription(
        null,
        'عنوان تست',
        '<p>[shortcode] این یک متن طولانی برای تست تولید متا دیسکریپشن است که باید بدون HTML و بدون قطع شدن وسط کلمه کوتاه شود.</p>'
    );

    expect($description)->not->toContain('<p>')
        ->and($description)->not->toContain('[shortcode]')
        ->and(mb_strlen($description))->toBeLessThanOrEqual(165)
        ->and($description)->not->toEndWith(' ');
});

it('creates valid json ld arrays for generic pages', function () {
    $service = app(SeoMetaService::class);
    $meta = $service->generic('صفحه تست', 'توضیح صفحه تست', Request::create('https://viptaxiiran.com/test'));
    $encoded = json_encode($meta['schema'][0], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    expect(json_last_error())->toBe(JSON_ERROR_NONE)
        ->and($encoded)->toContain('"@type":"WebPage"')
        ->and($meta['og']['title'])->toBe('صفحه تست')
        ->and($meta['twitter']['card'])->toBe('summary_large_image');
});
