<?php

use App\Models\SmsSetting;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Modules\Notification\Services\SmsService;
use Modules\Reservation\Models\Reservation;

uses(WithoutMiddleware::class);

beforeEach(function () {
    foreach (['neshan_location_cities', 'neshan_locations', 'reservations', 'users', 'sms_settings'] as $table) {
        Schema::dropIfExists($table);
    }

    Schema::create('sms_settings', function (Blueprint $table) {
        $table->id();
        $table->string('sender', 40)->nullable();
        $table->string('reservation_admin_recipient', 40)->nullable();
        $table->string('reservation_admin_pattern', 80)->nullable();
        $table->string('reservation_passenger_pattern', 80)->nullable();
        $table->boolean('require_phone_before_route_calculation')->default(false);
        $table->boolean('send_sms_after_early_phone_capture')->default(false);
        $table->timestamps();
    });

    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->uuid('uuid')->nullable();
        $table->string('username')->nullable();
        $table->string('mobile')->nullable();
        $table->string('first_name')->nullable();
        $table->string('last_name')->nullable();
        $table->string('password')->nullable();
        $table->timestamps();
    });

    Schema::create('reservations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('car_id')->nullable();
        $table->unsignedBigInteger('car_category_id')->nullable();
        $table->unsignedBigInteger('user_id')->nullable();
        $table->dateTime('date')->nullable();
        $table->string('phone')->nullable();
        $table->decimal('distance_km', 10, 2)->default(0);
        $table->decimal('total_price', 20, 2)->default(0);
        $table->string('status')->default(Reservation::STATUS_PENDING);
        $table->string('origin_address')->nullable();
        $table->string('destination_address')->nullable();
        $table->string('origin')->nullable();
        $table->string('destination')->nullable();
        $table->string('time', 15)->nullable();
        $table->string('second_phone')->nullable();
        $table->text('description')->nullable();
        $table->unsignedSmallInteger('passengers_count')->default(1);
        $table->boolean('needs_invoice')->default(false);
        $table->boolean('is_negotiable')->default(false);
        $table->timestamps();
    });

    Schema::create('neshan_locations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->decimal('latitude', 10, 7)->nullable();
        $table->decimal('longitude', 10, 7)->nullable();
        $table->string('address_text')->nullable();
        $table->string('type', 40)->nullable();
        $table->boolean('is_primary')->default(false);
        $table->timestamps();
    });

    Schema::create('neshan_location_cities', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('neshan_location_id')->nullable();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->string('city_name')->nullable();
        $table->decimal('distance_km', 20, 2)->default(0);
        $table->timestamps();
    });

    Http::fake(function ($request) {
        $url = (string) $request->url();

        if (str_contains($url, '/direction/')) {
            return Http::response([
                'routes' => [[
                    'legs' => [[
                        'distance' => ['value' => 125000],
                        'duration' => ['value' => 7200],
                    ]],
                    'overview_polyline' => ['points' => '??'],
                ]],
            ], 200);
        }

        return Http::response([
            'status' => 'OK',
            'formatted_address' => 'تهران، آزادی',
            'city' => 'تهران',
            'state' => 'تهران',
        ], 200);
    });
});

afterEach(function () {
    foreach (['neshan_location_cities', 'neshan_locations', 'reservations', 'users', 'sms_settings'] as $table) {
        Schema::dropIfExists($table);
    }
});

it('calculates routes without phone when early phone capture is disabled', function () {
    SmsSetting::query()->create([
        'reservation_admin_recipient' => '09120983462',
        'require_phone_before_route_calculation' => false,
        'send_sms_after_early_phone_capture' => false,
    ]);

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->never())->method('send');
    app()->instance(SmsService::class, $smsService);

    $this->postJson('/calculate-multiple-distances', distanceControllerEarlyPhoneRoutePayload())
        ->assertOk()
        ->assertJsonPath('success', true)
        ->assertJsonPath('reservation_created', true);

    expect(Reservation::query()->first()?->phone)->toBeNull();
});

it('requires phone but skips early sms when capture is enabled and early sms is disabled', function () {
    SmsSetting::query()->create([
        'reservation_admin_recipient' => '09120983462',
        'require_phone_before_route_calculation' => true,
        'send_sms_after_early_phone_capture' => false,
    ]);

    $this->postJson('/calculate-multiple-distances', distanceControllerEarlyPhoneRoutePayload())
        ->assertUnprocessable()
        ->assertJsonValidationErrors('phone');

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->never())->method('send');
    app()->instance(SmsService::class, $smsService);

    $this->postJson('/calculate-multiple-distances', distanceControllerEarlyPhoneRoutePayload('09123456789'))
        ->assertOk()
        ->assertJsonPath('success', true);

    expect(Reservation::query()->latest('id')->first()?->phone)->toBe('09123456789');
});

it('sends early sms when capture and early sms are both enabled', function () {
    SmsSetting::query()->create([
        'reservation_admin_recipient' => '09120983462',
        'require_phone_before_route_calculation' => true,
        'send_sms_after_early_phone_capture' => true,
    ]);

    $smsService = $this->createMock(SmsService::class);
    $smsService->expects($this->once())
        ->method('send')
        ->with(
            '09120983462',
            $this->callback(fn (string $message) => str_contains($message, '09123456789')
                && str_contains($message, 'کد رزرو اولیه'))
        )
        ->willReturn(true);
    app()->instance(SmsService::class, $smsService);

    $this->postJson('/calculate-multiple-distances', distanceControllerEarlyPhoneRoutePayload('09123456789'))
        ->assertOk()
        ->assertJsonPath('success', true);
});

function distanceControllerEarlyPhoneRoutePayload(?string $phone = null): array
{
    $payload = [
        'routes' => [[
            'origin_lat' => 35.7,
            'origin_lng' => 51.4,
            'destination_lat' => 32.65,
            'destination_lng' => 51.67,
            'origin_index' => 0,
            'destination_index' => 0,
        ]],
    ];

    if ($phone !== null) {
        $payload['phone'] = $phone;
    }

    return $payload;
}
