<?php

use App\Services\SeoHealthCrawler;
use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\Http;

beforeEach(function () {
    config()->set('app.url', 'http://localhost');
    config()->set('cache.default', 'array');
});

afterEach(function () {
    app()->forgetInstance('http');
    Facade::clearResolvedInstance('http');
});

it('reports seo health issues from a manual crawl', function () {
    Http::fake([
        'http://localhost/sitemap.xml' => Http::response(
            '<urlset><url><loc>http://localhost/</loc></url><url><loc>http://localhost/about</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'http://localhost/' => Http::response(
            '<html><head><title>Short</title><meta name="description" content=""><script type="application/ld+json">{"name":"bad"}</script></head><body><h1>Home</h1><img src="/big.jpg"><a href="/about">About</a><a href="/missing">Missing</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'http://localhost/about' => Http::response(
            '<html><head><title>About page title for vip taxi iran</title><meta name="description" content="This page has a useful and descriptive meta description for testing the crawler."></head><body><h1>About</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'http://localhost/missing' => Http::response('missing', 404, ['Content-Type' => 'text/html']),
        'http://localhost/big.jpg' => Http::response('', 200, ['Content-Length' => '600000']),
    ]);

    $result = app(SeoHealthCrawler::class)->crawl(10);
    $messages = collect($result['issues'])->pluck('message')->all();

    expect($result['scanned_urls'])->toBeGreaterThan(0)
        ->and($messages)->toContain('طول title مناسب نیست.')
        ->and($messages)->toContain('صفحه meta description ندارد.')
        ->and($messages)->toContain('schema ناقص است و @type ندارد.')
        ->and($messages)->toContain('تصویر بدون ALT پیدا شد.')
        ->and($messages)->toContain('حجم تصویر بالا است.');
});

it('normalizes internal http urls to the configured canonical scheme', function () {
    config()->set('app.url', 'https://viptaxiiran.test');

    Http::fake([
        'https://viptaxiiran.test/sitemap.xml' => Http::response(
            '<urlset><url><loc>https://viptaxiiran.test/driving-job-market</loc></url><url><loc>http://viptaxiiran.test/driving-job-market</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'https://viptaxiiran.test/' => Http::response(
            '<html><head><title>Home page title for vip taxi iran</title><meta name="description" content="This home page has a useful and descriptive meta description for testing."></head><body><h1>Home</h1><a href="http://viptaxiiran.test/driving-job-market">Market</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'https://viptaxiiran.test/driving-job-market' => Http::response(
            '<html><head><title>بازار کار شغل رانندگی</title><meta name="description" content="این صفحه درباره بازار کار شغل رانندگی و شرایط فعالیت رانندگان توضیح می‌دهد."></head><body><h1>بازار کار شغل رانندگی</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
    ]);

    $result = app(SeoHealthCrawler::class)->crawl(10);
    $issues = collect($result['issues']);

    expect($result['scanned_urls'])->toBe(2)
        ->and($issues->where('type', 'title')->where('detail', 'بازار کار شغل رانندگی')->count())->toBe(0)
        ->and($issues->where('type', 'description')->where('detail', 'این صفحه درباره بازار کار شغل رانندگی و شرایط فعالیت رانندگان توضیح می‌دهد.')->count())->toBe(0)
        ->and($issues->pluck('url')->contains('http://viptaxiiran.test/driving-job-market'))->toBeFalse();
});

it('reads canonical href values when checking canonical tags', function () {
    config()->set('app.url', 'https://viptaxiiran.test');

    Http::fake([
        'https://viptaxiiran.test/sitemap.xml' => Http::response(
            '<urlset><url><loc>https://viptaxiiran.test/page</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'https://viptaxiiran.test/' => Http::response(
            '<html><head><title>Home page title for vip taxi iran</title><meta name="description" content="This home page has a useful and descriptive meta description for testing."></head><body><h1>Home</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'https://viptaxiiran.test/page' => Http::response(
            '<html><head><title>Technical examination page title</title><meta name="description" content="This page has a useful and descriptive meta description for canonical testing."><link rel="canonical" href="https://viptaxiiran.test/page"></head><body><h1>Page</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
    ]);

    $result = app(SeoHealthCrawler::class)->crawl(10);
    $canonicalIssues = collect($result['issues'])->where('type', 'canonical')->where('url', 'https://viptaxiiran.test/page');

    expect($canonicalIssues->count())->toBe(0);
});

it('reports sitemap orphan pages even when they are not linked internally', function () {
    Http::fake([
        'http://localhost/sitemap.xml' => Http::response(
            '<urlset><url><loc>http://localhost/</loc></url><url><loc>http://localhost/orphan</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'http://localhost/' => Http::response(
            '<html><head><title>Home page title for vip taxi iran</title><meta name="description" content="This home page has a useful and descriptive meta description for testing."></head><body><h1>Home</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'http://localhost/orphan' => Http::response(
            '<html><head><title>Orphan page title for vip taxi iran</title><meta name="description" content="This orphan page has a useful and descriptive meta description for testing."></head><body><h1>Orphan</h1><a href="/">Home</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
    ]);

    $issues = collect(app(SeoHealthCrawler::class)->crawl(10)['issues']);

    expect($issues->where('type', 'orphan_page')->where('url', 'http://localhost/orphan')->count())->toBe(1);
});

it('reports pages without outgoing internal links', function () {
    Http::fake([
        'http://localhost/sitemap.xml' => Http::response(
            '<urlset><url><loc>http://localhost/</loc></url><url><loc>http://localhost/leaf</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'http://localhost/' => Http::response(
            '<html><head><title>Home page title for vip taxi iran</title><meta name="description" content="This home page has a useful and descriptive meta description for testing."></head><body><h1>Home</h1><a href="/leaf">Leaf</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'http://localhost/leaf' => Http::response(
            '<html><head><title>Leaf page title for vip taxi iran</title><meta name="description" content="This leaf page has a useful and descriptive meta description for testing."></head><body><h1>Leaf</h1></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
    ]);

    $issues = collect(app(SeoHealthCrawler::class)->crawl(10)['issues']);

    expect($issues->where('type', 'outgoing_internal_links')->where('url', 'http://localhost/leaf')->count())->toBe(1);
});

it('reports internal links that point to redirected urls', function () {
    Http::fake([
        'http://localhost/sitemap.xml' => Http::response(
            '<urlset><url><loc>http://localhost/</loc></url><url><loc>http://localhost/new-page</loc></url></urlset>',
            200,
            ['Content-Type' => 'application/xml']
        ),
        'http://localhost/' => Http::response(
            '<html><head><title>Home page title for vip taxi iran</title><meta name="description" content="This home page has a useful and descriptive meta description for testing."></head><body><h1>Home</h1><a href="/old-page">Old</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
        'http://localhost/old-page' => Http::response('', 301, ['Location' => 'http://localhost/new-page']),
        'http://localhost/new-page' => Http::response(
            '<html><head><title>New page title for vip taxi iran</title><meta name="description" content="This new page has a useful and descriptive meta description for testing."></head><body><h1>New</h1><a href="/">Home</a></body></html>',
            200,
            ['Content-Type' => 'text/html']
        ),
    ]);

    $issues = collect(app(SeoHealthCrawler::class)->crawl(10)['issues']);
    $redirected = $issues->where('type', 'redirected_link')->where('url', 'http://localhost/old-page')->first();

    expect($redirected)->not->toBeNull()
        ->and($redirected['detail'])->toContain('http://localhost/new-page')
        ->and($redirected['detail'])->toContain('http://localhost/');
});
