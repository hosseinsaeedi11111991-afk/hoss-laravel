<?php

use App\Services\HomeFaqService;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Modules\Faq\Models\Faq;
use Modules\Faq\Models\FaqContent;

beforeEach(function () {
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');
});

it('returns an empty collection when faq tables are missing', function () {
    expect(app(HomeFaqService::class)->items())->toBeEmpty();
});

it('returns active homepage faqs and builds faq schema', function () {
    Schema::create('faq', function (Blueprint $table) {
        $table->id();
        $table->string('subject');
        $table->string('title')->nullable();
        $table->text('description')->nullable();
        $table->string('status')->default(Faq::STATUS_ACTIVE);
        $table->timestamps();
    });

    Schema::create('faq_content', function (Blueprint $table) {
        $table->id();
        $table->foreignId('faq_id');
        $table->string('question');
        $table->text('answer');
        $table->integer('sort_order')->default(1);
        $table->string('status')->default(FaqContent::STATUS_ACTIVE);
        $table->timestamps();
    });

    $activeFaq = Faq::create([
        'subject' => 'Homepage',
        'title' => 'Homepage FAQ',
        'description' => null,
        'status' => Faq::STATUS_ACTIVE,
    ]);

    $inactiveFaq = Faq::create([
        'subject' => 'Hidden',
        'title' => 'Hidden FAQ',
        'description' => null,
        'status' => Faq::STATUS_INACTIVE,
    ]);

    FaqContent::create([
        'faq_id' => $activeFaq->id,
        'question' => 'سوال فعال؟',
        'answer' => '<p>پاسخ فعال</p>',
        'sort_order' => 2,
        'status' => FaqContent::STATUS_ACTIVE,
    ]);

    FaqContent::create([
        'faq_id' => $inactiveFaq->id,
        'question' => 'سوال مخفی؟',
        'answer' => 'پاسخ مخفی',
        'sort_order' => 1,
        'status' => FaqContent::STATUS_ACTIVE,
    ]);

    $service = app(HomeFaqService::class);
    $items = $service->items();
    $schema = $service->schema($items);

    expect($items)->toHaveCount(1)
        ->and($items->first()['question'])->toBe('سوال فعال؟')
        ->and($items->first()['answer'])->toBe('پاسخ فعال')
        ->and($schema['@type'])->toBe('FAQPage')
        ->and($schema['mainEntity'][0]['name'])->toBe('سوال فعال؟')
        ->and($schema['mainEntity'][0]['acceptedAnswer']['text'])->toBe('پاسخ فعال');
});
