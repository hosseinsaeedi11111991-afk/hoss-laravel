<?php

use App\Models\SmsSetting;
use App\Services\SmsSettingsService;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

beforeEach(function () {
    Schema::dropIfExists('sms_settings');
});

afterEach(function () {
    Schema::dropIfExists('sms_settings');
});

it('falls back to notification config before the sms settings table exists', function () {
    config()->set('notification.sms.farazsms.sender', '3000505');
    config()->set('notification.sms.reservation_admin_recipient', '09120983462');
    config()->set('notification.sms.reservation_admin_pattern', 'admin-pattern');
    config()->set('notification.sms.reservation_passenger_pattern', 'passenger-pattern');

    $settings = app(SmsSettingsService::class);

    expect($settings->tableExists())->toBeFalse()
        ->and($settings->sender())->toBe('3000505')
        ->and($settings->adminRecipient())->toBe('09120983462')
        ->and($settings->adminPattern())->toBe('admin-pattern')
        ->and($settings->passengerPattern())->toBe('passenger-pattern')
        ->and($settings->requirePhoneBeforeRouteCalculation())->toBeFalse()
        ->and($settings->sendSmsAfterEarlyPhoneCapture())->toBeFalse()
        ->and($settings->earlyPhoneCaptureColumnsExist())->toBeFalse();
});

it('uses dashboard sms settings when the table has values', function () {
    Schema::create('sms_settings', function (Blueprint $table) {
        $table->id();
        $table->string('sender', 40)->nullable();
        $table->string('reservation_admin_recipient', 40)->nullable();
        $table->string('reservation_admin_pattern', 80)->nullable();
        $table->string('reservation_passenger_pattern', 80)->nullable();
        $table->boolean('require_phone_before_route_calculation')->default(false);
        $table->boolean('send_sms_after_early_phone_capture')->default(false);
        $table->timestamps();
    });

    SmsSetting::query()->create([
        'sender' => '50001234',
        'reservation_admin_recipient' => '09120000000',
        'reservation_admin_pattern' => 'dashboard-admin',
        'reservation_passenger_pattern' => 'dashboard-passenger',
        'require_phone_before_route_calculation' => true,
        'send_sms_after_early_phone_capture' => true,
    ]);

    $settings = app(SmsSettingsService::class);

    expect($settings->tableExists())->toBeTrue()
        ->and($settings->sender())->toBe('50001234')
        ->and($settings->adminRecipient())->toBe('09120000000')
        ->and($settings->adminPattern())->toBe('dashboard-admin')
        ->and($settings->passengerPattern())->toBe('dashboard-passenger')
        ->and($settings->requirePhoneBeforeRouteCalculation())->toBeTrue()
        ->and($settings->sendSmsAfterEarlyPhoneCapture())->toBeTrue()
        ->and($settings->earlyPhoneCaptureColumnsExist())->toBeTrue();

});
