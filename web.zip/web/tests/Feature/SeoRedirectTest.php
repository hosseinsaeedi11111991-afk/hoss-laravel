<?php

use App\Models\SeoRedirect;
use App\Http\Middleware\SeoRedirectMiddleware;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

beforeEach(function () {
    config()->set('app.url', 'http://localhost');
    config()->set('cache.default', 'array');
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');

    Schema::create('seo_redirects', function (Blueprint $table) {
        $table->id();
        $table->string('source_path', 2048);
        $table->char('source_hash', 64)->unique();
        $table->string('target_url', 2048);
        $table->unsignedSmallInteger('status_code')->default(301);
        $table->boolean('is_active')->default(true)->index();
        $table->unsignedBigInteger('hits')->default(0);
        $table->timestamp('last_hit_at')->nullable();
        $table->text('notes')->nullable();
        $table->timestamps();
    });

    Cache::flush();
});

it('redirects exact active seo redirect paths', function () {
    SeoRedirect::create([
        'source_path' => '/old-taxi-page',
        'target_url' => '/new-taxi-page',
        'status_code' => 301,
        'is_active' => true,
    ]);

    $response = app(SeoRedirectMiddleware::class)->handle(
        Request::create('/old-taxi-page', 'GET'),
        fn () => response('next', 404)
    );

    expect($response->getStatusCode())->toBe(301)
        ->and($response->headers->get('Location'))->toContain('/new-taxi-page');

    expect(SeoRedirect::first()->hits)->toBe(1);
});

it('does not redirect inactive seo redirects', function () {
    SeoRedirect::create([
        'source_path' => '/inactive-page',
        'target_url' => '/target-page',
        'status_code' => 302,
        'is_active' => false,
    ]);

    $response = app(SeoRedirectMiddleware::class)->handle(
        Request::create('/inactive-page', 'GET'),
        fn () => response('next', 404)
    );

    expect($response->getStatusCode())->toBe(404);
});

it('skips direct self redirects', function () {
    SeoRedirect::create([
        'source_path' => '/same-page',
        'target_url' => '/same-page',
        'status_code' => 301,
        'is_active' => true,
    ]);

    $response = app(SeoRedirectMiddleware::class)->handle(
        Request::create('/same-page', 'GET'),
        fn () => response('next', 404)
    );

    expect($response->getStatusCode())->toBe(404);
});

it('returns gone for active 410 seo redirect rules', function () {
    SeoRedirect::create([
        'source_path' => '/removed-page',
        'target_url' => '',
        'status_code' => SeoRedirect::STATUS_410,
        'is_active' => true,
    ]);

    $response = app(SeoRedirectMiddleware::class)->handle(
        Request::create('/removed-page', 'GET'),
        fn () => response('next', 404)
    );

    expect($response->getStatusCode())->toBe(410)
        ->and($response->headers->has('Location'))->toBeFalse();

    expect(SeoRedirect::first()->hits)->toBe(1);
});
