<?php

use App\Http\Middleware\SecurityHeadersMiddleware;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

it('adds security headers to web responses', function () {
    $middleware = new SecurityHeadersMiddleware();
    $request = Request::create('/security-header-test');

    $response = $middleware->handle($request, fn () => new Response('ok'));

    expect($response->headers->get('X-Frame-Options'))->toBe('SAMEORIGIN')
        ->and($response->headers->get('X-Content-Type-Options'))->toBe('nosniff')
        ->and($response->headers->get('X-XSS-Protection'))->toBe('1; mode=block')
        ->and($response->headers->get('Referrer-Policy'))->toBe('strict-origin-when-cross-origin')
        ->and($response->headers->get('Content-Security-Policy'))
        ->toContain("default-src 'self'")
        ->and($response->headers->get('Permissions-Policy'))
        ->toContain('camera=()');
});

it('adds hsts to secure web responses', function () {
    $middleware = new SecurityHeadersMiddleware();
    $request = Request::create('https://viptaxiiran.test/secure-security-header-test');

    $response = $middleware->handle($request, fn () => new Response('ok'));

    expect($response->headers->get('Strict-Transport-Security'))
        ->toBe('max-age=31536000; includeSubDomains');
});
