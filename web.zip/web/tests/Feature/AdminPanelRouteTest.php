<?php

use Illuminate\Support\Facades\Route;
use Modules\Auth\Http\Controllers\Admin\AuthController;
use Modules\Reservation\Http\Controllers\Admin\ReservationController;

it('registers the admin auth and reservation routes used by the admin panel', function () {
    expect(Route::has('admin.auth.pass.login.form'))->toBeTrue()
        ->and(Route::has('admin.auth.pass.login.submit'))->toBeTrue()
        ->and(Route::has('admin.auth.logout'))->toBeTrue()
        ->and(Route::has('admin.reservations.index'))->toBeTrue()
        ->and(Route::has('admin.reservations.export'))->toBeTrue()
        ->and(Route::has('admin.reservations.bulkDestroy'))->toBeTrue()
        ->and(route('admin.auth.pass.login.form', [], false))->toBe('/admin-panel/auth/login/password')
        ->and(route('admin.auth.logout', [], false))->toBe('/admin-panel/auth/logout')
        ->and(route('admin.reservations.index', [], false))->toBe('/admin-panel/reservations');

    $loginRoute = Route::getRoutes()->getByName('admin.auth.pass.login.form');
    $logoutRoute = Route::getRoutes()->getByName('admin.auth.logout');
    $reservationsRoute = Route::getRoutes()->getByName('admin.reservations.index');

    expect($loginRoute)->not->toBeNull()
        ->and($loginRoute->uri())->toBe('admin-panel/auth/login/password')
        ->and($loginRoute->methods())->toContain('GET')
        ->and($loginRoute->getActionName())->toBe(AuthController::class . '@loginByPassForm')
        ->and($logoutRoute)->not->toBeNull()
        ->and($logoutRoute->uri())->toBe('admin-panel/auth/logout')
        ->and($logoutRoute->methods())->toContain('GET')
        ->and($logoutRoute->getActionName())->toBe(AuthController::class . '@logout')
        ->and($reservationsRoute)->not->toBeNull()
        ->and($reservationsRoute->uri())->toBe('admin-panel/reservations')
        ->and($reservationsRoute->methods())->toContain('GET')
        ->and($reservationsRoute->getActionName())->toBe(ReservationController::class . '@index');
});
