<?php

use App\Models\SeoIndexRule;
use App\Services\SeoIndexRuleService;
use App\Services\PublicSeoUrlCatalog;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Spatie\Sitemap\Tags\Url;

beforeEach(function () {
    config()->set('cache.default', 'array');
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.sqlite.database', ':memory:');

    DB::setDefaultConnection('sqlite');
    DB::purge('sqlite');
    DB::reconnect('sqlite');

    Schema::create('seo_index_rules', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('match_type', 32)->default('path');
        $table->string('pattern', 2048);
        $table->string('robots_directive', 64)->default('noindex, follow');
        $table->boolean('exclude_from_sitemap')->default(false);
        $table->boolean('is_active')->default(true);
        $table->unsignedInteger('priority')->default(100);
        $table->text('notes')->nullable();
        $table->timestamps();
    });

    Cache::flush();
});

it('does not add robots directives without active matching rules', function () {
    $service = app(SeoIndexRuleService::class);

    expect($service->robotsForRequest(Request::create('/articles')))->toBeNull();
});

it('returns noindex follow for matching query parameter rules', function () {
    SeoIndexRule::create([
        'name' => 'Search results',
        'match_type' => SeoIndexRule::MATCH_QUERY_KEY,
        'pattern' => 's',
        'robots_directive' => SeoIndexRule::ROBOTS_NOINDEX_FOLLOW,
        'is_active' => true,
        'priority' => 10,
    ]);

    $service = app(SeoIndexRuleService::class);

    expect($service->robotsForRequest(Request::create('/?s=taxi')))->toBe('noindex, follow')
        ->and($service->robotsForRequest(Request::create('/')))->toBeNull();
});

it('matches path wildcards and priority order', function () {
    SeoIndexRule::create([
        'name' => 'Broad filters',
        'match_type' => SeoIndexRule::MATCH_PATH,
        'pattern' => '/filter/*',
        'robots_directive' => SeoIndexRule::ROBOTS_NOINDEX_NOFOLLOW,
        'is_active' => true,
        'priority' => 20,
    ]);

    SeoIndexRule::create([
        'name' => 'Exact filter exception',
        'match_type' => SeoIndexRule::MATCH_PATH,
        'pattern' => '/filter/city',
        'robots_directive' => SeoIndexRule::ROBOTS_NOINDEX_FOLLOW,
        'is_active' => true,
        'priority' => 5,
    ]);

    $service = app(SeoIndexRuleService::class);

    expect($service->robotsForRequest(Request::create('/filter/city')))->toBe('noindex, follow')
        ->and($service->robotsForRequest(Request::create('/filter/price')))->toBe('noindex, nofollow');
});

it('can exclude matching sitemap entries only when explicitly requested', function () {
    SeoIndexRule::create([
        'name' => 'Reservation noindex',
        'match_type' => SeoIndexRule::MATCH_PATH,
        'pattern' => '/reservation*',
        'robots_directive' => SeoIndexRule::ROBOTS_NOINDEX_FOLLOW,
        'exclude_from_sitemap' => true,
        'is_active' => true,
        'priority' => 10,
    ]);

    $catalog = new PublicSeoUrlCatalog();
    $reflection = new ReflectionClass($catalog);
    $add = $reflection->getMethod('add');
    $add->setAccessible(true);
    $entries = collect();

    $add->invoke($catalog, $entries, 'https://viptaxiiran.com/reservation', 0.9, Url::CHANGE_FREQUENCY_WEEKLY);
    $add->invoke($catalog, $entries, 'https://viptaxiiran.com/articles', 0.9, Url::CHANGE_FREQUENCY_WEEKLY);

    expect($entries->keys()->all())->toBe(['https://viptaxiiran.com/articles']);
});
