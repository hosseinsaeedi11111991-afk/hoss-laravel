<?php

use Illuminate\Support\Facades\Route;

it('registers the admin sidebar routes for pricing discounts and neshan', function () {
    expect(Route::has('admin.pricing_rules.index'))->toBeTrue()
        ->and(Route::has('admin.city_pricings.index'))->toBeTrue()
        ->and(Route::has('admin.default_pricings.index'))->toBeTrue()
        ->and(Route::has('admin.discounts.index'))->toBeTrue()
        ->and(Route::has('admin.discounts.create'))->toBeTrue()
        ->and(Route::has('admin.discount-usages.index'))->toBeTrue()
        ->and(Route::has('admin.neshan-locations.index'))->toBeTrue()
        ->and(Route::has('admin.neshan-locations.city.index'))->toBeTrue()
        ->and(route('admin.pricing_rules.index', [], false))->toBe('/admin/pricing_rules')
        ->and(route('admin.city_pricings.index', [], false))->toBe('/admin/city_pricings')
        ->and(route('admin.default_pricings.index', [], false))->toBe('/admin/default_pricings')
        ->and(route('admin.discounts.index', [], false))->toBe('/admin-panel/discounts')
        ->and(route('admin.discount-usages.index', [], false))->toBe('/admin-panel/discount-usages')
        ->and(route('admin.neshan-locations.index', [], false))->toBe('/admin-panel/neshan-locations')
        ->and(route('admin.neshan-locations.city.index', [], false))->toBe('/admin-panel/neshan-location-cities');
});

it('registers the remaining admin sidebar accordion routes', function () {
    expect(Route::has('admin.menu.index'))->toBeTrue()
        ->and(Route::has('admin.menu.create'))->toBeTrue()
        ->and(Route::has('admin.menu_item.index'))->toBeTrue()
        ->and(Route::has('admin.faq.index'))->toBeTrue()
        ->and(Route::has('admin.faq.create'))->toBeTrue()
        ->and(Route::has('admin.faq_content.index'))->toBeTrue()
        ->and(Route::has('admin.page.index'))->toBeTrue()
        ->and(Route::has('admin.page.create'))->toBeTrue()
        ->and(Route::has('admin.role.index'))->toBeTrue()
        ->and(Route::has('admin.permission.index'))->toBeTrue()
        ->and(Route::has('admin.sms-settings.index'))->toBeTrue()
        ->and(Route::has('admin.sms-settings.update'))->toBeTrue()
        ->and(Route::has('admin.logs.index'))->toBeTrue()
        ->and(route('admin.menu.index', ['position' => 'header'], false))->toBe('/admin-panel/menu/header')
        ->and(route('admin.faq.index', [], false))->toBe('/admin-panel/faq')
        ->and(route('admin.page.index', [], false))->toBe('/admin-panel/page')
        ->and(route('admin.role.index', [], false))->toBe('/admin-panel/role')
        ->and(route('admin.permission.index', [], false))->toBe('/admin-panel/permission')
        ->and(route('admin.sms-settings.index', [], false))->toBe('/admin-panel/sms-settings')
        ->and(route('admin.sms-settings.update', [], false))->toBe('/admin-panel/sms-settings')
        ->and(route('admin.logs.index', [], false))->toBe('/admin-panel/logs');
});
