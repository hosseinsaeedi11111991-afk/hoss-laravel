<?php

use Nwidart\Modules\Facades\Module;
use Illuminate\Support\Facades\Route;
use Modules\Blog\Http\Controllers\site\BlogController;

it('boots the blog module and registers the public blog show route without changing article urls', function () {
    expect(Module::isEnabled('Blog'))->toBeTrue()
        ->and(Route::has('blog.show'))->toBeTrue()
        ->and(Route::has('admin.blog-post.index'))->toBeTrue()
        ->and(route('blog.show', 'sample-article', false))->toBe('/sample-article');

    $route = Route::getRoutes()->getByName('blog.show');

    expect($route)->not->toBeNull()
        ->and($route->getName())->toBe('blog.show')
        ->and($route->uri())->toBe('{slug}')
        ->and($route->methods())->toContain('GET')
        ->and($route->getActionName())->toBe(BlogController::class . '@show');
});
