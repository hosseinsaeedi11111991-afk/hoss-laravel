<?php

use App\Models\SmsSetting;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Modules\Reservation\Models\PopularRoute;
use Modules\Reservation\Models\Reservation;

uses(WithoutMiddleware::class);

beforeEach(function () {
    foreach (['neshan_location_cities', 'neshan_locations', 'reservations', 'popular_routes', 'users', 'sms_settings'] as $table) {
        Schema::dropIfExists($table);
    }

    Schema::create('sms_settings', function (Blueprint $table) {
        $table->id();
        $table->string('sender', 40)->nullable();
        $table->string('reservation_admin_recipient', 40)->nullable();
        $table->string('reservation_admin_pattern', 80)->nullable();
        $table->string('reservation_passenger_pattern', 80)->nullable();
        $table->boolean('require_phone_before_route_calculation')->default(false);
        $table->boolean('send_sms_after_early_phone_capture')->default(false);
        $table->timestamps();
    });

    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('mobile')->nullable();
        $table->timestamps();
    });

    Schema::create('popular_routes', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->string('origin_address');
        $table->string('destination_address');
        $table->decimal('origin_lat', 10, 8);
        $table->decimal('origin_lng', 10, 8);
        $table->decimal('destination_lat', 10, 8);
        $table->decimal('destination_lng', 10, 8);
        $table->string('image')->nullable();
        $table->unsignedInteger('sort_order')->default(0);
        $table->boolean('is_active')->default(true);
        $table->timestamps();
    });

    Schema::create('reservations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('car_id')->nullable();
        $table->unsignedBigInteger('car_category_id')->nullable();
        $table->unsignedBigInteger('user_id')->nullable();
        $table->dateTime('date')->nullable();
        $table->string('phone')->nullable();
        $table->decimal('distance_km', 10, 2)->default(0);
        $table->decimal('total_price', 20, 2)->default(0);
        $table->string('status')->default(Reservation::STATUS_PENDING);
        $table->string('origin_address')->nullable();
        $table->string('destination_address')->nullable();
        $table->string('origin')->nullable();
        $table->string('destination')->nullable();
        $table->string('time', 15)->nullable();
        $table->timestamps();
    });

    Schema::create('neshan_locations', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->decimal('latitude', 10, 7)->nullable();
        $table->decimal('longitude', 10, 7)->nullable();
        $table->string('address_text')->nullable();
        $table->string('type', 40)->nullable();
        $table->boolean('is_primary')->default(false);
        $table->timestamps();
    });

    Schema::create('neshan_location_cities', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('neshan_location_id')->nullable();
        $table->unsignedBigInteger('reservation_id')->nullable();
        $table->string('city_name')->nullable();
        $table->decimal('distance_km', 20, 2)->default(0);
        $table->timestamps();
    });

    Http::fake([
        'api.neshan.org/v4/direction/no-traffic*' => Http::response([
            'routes' => [[
                'legs' => [[
                    'distance' => ['value' => 125000],
                    'duration' => ['value' => 7200],
                ]],
            ]],
        ], 200),
        'api.neshan.org/v5/reverse*' => Http::response([
            'status' => 'OK',
            'formatted_address' => 'تهران، آزادی',
            'city' => 'تهران',
            'state' => 'تهران',
        ], 200),
    ]);
});

afterEach(function () {
    foreach (['neshan_location_cities', 'neshan_locations', 'reservations', 'popular_routes', 'users', 'sms_settings'] as $table) {
        Schema::dropIfExists($table);
    }
});

it('starts a popular route without phone when early capture is disabled', function () {
    SmsSetting::query()->create([
        'require_phone_before_route_calculation' => false,
        'send_sms_after_early_phone_capture' => false,
    ]);

    $popularRoute = popularRouteEarlyPhoneRoute();

    $this->post(route('site.popular-route.start', $popularRoute))
        ->assertRedirect();

    expect(Reservation::query()->first()?->phone)->toBeNull();
});

it('requires phone for popular routes when early capture is enabled', function () {
    SmsSetting::query()->create([
        'require_phone_before_route_calculation' => true,
        'send_sms_after_early_phone_capture' => false,
    ]);

    $popularRoute = popularRouteEarlyPhoneRoute();

    $this->postJson(route('site.popular-route.start', $popularRoute))
        ->assertUnprocessable()
        ->assertJsonValidationErrors('phone');
});

function popularRouteEarlyPhoneRoute(): PopularRoute
{
    return PopularRoute::query()->create([
        'title' => 'تهران به اصفهان',
        'origin_address' => 'تهران',
        'destination_address' => 'اصفهان',
        'origin_lat' => 35.70000000,
        'origin_lng' => 51.40000000,
        'destination_lat' => 32.65000000,
        'destination_lng' => 51.67000000,
        'is_active' => true,
    ]);
}
