# Minify Assets - راهنمای استفاده

این اسکریپت برای minify کردن فایل‌های CSS و JavaScript استفاده می‌شود.

## اجرای اسکریپت

```bash
php minify-assets.php
```

## فایل‌های Minified

بعد از اجرای اسکریپت، فایل‌های زیر ایجاد می‌شوند:

### CSS:
- `public/site/css/style.min.css` (از `style.css`)

### JavaScript:
- `public/site/js/select2.min.js` (از `select2.js`)
- `public/site/js/datepicker.min.js` (از `datepicker.js`)
- `public/site/js/jquery.magnific-popup.min.js` (از `jquery.magnific-popup.js`)

## تغییرات انجام شده

تمام فایل‌های Blade به‌روزرسانی شده‌اند تا از نسخه‌های minified استفاده کنند:

- `Modules/Shared/resources/views/layouts/site/head.blade.php`
- `Modules/Shared/resources/views/layouts/site/scripts.blade.php`
- `web/Modules/Shared/resources/views/layouts/site/head.blade.php`
- `web/Modules/Shared/resources/views/layouts/site/scripts.blade.php`
- `web/Modules/Shared/resources/views/layouts/site/auth/layout.blade.php`

## کاهش Unused CSS/JS

برای کاهش unused CSS و JavaScript:

1. **CSS**: استفاده از PurgeCSS یا تقسیم CSS به بخش‌های کوچکتر
2. **JavaScript**: استفاده از dynamic import برای لود کردن فقط در صورت نیاز

## نکات مهم

- فایل‌های minified باید بعد از هر تغییر در فایل‌های اصلی دوباره ایجاد شوند
- در production، بهتر است از build tools مثل Vite یا Webpack استفاده شود
- برای کاهش بیشتر، می‌توان از tree-shaking استفاده کرد

