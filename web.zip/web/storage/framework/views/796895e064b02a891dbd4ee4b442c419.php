<?php $__env->startSection('title', 'تنظیمات ایندکس سئو'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .seo-index-summary {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .75rem;
        }

        .seo-index-summary-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            padding: .85rem;
            background: #fff;
        }

        .seo-index-summary-item span {
            display: block;
            color: #7f8ea3;
            font-size: .75rem;
            margin-bottom: .35rem;
        }

        .seo-index-summary-item strong {
            color: #4f6074;
            font-size: 1.1rem;
        }

        .seo-index-table {
            table-layout: fixed;
            font-size: .84rem;
        }

        .seo-index-table th,
        .seo-index-table td {
            vertical-align: middle;
            white-space: normal;
            overflow-wrap: anywhere;
        }

        .seo-index-table .col-actions { width: 120px; }
        .seo-index-table .col-status { width: 92px; }
        .seo-index-table .col-priority { width: 84px; }

        @media (max-width: 991px) {
            .seo-index-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            <span>سئو/</span>
            تنظیمات ایندکس
        </h4>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($migrationMissing): ?>
        <div class="alert alert-warning">
            جدول تنظیمات ایندکس هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت noindex فعال می‌شود و سایت بدون خطا با رفتار قبلی ادامه می‌دهد.
        </div>
    <?php endif; ?>

    <div class="seo-index-summary mb-4">
        <div class="seo-index-summary-item"><span>کل قوانین</span><strong><?php echo e($summary['total']); ?></strong></div>
        <div class="seo-index-summary-item"><span>فعال</span><strong><?php echo e($summary['active']); ?></strong></div>
        <div class="seo-index-summary-item"><span>noindex</span><strong><?php echo e($summary['noindex']); ?></strong></div>
        <div class="seo-index-summary-item"><span>حذف از sitemap</span><strong><?php echo e($summary['sitemap_excluded']); ?></strong></div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن قانون جدید</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.seo.index-rules.store')); ?>" class="row g-3">
                <?php echo csrf_field(); ?>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نام</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="مثلاً فیلتر جستجو" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">نوع تطبیق</label>
                    <select name="match_type" class="form-select" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                        <?php $__currentLoopData = \App\Models\SeoIndexRule::matchTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('match_type', 'query_key') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['match_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">الگو</label>
                    <input type="text" name="pattern" class="form-control" value="<?php echo e(old('pattern')); ?>" dir="ltr" placeholder="s یا filter_* یا /search*" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                    <?php $__errorArgs = ['pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">Robots</label>
                    <select name="robots_directive" class="form-select" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                        <?php $__currentLoopData = \App\Models\SeoIndexRule::robotsDirectives(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('robots_directive', \App\Models\SeoIndexRule::ROBOTS_NOINDEX_FOLLOW) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['robots_directive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">اولویت</label>
                    <input type="number" name="priority" class="form-control" value="<?php echo e(old('priority', 100)); ?>" min="1" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                    <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">یادداشت</label>
                    <input type="text" name="notes" class="form-control" value="<?php echo e(old('notes')); ?>" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-4 col-md-6 d-flex align-items-end gap-4">
                    <div class="form-check">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" id="new-rule-active" <?php if(old('is_active', true)): echo 'checked'; endif; ?> <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label" for="new-rule-active">فعال</label>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="exclude_from_sitemap" value="1" class="form-check-input" id="new-rule-sitemap" <?php if(old('exclude_from_sitemap')): echo 'checked'; endif; ?> <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label" for="new-rule-sitemap">حذف از sitemap</label>
                    </div>
                </div>
                <div class="col-lg-4 d-flex align-items-end justify-content-lg-end">
                    <button class="btn btn-success" type="submit" <?php if($migrationMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-plus"></i>
                        ثبت قانون
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-striped seo-index-table mb-0">
                <thead>
                <tr>
                    <th>نام</th>
                    <th>نوع</th>
                    <th>الگو</th>
                    <th>Robots</th>
                    <th class="col-priority">اولویت</th>
                    <th class="col-status">وضعیت</th>
                    <th>یادداشت</th>
                    <th class="col-actions">عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <form id="rule-update-<?php echo e($rule->id); ?>" method="POST" action="<?php echo e(route('admin.seo.index-rules.update', $rule)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="text" name="name" class="form-control form-control-sm" value="<?php echo e($rule->name); ?>">
                            </form>
                        </td>
                        <td>
                            <select name="match_type" form="rule-update-<?php echo e($rule->id); ?>" class="form-select form-select-sm">
                                <?php $__currentLoopData = \App\Models\SeoIndexRule::matchTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php if($rule->match_type === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td><input type="text" name="pattern" form="rule-update-<?php echo e($rule->id); ?>" class="form-control form-control-sm" value="<?php echo e($rule->pattern); ?>" dir="ltr"></td>
                        <td>
                            <select name="robots_directive" form="rule-update-<?php echo e($rule->id); ?>" class="form-select form-select-sm">
                                <?php $__currentLoopData = \App\Models\SeoIndexRule::robotsDirectives(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php if($rule->robots_directive === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($rule->exclude_from_sitemap): ?>
                                <span class="badge bg-label-warning mt-1">حذف از sitemap</span>
                            <?php endif; ?>
                        </td>
                        <td><input type="number" name="priority" form="rule-update-<?php echo e($rule->id); ?>" class="form-control form-control-sm" value="<?php echo e($rule->priority); ?>" min="1"></td>
                        <td>
                            <div class="form-check mb-2">
                                <input type="checkbox" name="is_active" form="rule-update-<?php echo e($rule->id); ?>" value="1" class="form-check-input" id="rule-active-<?php echo e($rule->id); ?>" <?php if($rule->is_active): echo 'checked'; endif; ?>>
                                <label class="form-check-label" for="rule-active-<?php echo e($rule->id); ?>">فعال</label>
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="exclude_from_sitemap" form="rule-update-<?php echo e($rule->id); ?>" value="1" class="form-check-input" id="rule-sitemap-<?php echo e($rule->id); ?>" <?php if($rule->exclude_from_sitemap): echo 'checked'; endif; ?>>
                                <label class="form-check-label" for="rule-sitemap-<?php echo e($rule->id); ?>">sitemap</label>
                            </div>
                        </td>
                        <td><input type="text" name="notes" form="rule-update-<?php echo e($rule->id); ?>" class="form-control form-control-sm" value="<?php echo e($rule->notes); ?>"></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-warning" title="ذخیره" form="rule-update-<?php echo e($rule->id); ?>">
                                    <i class="bx bx-save"></i>
                                </button>
                                <form method="POST" action="<?php echo e(route('admin.seo.index-rules.destroy', $rule)); ?>" class="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" title="حذف">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-5">هنوز قانونی برای noindex یا مدیریت crawl ثبت نشده است.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($rules->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/seo_index_rules/index.blade.php ENDPATH**/ ?>