<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-tag.index')); ?>">برچسب‌ها/</a></span>
        ویرایش برچسب
    </h4>

    <form action="<?php echo e(route('admin.blog-tag.update', $blogTag)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">عنوان برچسب <span class="text-danger">*</span></label>
            <input type="text" name="tag_title" class="form-control" value="<?php echo e(old('tag_title', $blogTag->tag_title)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ فارسی <span class="text-danger">*</span></label>
            <input type="text" name="fa_slug" class="form-control" value="<?php echo e(old('fa_slug', $blogTag->fa_slug)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ انگلیسی <span class="text-danger">*</span></label>
            <input type="text" name="en_slug" class="form-control" value="<?php echo e(old('en_slug', $blogTag->en_slug)); ?>" required>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_tag/edit.blade.php ENDPATH**/ ?>