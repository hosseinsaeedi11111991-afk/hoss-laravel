<?php use Modules\Faq\Models\Faq; ?>


<?php $__env->startSection('title', 'پرسش و پاسخ ها'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.faq.index')); ?>">لیست سوالات متداول/</a></span>
    <span>پرسش و پاسخ ها</span>
</h4>

<a href="<?php echo e(route('admin.faq_content.create', $faq)); ?>" type="button" class="btn rounded-pill me-2 btn-success">
    افزودن پرسش و پاسخ جدید
</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>ترتیب نمایش</th>
                <th>سوال</th>
                <th>پاسخ</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($row->sort_order); ?></td>
                <td><?php echo e($row->question); ?></td>
                <td><?php echo e($row->answer); ?></td>
                <td>
                    <?php
                    switch ($row->status) {
                        case Faq::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case Faq::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case Faq::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    ?>
                </td>
                <td><?php echo e(Verta::instance($row->updated_at)->format('Y/m/d')); ?></td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('admin.faq_content.edit', [$faq, $row->id])); ?>"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="<?php echo e(route('admin.faq_content.toggle_status', [$faq, $row->id])); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="<?php echo e(route('admin.faq_content.destroy', [$faq, $row->id])); ?>"
                            class="delete-form d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-4">
    <?php echo e($contents->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/admin/faq_content/index.blade.php ENDPATH**/ ?>