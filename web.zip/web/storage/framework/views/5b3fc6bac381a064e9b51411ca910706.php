<?php if (isset($component)) { $__componentOriginala1827df990eb2773641a4d7f685e8616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1827df990eb2773641a4d7f685e8616 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'auth::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('auth.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1827df990eb2773641a4d7f685e8616)): ?>
<?php $attributes = $__attributesOriginala1827df990eb2773641a4d7f685e8616; ?>
<?php unset($__attributesOriginala1827df990eb2773641a4d7f685e8616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1827df990eb2773641a4d7f685e8616)): ?>
<?php $component = $__componentOriginala1827df990eb2773641a4d7f685e8616; ?>
<?php unset($__componentOriginala1827df990eb2773641a4d7f685e8616); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Auth/resources/views/index.blade.php ENDPATH**/ ?>