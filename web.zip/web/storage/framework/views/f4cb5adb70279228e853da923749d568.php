<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">دسته‌بندی ماشین‌ها/</a></span>
        ویرایش دسته‌بندی
    </h4>

    <form action="<?php echo e(route('admin.cars.categories.update', $car_category)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">عنوان <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control"
                   value="<?php echo e(old('title', $car_category->title)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">نوع <span class="text-danger">*</span></label>
            <select name="type" class="form-select" required>
                <?php $__currentLoopData = \Modules\Cars\Models\CarCategory::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('type', $car_category->type) == $key ? 'selected' : ''); ?>>
                        <?php echo e($label); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">لوگو</label>
            <input type="file" name="logo" class="form-control">
            <?php if($car_category->logo): ?>
                <img src="<?php echo e(Storage::url($car_category->logo)); ?>" width="80" class="mt-2 rounded">
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">توضیحات</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $car_category->description)); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">نوع قیمت <span class="text-danger">*</span></label>
            <select name="price_type" id="price_type" class="form-select" required>
                <?php $__currentLoopData = \Modules\Cars\Models\CarCategory::PRICE_TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('price_type', $car_category->price_type) == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3" id="fixed_price_field" style="display: none;">
            <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
            <input type="number" name="fixed_price" class="form-control" value="<?php echo e(old('fixed_price', $car_category->fixed_price)); ?>" step="0.01" min="0">
        </div>

        <div class="mb-3" id="price_per_km_field" style="display: none;">
            <label class="form-label">قیمت به ازای کیلومتر (تومان) <span class="text-danger">*</span></label>
            <input type="number" name="price_per_km" class="form-control" value="<?php echo e(old('price_per_km', $car_category->price_per_km)); ?>" step="0.01" min="0">
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>

    <script>
        document.getElementById('price_type').addEventListener('change', function() {
            const priceType = this.value;
            const fixedPriceField = document.getElementById('fixed_price_field');
            const pricePerKmField = document.getElementById('price_per_km_field');

            // مخفی کردن همه فیلدها
            fixedPriceField.style.display = 'none';
            pricePerKmField.style.display = 'none';

            // نمایش فیلد مربوطه
            if (priceType === 'fixed') {
                fixedPriceField.style.display = 'block';
            } else if (priceType === 'per_km') {
                pricePerKmField.style.display = 'block';
            }
        });

        // اجرای اولیه برای نمایش فیلد در صورت وجود مقدار قدیمی
        document.addEventListener('DOMContentLoaded', function() {
            const priceType = document.getElementById('price_type').value;
            if (priceType) {
                document.getElementById('price_type').dispatchEvent(new Event('change'));
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/car_categories/edit.blade.php ENDPATH**/ ?>