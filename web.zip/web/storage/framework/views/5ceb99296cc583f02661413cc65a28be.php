<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">آپشن‌ها/</a></span>
        لیست آپشن‌ها
    </h4>

    <a href="<?php echo e(route('admin.options.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن آپشن</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>نام</th>
                <th>دسته‌بندی ماشین</th>
                <th>نوع</th>
                <th>نوع محاسبه</th>
                <th>قیمت ثابت</th>
                <th>قیمت هر کیلومتر</th>
                <th>درصد قیمت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($option->name); ?></td>
                    <td>
                        <?php if($option->carCategory): ?>
                            <span class="badge bg-secondary"><?php echo e($option->carCategory->title); ?></span>
                        <?php else: ?>
                            <span class="badge bg-info">برای همه ماشین‌ها</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($option->type=='text' ? 'متن' : 'چک‌باکس'); ?>

                    </td>
                    <td>
                        <?php if($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_FIXED): ?>
                            قیمت ثابت
                        <?php elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PER_KM): ?>
                            به‌ازای کیلومتر
                        <?php elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PERCENTAGE): ?>
                            محاسبه درصدی
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($option->fixed_price ? number_format($option->fixed_price) : '-'); ?> تومان</td>
                    <td><?php echo e($option->per_km_price ? number_format($option->per_km_price) : '-'); ?> تومان</td>
                    <td><?php echo e($option->percentage_price ? number_format($option->percentage_price, 2) . '%' : '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.options.show', $option)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.options.edit', $option)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.options.destroy', $option)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($options->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/options/index.blade.php ENDPATH**/ ?>