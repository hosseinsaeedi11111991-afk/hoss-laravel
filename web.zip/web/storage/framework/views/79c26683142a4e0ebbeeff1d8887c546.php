<?php if (isset($component)) { $__componentOriginal184bc28f91dee3a96fe66461fa499d74 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal184bc28f91dee3a96fe66461fa499d74 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'text::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('text.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal184bc28f91dee3a96fe66461fa499d74)): ?>
<?php $attributes = $__attributesOriginal184bc28f91dee3a96fe66461fa499d74; ?>
<?php unset($__attributesOriginal184bc28f91dee3a96fe66461fa499d74); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal184bc28f91dee3a96fe66461fa499d74)): ?>
<?php $component = $__componentOriginal184bc28f91dee3a96fe66461fa499d74; ?>
<?php unset($__componentOriginal184bc28f91dee3a96fe66461fa499d74); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Text/resources/views/index.blade.php ENDPATH**/ ?>