<?php $__env->startSection('title', 'ویرایش FAQ'); ?>

<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.faq.index')); ?>">لیست سوالات متداول/</a></span>
        <span>ویرایش FAQ</span>
    </h4>

    <form method="POST" enctype="multipart/form-data"
        action="<?php echo e(route('admin.faq.update', ['faq' => $faq])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="subject">
                    <span>موضوع FAQ </span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="subject" type="text" name="subject" class="form-control"
                        value="<?php echo e(old('subject', $faq ? $faq->subject : '')); ?>">
                </div>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="title">
                    <span>عنوان صفحه</span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="title" type="text" name="title" class="form-control" placeholder="عنوان صفحه"
                        value="<?php echo e(old('title', $faq ? $faq->title : '')); ?>">
                </div>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4">
                <label class="form-label" for="description">
                    <span>توضیحات</span>
                </label>
                <textarea id="description" class="form-control" rows="8" placeholder="توضیحات" name="description">
                    <?php echo e(old('description', $faq ? $faq->description : '')); ?>

                </textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/admin/faq/edit.blade.php ENDPATH**/ ?>