<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-post-category.index')); ?>">دسته‌بندی مقالات/</a></span>
        ویرایش دسته‌بندی
    </h4>

    <form action="<?php echo e(route('admin.blog-post-category.update', $blogPostCategory)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">نام دسته‌بندی <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $blogPostCategory->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ فارسی <span class="text-danger">*</span></label>
            <input type="text" name="fa_slug" class="form-control" value="<?php echo e(old('fa_slug', $blogPostCategory->fa_slug)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ انگلیسی <span class="text-danger">*</span></label>
            <input type="text" name="en_slug" class="form-control" value="<?php echo e(old('en_slug', $blogPostCategory->en_slug)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">توضیحات</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $blogPostCategory->description)); ?></textarea>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_post_category/edit.blade.php ENDPATH**/ ?>