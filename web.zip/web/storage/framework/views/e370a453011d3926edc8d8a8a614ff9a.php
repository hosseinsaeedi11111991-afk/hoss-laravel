<?php if (isset($component)) { $__componentOriginal0bfb5324b36f96fe67c8e8b637d9a6fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bfb5324b36f96fe67c8e8b637d9a6fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'blog::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('blog.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bfb5324b36f96fe67c8e8b637d9a6fa)): ?>
<?php $attributes = $__attributesOriginal0bfb5324b36f96fe67c8e8b637d9a6fa; ?>
<?php unset($__attributesOriginal0bfb5324b36f96fe67c8e8b637d9a6fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bfb5324b36f96fe67c8e8b637d9a6fa)): ?>
<?php $component = $__componentOriginal0bfb5324b36f96fe67c8e8b637d9a6fa; ?>
<?php unset($__componentOriginal0bfb5324b36f96fe67c8e8b637d9a6fa); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/index.blade.php ENDPATH**/ ?>