<?php if (isset($component)) { $__componentOriginal2a67163f9eefe4caee637891e5d11e08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a67163f9eefe4caee637891e5d11e08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notification::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notification::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('notification.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a67163f9eefe4caee637891e5d11e08)): ?>
<?php $attributes = $__attributesOriginal2a67163f9eefe4caee637891e5d11e08; ?>
<?php unset($__attributesOriginal2a67163f9eefe4caee637891e5d11e08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a67163f9eefe4caee637891e5d11e08)): ?>
<?php $component = $__componentOriginal2a67163f9eefe4caee637891e5d11e08; ?>
<?php unset($__componentOriginal2a67163f9eefe4caee637891e5d11e08); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Notification/resources/views/index.blade.php ENDPATH**/ ?>