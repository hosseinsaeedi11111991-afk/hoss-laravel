<?php $__env->startSection('title', 'ویرایش پرسش و پاسخ'); ?>

<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.faq_content.index', $faq)); ?>">پرسش و پاسخ ها/</a></span>
        <span>ویرایش پرسش و پاسخ</span>
    </h4>

    <?php echo $__env->make('faq::admin.faq_content.partials.form', [
        'faq' => $faq,
        'faq_content' => $faq_content,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/admin/faq_content/edit.blade.php ENDPATH**/ ?>