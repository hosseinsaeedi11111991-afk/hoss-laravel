<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.neshan-locations.city.index')); ?>">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        لیست شهرها
    </h4>

    <a href="<?php echo e(route('admin.neshan-locations.city.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن شهر</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>لوکیشن نشان</th>
                <th>رزرو</th>
                <th>نام شهر</th>
                <th>کیلومتر</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cities->firstItem() + $key); ?></td>
                    <td><?php echo e($city->neshan_location_id); ?></td>
                    <td><?php echo e($city->reservation_id ?? '—'); ?></td>
                    <td><?php echo e($city->city_name); ?></td>
                    <td><?php echo e(number_format($city->distance_km, 2)); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.neshan-locations.city.show', $city)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.neshan-locations.city.edit', $city)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.neshan-locations.city.destroy', $city)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($cities->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Neshan/resources/views/admin/neshan_location_cities/index.blade.php ENDPATH**/ ?>