<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog_save.index')); ?>">ذخیره‌ها/</a></span>
        لیست ذخیره‌ها
    </h4>

    <a href="<?php echo e(route('admin.blog_save.create')); ?>" class="btn rounded-pill btn-success mb-3">ایجاد ذخیره جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>کاربر</th>
                <th>پست</th>
                <th>تاریخ</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $blog_saves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog_save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($blog_save->user->name ?? '-'); ?></td>
                    <td><?php echo e($blog_save->post->title ?? '-'); ?></td>
                    <td><?php echo e(verta($blog_save->created_at)->format('Y/m/d H:i')); ?></td>
                    <td>
                        <div class="btn-group flex-wrap gap-2">
                            <a href="<?php echo e(route('admin.blog_save.show', $blog_save)); ?>" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="<?php echo e(route('admin.blog_save.edit', $blog_save)); ?>" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.blog_save.destroy', $blog_save)); ?>" class="delete-form d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($blog_saves->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_save/index.blade.php ENDPATH**/ ?>