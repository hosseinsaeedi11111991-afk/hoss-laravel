<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-seo.index')); ?>">سئو/</a></span>
        مشاهده تنظیمات سئو
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات سئو</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>پست مرتبط:</strong> <?php echo e($blog_seo->post->title ?? '-'); ?></li>
                        <li class="list-group-item"><strong>عنوان:</strong> <?php echo e($blog_seo->title); ?></li>
                        <li class="list-group-item"><strong>توضیحات:</strong> <?php echo e($blog_seo->description); ?></li>
                        <li class="list-group-item"><strong>کلمات کلیدی:</strong> <?php echo e($blog_seo->keywords ?? '-'); ?></li>
                        <li class="list-group-item"><strong>نویسنده:</strong> <?php echo e($blog_seo->author_name ?? '-'); ?></li>
                        <li class="list-group-item"><strong>کلمه تمرکز:</strong> <?php echo e($blog_seo->focus_keyword ?? '-'); ?></li>
                        <li class="list-group-item"><strong>زمان مطالعه:</strong> <?php echo e($blog_seo->reading_time ?? '-'); ?></li>
                        <li class="list-group-item"><strong>Schema:</strong>
                            <pre class="mt-2"><?php echo e(json_encode($blog_seo->schema_markup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($blog_seo->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($blog_seo->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_seo/show.blade.php ENDPATH**/ ?>