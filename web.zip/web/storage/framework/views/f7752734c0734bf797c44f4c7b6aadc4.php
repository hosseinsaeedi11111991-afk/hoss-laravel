<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.default_pricings.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.default_pricings.index')); ?>">قیمت‌گذاری پیش‌فرض/</a></span>
        لیست قیمت‌ها
    </h4>

    <a href="<?php echo e(route('admin.default_pricings.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن قیمت پیش‌فرض</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>قیمت هر کیلومتر</th>
                <th>وضعیت</th>
                <th>تاریخ ایجاد</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $defaultPricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $defaultPricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td>
                        <span class="badge bg-primary fs-6">
                            <?php echo e($defaultPricing->getFormattedPrice()); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge bg-<?php echo e($defaultPricing->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($defaultPricing->is_active ? 'فعال' : 'غیرفعال'); ?>

                        </span>
                    </td>
                    <td><?php echo e($defaultPricing->created_at->format('Y/m/d H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.default_pricings.show', $defaultPricing)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.default_pricings.edit', $defaultPricing)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.default_pricings.destroy', $defaultPricing)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($defaultPricings->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/default_pricings/index.blade.php ENDPATH**/ ?>