<?php if (isset($component)) { $__componentOriginal744508cc19cea4b8f1d98b84f949d170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal744508cc19cea4b8f1d98b84f949d170 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'page::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('page.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal744508cc19cea4b8f1d98b84f949d170)): ?>
<?php $attributes = $__attributesOriginal744508cc19cea4b8f1d98b84f949d170; ?>
<?php unset($__attributesOriginal744508cc19cea4b8f1d98b84f949d170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal744508cc19cea4b8f1d98b84f949d170)): ?>
<?php $component = $__componentOriginal744508cc19cea4b8f1d98b84f949d170; ?>
<?php unset($__componentOriginal744508cc19cea4b8f1d98b84f949d170); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Page/resources/views/index.blade.php ENDPATH**/ ?>