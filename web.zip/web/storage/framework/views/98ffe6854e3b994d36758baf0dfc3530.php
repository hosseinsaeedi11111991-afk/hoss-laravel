<?php $__env->startSection('title', 'افزودن صفحه جدید'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.page.index')); ?>">لیست صفحات/</a></span>
    <span>افزودن صفحه جدید</span>
</h4>

<?php echo $__env->make('page::admin.partials.form', [
    'page' => $page,
    'pages' => $pages,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Page/resources/views/admin/create.blade.php ENDPATH**/ ?>