<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-post-category.index')); ?>">دسته‌بندی مقالات/</a></span>
        ایجاد دسته‌بندی جدید
    </h4>

    <form action="<?php echo e(route('admin.blog-post-category.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">نام دسته‌بندی <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ فارسی <span class="text-danger">*</span></label>
            <input type="text" name="fa_slug" class="form-control" value="<?php echo e(old('fa_slug')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ انگلیسی <span class="text-danger">*</span></label>
            <input type="text" name="en_slug" class="form-control" value="<?php echo e(old('en_slug')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">توضیحات</label>
            <textarea name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_post_category/create.blade.php ENDPATH**/ ?>