<style>
    @font-face {
        font-family: 'Vazirmatn';
        src: url('<?php echo e(asset('admin/assets/vendor/fonts/farsi-fonts-en-num/vazir-400.woff2')); ?>') format('woff2');
        font-weight: 400;
        font-style: normal;
        font-display: swap;
    }

    @font-face {
        font-family: 'Vazirmatn';
        src: url('<?php echo e(asset('admin/assets/vendor/fonts/farsi-fonts-en-num/vazir-500.woff2')); ?>') format('woff2');
        font-weight: 500;
        font-style: normal;
        font-display: swap;
    }

    @font-face {
        font-family: 'Vazirmatn';
        src: url('<?php echo e(asset('admin/assets/vendor/fonts/farsi-fonts-en-num/vazir-700.woff2')); ?>') format('woff2');
        font-weight: 600 700;
        font-style: normal;
        font-display: swap;
    }

    :root {
        --viptaxi-font-family: 'Vazirmatn', Tahoma, Arial, sans-serif;
    }

    html,
    body,
    button,
    input,
    select,
    textarea,
    optgroup,
    ::placeholder,
    .tooltip,
    .popover,
    .modal,
    .dropdown-menu,
    .table {
        font-family: var(--viptaxi-font-family) !important;
    }

    body :where(*):not(i):not(svg):not(path):not([class^="fa-"]):not([class*=" fa-"]):not(.fa):not(.fas):not(.far):not(.fal):not(.fab):not(.fad):not(.fa-solid):not(.fa-regular):not(.fa-light):not(.fa-brands):not([class^="ti-"]):not([class*=" ti-"]):not([class^="flaticon-"]):not([class*=" flaticon-"]):not([class^="bx"]):not([class*=" bx"]) {
        font-family: var(--viptaxi-font-family) !important;
    }
</style>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/partials/local-font.blade.php ENDPATH**/ ?>