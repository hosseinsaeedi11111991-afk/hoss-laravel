<?php $__env->startSection('main'); ?>

    <h4 class="py-3 breadcrumb-wrapper mb-4">

        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-post.index')); ?>"> مقالات/</a></span>
          مقالات

    </h4>

    <div class="d-flex gap-2 mb-3">
        <?php if(Route::has('admin.blog-post.create')): ?>
        <a href="<?php echo e(route('admin.blog-post.create')); ?>" type="button" class="btn rounded-pill btn-success">
            <i class="bx bx-plus"></i> ایجاد مقاله
        </a>
        <?php endif; ?>
        <?php if(Route::has('admin.blog-post.import')): ?>
        <a href="<?php echo e(route('admin.blog-post.import')); ?>" type="button" class="btn rounded-pill btn-primary">
            <i class="bx bx-import"></i> واردات از وردپرس
        </a>
        <?php endif; ?>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>عنوان</th>
                <th>وضعیت</th>
                <th>تعداد دیده شده</th>
                <th>تارخ ایجاد</th>
                <th>عمل</th>
            </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($row->title); ?></td>
                    <td>
                        <label class="me-3 switch switch-success">
                            <input type="checkbox" class="status-toggle switch-input" data-id="<?php echo e($row->id); ?>" data-field="is_active"   <?php echo e($row->is_active ? 'checked' : ''); ?>>
                            <span class="switch-toggle-slider">
                              <span class="switch-on">
                                <i class="bx bx-check"></i>
                              </span>
                              <span class="switch-off">
                                <i class="bx bx-x"></i>
                              </span>
                            </span>
                        </label>
                    </td>
                    <td><?php echo e($row->views_count); ?></td>
                    <td><?php echo e(Verta::instance($row->created_at)->format('Y/m/d')); ?></td>

                    <td>
                        <div class="btn-group  gap-2">
                            <?php if(Route::has('admin.blog-post.show')): ?>
                            <a href="<?php echo e(route('admin.blog-post.show', $row->id)); ?>"
                               class="btn btn-info btn-sm"
                               title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <?php endif; ?>
                            <?php if(Route::has('admin.blog-post.edit')): ?>
                            <a href="<?php echo e(route('admin.blog-post.edit', $row->id)); ?>"
                               class="btn btn-warning btn-sm"
                               title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <?php endif; ?>
                            <?php if(Route::has('admin.blog-post.destroy')): ?>
                            <form method="POST"
                                  action="<?php echo e(route('admin.blog-post.destroy', $row->id)); ?>"
                                  class="delete-form d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="btn btn-danger btn-sm"
                                        title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <div class="mt-4">
        <?php echo e($blog_posts->links('pagination::bootstrap-5')); ?>

    </div>
    <?php $__env->startSection('script'); ?>
        <script>
            function deleteRow (e) {
                Swal.fire({
                    title: 'هشدار',
                    text: "آیا از حذف مطمعا هستید",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'بله حذف کن',
                    cancelButtonText: 'خیر',
                    customClass: {
                        confirmButton: 'btn btn-primary me-1',
                        cancelButton: 'btn btn-label-secondary'
                    },
                    buttonsStyling: false
                }).then(function(result) {

                    if (result.value) {
                        var form =  e.parentElement.children[3];
                        form.submit();
                    }
                });
            }
        </script>
    <?php $__env->appendSection(); ?>
    <?php if(Route::has('admin.blog-post.toggle.status')): ?>
    <?php $__env->startSection('script'); ?>
        <script>
            document.querySelectorAll('.status-toggle').forEach(switchEl => {
                switchEl.addEventListener('change', function() {
                    const postId = this.getAttribute('data-id');
                    const field = this.getAttribute('data-field');
                    const isChecked = this.checked;

                    // نمایش اسپینر (اختیاری)
                    this.disabled = true;

                    fetch("<?php echo e(route('admin.blog-post.toggle.status')); ?>", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            id: postId,
                            field: field,
                            value: isChecked
                        })
                    })
                        .then(response => response.json())
                        .then(data => {
                            if(data.status !== 'success') {
                                // بازگشت به حالت قبلی در صورت خطا
                                this.checked = !isChecked;
                            }
                        })
                        .catch(() => {
                            this.checked = !isChecked;
                        })
                        .finally(() => {
                            this.disabled = false;
                        });
                });
            });
        </script>
    <?php $__env->appendSection(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_post/index.blade.php ENDPATH**/ ?>