<div>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <form wire:submit.prevent="save">
        
        <div class="d-flex mb-3 flex-wrap">
            
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="subject">
                    <span>موضوع FAQ</span>
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-bookmark"></i></span>
                    <input id="subject" type="text" class="form-control" placeholder="موضوع FAQ" wire:model="subject">
                </div>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="title">
                    <span>عنوان</span>
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="title" type="text" class="form-control" placeholder="عنوان" wire:model="title">
                </div>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4">
                <label class="form-label" for="description">
                    <span>توضیحات</span>
                </label>
                <textarea id="description" class="form-control" rows="3" placeholder="توضیحات" wire:model="description"></textarea>
            </div>
        </div>

        <h5 class="mb-3 px-4">پرسش و پاسخ‌ها</h5>
        
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded p-3 mb-3 mx-4">
                <div class="d-flex flex-wrap mb-3">
                    <div class="col-12 col-lg-5 col-md-6 px-3 mb-2 mb-lg-0">
                        <label class="form-label" for="sort_order-<?php echo e($index); ?>">
                            ترتیب
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-pen"></i></span>
                            <input id="sort_order-<?php echo e($index); ?>" type="number" class="form-control form-control-sm ps-2"
                               placeholder="ترتیب" wire:model="contents.<?php echo e($index); ?>.sort_order">
                        </div>
                        <label class="form-label" for="question-<?php echo e($index); ?>">
                            پرسش
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-pen"></i></span>
                            <input id="question-<?php echo e($index); ?>" type="text" class="form-control form-control-sm" placeholder="پرسش"
                               wire:model="contents.<?php echo e($index); ?>.question">
                        </div>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 col-lg-6 col-md-6 px-3">
                        <label class="form-label" for="answer-<?php echo e($index); ?>">
                            <span>پاسخ</span>
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <textarea id="answer-<?php echo e($index); ?>" class="form-control form-control-sm" rows="3" placeholder="پاسخ"
                                  wire:model="contents.<?php echo e($index); ?>.answer"></textarea>
                        <?php $__errorArgs = ['contents.'.$index.'.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 col-lg-1 col-md-12 px-3 pt-4 d-flex flex-column justify-content-between">
                        <button type="button" class="btn btn-sm btn-danger" wire:click="removeContent(<?php echo e($index); ?>)">
                            <i class="bx bx-trash"></i>
                            حذف
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="px-4 mb-4">
            <button type="button" class="btn btn-sm btn-success" wire:click="addContent">
                <i class="bx bx-plus"></i>
                <span>افزودن پرسش و پاسخ</span>
            </button>
        </div>
        <div class="px-4 mb-5">
            <button type="submit" class="btn btn-primary">ثبت</button>
        </div>
    </form>
</div>
<?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/livewire/admin/faq_form.blade.php ENDPATH**/ ?>