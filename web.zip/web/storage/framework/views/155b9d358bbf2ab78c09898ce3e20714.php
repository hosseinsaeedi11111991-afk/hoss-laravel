<?php $__env->startSection('title', 'لیست رزروها'); ?>

<?php
    $statuses = \Modules\Reservation\Models\Reservation::statuses();
    $activeStatus = request('status');
    $baseFilters = request()->except(['status', 'page']);
    $hasFilters = request()->hasAny(['username', 'phone', 'origin_address', 'destination_address', 'status', 'date_from', 'date_to']);
?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css" />
    <style>
        .reservation-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .reservation-toolbar .btn {
            padding: .42rem .85rem;
            font-size: .8125rem;
        }

        .reservation-toolbar .breadcrumb-wrapper {
            font-size: 1.05rem;
        }

        #reservationFilters .card-header,
        #reservationFilters .card-body {
            padding: .85rem 1rem;
        }

        #reservationFilters .form-label {
            font-size: .75rem;
        }

        #reservationFilters .form-control,
        #reservationFilters .form-select {
            min-height: 34px;
            padding-top: .35rem;
            padding-bottom: .35rem;
            font-size: .8125rem;
        }

        .reservation-tabs {
            display: flex;
            gap: .5rem;
            flex-wrap: wrap;
        }

        .reservation-tabs .btn {
            min-width: 84px;
            padding: .38rem .75rem;
            font-size: .8125rem;
        }

        .reservation-table-card {
            overflow: hidden;
        }

        .reservation-table {
            table-layout: fixed;
            margin-bottom: 0;
            font-size: .84rem;
        }

        .reservation-table th,
        .reservation-table td {
            vertical-align: middle;
            white-space: normal;
        }

        .reservation-table th,
        .reservation-table td {
            padding: .55rem .65rem;
        }

        .reservation-table thead th {
            font-size: .74rem;
            font-weight: 700;
            color: #66758a;
        }

        .reservation-table .col-select { width: 38px; }
        .reservation-table .col-row { width: 48px; }
        .reservation-table .col-actions { width: 112px; }
        .reservation-table .col-passenger { width: 19%; }
        .reservation-table .col-phone { width: 13%; }
        .reservation-table .col-route { width: 30%; }
        .reservation-table .col-date { width: 13%; }
        .reservation-table .col-car { width: 14%; }
        .reservation-table .col-status { width: 125px; }

        .reservation-primary {
            color: #4f6074;
            font-weight: 600;
            line-height: 1.55;
        }

        .reservation-muted {
            color: #7f8ea3;
            font-size: .77rem;
            line-height: 1.5;
        }

        .reservation-ellipsis {
            display: block;
            max-width: 100%;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .route-chip {
            display: inline-flex;
            align-items: center;
            gap: .35rem;
            max-width: 100%;
        }

        .route-chip i {
            color: #696cff;
            flex-shrink: 0;
        }

        .reservation-actions {
            display: grid;
            grid-template-columns: repeat(3, 24px);
            gap: .25rem;
            align-items: center;
            justify-content: end;
        }

        .reservation-actions .btn {
            width: 24px;
            height: 24px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: .76rem;
            border-radius: 6px !important;
            line-height: 1;
        }

        .reservation-bulk-actions {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            flex-wrap: wrap;
        }

        .reservation-bulk-actions .btn {
            padding: .38rem .75rem;
            font-size: .8125rem;
        }

        .status-dropdown {
            min-width: 112px;
            padding-top: .25rem;
            padding-bottom: .25rem;
            font-size: .78rem;
        }

        .reservation-details-row td {
            background: rgba(105, 108, 255, .035);
            padding: 0;
        }

        .reservation-details {
            padding: .85rem 1rem;
            border-top: 1px solid rgba(67, 89, 113, .08);
        }

        .reservation-detail-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .75rem 1rem;
        }

        .reservation-detail-item span {
            display: block;
            color: #8795a8;
            font-size: .72rem;
            margin-bottom: .2rem;
        }

        .reservation-detail-item strong {
            display: block;
            color: #4f6074;
            font-weight: 600;
            line-height: 1.6;
            font-size: .82rem;
            overflow-wrap: anywhere;
        }

        @media (max-width: 1199px) {
            .reservation-table {
                table-layout: auto;
            }

            .reservation-table .col-date,
            .reservation-table .col-car {
                display: none;
            }

            .reservation-detail-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 767px) {
            .reservation-toolbar {
                align-items: stretch;
            }

            .reservation-toolbar > * {
                width: 100%;
            }

            .reservation-tabs .btn {
                flex: 1 1 44%;
            }

            .reservation-table thead {
                display: none;
            }

            .reservation-table,
            .reservation-table tbody,
            .reservation-table tr,
            .reservation-table td {
                display: block;
                width: 100% !important;
            }

            .reservation-table tbody tr:not(.reservation-details-row) {
                border-bottom: 1px solid rgba(67, 89, 113, .08);
                padding: .85rem 1rem;
            }

            .reservation-table tbody tr:not(.reservation-details-row) td {
                border: 0;
                padding: .25rem 0;
            }

            .reservation-actions {
                justify-content: start;
            }

            .reservation-table .col-row,
            .reservation-table .col-select,
            .reservation-table td.col-row {
                display: none;
            }

            .reservation-table .col-date,
            .reservation-table .col-car {
                display: block;
            }

            .reservation-detail-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="reservation-toolbar mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.reservations.index')); ?>">پنل/</a></span>
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.reservations.index')); ?>">رزرو‌ها/</a></span>
            لیست رزرو‌ها
        </h4>

        <div class="d-flex gap-2 flex-wrap">
            <button class="btn btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#reservationFilters" aria-expanded="<?php echo e($hasFilters ? 'true' : 'false'); ?>" aria-controls="reservationFilters">
                <i class="bx bx-filter-alt"></i>
                فیلترها
                <?php if($hasFilters): ?>
                    <span class="badge bg-info ms-1"><?php echo e($reservations->total()); ?></span>
                <?php endif; ?>
            </button>
            <a href="<?php echo e(route('admin.reservations.create')); ?>" class="btn btn-success">
                <i class="bx bx-plus"></i>
                افزودن رزرو
            </a>
            <a href="<?php echo e(route('admin.reservations.export', request()->query())); ?>" class="btn btn-outline-success">
                <i class="bx bx-export"></i>
                خروجی Excel
            </a>
        </div>
    </div>

    <div class="collapse <?php echo e($hasFilters ? 'show' : ''); ?>" id="reservationFilters">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">جستجو و فیلتر</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.reservations.index')); ?>" id="searchForm">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">نام کاربر</label>
                            <input type="text" name="username" class="form-control" value="<?php echo e(request('username')); ?>" placeholder="جستجو...">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">شماره تماس</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo e(request('phone')); ?>" placeholder="جستجو...">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">مبدا</label>
                            <input type="text" name="origin_address" class="form-control" value="<?php echo e(request('origin_address')); ?>" placeholder="جستجو...">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">مقصد</label>
                            <input type="text" name="destination_address" class="form-control" value="<?php echo e(request('destination_address')); ?>" placeholder="جستجو...">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">وضعیت</label>
                            <select name="status" class="form-select">
                                <option value="">همه وضعیت‌ها</option>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($statusKey); ?>" <?php echo e(request('status') == $statusKey ? 'selected' : ''); ?>>
                                        <?php echo e($label); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">تاریخ از</label>
                            <input type="text" name="date_from" id="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>" placeholder="انتخاب تاریخ">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">تاریخ تا</label>
                            <input type="text" name="date_to" id="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>" placeholder="انتخاب تاریخ">
                        </div>
                    </div>

                    <div class="d-flex flex-wrap gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-search"></i>
                            جستجو
                        </button>
                        <a href="<?php echo e(route('admin.reservations.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-refresh"></i>
                            پاک کردن فیلترها
                        </a>
                        <?php if($hasFilters): ?>
                            <span class="badge bg-info align-self-center">
                                <?php echo e($reservations->total()); ?> نتیجه یافت شد
                            </span>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="reservation-tabs mb-3">
        <a class="btn <?php echo e($activeStatus ? 'btn-outline-primary' : 'btn-primary'); ?>"
           href="<?php echo e(route('admin.reservations.index', $baseFilters)); ?>">
            همه
        </a>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="btn <?php echo e($activeStatus === $statusKey ? 'btn-primary' : 'btn-outline-primary'); ?>"
               href="<?php echo e(route('admin.reservations.index', array_merge($baseFilters, ['status' => $statusKey]))); ?>">
                <?php echo e($label); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card reservation-table-card">
        <div class="card-header reservation-bulk-actions">
            <div class="reservation-muted">
                <?php echo e($reservations->total()); ?> رزرو
            </div>
            <form id="bulkDeleteForm" class="bulk-delete-form mb-0" method="POST" action="<?php echo e(route('admin.reservations.bulkDestroy')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-outline-danger" id="bulkDeleteButton" disabled>
                    <i class="bx bx-trash"></i>
                    حذف انتخاب‌شده‌ها
                </button>
            </form>
        </div>
        <div class="table-responsive">
            <table class="table table-striped reservation-table">
                <thead>
                <tr>
                    <th class="col-select">
                        <input class="form-check-input" type="checkbox" id="selectAllReservations" aria-label="انتخاب همه رزروها">
                    </th>
                    <th class="col-row">#</th>
                    <th class="col-actions">عملیات</th>
                    <th class="col-passenger">مسافر</th>
                    <th class="col-phone">تماس</th>
                    <th class="col-route">مسیر</th>
                    <th class="col-date">تاریخ</th>
                    <th class="col-car">خودرو</th>
                    <th class="col-status">وضعیت</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $rowNumber = ($reservations->currentPage() - 1) * $reservations->perPage() + $key + 1;
                        $originBrief = $res->origin ?: $res->origin_address;
                        $destinationBrief = $res->destination ?: $res->destination_address;
                        $originFull = $res->origin_address ?: $res->origin;
                        $destinationFull = $res->destination_address ?: $res->destination;
                        $looksLikeCoordinates = function ($value) {
                            return is_string($value) && preg_match('/^[\d\s.,،+\-]+$/u', trim($value));
                        };
                        $originList = $looksLikeCoordinates($originBrief) ? null : $originBrief;
                        $destinationList = $looksLikeCoordinates($destinationBrief) ? null : $destinationBrief;
                        $detailsId = 'reservation-details-' . $res->id;
                    ?>
                    <tr>
                        <td class="col-select">
                            <input class="form-check-input reservation-checkbox" type="checkbox" name="reservation_ids[]" value="<?php echo e($res->id); ?>" form="bulkDeleteForm" aria-label="انتخاب رزرو <?php echo e($rowNumber); ?>">
                        </td>
                        <td class="col-row"><?php echo e($rowNumber); ?></td>
                        <td class="col-actions">
                            <div class="reservation-actions">
                                <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($detailsId); ?>" aria-expanded="false" aria-controls="<?php echo e($detailsId); ?>" title="جزئیات">
                                    <i class="bx bx-detail"></i>
                                </button>
                                <a href="<?php echo e(route('admin.reservations.show', $res)); ?>" class="btn btn-sm btn-info" title="نمایش">
                                    <i class="bx bxs-show"></i>
                                </a>
                                <a href="<?php echo e(route('admin.reservations.edit', $res)); ?>" class="btn btn-sm btn-warning" title="ویرایش">
                                    <i class="bx bx-edit-alt"></i>
                                </a>
                                <a href="<?php echo e(route('admin.reservations.neshan', $res)); ?>" class="btn btn-sm btn-secondary" title="نشان">
                                    <i class="bx bx-map"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.reservations.destroy', $res)); ?>" class="d-inline delete-form">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" title="حذف">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="col-passenger">
                            <span class="reservation-primary reservation-ellipsis" title="<?php echo e($res->user->username ?? '-'); ?>">
                                <?php echo e($res->user->username ?? '-'); ?>

                            </span>
                            <span class="reservation-muted"><?php echo e($res->passengers_count ?? 1); ?> نفر</span>
                        </td>
                        <td class="col-phone">
                            <span dir="ltr" class="reservation-primary"><?php echo e($res->phone ?? $res->user->mobile ?? '-'); ?></span>
                            <?php if($res->second_phone): ?>
                                <span dir="ltr" class="reservation-muted"><?php echo e($res->second_phone); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="col-route">
                            <span class="route-chip reservation-primary" title="<?php echo e(($originList ?: 'ثبت شده') . ' به ' . ($destinationList ?: 'ثبت شده')); ?>">
                                <span class="reservation-ellipsis"><?php echo e(\Illuminate\Support\Str::limit($originList ?: 'ثبت شده', 30)); ?></span>
                                <i class="bx bx-left-arrow-alt"></i>
                                <span class="reservation-ellipsis"><?php echo e(\Illuminate\Support\Str::limit($destinationList ?: 'ثبت شده', 30)); ?></span>
                            </span>
                        </td>
                        <td class="col-date">
                            <span class="reservation-primary">
                                <?php echo e($res->date ? verta($res->date)->format('Y/m/d') : '-'); ?>

                            </span>
                            <span class="reservation-muted">
                                <?php echo e($res->time ?: ($res->date ? verta($res->date)->format('H:i') : '-')); ?>

                            </span>
                        </td>
                        <td class="col-car">
                            <span class="reservation-primary reservation-ellipsis" title="<?php echo e($res->car->title ?? '-'); ?>">
                                <?php echo e($res->car->title ?? '-'); ?>

                            </span>
                            <span class="reservation-muted"><?php echo e($res->carCategory->title ?? '-'); ?></span>
                        </td>
                        <td class="col-status">
                            <span class="badge mb-1
                                <?php if($res->status == 'pending'): ?> bg-warning
                                <?php elseif($res->status == 'confirmed'): ?> bg-success
                                <?php elseif($res->status == 'canceled'): ?> bg-danger
                                <?php elseif($res->status == 'completed'): ?> bg-info
                                <?php else: ?> bg-secondary
                                <?php endif; ?>" data-status="<?php echo e($res->status); ?>">
                                <?php echo e($res->status_label); ?>

                            </span>
                            <select class="form-select form-select-sm status-dropdown" data-id="<?php echo e($res->id); ?>">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($statusKey); ?>" <?php echo e($res->status == $statusKey ? 'selected' : ''); ?>>
                                        <?php echo e($label); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr class="reservation-details-row">
                        <td colspan="9">
                            <div class="collapse" id="<?php echo e($detailsId); ?>">
                                <div class="reservation-details">
                                    <div class="reservation-detail-grid">
                                        <div class="reservation-detail-item">
                                            <span>آدرس کامل مبدا</span>
                                            <strong><?php echo e($originFull ?: '-'); ?></strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>آدرس کامل مقصد</span>
                                            <strong><?php echo e($destinationFull ?: '-'); ?></strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>شماره دوم</span>
                                            <strong dir="ltr"><?php echo e($res->second_phone ?: '-'); ?></strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>دسته‌بندی</span>
                                            <strong><?php echo e($res->carCategory->title ?? '-'); ?></strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>خودرو</span>
                                            <strong><?php echo e($res->car->title ?? '-'); ?></strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>مسافت</span>
                                            <strong><?php echo e(number_format((float) $res->distance_km, 2)); ?> km</strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>مبلغ کل</span>
                                            <strong><?php echo e(number_format((float) $res->total_price)); ?> تومان</strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>فاکتور</span>
                                            <strong>
                                                <?php if($res->needs_invoice): ?>
                                                    <span class="badge bg-success">بله</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">خیر</span>
                                                <?php endif; ?>
                                            </strong>
                                        </div>
                                        <div class="reservation-detail-item">
                                            <span>قیمت توافقی</span>
                                            <strong>
                                                <?php if($res->is_negotiable): ?>
                                                    <span class="badge bg-warning">بله</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">خیر</span>
                                                <?php endif; ?>
                                            </strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-5">رزروی یافت نشد.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($reservations->links('pagination::bootstrap-5')); ?>

    </div>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
        <script>
            $(document).ready(function() {
                var dateFromValue = $('#date_from').val();
                var dateToValue = $('#date_to').val();

                $('#date_from').persianDatepicker({
                    format: 'YYYY/MM/DD',
                    observer: true,
                    calendarType: 'persian',
                    initialValue: dateFromValue ? true : false,
                    autoClose: true
                });

                if (dateFromValue) {
                    $('#date_from').val(dateFromValue);
                }

                $('#date_to').persianDatepicker({
                    format: 'YYYY/MM/DD',
                    observer: true,
                    calendarType: 'persian',
                    initialValue: dateToValue ? true : false,
                    autoClose: true
                });

                if (dateToValue) {
                    $('#date_to').val(dateToValue);
                }
            });

            const statusLabels = {
                'pending': 'در انتظار تایید',
                'confirmed': 'تایید شده',
                'canceled': 'لغو شده',
                'completed': 'تکمیل شده'
            };

            const statusColors = {
                'pending': 'bg-warning',
                'confirmed': 'bg-success',
                'canceled': 'bg-danger',
                'completed': 'bg-info'
            };

            $('.status-dropdown').change(function() {
                const id = $(this).data('id');
                const status = $(this).val();
                const $badge = $(this).closest('td').find('.badge');
                const oldStatus = $badge.data('status');

                $.ajax({
                    url: `/admin-panel/reservations/${id}/status`,
                    type: 'PATCH',
                    data: { status, _token: '<?php echo e(csrf_token()); ?>' },
                    success: () => {
                        $badge.removeClass('bg-warning bg-success bg-danger bg-info bg-secondary')
                            .addClass(statusColors[status] || 'bg-secondary')
                            .text(statusLabels[status] || status)
                            .data('status', status);
                        toastr.success('وضعیت رزرو با موفقیت بروز شد.', '', { rtl: true });
                    },
                    error: () => {
                        $(this).val(oldStatus);
                        toastr.error('مشکلی در تغییر وضعیت رخ داد.');
                    }
                });
            });

            const $selectAll = $('#selectAllReservations');
            const $reservationCheckboxes = $('.reservation-checkbox');
            const $bulkDeleteButton = $('#bulkDeleteButton');
            const $bulkDeleteForm = $('#bulkDeleteForm');

            function updateBulkDeleteState() {
                const selectedCount = $('.reservation-checkbox:checked').length;
                $bulkDeleteButton.prop('disabled', selectedCount === 0);
                $bulkDeleteButton.html('<i class="bx bx-trash"></i> حذف انتخاب‌شده‌ها' + (selectedCount ? ' (' + selectedCount + ')' : ''));
                $selectAll.prop('checked', selectedCount > 0 && selectedCount === $reservationCheckboxes.length);
            }

            $selectAll.on('change', function() {
                $reservationCheckboxes.prop('checked', $(this).is(':checked'));
                updateBulkDeleteState();
            });

            $reservationCheckboxes.on('change', updateBulkDeleteState);

            $bulkDeleteForm.on('submit', function(e) {
                const selectedCount = $('.reservation-checkbox:checked').length;
                if (!selectedCount) {
                    e.preventDefault();
                    return;
                }

                e.preventDefault();
                Swal.fire({
                    title: 'حذف گروهی رزروها',
                    text: selectedCount + ' رزرو انتخاب‌شده حذف می‌شود. این عملیات قابل بازگشت نیست.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'بله، حذف کن',
                    cancelButtonText: 'لغو'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/reservations/index.blade.php ENDPATH**/ ?>