
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.reservations.index')); ?>">پنل/</a></span>
        <span class="text-muted fw-light">رزرو‌ها/</span>
        نشان رزرو #<?php echo e($reservation->id); ?>

    </h4>

    <div class="card mb-3">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3"><span class="fw-bold">کاربر:</span> <?php echo e($reservation->user->first_name ?? '-'); ?></div>
                <div class="col-md-3"><span class="fw-bold">خودرو:</span> <?php echo e($reservation->car->title ?? '-'); ?></div>
                <div class="col-md-3"><span class="fw-bold">تاریخ:</span> <?php echo e($reservation->date ? verta($reservation->date)->format('Y/m/d') : '-'); ?></div>
                <div class="col-md-3"><span class="fw-bold">مسافت:</span> <?php echo e(number_format($reservation->distance_km, 2)); ?> km</div>
            </div>
        </div>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <span class="badge bg-<?php echo e($loc->type === 'origin' ? 'primary' : 'info'); ?>"><?php echo e($loc->type === 'origin' ? 'مبدا' : 'مقصد'); ?></span>
                    <?php if($loc->is_primary): ?>
                        <span class="badge bg-success">اصلی</span>
                    <?php endif; ?>
                </div>
                <div>
                    Lat: <?php echo e($loc->latitude); ?> | Lng: <?php echo e($loc->longitude); ?>

                </div>
            </div>
            <div class="card-body">
                <p class="mb-2"><span class="fw-bold">آدرس:</span> <?php echo e($loc->address_text); ?></p>

                <?php if($loc->cities->count()): ?>
                    <div class="table-responsive text-nowrap">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>نام شهر</th>
                                <th>کیلومتر</th>
                                <th>رزرو مرتبط</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $loc->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($idx + 1); ?></td>
                                    <td><?php echo e($city->city_name); ?></td>
                                    <td><?php echo e(number_format($city->distance_km, 2)); ?></td>
                                    <td><?php echo e($city->reservation_id ?? '—'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <span class="text-muted">هیچ شهری ثبت نشده است.</span>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">هیچ لوکیشنی برای این رزرو ثبت نشده است.</div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.reservations.index')); ?>" class="btn btn-secondary mt-2">بازگشت</a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/reservations/neshan.blade.php ENDPATH**/ ?>