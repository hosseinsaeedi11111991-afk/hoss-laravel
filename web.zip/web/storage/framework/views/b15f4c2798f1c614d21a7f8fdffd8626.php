
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.city_pricings.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.city_pricings.index')); ?>">قیمت‌گذاری شهری/</a></span>
        جزئیات قیمت شهری
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قیمت‌گذاری شهری</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>نام شهر:</strong>
                    <p class="text-muted fs-5"><?php echo e($cityPricing->city_name); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>دسته‌بندی ماشین:</strong>
                    <p>
                        <?php if($cityPricing->carCategory): ?>
                            <span class="badge bg-secondary"><?php echo e($cityPricing->carCategory->title); ?></span>
                        <?php else: ?>
                            <span class="text-muted">تعیین نشده</span>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p>
                        <span class="badge bg-info fs-6">
                            <?php echo e($cityPricing->getFormattedPrice()); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-<?php echo e($cityPricing->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($cityPricing->is_active ? 'فعال' : 'غیرفعال'); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted"><?php echo e($cityPricing->created_at->format('Y/m/d H:i')); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted"><?php echo e($cityPricing->updated_at->format('Y/m/d H:i')); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (100 کیلومتر):</strong>
                    <p class="text-success fs-5">
                        <?php echo e(number_format($cityPricing->calculatePrice(100))); ?> تومان
                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('admin.city_pricings.edit', $cityPricing)); ?>" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="<?php echo e(route('admin.city_pricings.index')); ?>" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/city_pricings/show.blade.php ENDPATH**/ ?>