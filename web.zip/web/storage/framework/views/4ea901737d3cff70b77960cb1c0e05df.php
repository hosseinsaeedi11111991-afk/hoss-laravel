<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">دسته‌بندی ماشین‌ها/</a></span>
        لیست دسته‌بندی‌ها
    </h4>

    <a href="<?php echo e(route('admin.cars.categories.create')); ?>"
       class="btn rounded-pill btn-success mb-3">
        ایجاد دسته‌بندی جدید
    </a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>عنوان</th>
                <th>نوع</th>
                <th>نوع قیمت</th>
                <th>قیمت</th>
                <th>logo</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($category->title); ?></td>
                    <td><?php echo e(\Modules\Cars\Models\CarCategory::TYPES[$category->type] ?? '-'); ?></td>
                    <td><?php echo e($category->price_type_label); ?></td>
                    <td>
                        <?php if($category->price_type === 'fixed'): ?>
                            <?php echo e(number_format($category->fixed_price ?? 0)); ?> تومان
                        <?php elseif($category->price_type === 'per_km'): ?>
                            <?php echo e(number_format($category->price_per_km ?? 0)); ?> تومان/کیلومتر
                        <?php else: ?>
                            توافقی
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($category->logo): ?>
                            <img src="<?php echo e(Storage::url($category->logo)); ?>" width="120">
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group flex-wrap gap-2" role="group">
                            <a href="<?php echo e(route('admin.cars.categories.show', $category)); ?>"
                               class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>

                            <a href="<?php echo e(route('admin.cars.categories.edit', $category)); ?>"
                               class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>

                            <form method="POST"
                                  action="<?php echo e(route('admin.cars.categories.destroy', $category)); ?>"
                                  class="d-inline delete-form">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($categories->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/car_categories/index.blade.php ENDPATH**/ ?>