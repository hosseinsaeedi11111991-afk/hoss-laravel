<?php $__env->startSection('title', 'مدیریت ریدایرکت‌ها'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .seo-summary {
            display: grid;
            grid-template-columns: repeat(6, minmax(0, 1fr));
            gap: .75rem;
        }

        .seo-summary-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            padding: .85rem;
            background: #fff;
        }

        .seo-summary-item span {
            display: block;
            color: #7f8ea3;
            font-size: .75rem;
            margin-bottom: .35rem;
        }

        .seo-summary-item strong {
            color: #4f6074;
            font-size: 1.1rem;
        }

        .seo-redirect-table {
            table-layout: fixed;
            font-size: .84rem;
        }

        .seo-redirect-table th,
        .seo-redirect-table td {
            vertical-align: middle;
            white-space: normal;
            overflow-wrap: anywhere;
        }

        .seo-redirect-table .col-actions { width: 112px; }
        .seo-redirect-table .col-status { width: 94px; }
        .seo-redirect-table .col-code { width: 82px; }
        .seo-redirect-table .col-hits { width: 82px; }

        @media (max-width: 991px) {
            .seo-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            <span>سئو/</span>
            ریدایرکت‌ها
        </h4>

        <a href="<?php echo e(route('admin.seo.redirects.create')); ?>" class="btn btn-success <?php echo e($migrationMissing ? 'disabled' : ''); ?>" <?php if($migrationMissing): ?> aria-disabled="true" <?php endif; ?>>
            <i class="bx bx-plus"></i>
            افزودن ریدایرکت
        </a>
    </div>

    <?php if($migrationMissing): ?>
        <div class="alert alert-warning">
            جدول ریدایرکت‌ها هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، این بخش فعال می‌شود و خطای 500 رخ نمی‌دهد.
        </div>
    <?php endif; ?>

    <div class="seo-summary mb-4">
        <div class="seo-summary-item"><span>کل ریدایرکت‌ها</span><strong><?php echo e($summary['total']); ?></strong></div>
        <div class="seo-summary-item"><span>فعال</span><strong><?php echo e($summary['active']); ?></strong></div>
        <div class="seo-summary-item"><span>301</span><strong><?php echo e($summary['permanent']); ?></strong></div>
        <div class="seo-summary-item"><span>302</span><strong><?php echo e($summary['temporary']); ?></strong></div>
        <div class="seo-summary-item"><span>410</span><strong><?php echo e($summary['gone']); ?></strong></div>
        <div class="seo-summary-item"><span>نیازمند بررسی</span><strong><?php echo e($summary['issues']); ?></strong></div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.seo.redirects.index')); ?>" class="row g-3 align-items-end">
                <div class="col-lg-5 col-md-6">
                    <label class="form-label">جستجو در مبدا یا مقصد</label>
                    <input type="text" name="q" class="form-control" value="<?php echo e(request('q')); ?>" placeholder="/old-url یا /new-url">
                </div>
                <div class="col-lg-2 col-md-3">
                    <label class="form-label">کد</label>
                    <select name="status_code" class="form-select">
                        <option value="">همه</option>
                        <?php $__currentLoopData = \App\Models\SeoRedirect::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($code); ?>" <?php if((string) request('status_code') === (string) $code): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-2 col-md-3">
                    <label class="form-label">وضعیت</label>
                    <select name="is_active" class="form-select">
                        <option value="">همه</option>
                        <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>فعال</option>
                        <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>غیرفعال</option>
                    </select>
                </div>
                <div class="col-lg-3 d-flex gap-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bx bx-search"></i>
                        جستجو
                    </button>
                    <a href="<?php echo e(route('admin.seo.redirects.index')); ?>" class="btn btn-outline-secondary">پاک کردن</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-striped seo-redirect-table mb-0">
                <thead>
                <tr>
                    <th>مبدا</th>
                    <th>مقصد</th>
                    <th class="col-code">کد</th>
                    <th class="col-status">وضعیت</th>
                    <th class="col-hits">بازدید</th>
                    <th>گزارش خطا</th>
                    <th class="col-actions">عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $redirects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redirect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($issues = $diagnostics[$redirect->id] ?? []); ?>
                    <tr>
                        <td dir="ltr"><?php echo e($redirect->source_path); ?></td>
                        <td dir="ltr">
                            <?php if((int) $redirect->status_code === \App\Models\SeoRedirect::STATUS_410): ?>
                                <span class="text-muted">Gone</span>
                            <?php else: ?>
                                <?php echo e($redirect->target_url); ?>

                            <?php endif; ?>
                        </td>
                        <td><span class="badge bg-label-primary"><?php echo e($redirect->status_code); ?></span></td>
                        <td>
                            <?php if($redirect->is_active): ?>
                                <span class="badge bg-success">فعال</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">غیرفعال</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format($redirect->hits)); ?></td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span class="badge bg-warning text-dark mb-1"><?php echo e($issue); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span class="text-success">سالم</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="<?php echo e(route('admin.seo.redirects.edit', $redirect)); ?>" class="btn btn-sm btn-warning" title="ویرایش">
                                    <i class="bx bx-edit-alt"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.seo.redirects.destroy', $redirect)); ?>" class="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" title="حذف">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">هنوز ریدایرکتی ثبت نشده است.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($redirects->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/seo_redirects/index.blade.php ENDPATH**/ ?>