<?php $__env->startSection('title', 'ویرایش ریدایرکت'); ?>

<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.seo.redirects.index')); ?>">ریدایرکت‌ها/</a></span>
        ویرایش ریدایرکت
    </h4>

    <?php echo $__env->make('admin.seo_redirects.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/seo_redirects/edit.blade.php ENDPATH**/ ?>