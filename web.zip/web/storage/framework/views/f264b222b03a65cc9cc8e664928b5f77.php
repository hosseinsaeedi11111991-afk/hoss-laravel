<?php if (isset($component)) { $__componentOriginalbefff2b4ce705509397732552e8004a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbefff2b4ce705509397732552e8004a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cars::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cars::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('cars.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbefff2b4ce705509397732552e8004a2)): ?>
<?php $attributes = $__attributesOriginalbefff2b4ce705509397732552e8004a2; ?>
<?php unset($__attributesOriginalbefff2b4ce705509397732552e8004a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbefff2b4ce705509397732552e8004a2)): ?>
<?php $component = $__componentOriginalbefff2b4ce705509397732552e8004a2; ?>
<?php unset($__componentOriginalbefff2b4ce705509397732552e8004a2); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/index.blade.php ENDPATH**/ ?>