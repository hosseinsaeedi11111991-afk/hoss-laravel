
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">قوانین قیمت‌گذاری/</a></span>
        لیست قوانین
    </h4>

    <div class="mb-3">
        <a href="<?php echo e(route('admin.pricing_rules.create')); ?>" class="btn btn-success rounded-pill me-2">+ افزودن قانون قیمت‌گذاری</a>
        <a href="<?php echo e(route('admin.pricing_rules.bulk.create')); ?>" class="btn btn-primary rounded-pill me-2">+ افزودن دسته‌ای قوانین</a>
        <a href="<?php echo e(route('admin.pricing_rules.bulk.edit')); ?>" class="btn btn-warning rounded-pill me-2">✏️ ویرایش دسته‌ای قوانین</a>
        <a href="<?php echo e(route('admin.pricing_rules.bulk.delete')); ?>" class="btn btn-danger rounded-pill">🗑️ حذف دسته‌ای قوانین</a>
    </div>

    <!-- فرم جستجو -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">جستجو و فیلتر</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.pricing_rules.index')); ?>" id="searchForm">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">شهر مبدا</label>
                        <input type="text" name="origin_city" class="form-control" value="<?php echo e(request('origin_city')); ?>" placeholder="جستجو...">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">شهر مقصد</label>
                        <input type="text" name="destination_city" class="form-control" value="<?php echo e(request('destination_city')); ?>" placeholder="جستجو...">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">استان</label>
                        <select name="province_id" class="form-select">
                            <option value="">همه استان‌ها</option>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($province->id); ?>" <?php echo e(request('province_id') == $province->id ? 'selected' : ''); ?>>
                                    <?php echo e($province->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">دسته‌بندی ماشین</label>
                        <select name="car_category_id" class="form-select">
                            <option value="">همه دسته‌بندی‌ها</option>
                            <?php $__currentLoopData = $carCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(request('car_category_id') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">نحوه محاسبه</label>
                        <select name="pricing_type" class="form-select">
                            <option value="">همه</option>
                            <option value="fixed" <?php echo e(request('pricing_type') == 'fixed' ? 'selected' : ''); ?>>قیمت ثابت</option>
                            <option value="per_km" <?php echo e(request('pricing_type') == 'per_km' ? 'selected' : ''); ?>>قیمت به ازای کیلومتر</option>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">اولویت</label>
                        <select name="priority" class="form-select">
                            <option value="">همه</option>
                            <option value="high" <?php echo e(request('priority') == 'high' ? 'selected' : ''); ?>>بالا</option>
                            <option value="medium" <?php echo e(request('priority') == 'medium' ? 'selected' : ''); ?>>متوسط</option>
                            <option value="low" <?php echo e(request('priority') == 'low' ? 'selected' : ''); ?>>پایین</option>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">وضعیت</label>
                        <select name="is_active" class="form-select">
                            <option value="">همه</option>
                            <option value="1" <?php echo e(request('is_active') == '1' ? 'selected' : ''); ?>>فعال</option>
                            <option value="0" <?php echo e(request('is_active') === '0' ? 'selected' : ''); ?>>غیرفعال</option>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">قیمت ثابت (حداقل)</label>
                        <input type="number" name="fixed_price_min" class="form-control" value="<?php echo e(request('fixed_price_min')); ?>" placeholder="0" min="0" step="1000">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">قیمت ثابت (حداکثر)</label>
                        <input type="number" name="fixed_price_max" class="form-control" value="<?php echo e(request('fixed_price_max')); ?>" placeholder="0" min="0" step="1000">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">قیمت هر کیلومتر (حداقل)</label>
                        <input type="number" name="per_km_price_min" class="form-control" value="<?php echo e(request('per_km_price_min')); ?>" placeholder="0" min="0" step="100">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">قیمت هر کیلومتر (حداکثر)</label>
                        <input type="number" name="per_km_price_max" class="form-control" value="<?php echo e(request('per_km_price_max')); ?>" placeholder="0" min="0" step="100">
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="bx bx-search"></i> جستجو
                        </button>
                        <a href="<?php echo e(route('admin.pricing_rules.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-refresh"></i> پاک کردن فیلترها
                        </a>
                        <?php if(request()->hasAny(['origin_city', 'destination_city', 'province_id', 'car_category_id', 'pricing_type', 'priority', 'is_active', 'fixed_price_min', 'fixed_price_max', 'per_km_price_min', 'per_km_price_max'])): ?>
                            <span class="badge bg-info ms-2">
                                <?php echo e($pricingRules->total()); ?> نتیجه یافت شد
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>استان</th>
                <th>شهر مبدا</th>
                <th>شهر مقصد</th>
                <th>دسته‌بندی ماشین</th>
                <th>نحوه محاسبه</th>
                <th>قیمت ثابت</th>
                <th>قیمت هر کیلومتر</th>
                <th>اولویت</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pricingRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($pricingRules->currentPage() - 1) * $pricingRules->perPage() + $key + 1); ?></td>
                    <td>
                        <?php if($rule->province): ?>
                            <span class="badge bg-primary"><?php echo e($rule->province->title); ?></span>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($rule->origin_city); ?></td>
                    <td><?php echo e($rule->destination_city); ?></td>
                    <td>
                        <?php if($rule->carCategory): ?>
                            <span class="badge bg-secondary"><?php echo e($rule->carCategory->title); ?></span>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge bg-<?php echo e($rule->pricing_type == 'fixed' ? 'primary' : 'info'); ?>">
                            <?php echo e($rule->getPricingTypeLabel()); ?>

                        </span>
                    </td>
                    <td><?php echo e(number_format($rule->fixed_price)); ?> تومان</td>
                    <td><?php echo e(number_format($rule->per_km_price)); ?> تومان</td>
                    <td>
                        <span class="badge bg-<?php echo e($rule->priority == 'high' ? 'danger' : ($rule->priority == 'medium' ? 'warning' : 'secondary')); ?>">
                            <?php echo e($rule->getPriorityLabel()); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge bg-<?php echo e($rule->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($rule->is_active ? 'فعال' : 'غیرفعال'); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.pricing_rules.show', $rule)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.pricing_rules.edit', $rule)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.pricing_rules.destroy', $rule)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($pricingRules->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/pricing_rules/index.blade.php ENDPATH**/ ?>