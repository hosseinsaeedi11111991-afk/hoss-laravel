<?php
    use Modules\Menu\Models\Menu;

    // آمار — از روت پاس داده می‌شود؛ در صورت دسترسی مستقیم، مقدار پیش‌فرض صفر
    $stats = $stats ?? ['today' => 0, 'pending' => 0, 'completed' => 0, 'revenue' => 0];

    // تبدیل ارقام به فارسی
    $fa = function ($n) {
        return str_replace(
            ['0','1','2','3','4','5','6','7','8','9'],
            ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],
            (string) $n
        );
    };

    $cards = [
        ['label' => 'رزروهای امروز',   'value' => $fa(number_format($stats['today'])),     'suffix' => '',       'icon' => 'bx-calendar-check', 'color' => 'primary'],
        ['label' => 'در انتظار تایید', 'value' => $fa(number_format($stats['pending'])),   'suffix' => '',       'icon' => 'bx-time-five',      'color' => 'warning'],
        ['label' => 'سفرهای تکمیل‌شده', 'value' => $fa(number_format($stats['completed'])), 'suffix' => '',       'icon' => 'bx-check-circle',   'color' => 'success'],
        ['label' => 'درآمد این ماه',   'value' => $fa(number_format($stats['revenue'])),   'suffix' => 'تومان', 'icon' => 'bx-wallet',         'color' => 'info'],
    ];

    // بخش‌های دسترسی سریع — برگرفته از نام‌روت‌ها و برچسب‌های منوی کناری
    $groups = [
        [
            'title' => 'مدیریت سفرها',
            'icon'  => 'bx-navigation',
            'items' => [
                ['label' => 'رزروها',            'desc' => 'مدیریت درخواست‌های رزرو',    'icon' => 'bx-calendar-check', 'color' => 'primary',  'route' => 'admin.reservations.index'],
                ['label' => 'مسیرهای پرطرفدار',  'desc' => 'رزرو سریع مسیرهای پرتردد',   'icon' => 'bx-been-here',      'color' => 'info',     'route' => 'admin.popular-routes.index'],
                ['label' => 'گزینه‌های اضافه',    'desc' => 'آپشن‌های قابل انتخاب سفر',    'icon' => 'bx-slider-alt',     'color' => 'secondary','route' => 'admin.options.index'],
                ['label' => 'ماشین‌ها',           'desc' => 'خودروها و دسته‌بندی‌ها',      'icon' => 'bx-car',            'color' => 'warning',  'route' => 'admin.cars.index'],
                ['label' => 'قیمت‌گذاری',         'desc' => 'نرخ شهر به شهر و پیش‌فرض',    'icon' => 'bx-money',          'color' => 'success',  'route' => 'admin.pricing_rules.index'],
                ['label' => 'تخفیف‌ها',           'desc' => 'کدهای تخفیف و گزارش استفاده', 'icon' => 'bxs-discount',      'color' => 'danger',   'route' => 'admin.discounts.index'],
                ['label' => 'نشان (لوکیشن‌ها)',   'desc' => 'مدیریت لوکیشن‌های نقشه',      'icon' => 'bx-map',            'color' => 'primary',  'route' => 'admin.neshan-locations.index'],
            ],
        ],
        [
            'title' => 'مدیریت محتوا',
            'icon'  => 'bx-edit',
            'items' => [
                ['label' => 'مقالات بلاگ',        'desc' => 'نوشته‌ها، دسته‌ها و برچسب‌ها', 'icon' => 'bx-news',           'color' => 'primary',  'route' => 'admin.blog-post.index'],
                ['label' => 'کامنت‌ها',           'desc' => 'مدیریت نظرات کاربران',        'icon' => 'bx-comment-detail', 'color' => 'info',     'route' => 'admin.blog-comment.index'],
                ['label' => 'صفحات',              'desc' => 'صفحات ثابت سایت',             'icon' => 'bx-dock-top',       'color' => 'secondary','route' => 'admin.page.index'],
                ['label' => 'سوالات متداول',      'desc' => 'مدیریت پرسش و پاسخ‌ها',       'icon' => 'bx-help-circle',    'color' => 'warning',  'route' => 'admin.faq.index'],
                ['label' => 'بیلبورد',            'desc' => 'بنرها و تبلیغات سایت',        'icon' => 'bx-image-alt',      'color' => 'success',  'route' => 'admin.billboard.index'],
            ],
        ],
        [
            'title' => 'ابزارها و کاربران',
            'icon'  => 'bx-cog',
            'items' => [
                ['label' => 'منوها',              'desc' => 'منوهای هدر، فوتر و کناری',    'icon' => 'bx-grid-alt',        'color' => 'info',    'route' => 'admin.menu.index', 'param' => Menu::POSITION_HEADER],
                ['label' => 'نقش‌ها',             'desc' => 'مدیریت نقش‌های کاربری',       'icon' => 'bx-universal-access','color' => 'primary', 'route' => 'admin.role.index'],
                ['label' => 'دسترسی‌ها',          'desc' => 'مدیریت مجوزهای دسترسی',       'icon' => 'bx-lock-alt',        'color' => 'danger',  'route' => 'admin.permission.index'],
            ],
        ],
    ];

    $userName = auth()->user()->name ?? auth()->user()->mobile ?? 'مدیر';
?>

<?php $__env->startSection('title', 'داشبورد مدیریت'); ?>
<?php $__env->startSection('description', 'پنل مدیریت وی‌آی‌پی تاکسی ایران'); ?>

<?php $__env->startSection('css'); ?>
<style>
    /* پس‌زمینه‌ی رنگی برای دیده‌شدن افکت شیشه‌ای */
    .dash-wrap { position: relative; z-index: 0; }
    .dash-blob {
        position: absolute; border-radius: 50%;
        filter: blur(70px); z-index: 0; pointer-events: none;
    }
    .dash-blob-1 { width: 340px; height: 340px; background: rgba(105,108,255,.45); top: -80px; right: -70px; }
    .dash-blob-2 { width: 300px; height: 300px; background: rgba(3,195,236,.30);  top: 180px; left: -90px; }
    .dash-blob-3 { width: 280px; height: 280px; background: rgba(113,221,55,.22);  bottom: -60px; right: 25%; }
    .dash-wrap > *:not(.dash-blob) { position: relative; z-index: 1; }

    /* هدر خوش‌آمد */
    .dash-hero {
        border: 1px solid rgba(255,255,255,.35);
        border-radius: 16px;
        background: linear-gradient(120deg, rgba(105,108,255,.92), rgba(138,141,255,.85));
        backdrop-filter: blur(8px);
        color: #fff; overflow: hidden; position: relative;
    }
    .dash-hero .bx-taxi {
        font-size: 6rem; opacity: .18; position: absolute;
        left: 1.5rem; top: 50%; transform: translateY(-50%);
    }

    /* کارت‌های آماری — شیشه‌ای */
    .stat-card {
        background: rgba(255,255,255,.55);
        -webkit-backdrop-filter: blur(16px) saturate(150%);
        backdrop-filter: blur(16px) saturate(150%);
        border: 1px solid rgba(255,255,255,.6);
        border-radius: 16px;
        padding: 1.15rem 1.25rem;
        box-shadow: 0 6px 22px rgba(67,89,113,.07);
        height: 100%;
        transition: transform .18s ease, box-shadow .18s ease;
    }
    .stat-card:hover { transform: translateY(-3px); box-shadow: 0 10px 26px rgba(67,89,113,.12); }
    .stat-label { color: #7a8699; font-size: .85rem; margin: 0; }
    .stat-value { color: #566a7f; font-weight: 700; margin: .35rem 0 0; line-height: 1.2; }
    .stat-value small { font-size: .7rem; font-weight: 500; color: #8a94a6; }
    .stat-icon {
        width: 48px; height: 48px; border-radius: 13px; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center; font-size: 1.55rem;
    }

    /* عنوان گروه‌ها */
    .dash-group-title {
        display: flex; align-items: center; gap: .5rem;
        font-weight: 600; color: #566a7f; margin: .25rem 0 1rem;
    }
    .dash-group-title .bx { color: #696cff; font-size: 1.35rem; }

    /* کارت‌های دسترسی سریع — شیشه‌ای */
    .dash-card {
        display: block; height: 100%;
        background: rgba(255,255,255,.5);
        -webkit-backdrop-filter: blur(14px) saturate(140%);
        backdrop-filter: blur(14px) saturate(140%);
        border: 1px solid rgba(255,255,255,.55);
        border-radius: 14px;
        padding: 1.15rem;
        text-decoration: none;
        box-shadow: 0 4px 16px rgba(67,89,113,.05);
        transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
    }
    .dash-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 .6rem 1.6rem rgba(67,89,113,.14);
        border-color: rgba(105,108,255,.6);
    }
    .dash-card .avatar-initial {
        width: 44px; height: 44px; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        border-radius: 12px; font-size: 1.4rem;
    }
    .dash-card .dash-title { color: #566a7f; font-weight: 600; margin: 0; }
    .dash-card .dash-desc { color: #98a2b3; font-size: .8125rem; margin: .15rem 0 0; }
    .dash-card .dash-arrow { color: #cfd6de; transition: color .18s ease, transform .18s ease; }
    .dash-card:hover .dash-arrow { color: #696cff; transform: translateX(-4px); }

    /* حالت تیره */
    html:not(.light-style) .stat-card,
    html:not(.light-style) .dash-card { background: rgba(40,42,66,.55); border-color: rgba(255,255,255,.08); }
    html:not(.light-style) .stat-value,
    html:not(.light-style) .dash-title { color: #cbd0dd; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="dash-wrap">
    <span class="dash-blob dash-blob-1"></span>
    <span class="dash-blob dash-blob-2"></span>
    <span class="dash-blob dash-blob-3"></span>

    
    <div class="dash-hero mb-4">
        <div class="p-4">
            <i class="bx bx-taxi"></i>
            <h4 class="mb-1 text-white fw-bold">سلام <?php echo e($userName); ?> 👋</h4>
            <p class="mb-0 text-white-50">به پنل مدیریت وی‌آی‌پی تاکسی ایران خوش آمدید.</p>
        </div>
    </div>

    
    <div class="row g-3 mb-4">
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-xl-3">
                <div class="stat-card">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <p class="stat-label"><?php echo e($card['label']); ?></p>
                            <h3 class="stat-value">
                                <?php echo e($card['value']); ?>

                                <?php if($card['suffix']): ?><small><?php echo e($card['suffix']); ?></small><?php endif; ?>
                            </h3>
                        </div>
                        <span class="stat-icon bg-label-<?php echo e($card['color']); ?>">
                            <i class="bx <?php echo e($card['icon']); ?>"></i>
                        </span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dash-group-title">
            <i class="bx <?php echo e($group['icon']); ?>"></i>
            <span><?php echo e($group['title']); ?></span>
        </div>

        <div class="row g-3 mb-4">
            <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    try {
                        $href = isset($item['param'])
                            ? route($item['route'], $item['param'])
                            : route($item['route']);
                    } catch (\Throwable $e) {
                        $href = null; // اگر روتی موجود نبود، کارت رندر نمی‌شود
                    }
                ?>
                <?php if($href): ?>
                    <div class="col-sm-6 col-lg-4 col-xxl-3">
                        <a href="<?php echo e($href); ?>" class="dash-card">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="avatar-initial rounded bg-label-<?php echo e($item['color']); ?>">
                                        <i class="bx <?php echo e($item['icon']); ?>"></i>
                                    </span>
                                    <div>
                                        <h6 class="dash-title"><?php echo e($item['label']); ?></h6>
                                        <p class="dash-desc"><?php echo e($item['desc']); ?></p>
                                    </div>
                                </div>
                                <i class="bx bx-chevron-left dash-arrow bx-sm"></i>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>