<?php if (isset($component)) { $__componentOriginala738248314269eb64f09554d85bed5d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala738248314269eb64f09554d85bed5d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'billboard::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('billboard::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('billboard.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala738248314269eb64f09554d85bed5d9)): ?>
<?php $attributes = $__attributesOriginala738248314269eb64f09554d85bed5d9; ?>
<?php unset($__attributesOriginala738248314269eb64f09554d85bed5d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala738248314269eb64f09554d85bed5d9)): ?>
<?php $component = $__componentOriginala738248314269eb64f09554d85bed5d9; ?>
<?php unset($__componentOriginala738248314269eb64f09554d85bed5d9); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/index.blade.php ENDPATH**/ ?>