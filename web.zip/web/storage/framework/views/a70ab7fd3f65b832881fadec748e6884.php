<?php $__env->startSection('title', $metaTitle ?? ($post->title ?? 'مقاله')); ?>
<?php $__env->startSection('description', $metaDescription ?? ''); ?>

<?php
    use Modules\Blog\Models\BlogPost;
?>
<?php $__env->startPush('styles'); ?>
    <style>
        .post-navigation {
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            padding: 20px 0;
        }
        .post-navigation a {
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        .post-navigation a:hover {
            color: #aa8453;
        }
        .post-navigation h6 {
            font-size: 14px;
            margin-top: 5px;
        }
        .widget {
            background: #f9f9f9;
            padding: 25px;
            border-radius: 8px;
        }
        .widget-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #aa8453;
            color: #333;
        }
        .widget ul li a {
            text-decoration: none;
            color: #555;
            transition: all 0.3s ease;
            padding: 8px 0;
        }
        .widget ul li a:hover {
            color: #aa8453;
            padding-right: 5px;
        }
        .recent-post-item a,
        .related-post-item a {
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        .recent-post-item a:hover,
        .related-post-item a:hover {
            color: #aa8453;
        }
        .recent-post-item img,
        .related-post-item img {
            object-fit: cover;
            height: 60px;
        }
        .post-tags {
            border-top: 1px solid #e0e0e0;
            padding-top: 20px;
        }
        .tag-link {
            display: inline-block;
            padding: 5px 15px;
            background: #f0f0f0;
            border-radius: 20px;
            margin: 5px;
            text-decoration: none;
            color: #555;
            transition: all 0.3s ease;
        }
        .tag-link:hover {
            background: #aa8453;
            color: #fff;
        }
        .post-summary-box {
            border: 1px solid #e6e0d7;
            border-right: 4px solid #aa8453;
            border-radius: 8px;
            background: #fffaf3;
            padding: 18px 20px;
        }
        .post-summary-box h2 {
            font-size: 20px;
            margin-bottom: 12px;
            color: #333;
        }
        .post-summary-box p {
            margin-bottom: 0;
            line-height: 2;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>

    <!-- Header Banner -->
    <section class="banner-header section-padding bg-img" data-overlay-dark="5" data-background="<?php echo e(!empty($post->thumbnail) ? asset('storage/' . $post->thumbnail) : asset('site/img/slider/1.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="post-wrapper">
                            <div><a href="<?php echo e(route('home')); ?>" class="text-white">خانه</a></div>
                            <div class="divider"></div>
                            <div class="text-white"><a href="<?php echo e(route('blog.index')); ?>">مقاله</a></div>
                            <?php if(isset($post->category) && $post->category): ?>
                                <div class="divider"></div>
                                <div class="text-white"><a href="<?php echo e(route('blog.category', $post->category->en_slug ?? '#')); ?>"><?php echo e($post->category->name ?? ''); ?></a></div>
                            <?php endif; ?>
                        </div>
                        <h1><?php echo e($post->title ?? 'بدون عنوان'); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Post -->
    <?php if(!empty($post->thumbnail)): ?>
        <div class="row mt-4">
            <div class="col-md-12 mb-30">
                <img src="<?php echo e(asset('storage/' . $post->thumbnail)); ?>" class="rounded-4 img-fluid" alt="<?php echo e($post->title ?? 'مقاله'); ?>">
            </div>
        </div>
    <?php endif; ?>
    <section class="post section-padding">
        <div class="container">
            <div class="row">
                <!-- محتوای اصلی مقاله -->
                <div class="col-lg-8 col-md-12 mb-30">
                    <?php if(!empty($articleSummary)): ?>
                        <div class="post-summary-box mb-30">
                            <h2>خلاصه مطلب</h2>
                            <p><?php echo e($articleSummary); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="post-content">
                        <?php echo $post->body ?? ''; ?>

                    </div>

                    <?php if(isset($post->tags) && $post->tags->count() > 0): ?>
                        <div class="post-tags mt-30">
                            <strong>برچسب‌ها: </strong>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('blog.tag', $tag->en_slug ?? '#')); ?>" class="tag-link"><?php echo e($tag->tag_title ?? ''); ?></a><?php if(!$loop->last): ?>, <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <!-- مقاله قبلی و بعدی -->
                    <?php if($previousPost || $nextPost): ?>
                        <div class="post-navigation mt-5">
                            <div class="row">
                                <?php if($previousPost): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="nav-previous">
                                            <a href="<?php echo e(route('blog.show', $previousPost->en_slug)); ?>" class="d-flex align-items-center">
                                                <i class="ti-arrow-right me-2"></i>
                                                <div>
                                                    <small class="text-muted">مقاله قبلی</small>
                                                    <h6 class="mb-0"><?php echo e(Str::limit($previousPost->title, 50)); ?></h6>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if($nextPost): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="nav-next text-end">
                                            <a href="<?php echo e(route('blog.show', $nextPost->en_slug)); ?>" class="d-flex align-items-center justify-content-end">
                                                <div>
                                                    <small class="text-muted">مقاله بعدی</small>
                                                    <h6 class="mb-0"><?php echo e(Str::limit($nextPost->title, 50)); ?></h6>
                                                </div>
                                                <i class="ti-arrow-left ms-2"></i>
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4 col-md-12">
                    <!-- دسته‌بندی‌ها -->
                    <?php if(isset($categories) && $categories->count() > 0): ?>
                        <div class="widget mb-40">
                            <h5 class="widget-title">دسته‌بندی‌ها</h5>
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="mb-2">
                                        <a href="<?php echo e(route('blog.category', $category->en_slug ?? '#')); ?>" class="d-flex justify-content-between align-items-center">
                                            <span><?php echo e($category->name ?? ''); ?></span>
                                            <span class="badge bg-secondary"><?php echo e($category->posts()->where('is_active', 1)->where('status', BlogPost::STATUS_PUBLISHED)->count()); ?></span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <!-- جدیدترین مقالات -->
                    <?php if(isset($recentPosts) && $recentPosts->count() > 0): ?>
                        <div class="widget mb-40">
                            <h5 class="widget-title">جدیدترین مقالات</h5>
                            <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recent-post-item mb-3">
                                    <div class="row">
                                        <?php if(!empty($recentPost->thumbnail)): ?>
                                            <div class="col-4">
                                                <a href="<?php echo e(route('blog.show', $recentPost->en_slug)); ?>">
                                                    <img src="<?php echo e(asset('storage/' . $recentPost->thumbnail)); ?>" class="img-fluid rounded" alt="<?php echo e($recentPost->title); ?>">
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="<?php echo e(!empty($recentPost->thumbnail) ? 'col-8' : 'col-12'); ?>">
                                            <h6 class="mb-1">
                                                <a href="<?php echo e(route('blog.show', $recentPost->en_slug)); ?>"><?php echo e(Str::limit($recentPost->title, 60)); ?></a>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="ti-calendar"></i>
                                                <?php echo e(verta($recentPost->published_at)->format('d F Y')); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <!-- مقالات مرتبط -->
                    <?php if(isset($relatedPosts) && $relatedPosts->count() > 0): ?>
                        <div class="widget mb-40">
                            <h5 class="widget-title">مقالات مرتبط</h5>
                            <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="related-post-item mb-3">
                                    <div class="row">
                                        <?php if(!empty($relatedPost->thumbnail)): ?>
                                            <div class="col-4">
                                                <a href="<?php echo e(route('blog.show', $relatedPost->en_slug)); ?>">
                                                    <img src="<?php echo e(asset('storage/' . $relatedPost->thumbnail)); ?>" class="img-fluid rounded" alt="<?php echo e($relatedPost->title); ?>">
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="<?php echo e(!empty($relatedPost->thumbnail) ? 'col-8' : 'col-12'); ?>">
                                            <h6 class="mb-1">
                                                <a href="<?php echo e(route('blog.show', $relatedPost->en_slug)); ?>"><?php echo e(Str::limit($relatedPost->title, 60)); ?></a>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="ti-calendar"></i>
                                                <?php echo e(verta($relatedPost->published_at)->format('d F Y')); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.site.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/site/show.blade.php ENDPATH**/ ?>