<form method="POST" enctype="multipart/form-data"
    action="<?php if($permission): ?> <?php echo e(route('admin.permission.update', ['permission' => $permission])); ?>

      <?php else: ?> <?php echo e(route('admin.permission.store')); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($permission): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if(!$permission): ?>
        <div class="d-flex mb-3 flex-wrap gap-3">
            <div class="col-12 col-lg-4 col-md-6">
                <label class="form-label" for="name">
                    <span>guard</span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_web" value="web"
                        <?php echo e((collect(old('guard_name'))->contains('web')) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="guard_web">web</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_api" value="api"
                        <?php echo e((collect(old('guard_name'))->contains('api')) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="guard_api">api</label>
                </div>
                <?php $__errorArgs = ['guard_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-4 col-md-6">
            <label class="form-label" for="name">
                <span>نام</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="<?php echo e(old('name', $permission ? $permission->name : '')); ?>">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Permission/resources/views/admin/permission/partials/form.blade.php ENDPATH**/ ?>