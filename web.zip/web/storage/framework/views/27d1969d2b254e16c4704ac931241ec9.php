<?php $__env->startSection('title', 'رسانه'); ?>

<?php
    use Illuminate\Support\Facades\Storage;
    use Modules\Attachment\Models\Attachment;

    $typeLabels = [
        Attachment::FILE_TYPE_IMAGE => 'تصویر',
        Attachment::FILE_TYPE_VIDEO => 'ویدئو',
        Attachment::FILE_TYPE_AUDIO => 'صدا',
        Attachment::FILE_TYPE_DOCUMENT => 'سند',
        Attachment::FILE_TYPE_OTHER => 'سایر',
    ];

    $humanSize = function ($bytes) {
        $bytes = (float) $bytes;
        return $bytes >= 1048576
            ? number_format($bytes / 1048576, 2) . ' MB'
            : number_format($bytes / 1024, 1) . ' KB';
    };
?>

<?php $__env->startSection('css'); ?>
    <style>
        .media-summary {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: .75rem;
        }
        .media-summary-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            padding: .85rem;
            background: #fff;
        }
        .media-summary-item span {
            display: block;
            color: #7f8ea3;
            font-size: .76rem;
            margin-bottom: .35rem;
        }
        .media-summary-item strong {
            color: #4f6074;
            font-size: 1.15rem;
        }
        .media-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 1rem;
        }
        .media-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }
        .media-preview {
            aspect-ratio: 4 / 3;
            background: #f5f6fa;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .media-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .media-preview i {
            font-size: 2.2rem;
            color: #8b9ab0;
        }
        .media-body {
            padding: .85rem;
        }
        .media-name {
            font-size: .84rem;
            font-weight: 600;
            color: #4f6074;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .media-meta {
            color: #7f8ea3;
            font-size: .76rem;
            line-height: 1.6;
        }
        .media-actions {
            display: flex;
            gap: .35rem;
            flex-wrap: wrap;
        }
        @media (max-width: 1199px) {
            .media-summary,
            .media-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        }
        @media (max-width: 767px) {
            .media-summary,
            .media-grid { grid-template-columns: 1fr; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            رسانه
        </h4>
    </div>

    <?php if($tableMissing): ?>
        <div class="alert alert-warning">
            جدول‌های رسانه هنوز در دیتابیس ساخته نشده‌اند. بعد از اجرای migrationهای Attachment، این بخش فعال می‌شود.
        </div>
    <?php endif; ?>

    <div class="media-summary mb-4">
        <div class="media-summary-item"><span>کل فایل‌ها</span><strong><?php echo e($summary['total']); ?></strong></div>
        <div class="media-summary-item"><span>تصاویر</span><strong><?php echo e($summary['images']); ?></strong></div>
        <div class="media-summary-item"><span>تصاویر فایل‌سیستم</span><strong><?php echo e($summary['public_images']); ?></strong></div>
        <div class="media-summary-item"><span>بدون اتصال</span><strong><?php echo e($summary['unused']); ?></strong></div>
        <div class="media-summary-item"><span>تصویر بدون ALT</span><strong><?php echo e($summary['without_alt']); ?></strong></div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.media.store')); ?>" enctype="multipart/form-data" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">افزودن فایل</label>
                    <input type="file" name="file" class="form-control" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-5 col-md-6">
                    <label class="form-label">ALT تصویر</label>
                    <input type="text" name="image_alt" class="form-control" maxlength="255" placeholder="متن جایگزین تصویر" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-3">
                    <button class="btn btn-success" type="submit" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-upload"></i>
                        آپلود
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.media.index')); ?>" class="row g-3 align-items-end">
                <div class="col-lg-5 col-md-6">
                    <label class="form-label">جستجو</label>
                    <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="نام فایل، مسیر یا نوع">
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نوع فایل</label>
                    <select name="type" class="form-select">
                        <option value="">همه</option>
                        <?php $__currentLoopData = $typeLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>" <?php if(request('type') === $type): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-4 d-flex gap-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bx bx-search"></i>
                        جستجو
                    </button>
                    <a href="<?php echo e(route('admin.media.index')); ?>" class="btn btn-outline-secondary">پاک کردن</a>
                </div>
            </form>
        </div>
    </div>

    <form method="POST" action="<?php echo e(route('admin.media.bulkDestroy')); ?>" id="bulkDeleteMediaForm" class="d-none">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>

    <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap mb-3">
        <div class="text-muted"><?php echo e($attachments->total()); ?> فایل ثبت‌شده در دیتابیس</div>
        <button class="btn btn-outline-danger" type="submit" form="bulkDeleteMediaForm" id="bulkDeleteMediaButton" disabled>
            <i class="bx bx-trash"></i>
            حذف انتخاب‌شده‌ها
        </button>
    </div>

    <div class="media-grid">
        <?php $__empty_1 = true; $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $url = Storage::disk($attachment->disk)->url($attachment->path);
                $alt = $attachment->display_alt ?? $attachment->meta->firstWhere('attribute', 'image_alt')?->value;
                $isImage = $attachment->file_type === Attachment::FILE_TYPE_IMAGE;
                $isUsed = $attachment->attachables->isNotEmpty();
            ?>
            <div class="media-item">
                <div class="media-preview">
                    <?php if($isImage): ?>
                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener">
                            <img src="<?php echo e($url); ?>" alt="<?php echo e($alt ?: $attachment->file_name); ?>">
                        </a>
                    <?php else: ?>
                        <i class="bx bx-file"></i>
                    <?php endif; ?>
                </div>
                <div class="media-body">
                    <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                        <div class="media-name" title="<?php echo e($attachment->file_name); ?>"><?php echo e($attachment->file_name); ?></div>
                        <?php if(! $isUsed): ?>
                            <input class="form-check-input media-checkbox" type="checkbox" name="attachment_ids[]" value="<?php echo e($attachment->id); ?>" form="bulkDeleteMediaForm" aria-label="انتخاب <?php echo e($attachment->file_name); ?>">
                        <?php else: ?>
                            <span class="badge bg-label-secondary">در حال استفاده</span>
                        <?php endif; ?>
                    </div>

                    <div class="media-meta mb-2">
                        <div><?php echo e($typeLabels[$attachment->file_type] ?? $attachment->file_type); ?> | <?php echo e($humanSize($attachment->file_size)); ?></div>
                        <div dir="ltr"><?php echo e($attachment->path); ?></div>
                        <div><?php echo e($attachment->mime_type); ?></div>
                    </div>

                    <?php if($isImage): ?>
                        <form method="POST" action="<?php echo e(route('admin.media.update', $attachment)); ?>" class="mb-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label class="form-label mb-1">ALT</label>
                            <?php if(($attachment->alt_source ?? 'saved') === 'suggested'): ?>
                                <span class="badge bg-label-info mb-1">پیشنهادی</span>
                            <?php endif; ?>
                            <div class="input-group input-group-sm">
                                <input type="text" name="image_alt" class="form-control" value="<?php echo e($alt); ?>" maxlength="255" placeholder="ALT تصویر">
                                <button class="btn btn-outline-primary" type="submit">
                                    <i class="bx bx-save"></i>
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>

                    <div class="media-actions">
                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-info">
                            <i class="bx bx-show"></i>
                            مشاهده
                        </a>
                        <?php if(! $isUsed): ?>
                            <form method="POST" action="<?php echo e(route('admin.media.destroy', $attachment)); ?>" class="d-inline single-delete-media-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                    <i class="bx bx-trash"></i>
                                    حذف
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body text-center text-muted py-5">فایلی یافت نشد.</div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4">
        <?php echo e($attachments->links('pagination::bootstrap-5')); ?>

    </div>

    <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap mt-5 mb-3">
        <h5 class="mb-0">تصاویر موجود روی فایل‌سیستم</h5>
        <span class="text-muted"><?php echo e($publicImages->total()); ?> تصویر فایل‌سیستم</span>
    </div>

    <div class="alert alert-info">
        این بخش عکس‌هایی را نشان می‌دهد که واقعاً داخل فایل‌سیستم سایت وجود دارند. حذف فایل‌ها برای جلوگیری از خطای Production فقط از بخش فایل‌های ثبت‌شده در دیتابیس انجام می‌شود، اما متن جایگزین این تصاویر از همین‌جا قابل ویرایش است.
    </div>

    <div class="media-grid">
        <?php $__empty_1 = true; $__currentLoopData = $publicImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="media-item">
                <div class="media-preview">
                    <a href="<?php echo e($image['url']); ?>" target="_blank" rel="noopener">
                        <img src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['alt'] ?: $image['name']); ?>">
                    </a>
                </div>
                <div class="media-body">
                    <div class="media-name" title="<?php echo e($image['name']); ?>"><?php echo e($image['name']); ?></div>
                    <div class="media-meta mb-2">
                        <div><?php echo e(strtoupper($image['extension'])); ?> | <?php echo e($humanSize($image['size'])); ?></div>
                        <div dir="ltr"><?php echo e($image['relative']); ?></div>
                        <div>آخرین تغییر: <?php echo e($image['modified_at']); ?></div>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.media.filesystemAlt')); ?>" class="mb-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="image_path" value="<?php echo e($image['relative']); ?>">
                        <label class="form-label mb-1">متن جایگزین تصویر</label>
                        <?php if(($image['alt_source'] ?? 'saved') === 'suggested'): ?>
                            <span class="badge bg-label-info mb-1">پیشنهادی</span>
                        <?php endif; ?>
                        <div class="input-group input-group-sm">
                            <input type="text" name="image_alt" class="form-control" value="<?php echo e($image['alt']); ?>" maxlength="255" placeholder="متن جایگزین تصویر">
                            <button class="btn btn-outline-primary" type="submit">
                                <i class="bx bx-save"></i>
                            </button>
                        </div>
                    </form>
                    <div class="media-actions">
                        <a href="<?php echo e($image['url']); ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-info">
                            <i class="bx bx-show"></i>
                            مشاهده
                        </a>
                        <span class="badge bg-label-secondary align-self-center">فایل‌سیستم</span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body text-center text-muted py-5">تصویری روی فایل‌سیستم یافت نشد.</div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4">
        <?php echo e($publicImages->links('pagination::bootstrap-5')); ?>

    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            const mediaCheckboxes = document.querySelectorAll('.media-checkbox');
            const bulkDeleteMediaButton = document.getElementById('bulkDeleteMediaButton');
            const bulkDeleteMediaForm = document.getElementById('bulkDeleteMediaForm');

            function updateMediaBulkState() {
                const selected = document.querySelectorAll('.media-checkbox:checked').length;
                bulkDeleteMediaButton.disabled = selected === 0;
                bulkDeleteMediaButton.innerHTML = '<i class="bx bx-trash"></i> حذف انتخاب‌شده‌ها' + (selected ? ' (' + selected + ')' : '');
            }

            mediaCheckboxes.forEach((checkbox) => checkbox.addEventListener('change', updateMediaBulkState));

            if (bulkDeleteMediaForm) {
                bulkDeleteMediaForm.addEventListener('submit', function (event) {
                    const selected = document.querySelectorAll('.media-checkbox:checked').length;
                    if (!selected || !confirm(selected + ' فایل بدون اتصال حذف می‌شود. ادامه می‌دهید؟')) {
                        event.preventDefault();
                    }
                });
            }

            document.querySelectorAll('.single-delete-media-form').forEach((form) => {
                form.addEventListener('submit', function (event) {
                    if (!confirm('این فایل بدون اتصال حذف می‌شود. ادامه می‌دهید؟')) {
                        event.preventDefault();
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/media/index.blade.php ENDPATH**/ ?>