<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.popular-routes.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.popular-routes.index')); ?>">مسیرهای پرطرفدار/</a></span>
        لیست مسیرهای پرطرفدار
    </h4>

    <a href="<?php echo e(route('admin.popular-routes.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن مسیر پرطرفدار</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>عنوان</th>
                <th>مبدا</th>
                <th>مقصد</th>
                <th>ترتیب</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $popularRoutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($popularRoutes->currentPage() - 1) * $popularRoutes->perPage() + $key + 1); ?></td>
                    <td><?php echo e($route->title); ?></td>
                    <td><?php echo e(Str::limit($route->origin_address, 30)); ?></td>
                    <td><?php echo e(Str::limit($route->destination_address, 30)); ?></td>
                    <td><?php echo e($route->sort_order); ?></td>
                    <td>
                        <?php if($route->is_active): ?>
                            <span class="badge bg-success">فعال</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">غیرفعال</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.popular-routes.edit', $route)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.popular-routes.destroy', $route)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف" type="submit" onclick="return confirm('آیا از حذف این مسیر اطمینان دارید؟');"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($popularRoutes->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/popular-routes/index.blade.php ENDPATH**/ ?>