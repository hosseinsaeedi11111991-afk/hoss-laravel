<?php $__env->startSection('title', 'مدیریت نقش ها'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span>مدیریت نقش ها</span>
</h4>

<a href="<?php echo e(route('admin.role.create')); ?>" type="button" class="btn rounded-pill me-2 btn-success">تعریف نقش جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>Guard</th>
                <th>نام صفحه</th>
                <th>دسترسی‌ها</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($row->guard_name); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td>
                    <?php if(count($row->permissions) > 0): ?>
                        <?php echo e($row->permissions->pluck('name')->join(', ')); ?>

                    <?php else: ?>
                        <i>دسترسی تعریف نشده</i>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('admin.role.edit', $row->id)); ?>"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="<?php echo e(route('admin.role.destroy', $row->id)); ?>"
                            class="delete-form d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-4">
    <?php echo e($roles->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Permission/resources/views/admin/role/index.blade.php ENDPATH**/ ?>