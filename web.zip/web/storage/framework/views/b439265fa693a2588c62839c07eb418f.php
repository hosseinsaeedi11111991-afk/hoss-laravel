<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">آپشن‌ها/</a></span>
        ویرایش آپشن
    </h4>

    <form action="<?php echo e(route('admin.options.update', $option)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">نام آپشن <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $option->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">برای همه ماشین‌ها (پیش‌فرض)</option>
                    <?php $__currentLoopData = $carCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('car_category_id', $option->car_category_id) == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['car_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">نوع <span class="text-danger">*</span></label>
                <select name="type" class="form-select" required>
                    <option value="text" <?php echo e(old('type',$option->type)=='text' ? 'selected' : ''); ?>>متن</option>
                    <option value="checkbox" <?php echo e(old('type',$option->type)=='checkbox' ? 'selected' : ''); ?>>چک‌باکس</option>
                </select>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">نوع محاسبه <span class="text-danger">*</span></label>
                <select name="pricing_type" class="form-select" required>
                    <option value="fixed" <?php echo e(old('pricing_type',$option->pricing_type)=='fixed' ? 'selected' : ''); ?>>قیمت ثابت</option>
                    <option value="per_km" <?php echo e(old('pricing_type',$option->pricing_type)=='per_km' ? 'selected' : ''); ?>>به‌ازای هر کیلومتر</option>
                    <option value="percentage" <?php echo e(old('pricing_type',$option->pricing_type)=='percentage' ? 'selected' : ''); ?>>محاسبه درصدی</option>
                </select>
                <?php $__errorArgs = ['pricing_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت ثابت (تومان)</label>
                <input type="number" step="0.01" name="fixed_price" class="form-control" value="<?php echo e(old('fixed_price', $option->fixed_price)); ?>" min="0">
                <?php $__errorArgs = ['fixed_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان)</label>
                <input type="number" step="0.01" name="per_km_price" class="form-control" value="<?php echo e(old('per_km_price', $option->per_km_price)); ?>" min="0">
                <?php $__errorArgs = ['per_km_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">درصد قیمت (%)</label>
                <input type="number" step="0.01" name="percentage_price" class="form-control" value="<?php echo e(old('percentage_price', $option->percentage_price ?? 0)); ?>" min="0" max="100">
                <?php $__errorArgs = ['percentage_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/options/edit.blade.php ENDPATH**/ ?>