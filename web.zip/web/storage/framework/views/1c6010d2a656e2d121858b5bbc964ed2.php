
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">تخفیف‌ها/</a></span>
        لیست تخفیف‌ها
    </h4>

    <a href="<?php echo e(route('admin.discounts.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن تخفیف</a>

    <!-- فرم جستجو -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">جستجو و فیلتر</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.discounts.index')); ?>">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">عنوان</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(request('title')); ?>" placeholder="جستجو...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">کد تخفیف</label>
                        <input type="text" name="code" class="form-control" value="<?php echo e(request('code')); ?>" placeholder="جستجو...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">وضعیت</label>
                        <select name="is_active" class="form-select">
                            <option value="">همه</option>
                            <option value="1" <?php echo e(request('is_active') == '1' ? 'selected' : ''); ?>>فعال</option>
                            <option value="0" <?php echo e(request('is_active') == '0' ? 'selected' : ''); ?>>غیرفعال</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">نوع فعال‌سازی</label>
                        <select name="trigger_type" class="form-select">
                            <option value="">همه</option>
                            <option value="code" <?php echo e(request('trigger_type') == 'code' ? 'selected' : ''); ?>>کد</option>
                            <option value="automatic" <?php echo e(request('trigger_type') == 'automatic' ? 'selected' : ''); ?>>خودکار</option>
                            <option value="both" <?php echo e(request('trigger_type') == 'both' ? 'selected' : ''); ?>>کد و خودکار</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">اولویت</label>
                        <select name="priority" class="form-select">
                            <option value="">همه</option>
                            <option value="high" <?php echo e(request('priority') == 'high' ? 'selected' : ''); ?>>بالا</option>
                            <option value="medium" <?php echo e(request('priority') == 'medium' ? 'selected' : ''); ?>>متوسط</option>
                            <option value="low" <?php echo e(request('priority') == 'low' ? 'selected' : ''); ?>>پایین</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary me-2">جستجو</button>
                        <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-secondary">پاک کردن</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>عنوان</th>
                <th>کد</th>
                <th>نوع</th>
                <th>مقدار</th>
                <th>نوع فعال‌سازی</th>
                <th>اولویت</th>
                <th>استفاده شده</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($discounts->currentPage() - 1) * $discounts->perPage() + $key + 1); ?></td>
                    <td><?php echo e($discount->title); ?></td>
                    <td><?php echo e($discount->code ?? '-'); ?></td>
                    <td><?php echo e($discount->getDiscountTypeLabel()); ?></td>
                    <td>
                        <?php if($discount->isPercentage()): ?>
                            <?php echo e($discount->discount_value); ?>%
                        <?php else: ?>
                            <?php echo e(number_format($discount->discount_value)); ?> تومان
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($discount->getTriggerTypeLabel()); ?></td>
                    <td>
                        <span class="badge 
                            <?php if($discount->priority == 'high'): ?> bg-danger
                            <?php elseif($discount->priority == 'medium'): ?> bg-warning
                            <?php else: ?> bg-secondary
                            <?php endif; ?>">
                            <?php echo e($discount->getPriorityLabel()); ?>

                        </span>
                    </td>
                    <td><?php echo e($discount->current_usage_count); ?> / <?php echo e($discount->usage_limit ?? '∞'); ?></td>
                    <td>
                        <?php if($discount->is_active): ?>
                            <span class="badge bg-success">فعال</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">غیرفعال</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.discounts.show', $discount)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.discounts.edit', $discount)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.discounts.destroy', $discount)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($discounts->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Discount/resources/views/admin/discounts/index.blade.php ENDPATH**/ ?>