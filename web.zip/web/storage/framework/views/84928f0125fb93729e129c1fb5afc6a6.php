<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.categories.index')); ?>">دسته‌بندی ماشین‌ها/</a></span>
        مشاهده دسته‌بندی
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات دسته‌بندی</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>عنوان:</strong> <?php echo e($car_category->title); ?></li>
                        <li class="list-group-item"><strong>نوع:</strong> <?php echo e(\Modules\Cars\Models\CarCategory::TYPES[$car_category->type] ?? '-'); ?></li>
                        <li class="list-group-item">
                            <strong>لوگو:</strong><br>
                            <?php if($car_category->logo): ?>
                                <img src="<?php echo e(Storage::url($car_category->logo)); ?>" width="120" class="rounded border mt-2">
                            <?php else: ?>
                                <span class="text-muted">بدون لوگو</span>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item"><strong>توضیحات:</strong> <?php echo e($car_category->description ?? 'بدون توضیحات'); ?></li>
                        <li class="list-group-item"><strong>نوع قیمت:</strong> <?php echo e($car_category->price_type_label); ?></li>
                        <li class="list-group-item">
                            <strong>قیمت:</strong>
                            <?php if($car_category->price_type === 'fixed'): ?>
                                <?php echo e(number_format($car_category->fixed_price ?? 0)); ?> تومان (ثابت)
                            <?php elseif($car_category->price_type === 'per_km'): ?>
                                <?php echo e(number_format($car_category->price_per_km ?? 0)); ?> تومان به ازای هر کیلومتر
                            <?php else: ?>
                                توافقی
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($car_category->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($car_category->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/car_categories/show.blade.php ENDPATH**/ ?>