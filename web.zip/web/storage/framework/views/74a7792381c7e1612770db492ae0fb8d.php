<?php $__env->startSection('title', 'تنظیمات پیامک'); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            تنظیمات پیامک
        </h4>
        <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo e(route('admin.sms-settings.index', ['check' => 'balance'])); ?>" class="btn btn-outline-primary">
                <i class="bx bx-wallet"></i>
                استعلام موجودی
            </a>
            <a href="<?php echo e(route('admin.sms-settings.index', ['check' => 'profile'])); ?>" class="btn btn-outline-secondary">
                <i class="bx bx-user-check"></i>
                استعلام پروفایل
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($remoteError): ?>
        <div class="alert alert-warning"><?php echo e($remoteError); ?></div>
    <?php endif; ?>

    <?php if($settingsTableMissing): ?>
        <div class="alert alert-warning">
            جدول تنظیمات پیامک هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، امکان ویرایش از داشبورد فعال می‌شود.
        </div>
    <?php elseif($earlyPhoneSettingsMissing): ?>
        <div class="alert alert-warning">
            ستون‌های تنظیم دریافت شماره قبل از نمایش قیمت هنوز در دیتابیس ساخته نشده‌اند. بعد از اجرای migration، این دو گزینه فعال می‌شوند.
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <p class="text-muted mb-1">وضعیت سرویس</p>
                            <h5 class="mb-0"><?php echo e($configured ? 'فعال' : 'پیکربندی نشده'); ?></h5>
                        </div>
                        <span class="badge bg-label-<?php echo e($configured ? 'success' : 'danger'); ?>">
                            <?php echo e($configured ? 'API Key موجود است' : 'API Key خالی است'); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <p class="text-muted mb-1">ارائه‌دهنده</p>
                    <h5 class="mb-1"><?php echo e($settings['provider']); ?></h5>
                    <div class="small text-muted" dir="ltr"><?php echo e($settings['base_url']); ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <p class="text-muted mb-1">کلید API</p>
                    <h5 class="mb-0" dir="ltr"><?php echo e($settings['api_key_masked']); ?></h5>
                    <div class="small text-muted mt-2">کلید کامل نمایش داده نمی‌شود و از تنظیمات امن سرور خوانده می‌شود.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">ویرایش تنظیمات غیرحساس پیامک</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.sms-settings.update')); ?>" class="row g-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col-lg-6">
                    <label class="form-label" for="sender">شماره فرستنده</label>
                    <input
                        type="text"
                        id="sender"
                        name="sender"
                        class="form-control <?php $__errorArgs = ['sender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('sender', $settings['sender'])); ?>"
                        dir="ltr"
                        <?php if($settingsTableMissing): echo 'disabled'; endif; ?>
                    >
                    <?php $__errorArgs = ['sender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6">
                    <label class="form-label" for="reservation_admin_recipient">شماره مدیر گیرنده پیامک رزرو</label>
                    <input
                        type="text"
                        id="reservation_admin_recipient"
                        name="reservation_admin_recipient"
                        class="form-control <?php $__errorArgs = ['reservation_admin_recipient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('reservation_admin_recipient', $settings['admin_recipient'])); ?>"
                        dir="ltr"
                        <?php if($settingsTableMissing): echo 'disabled'; endif; ?>
                    >
                    <?php $__errorArgs = ['reservation_admin_recipient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6">
                    <label class="form-label" for="reservation_admin_pattern">Pattern مدیر</label>
                    <input
                        type="text"
                        id="reservation_admin_pattern"
                        name="reservation_admin_pattern"
                        class="form-control <?php $__errorArgs = ['reservation_admin_pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('reservation_admin_pattern', $settings['admin_pattern'])); ?>"
                        dir="ltr"
                        <?php if($settingsTableMissing): echo 'disabled'; endif; ?>
                    >
                    <?php $__errorArgs = ['reservation_admin_pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6">
                    <label class="form-label" for="reservation_passenger_pattern">Pattern مسافر</label>
                    <input
                        type="text"
                        id="reservation_passenger_pattern"
                        name="reservation_passenger_pattern"
                        class="form-control <?php $__errorArgs = ['reservation_passenger_pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('reservation_passenger_pattern', $settings['passenger_pattern'])); ?>"
                        dir="ltr"
                        <?php if($settingsTableMissing): echo 'disabled'; endif; ?>
                    >
                    <?php $__errorArgs = ['reservation_passenger_pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6">
                    <div class="form-check form-switch mt-4">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="require_phone_before_route_calculation"
                            name="require_phone_before_route_calculation"
                            value="1"
                            <?php if(old('require_phone_before_route_calculation', $settings['require_phone_before_route_calculation'])): echo 'checked'; endif; ?>
                            <?php if($settingsTableMissing || $earlyPhoneSettingsMissing): echo 'disabled'; endif; ?>
                        >
                        <label class="form-check-label fw-semibold" for="require_phone_before_route_calculation">
                            دریافت شماره موبایل قبل از نمایش قیمت
                        </label>
                    </div>
                    <div class="small text-muted mt-1">
                        در حالت خاموش، کاربر بدون وارد کردن موبایل مسیر و قیمت را می‌بیند.
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-check form-switch mt-4">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="send_sms_after_early_phone_capture"
                            name="send_sms_after_early_phone_capture"
                            value="1"
                            <?php if(old('send_sms_after_early_phone_capture', $settings['send_sms_after_early_phone_capture'])): echo 'checked'; endif; ?>
                            <?php if($settingsTableMissing || $earlyPhoneSettingsMissing || ! old('require_phone_before_route_calculation', $settings['require_phone_before_route_calculation'])): echo 'disabled'; endif; ?>
                        >
                        <label class="form-check-label fw-semibold" for="send_sms_after_early_phone_capture">
                            ارسال پیامک پس از دریافت شماره موبایل
                        </label>
                    </div>
                    <div class="small text-muted mt-1">
                        فقط وقتی گزینه دریافت شماره قبل از نمایش قیمت فعال باشد استفاده می‌شود و روی پیامک رزرو نهایی اثری ندارد.
                    </div>
                </div>

                <div class="col-12 d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary" <?php if($settingsTableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-save"></i>
                        ذخیره تنظیمات
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">تنظیمات خواندنی سرویس</h5>
        </div>
        <div class="table-responsive">
            <table class="table">
                <tbody>
                <tr>
                    <th class="w-25">API Key</th>
                    <td dir="ltr"><?php echo e($settings['api_key_masked']); ?></td>
                </tr>
                <tr>
                    <th>Base URL</th>
                    <td dir="ltr"><?php echo e($settings['base_url']); ?></td>
                </tr>
                <tr>
                    <th>Timeout</th>
                    <td dir="ltr"><?php echo e($settings['timeout']); ?> ثانیه</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php if($balance !== null): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">نتیجه استعلام موجودی</h5>
            </div>
            <div class="card-body">
                <pre class="mb-0 text-start" dir="ltr"><?php echo e(json_encode($balance, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
            </div>
        </div>
    <?php endif; ?>

    <?php if($profile !== null): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">نتیجه استعلام پروفایل</h5>
            </div>
            <div class="card-body">
                <pre class="mb-0 text-start" dir="ltr"><?php echo e(json_encode($profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
            </div>
        </div>
    <?php endif; ?>

    <div class="alert alert-info">
        این صفحه فقط تنظیمات غیرحساس پیامک را ویرایش می‌کند. کلید API کامل نمایش داده نمی‌شود و برای تغییر مقادیر حساس باید تنظیمات سرور به‌صورت امن به‌روزرسانی شود.
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const captureInput = document.getElementById('require_phone_before_route_calculation');
            const earlySmsInput = document.getElementById('send_sms_after_early_phone_capture');

            if (!captureInput || !earlySmsInput) {
                return;
            }

            const syncEarlySmsState = function () {
                earlySmsInput.disabled = !captureInput.checked;
                if (!captureInput.checked) {
                    earlySmsInput.checked = false;
                }
            };

            captureInput.addEventListener('change', syncEarlySmsState);
            syncEarlySmsState();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/sms_settings/index.blade.php ENDPATH**/ ?>