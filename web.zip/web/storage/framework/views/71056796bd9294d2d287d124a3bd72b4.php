<?php $__env->startSection('title', $metaTitle ?? 'مقالات و اخبار'); ?>
<?php $__env->startSection('description', $metaDescription ?? 'مقالات و اخبار به‌روز در زمینه اجاره خودرو'); ?>

<?php $__env->startSection('main'); ?>


    <!-- Header Banner -->
    <section class="banner-header section-padding bg-img" data-overlay-dark="5" data-background="<?php echo e(asset('site/img/slider/10.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <?php if(($seoMeta['page'] ?? 1) > 1): ?>
                            <p class="text-white mb-2">صفحه <?php echo e($seoMeta['page']); ?></p>
                        <?php endif; ?>
                        <h6>مقالات و اخبار</h6>
                        <h1>مقالات</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Blog 3 -->
    <section class="blog3 section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $posts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-12">
                                <div class="item">
                                    <div class="post-img">
                                        <a href="<?php echo e(route('blog.show', $post->en_slug ?? '#')); ?>">
                                            <?php if(!empty($post->thumbnail)): ?>
                                                <img src="<?php echo e(asset('storage/' . $post->thumbnail)); ?>" alt="<?php echo e($post->title ?? 'مقاله'); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('site/img/slider/5.jpg')); ?>" alt="<?php echo e($post->title ?? 'مقاله'); ?>">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="post-cont">
                                        <?php if(isset($post->category) && $post->category): ?>
                                            <span class="category">
                                                <h2><a href="<?php echo e(route('blog.category', $post->category->en_slug ?? '#')); ?>"><?php echo e($post->category->name ?? ''); ?></a></h2>
                                            </span>
                                        <?php endif; ?>
                                        <span class="calendar">
                                            <a href="#">
                                                <?php if(!empty($post->published_at)): ?>
                                                    <?php echo e(\Verta::instance($post->published_at)->format('j F Y')); ?>

                                                <?php elseif(!empty($post->created_at)): ?>
                                                    <?php echo e(\Verta::instance($post->created_at)->format('j F Y')); ?>

                                                <?php else: ?>
                                                    <?php echo e(\Verta::now()->format('j F Y')); ?>

                                                <?php endif; ?>
                                            </a>
                                        </span>
                                        <h5>
                                            <a href="<?php echo e(route('blog.show', $post->en_slug ?? '#')); ?>"><?php echo e($post->title ?? 'بدون عنوان'); ?></a>
                                        </h5>
                                        <p><?php echo e(Str::limit(strip_tags($post->summary ?? $post->body ?? ''), 200)); ?></p>
                                        <a href="<?php echo e(route('blog.show', $post->en_slug ?? '#')); ?>" class="button-4">بیشتر بخوانید</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-md-12">
                                <div class="alert alert-info text-center">
                                    <p>مقاله‌ای یافت نشد.</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Pagination -->
                    <?php if(isset($posts) && $posts->hasPages()): ?>
                        <div class="row">
                            <div class="col-md-12 mt-30 mb-30">
                                <ul class="pagination-wrap">
                                    <?php if($posts->onFirstPage()): ?>
                                        <li><span><i class="ti-angle-right"></i></span></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e($posts->previousPageUrl()); ?>"><i class="ti-angle-right"></i></a></li>
                                    <?php endif; ?>

                                    <?php $__currentLoopData = $posts->getUrlRange(max(1, $posts->currentPage() - 2), min($posts->lastPage(), $posts->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e($url); ?>" class="<?php echo e($page == $posts->currentPage() ? 'active' : ''); ?>">
                                                <?php echo e($page); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($posts->hasMorePages()): ?>
                                        <li><a href="<?php echo e($posts->nextPageUrl()); ?>"><i class="ti-angle-left"></i></a></li>
                                    <?php else: ?>
                                        <li><span><i class="ti-angle-left"></i></span></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="blog3-sidebar row">
                        <div class="col-md-12">
                            <div class="widget search">
                                <form action="<?php echo e(route('blog.index')); ?>" method="GET">
                                    <input type="text" name="search" placeholder="بنویسید..." value="<?php echo e(request('search')); ?>">
                                    <button type="submit"><i class="ti-search" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </div>
                        <?php if($recentPosts->count() > 0): ?>
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-title">
                                        <h6>مقالات اخیر</h6>
                                    </div>
                                    <ul class="recent">
                                        <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="thum">
                                                    <?php if($recentPost->thumbnail): ?>
                                                        <img src="<?php echo e(asset('storage/' . $recentPost->thumbnail)); ?>" class="img-fluid" alt="<?php echo e($recentPost->title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('site/img/slider/2.jpg')); ?>" class="img-fluid" alt="<?php echo e($recentPost->title); ?>">
                                                    <?php endif; ?>
                                                </div>
                                                <a href="<?php echo e(route('blog.show', $recentPost->en_slug)); ?>"><?php echo e(Str::limit($recentPost->title, 50)); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                
                        <?php if($categories->count() > 0): ?>
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-title">
                                        <h6>دسته بندی ها</h6>
                                    </div>
                                    <ul class="tags">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('blog.category', $category->en_slug)); ?>"><?php echo e($category->name); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="5" data-background="<?php echo e(asset('site/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>ماشینتو اجاره کن</h6>
                    <h5>دوست داری اجاره کنی؟</h5>
                    <p>درنگ نکن و به ما پیام بده.</p>
                    <a class="button-2 mt-15 mb-15" data-bs-target="#exampleModal" data-bs-toggle="modal" data-bs-whatever="@mdo" href="#0">الان اجاره کن<span class="ti-arrow-top-right"></span></a><a class="button-1 mt-15 mb-15 me-2" href="tel:+8001234567" dir="ltr"><i class="fa-brands fa-whatsapp"></i>واتس اپ</a>
                </div>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.site.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/site/category.blade.php ENDPATH**/ ?>