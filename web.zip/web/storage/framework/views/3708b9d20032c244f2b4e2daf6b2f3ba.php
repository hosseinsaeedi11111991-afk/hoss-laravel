<form method="POST" enctype="multipart/form-data"
    action="<?php if($billboard): ?> <?php echo e(route('admin.billboard.update', ['billboard' => $billboard])); ?>

      <?php else: ?> <?php echo e(route('admin.billboard.store')); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($billboard): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-2 col-md-6 px-4">
            <label class="form-label" for="figure">
                <span>طرح</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <select class="form-select" id="figure" name="figure">
                <option <?php if(!$billboard): echo 'selected'; endif; ?>>لطفا انتخاب کنید</option>
                <?php $__currentLoopData = $figures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $lable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($billboard && $billboard->figure == $value): echo 'selected'; endif; ?>>
                        <?php echo e($lable); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['figure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="name">
                <span>نام بیلبورد</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="<?php echo e(old('name', $billboard ? $billboard->name : '')); ?>">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4 mt-4">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/billboard/partials/form.blade.php ENDPATH**/ ?>