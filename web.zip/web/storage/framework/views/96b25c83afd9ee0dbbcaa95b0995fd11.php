<?php $__env->startSection('title', 'کد تایید را وارد کنید'); ?>

<?php $__env->startSection('main'); ?>
    <div class="container mt-5">
        <div class="row pt-5">
            <div class="col-lg-5 col-12 d-block mx-auto">
                <div class="card p-4">
                    <div class="card-header">
                        <div class="brand">
                            <img class="d-block mx-auto img-fluid" src="<?php echo e(asset('site/images/_logo.png')); ?>"
                                 alt="logo">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div>
                                <h3>کد تایید را وارد کنید</h3>
                                <div class="form-note">کد تایید برای شماره <?php echo e($mobile); ?> پیامک شد</div>
                            </div>
                        </div>

                        <form method="POST" action="<?php echo e(route('auth.otp.verify.submit')); ?>">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="mobile" value="<?php echo e($mobile); ?>">

                            <div class="mb-3">
                                <div class="input-group">
                                    <input id="code" class="form-control" name="code" type="text"
                                           placeholder="کد تایید" value="<?php echo e(old('code')); ?>"/>
                                </div>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-grid mt-3">
                                <button type="submit" class="btn btn-outline w-100">تایید</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.site.auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Auth/resources/views/site/verify_otp.blade.php ENDPATH**/ ?>