<?php if (isset($component)) { $__componentOriginal69c537c4cc0ac04cefd44ab64e3b8d5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69c537c4cc0ac04cefd44ab64e3b8d5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'sitemap::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sitemap::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('sitemap.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69c537c4cc0ac04cefd44ab64e3b8d5a)): ?>
<?php $attributes = $__attributesOriginal69c537c4cc0ac04cefd44ab64e3b8d5a; ?>
<?php unset($__attributesOriginal69c537c4cc0ac04cefd44ab64e3b8d5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69c537c4cc0ac04cefd44ab64e3b8d5a)): ?>
<?php $component = $__componentOriginal69c537c4cc0ac04cefd44ab64e3b8d5a; ?>
<?php unset($__componentOriginal69c537c4cc0ac04cefd44ab64e3b8d5a); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Sitemap/resources/views/index.blade.php ENDPATH**/ ?>