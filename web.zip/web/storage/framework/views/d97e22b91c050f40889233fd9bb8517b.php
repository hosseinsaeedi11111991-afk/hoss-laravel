
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">قوانین قیمت‌گذاری/</a></span>
        جزئیات قانون
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قانون قیمت‌گذاری</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>شهر مبدا:</strong>
                    <p class="text-muted"><?php echo e($pricingRule->origin_city); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>شهر مقصد:</strong>
                    <p class="text-muted"><?php echo e($pricingRule->destination_city); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>دسته‌بندی ماشین:</strong>
                    <p>
                        <?php if($pricingRule->carCategory): ?>
                            <span class="badge bg-secondary"><?php echo e($pricingRule->carCategory->title); ?></span>
                        <?php else: ?>
                            <span class="text-muted">تعیین نشده</span>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>نحوه محاسبه قیمت:</strong>
                    <p>
                        <span class="badge bg-<?php echo e($pricingRule->pricing_type == 'fixed' ? 'primary' : 'info'); ?>">
                            <?php echo e($pricingRule->getPricingTypeLabel()); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>اولویت:</strong>
                    <p>
                        <span class="badge bg-<?php echo e($pricingRule->priority == 'high' ? 'danger' : ($pricingRule->priority == 'medium' ? 'warning' : 'secondary')); ?>">
                            <?php echo e($pricingRule->getPriorityLabel()); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت ثابت:</strong>
                    <p class="text-muted"><?php echo e(number_format($pricingRule->fixed_price)); ?> تومان</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p class="text-muted"><?php echo e(number_format($pricingRule->per_km_price)); ?> تومان</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-<?php echo e($pricingRule->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($pricingRule->is_active ? 'فعال' : 'غیرفعال'); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted"><?php echo e($pricingRule->created_at->format('Y/m/d H:i')); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted"><?php echo e($pricingRule->updated_at->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('admin.pricing_rules.edit', $pricingRule)); ?>" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="<?php echo e(route('admin.pricing_rules.index')); ?>" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/pricing_rules/show.blade.php ENDPATH**/ ?>