<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.options.index')); ?>">آپشن‌ها/</a></span>
        مشاهده آپشن
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات آپشن</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>نام:</strong> <?php echo e($option->name); ?></li>
                        <li class="list-group-item">
                            <strong>دسته‌بندی ماشین:</strong>
                            <?php if($option->carCategory): ?>
                                <span class="badge bg-secondary"><?php echo e($option->carCategory->title); ?></span>
                            <?php else: ?>
                                <span class="badge bg-info">برای همه ماشین‌ها</span>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item"><strong>نوع:</strong> <?php echo e($option->type=='text' ? 'متن' : 'چک‌باکس'); ?></li>
                        <li class="list-group-item">
                            <strong>نوع محاسبه:</strong>
                            <?php if($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_FIXED): ?>
                                قیمت ثابت
                            <?php elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PER_KM): ?>
                                به‌ازای کیلومتر
                            <?php elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PERCENTAGE): ?>
                                محاسبه درصدی
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item"><strong>قیمت ثابت:</strong> <?php echo e($option->fixed_price ? number_format($option->fixed_price) . ' تومان' : '-'); ?></li>
                        <li class="list-group-item"><strong>قیمت هر کیلومتر:</strong> <?php echo e($option->per_km_price ? number_format($option->per_km_price) . ' تومان' : '-'); ?></li>
                        <li class="list-group-item"><strong>درصد قیمت:</strong> <?php echo e($option->percentage_price ? number_format($option->percentage_price, 2) . '%' : '-'); ?></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($option->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($option->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/options/show.blade.php ENDPATH**/ ?>