<?php $__env->startSection('title', 'ویرایش: <?php echo e($billboard->name); ?>'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.billboard.index')); ?>">لیست بیلبوردها/</a></span>
    <span>ویرایش: <?php echo e($billboard->name); ?></span>
</h4>

<?php echo $__env->make('billboard::admin.billboard.partials.form', [
    'billboard' => $billboard,
    'figures' => $figures,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/billboard/edit.blade.php ENDPATH**/ ?>