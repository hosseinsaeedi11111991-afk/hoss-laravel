
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discount-usages.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discount-usages.index')); ?>">گزارش استفاده/</a></span>
        نمایش جزئیات
    </h4>

    <div class="card mb-4">
        <div class="card-header">
            <h5>جزئیات استفاده از تخفیف</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>تخفیف:</strong> <?php echo e($discountUsage->discount->title); ?></p>
                    <p><strong>کاربر:</strong> <?php echo e($discountUsage->user->username ?? '-'); ?></p>
                    <p><strong>رزرو:</strong> #<?php echo e($discountUsage->reservation_id ?? '-'); ?></p>
                    <p><strong>نحوه اعمال:</strong> <?php echo e($discountUsage->applied_via == 'automatic' ? 'خودکار' : 'کد'); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>مبلغ تخفیف:</strong> <?php echo e(number_format($discountUsage->discount_amount)); ?> تومان</p>
                    <p><strong>قیمت اولیه:</strong> <?php echo e(number_format($discountUsage->original_price)); ?> تومان</p>
                    <p><strong>قیمت نهایی:</strong> <?php echo e(number_format($discountUsage->final_price)); ?> تومان</p>
                    <p><strong>تاریخ استفاده:</strong> <?php echo e(verta($discountUsage->used_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('admin.discount-usages.index')); ?>" class="btn btn-secondary">بازگشت</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Discount/resources/views/admin/discount_usages/show.blade.php ENDPATH**/ ?>