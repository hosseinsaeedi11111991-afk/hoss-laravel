<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-seo.index')); ?>">سئو/</a></span>
        افزودن تنظیمات سئو جدید
    </h4>

    <form action="<?php echo e(route('admin.blog-seo.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">انتخاب پست <span class="text-danger">*</span></label>
            <select name="blog_post_id" class="form-select" required>
                <option value="">-- انتخاب کنید --</option>
                <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($post->id); ?>" <?php echo e(old('blog_post_id') == $post->id ? 'selected' : ''); ?>>
                        <?php echo e($post->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">عنوان سئو (title) <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" maxlength="60" required>
        </div>

        <div class="mb-3">
            <label class="form-label">توضیحات سئو (description) <span class="text-danger">*</span></label>
            <textarea name="description" class="form-control" rows="3" maxlength="160" required><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">کلمات کلیدی (با کاما جدا کنید)</label>
            <input type="text" name="keywords" class="form-control" value="<?php echo e(old('keywords')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">نام نویسنده</label>
            <input type="text" name="author_name" class="form-control" value="<?php echo e(old('author_name')); ?>" maxlength="100">
        </div>

        <div class="mb-3">
            <label class="form-label">کلمه کلیدی تمرکز</label>
            <input type="text" name="focus_keyword" class="form-control" value="<?php echo e(old('focus_keyword')); ?>" maxlength="50">
        </div>

        <div class="mb-3">
            <label class="form-label">زمان مطالعه</label>
            <input type="text" name="reading_time" class="form-control" value="<?php echo e(old('reading_time')); ?>" maxlength="10" placeholder="مثلاً 5 دقیقه">
        </div>

        <div class="mb-3">
            <label class="form-label"> markup (Schema JSON)</label>
            <textarea name="schema_markup" class="form-control" rows="4"><?php echo e(old('schema_markup')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_seo/create.blade.php ENDPATH**/ ?>