<?php $__env->startSection('title', 'خدمات فوتر'); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            خدمات فوتر
        </h4>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($tableMissing): ?>
        <div class="alert alert-warning">
            جدول لینک‌های خدمات فوتر هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و سایت فعلاً از آیتم‌های قبلی فوتر استفاده می‌کند.
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن لینک خدمات</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.footer-service-links.store')); ?>" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" maxlength="160" required <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="text" name="url" value="<?php echo e(old('url')); ?>" class="form-control" maxlength="255" dir="ltr" placeholder="/reservation یا https://..." <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-2 col-md-4">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>" class="form-control" min="0" max="9999" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-1 col-md-4">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label">فعال</label>
                    </div>
                </div>
                <div class="col-lg-1 col-md-4">
                    <button class="btn btn-success w-100" type="submit" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if(! $tableMissing): ?>
        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>لینک</th>
                        <th>ترتیب</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td colspan="5">
                                <form method="POST" action="<?php echo e(route('admin.footer-service-links.update', $link)); ?>" class="row g-2 align-items-center">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="col-lg-3 col-md-6">
                                        <input type="text" name="title" value="<?php echo e(old('title', $link->title)); ?>" class="form-control form-control-sm" maxlength="160" required>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <input type="text" name="url" value="<?php echo e(old('url', $link->url)); ?>" class="form-control form-control-sm" maxlength="255" dir="ltr">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $link->sort_order)); ?>" class="form-control form-control-sm" min="0" max="9999">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="is_active" value="1" class="form-check-input" <?php if($link->is_active): echo 'checked'; endif; ?>>
                                            <label class="form-check-label">فعال</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-6 d-flex gap-2">
                                        <button class="btn btn-sm btn-primary" type="submit">
                                            <i class="bx bx-save"></i>
                                            ذخیره
                                        </button>
                                    </div>
                                </form>
                                <form method="POST" action="<?php echo e(route('admin.footer-service-links.destroy', $link)); ?>" class="mt-2" onsubmit="return confirm('این لینک حذف شود؟')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger" type="submit">
                                        <i class="bx bx-trash"></i>
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                هنوز لینکی ثبت نشده است. تا زمان ثبت لینک، سایت از آیتم‌های قبلی فوتر استفاده می‌کند.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3">
            <?php echo e($links->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/footer_service_links/index.blade.php ENDPATH**/ ?>