<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نقاط Neshan - رزرو <?php echo e($reservation); ?></title>
    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .content {
            padding: 20px;
        }
        .location-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
        }
        .location-header {
            padding: 15px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .origin {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
        }
        .destination {
            background: #f3e5f5;
            border-left: 4px solid #9c27b0;
        }
        .primary {
            background: #e8f5e8;
            border-left: 4px solid #4caf50;
        }
        .location-details {
            padding: 15px;
            background: white;
        }
        .badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            color: white;
        }
        .badge-primary {
            background: #007bff;
        }
        .badge-success {
            background: #28a745;
        }
        .coordinates {
            font-family: monospace;
            background: #f8f9fa;
            padding: 8px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .address {
            color: #666;
            margin: 10px 0;
        }
        .stats {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .stats h3 {
            margin-top: 0;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>نقاط Neshan</h1>
            <p>رزرو شماره: <?php echo e($reservation); ?></p>
        </div>
        
        <div class="content">
            <div class="stats">
                <h3>آمار نقاط</h3>
                <p><strong>تعداد کل نقاط:</strong> <?php echo e($locations->count()); ?></p>
                <p><strong>مبداها:</strong> <?php echo e($locations->where('type', 'origin')->count()); ?></p>
                <p><strong>مقصدها:</strong> <?php echo e($locations->where('type', 'destination')->count()); ?></p>
                <p><strong>نقاط اصلی:</strong> <?php echo e($locations->where('is_primary', true)->count()); ?></p>
            </div>

            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="location-card">
                    <div class="location-header <?php echo e($location->type); ?> <?php echo e($location->is_primary ? 'primary' : ''); ?>">
                        <div>
                            <?php if($location->type == 'origin'): ?>
                                <span class="badge badge-primary">مبدا</span>
                            <?php else: ?>
                                <span class="badge badge-success">مقصد</span>
                            <?php endif; ?>
                            
                            <?php if($location->is_primary): ?>
                                <span class="badge badge-success">اصلی</span>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php echo e($location->created_at->format('Y/m/d H:i')); ?>

                        </div>
                    </div>
                    
                    <div class="location-details">
                        <div class="coordinates">
                            <strong>مختصات:</strong> <?php echo e($location->latitude); ?>, <?php echo e($location->longitude); ?>

                        </div>
                        
                        <div class="address">
                            <strong>آدرس:</strong> <?php echo e($location->address_text); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($locations->isEmpty()): ?>
                <div style="text-align: center; padding: 40px; color: #666;">
                    <h3>هیچ نقطه‌ای یافت نشد</h3>
                    <p>برای این رزرو هنوز نقاطی در Neshan ذخیره نشده است.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/tajhizta/web/resources/views/neshan-locations.blade.php ENDPATH**/ ?>