<?php use Modules\Billboard\Models\Billboard; ?>


<?php $__env->startSection('title', 'لیست بیلبوردها'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span>لیست بیلبوردها</span>
</h4>

<a href="<?php echo e(route('admin.billboard.create')); ?>" type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>نام بیلبورد</th>
                <th>طرح بیلبورد</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td>
                    <?php switch($row->figure):
                        case (Billboard::FIGURE_HERO): ?>
                            <span>hero</span>
                            <?php break; ?>
                        <?php case (Billboard::FIGURE_SLIDER): ?>
                            <span>اسلایدر</span>
                            <?php break; ?>
                        <?php case (Billboard::FIGURE_BANNER): ?>
                            <span>بنر</span>
                            <?php break; ?>
                        <?php default: ?>
                            <span>نامشخص</span>
                            <?php break; ?>
                    <?php endswitch; ?>
                </td>
                <td>
                    <?php if($row->is_active): ?>
                        <span class="text-success">فعال</span>
                    <?php else: ?>
                        <span class="text-danger">غیرفعال</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e(Verta::instance($row->updated_at)->format('Y/m/d')); ?></td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('admin.billboard.edit', $row->id)); ?>"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <a href="<?php echo e(route('admin.billboard.image.index', $row->id)); ?>"
                            class="btn btn-dark btn-sm"
                            title="گالری عکس">
                            <i class="bx bx-image-alt"></i>
                        </a>
                        <form method="POST"
                            action="<?php echo e(route('admin.billboard.toggle_status', $row->id)); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="<?php echo e(route('admin.billboard.destroy', $row->id)); ?>"
                            class="delete-form d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-4">
    <?php echo e($items->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/billboard/index.blade.php ENDPATH**/ ?>