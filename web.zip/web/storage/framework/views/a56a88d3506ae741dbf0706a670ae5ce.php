<?php if (isset($component)) { $__componentOriginal6fbc781239bdfe6ff69f9ac5c6ad9284 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fbc781239bdfe6ff69f9ac5c6ad9284 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'permission::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('permission::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('permission.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fbc781239bdfe6ff69f9ac5c6ad9284)): ?>
<?php $attributes = $__attributesOriginal6fbc781239bdfe6ff69f9ac5c6ad9284; ?>
<?php unset($__attributesOriginal6fbc781239bdfe6ff69f9ac5c6ad9284); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fbc781239bdfe6ff69f9ac5c6ad9284)): ?>
<?php $component = $__componentOriginal6fbc781239bdfe6ff69f9ac5c6ad9284; ?>
<?php unset($__componentOriginal6fbc781239bdfe6ff69f9ac5c6ad9284); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Permission/resources/views/index.blade.php ENDPATH**/ ?>