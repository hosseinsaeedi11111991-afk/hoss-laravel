<div>
    <form wire:submit.prevent="save" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 col-md-6 px-4">
                <label class="form-label">نام بیلبورد <span class="text-danger">*</span></label>
                <input type="text" wire:model="name" class="form-control">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 col-md-6 px-4">
                <label class="form-label">طرح بیلبورد <span class="text-danger">*</span></label>
                <select wire:model="figure" class="form-control">
                    <?php $__currentLoopData = $figures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['figure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 px-4 pt-4">
                <input type="checkbox" wire:model="is_active" class="form-check-input" id="is_active">
                <label class="form-check-label" for="is_active">فعال / غیر فعال</label>
            </div>
        </div>

        
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex mb-3 flex-wrap border rounded p-3 position-relative">
            
            <button type="button" wire:click="removeSlide(<?php echo e($index); ?>)" class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2" title="حذف اسلاید">
                <i class="bx bx-trash"></i>
            </button>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">تصویر <span class="text-danger">*</span></label>
                <input type="file" wire:model="slides.<?php echo e($index); ?>.image" class="form-control">
                <?php $__errorArgs = ["slides.$index.image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">متن جایگزین تصویر <span class="text-danger">*</span></label>
                <input type="text" wire:model="slides.<?php echo e($index); ?>.image_alt" class="form-control">
                <?php $__errorArgs = ["slides.$index.image_alt"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">لینک</label>
                <input type="text" wire:model="slides.<?php echo e($index); ?>.link" class="form-control">
                <?php $__errorArgs = ["slides.$index.link"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">کپشن</label>
                <input type="text" wire:model="slides.<?php echo e($index); ?>.caption" class="form-control">
                <?php $__errorArgs = ["slides.$index.caption"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">ترتیب نمایش</label>
                <input type="text" wire:model="slides.<?php echo e($index); ?>.sort_order" class="form-control" readonly>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 pt-4 mb-2">
                <input type="checkbox" wire:model="slides.<?php echo e($index); ?>.new_tab" class="form-check-input" id="new_tab_<?php echo e($index); ?>">
                <label class="form-check-label" for="new_tab_<?php echo e($index); ?>">باز شدن لینک در تب جدید</label>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="col-12 px-2 mb-3">
            <button type="button" wire:click="addSlide" class="btn btn-success">
                <i class="bx bx-plus"></i> افزودن تصویر جدید
            </button>
        </div>

        <button type="submit" class="btn btn-primary rounded-pill mt-3">ذخیره بیلبورد</button>
    </form>
</div>
<?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/livewire/create_billboard.blade.php ENDPATH**/ ?>