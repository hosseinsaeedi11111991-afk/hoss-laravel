
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">تخفیف‌ها/</a></span>
        افزودن تخفیف
    </h4>

    <form action="<?php echo e(route('admin.discounts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <!-- اطلاعات پایه -->
        <div class="card mb-4">
            <div class="card-header"><h5>اطلاعات پایه</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">عنوان <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">کد تخفیف</label>
                        <input type="text" name="code" class="form-control" value="<?php echo e(old('code')); ?>" id="code-input">
                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">توضیحات</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- نوع تخفیف -->
        <div class="card mb-4">
            <div class="card-header"><h5>نوع تخفیف</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع تخفیف <span class="text-danger">*</span></label>
                        <select name="discount_type" class="form-select" required>
                            <option value="percentage" <?php echo e(old('discount_type') == 'percentage' ? 'selected' : ''); ?>>درصدی</option>
                            <option value="fixed_amount" <?php echo e(old('discount_type') == 'fixed_amount' ? 'selected' : ''); ?>>مبلغ ثابت</option>
                            <option value="free_delivery" <?php echo e(old('discount_type') == 'free_delivery' ? 'selected' : ''); ?>>ارسال رایگان</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">مقدار تخفیف <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="discount_value" class="form-control" value="<?php echo e(old('discount_value')); ?>" required>
                        <?php $__errorArgs = ['discount_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4 mb-3" id="max-discount-amount-field">
                        <label class="form-label">حداکثر مبلغ تخفیف</label>
                        <input type="number" step="0.01" name="max_discount_amount" class="form-control" value="<?php echo e(old('max_discount_amount')); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع فعال‌سازی <span class="text-danger">*</span></label>
                        <select name="trigger_type" class="form-select" id="trigger-type" required>
                            <option value="automatic" <?php echo e(old('trigger_type') == 'automatic' ? 'selected' : ''); ?>>فقط خودکار</option>
                            <option value="code" <?php echo e(old('trigger_type') == 'code' ? 'selected' : ''); ?>>فقط با کد</option>
                            <option value="both" <?php echo e(old('trigger_type') == 'both' ? 'selected' : ''); ?>>کد و خودکار</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="auto_apply" value="1" <?php echo e(old('auto_apply', true) ? 'checked' : ''); ?>>
                            <span class="form-check-label">اعمال خودکار</span>
                        </label>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="stackable" value="1" <?php echo e(old('stackable') ? 'checked' : ''); ?>>
                            <span class="form-check-label">قابل ترکیب با تخفیف‌های دیگر</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های اعمال -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های اعمال</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع اعمال <span class="text-danger">*</span></label>
                        <select name="applicable_to" class="form-select" id="applicable-to" required>
                            <option value="all" <?php echo e(old('applicable_to') == 'all' ? 'selected' : ''); ?>>همه</option>
                            <option value="specific_route" <?php echo e(old('applicable_to') == 'specific_route' ? 'selected' : ''); ?>>مسیر خاص</option>
                            <option value="specific_car_category" <?php echo e(old('applicable_to') == 'specific_car_category' ? 'selected' : ''); ?>>دسته‌بندی خاص</option>
                            <option value="route_and_category" <?php echo e(old('applicable_to') == 'route_and_category' ? 'selected' : ''); ?>>مسیر + دسته‌بندی</option>
                            <option value="specific_city" <?php echo e(old('applicable_to') == 'specific_city' ? 'selected' : ''); ?>>شهر خاص</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3" id="origin-city-field" style="display:none;">
                        <label class="form-label">شهر مبدا</label>
                        <input type="text" name="origin_city" class="form-control" value="<?php echo e(old('origin_city')); ?>">
                    </div>
                    <div class="col-md-4 mb-3" id="destination-city-field" style="display:none;">
                        <label class="form-label">شهر مقصد</label>
                        <input type="text" name="destination_city" class="form-control" value="<?php echo e(old('destination_city')); ?>">
                    </div>
                    <div class="col-md-4 mb-3" id="car-category-field" style="display:none;">
                        <label class="form-label">دسته‌بندی خودرو</label>
                        <select name="car_category_id" class="form-select">
                            <option value="">انتخاب کنید...</option>
                            <?php $__currentLoopData = $carCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('car_category_id') == $id ? 'selected' : ''); ?>><?php echo e($title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های مسافت و مبلغ -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های مسافت و مبلغ</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداقل مسافت (km)</label>
                        <input type="number" step="0.01" name="min_distance_km" class="form-control" value="<?php echo e(old('min_distance_km')); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداکثر مسافت (km)</label>
                        <input type="number" step="0.01" name="max_distance_km" class="form-control" value="<?php echo e(old('max_distance_km')); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداقل مبلغ سفارش</label>
                        <input type="number" step="0.01" name="min_order_amount" class="form-control" value="<?php echo e(old('min_order_amount')); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداکثر مبلغ سفارش</label>
                        <input type="number" step="0.01" name="max_order_amount" class="form-control" value="<?php echo e(old('max_order_amount')); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های زمان -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های زمان</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">روزهای هفته</label>
                        <div class="row">
                            <?php $__currentLoopData = [1 => 'دوشنبه', 2 => 'سه‌شنبه', 3 => 'چهارشنبه', 4 => 'پنج‌شنبه', 5 => 'جمعه', 6 => 'شنبه', 7 => 'یکشنبه']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-2">
                                    <label class="form-check">
                                        <input class="form-check-input" type="checkbox" name="day_of_week[]" value="<?php echo e($day); ?>" <?php echo e(in_array($day, old('day_of_week', [])) ? 'checked' : ''); ?>>
                                        <span class="form-check-label"><?php echo e($label); ?></span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">ساعت شروع</label>
                        <input type="time" name="time_from" class="form-control" value="<?php echo e(old('time_from')); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">ساعت پایان</label>
                        <input type="time" name="time_until" class="form-control" value="<?php echo e(old('time_until')); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- محدودیت‌ها -->
        <div class="card mb-4">
            <div class="card-header"><h5>محدودیت‌ها و اعتبار</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">تاریخ شروع <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="valid_from" class="form-control" value="<?php echo e(old('valid_from')); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">تاریخ پایان <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="valid_until" class="form-control" value="<?php echo e(old('valid_until')); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">اولویت <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select" required>
                            <option value="high" <?php echo e(old('priority') == 'high' ? 'selected' : ''); ?>>بالا</option>
                            <option value="medium" <?php echo e(old('priority', 'medium') == 'medium' ? 'selected' : ''); ?>>متوسط</option>
                            <option value="low" <?php echo e(old('priority') == 'low' ? 'selected' : ''); ?>>پایین</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">محدودیت استفاده کل</label>
                        <input type="number" name="usage_limit" class="form-control" value="<?php echo e(old('usage_limit')); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">محدودیت برای هر کاربر</label>
                        <input type="number" name="usage_limit_per_user" class="form-control" value="<?php echo e(old('usage_limit_per_user')); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>>
                            <span class="form-check-label">فعال</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
        <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-secondary">انصراف</a>
    </form>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const applicableTo = document.getElementById('applicable-to');
            const triggerType = document.getElementById('trigger-type');
            
            function toggleFields() {
                const applicableValue = applicableTo.value;
                const originField = document.getElementById('origin-city-field');
                const destinationField = document.getElementById('destination-city-field');
                const carCategoryField = document.getElementById('car-category-field');
                
                if (applicableValue === 'specific_route' || applicableValue === 'route_and_category') {
                    originField.style.display = 'block';
                    destinationField.style.display = 'block';
                } else if (applicableValue === 'specific_city') {
                    originField.style.display = 'block';
                    destinationField.style.display = 'none';
                } else {
                    originField.style.display = 'none';
                    destinationField.style.display = 'none';
                }
                
                if (applicableValue === 'specific_car_category' || applicableValue === 'route_and_category') {
                    carCategoryField.style.display = 'block';
                } else {
                    carCategoryField.style.display = 'none';
                }
            }
            
            function toggleCodeField() {
                const triggerValue = triggerType.value;
                const codeInput = document.getElementById('code-input');
                if (triggerValue === 'code' || triggerValue === 'both') {
                    codeInput.required = true;
                } else {
                    codeInput.required = false;
                }
            }
            
            applicableTo.addEventListener('change', toggleFields);
            triggerType.addEventListener('change', toggleCodeField);
            toggleFields();
            toggleCodeField();
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Discount/resources/views/admin/discounts/create.blade.php ENDPATH**/ ?>