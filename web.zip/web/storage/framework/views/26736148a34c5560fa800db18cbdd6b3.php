<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">

<title><?php echo $__env->yieldContent('title'); ?></title>

<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/assets/img/favicon/favicon.ico')); ?>">

<!-- Icons -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/boxicons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/fontawesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/flag-icons.css')); ?>">

<!-- Core CSS -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/rtl/core.css')); ?>" class="template-customizer-core-css">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/rtl/theme-default.css')); ?>" class="template-customizer-theme-css">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/demo.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/rtl/rtl.css')); ?>">

<!-- Vendors CSS -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/typeahead-js/typeahead.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/apex-charts/apex-charts.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/toastr/toastr.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/animate-css/animate.css')); ?>" />
<!-- flatpickr -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/flatpickr/flatpickr.css')); ?>" />
<!-- select2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/select2/select2.css')); ?> " />
<!-- sweetalert2 -->
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/animate-css/animate.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/sweetalert2/sweetalert2.css')); ?>" />
<!-- Page CSS -->
<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldPushContent('styles'); ?>
<?php echo $__env->make('Shared::layouts.partials.local-font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- Helpers -->
<script src="<?php echo e(asset('admin/assets/vendor/js/helpers.js')); ?>"></script>

<!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
<!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
<script src="<?php echo e(asset('admin/assets/vendor/js/template-customizer.js')); ?>"></script>
<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="<?php echo e(asset('admin/assets/js/config.js')); ?>"></script>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/head.blade.php ENDPATH**/ ?>