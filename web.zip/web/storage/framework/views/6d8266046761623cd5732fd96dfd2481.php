<!DOCTYPE html>

<html lang="fa" class="light-style layout-navbar-fixed layout-menu-fixed" dir="rtl" data-theme="theme-default"
      data-assets-path="<?php echo e(asset('admin/assets')); ?>/" data-template="vertical-menu-template">
<head>

    <?php echo $__env->make('Shared::layouts.admin.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('Shared::layouts.admin.custom-theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">

    <div class="layout-container">

        <?php echo $__env->make('Shared::layouts.admin.side-bar-menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Layout container -->
        <div class="layout-page">
            <?php echo $__env->make('Shared::layouts.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="position-absolut " style="position: absolute;top: 2rem;right: 2rem ; z-index: 10000">
                        <?php echo $__env->make('Shared::layouts.admin.components.alerts.basic.error', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('Shared::layouts.admin.components.alerts.toaster.toasters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('Shared::layouts.admin.components.alerts.sweetAlerts.deleteConfirm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <?php $__env->startSection('main'); ?>
                    <?php echo $__env->yieldSection(); ?>
                </div>
                <!-- / Content -->
                <?php echo $__env->make('Shared::layouts.admin.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="content-backdrop fade"></div>
            </div>
        </div>

    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>

    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>
</div>

<?php echo $__env->make('Shared::layouts.admin.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/main.blade.php ENDPATH**/ ?>