
<!-- Footer -->




<!-- / Footer -->
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/footer.blade.php ENDPATH**/ ?>