<?php $__env->startSection('title', 'ویرایش تصویر بیلبورد'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.billboard.index')); ?>">لیست بیلبوردها/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.billboard.image.index', ['billboard' => $billboard])); ?>">تصاویر <?php echo e($billboard->name); ?>/</a></span>
    <span>ویرایش تصویر بیلبورد</span>
</h4>

<?php echo $__env->make('billboard::admin.billboard_image.partials.form', [
    'billboard' => $billboard,
    'billboard_image' => $billboard_image,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/billboard_image/edit.blade.php ENDPATH**/ ?>