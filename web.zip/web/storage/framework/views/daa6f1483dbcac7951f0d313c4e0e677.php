

<?php if(session('toast-success')): ?>
    <div class="bs-toast toast fade show animate__animated animate__zoomIn" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-success">
            <div class="me-auto fw-semibold">موفق<i class="fa-duotone mx-2 fa-solid fa-clipboard-check"></i></div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"> <?php echo e(session('toast-success')); ?></div>
    </div>
<?php endif; ?>

<?php if(session('toast-error')): ?>
    <div class="bs-toast toast fade show animate__animated animate__zoomIn" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-danger">
            <div class="me-auto fw-semibold">اخطار<i class="fa-duotone fa-triangle-exclamation mx-2 "></i></div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"> <?php echo e(session('toast-error')); ?></div>
    </div>
<?php endif; ?>

<?php if(session('toast-warning')): ?>
    <div class="bs-toast toast fade show animate__animated animate__zoomIn" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-warning">
            <div class="me-auto fw-semibold">هشدار<i class="fa-duotone fa-triangle-exclamation mx-2 "></div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"> <?php echo e(session('toast-warning')); ?></div>
    </div>
<?php endif; ?>

<?php if(session('toast-info')): ?>
    <div class="bs-toast toast fade show animate__animated animate__zoomIn" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-info">
            <div class="me-auto fw-semibold">اطلاعیه</div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"> <?php echo e(session('toast-info')); ?></div>
    </div>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/components/alerts/toaster/toasters.blade.php ENDPATH**/ ?>