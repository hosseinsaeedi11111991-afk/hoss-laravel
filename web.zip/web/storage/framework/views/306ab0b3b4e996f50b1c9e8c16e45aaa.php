<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <title>ورود به پنل مدیریت</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


</head>
<body>
<div class="auth-container-admin">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7 col-12">
                <div class="card auth-card-admin">
                    <div class="card-header">
                        <div class="brand">
                            <h2 class="text-center mb-0">ورود به پنل مدیریت</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('admin.auth.pass.login.submit')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="username" class="form-label">نام کاربری</label>
                                <div class="input-group">
                                    <input type="text"
                                           id="username"
                                           name="username"
                                           class="form-control"
                                           placeholder="نام کاربری را وارد کنید"
                                           value="<?php echo e(old('username')); ?>"
                                           required>
                                    <span class="input-group-text">
                                            <i class="bx bx-user"></i>
                                        </span>
                                </div>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger text-sm"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">رمز عبور</label>
                                <div class="input-group">
                                    <input type="password"
                                           id="password"
                                           name="password"
                                           class="form-control"
                                           placeholder="رمز عبور را وارد کنید"
                                           required>
                                    <span class="input-group-text">
                                            <i class="bx bx-lock-alt"></i>
                                        </span>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger text-sm"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <?php
                                $captchaAvailable = (extension_loaded('gd') || extension_loaded('imagick')) && !config('captcha.disable', false);
                            ?>
                            <?php if($captchaAvailable): ?>
                            <div class="mb-3">
                                <label class="form-label">کد امنیتی</label>
                                <div class="captcha-wrapper">
                                    <div class="captcha-image">
                                        <img src="<?php echo e(captcha_src('numeric')); ?>"
                                             alt="captcha"
                                             onclick="this.src='<?php echo e(captcha_src('numeric')); ?>' + Math.random()"
                                             class="captcha-img">
                                        <button type="button"
                                                class="btn-refresh-captcha"
                                                onclick="this.previousElementSibling.src='<?php echo e(captcha_src('numeric')); ?>' + Math.random()">
                                            <i class="bx bx-refresh"></i>
                                        </button>
                                    </div>
                                    <div class="input-group mt-2">
                                        <input type="text"
                                               name="captcha"
                                               class="form-control"
                                               placeholder="کد امنیتی را وارد کنید"
                                               required>
                                        <span class="input-group-text">
                                                <i class="bx bx-shield"></i>
                                            </span>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger text-sm"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php else: ?>
                            <input type="hidden" name="captcha" value="">
                            <?php endif; ?>

                            <div class="d-grid mt-4">
                                <button type="submit" class="btn btn-primary btn-login">
                                    <i class="bx bx-log-in me-2"></i>
                                    ورود به پنل
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body {
        margin: 0;
        padding: 0;
        background: #000000;
    }

    .auth-container-admin {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        background: #000000;
        position: relative;
        overflow: hidden;
    }

    .auth-container-admin::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse"><path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
        opacity: 0.3;
    }

    .auth-card-admin {
        background: rgba(255, 255, 255, 0.98);
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        overflow: hidden;
        position: relative;
        z-index: 1;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .auth-card-admin:hover {
        transform: translateY(-5px);
        box-shadow: 0 25px 70px rgba(0, 0, 0, 0.35);
    }

    .auth-card-admin .card-header {
        background: #f5b754;
        padding: 30px 20px;
        border: none;
        text-align: center;
    }

    .auth-card-admin .card-header .brand h2 {
        color: #000000;
        font-weight: 700;
        font-size: 24px;
        margin: 0;
    }

    .auth-card-admin .card-body {
        padding: 40px 35px;
    }

    .auth-card-admin .form-label {
        color: #2d3748;
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 8px;
        text-align: right;
        display: block;
    }

    .auth-card-admin .input-group {
        margin-bottom: 0;
    }

    .auth-card-admin .input-group-text {
        background: #f7fafc;
        border: 2px solid #e2e8f0;
        border-right: none;
        border-radius: 0 12px 12px 0;
        color: #f5b754;
        padding: 14px 15px;
    }

    .auth-card-admin .form-control {
        border: 2px solid #e2e8f0;
        border-radius: 12px 0 0 12px;
        border-right: none;
        padding: 14px 18px;
        font-size: 15px;
        transition: all 0.3s ease;
        background: #f7fafc;
        color: #2d3748;
        text-align: right;
    }

    .auth-card-admin .form-control:focus {
        border-color: #f5b754;
        background: #ffffff;
        box-shadow: 0 0 0 4px rgba(245, 183, 84, 0.1);
        outline: none;
    }

    .auth-card-admin .input-group:focus-within .input-group-text {
        border-color: #f5b754;
    }

    .auth-card-admin .input-group:focus-within .form-control {
        border-color: #f5b754;
    }

    .auth-card-admin .form-control::placeholder {
        color: #a0aec0;
    }

    .auth-card-admin .text-danger {
        color: #e53e3e !important;
        font-size: 13px;
        margin-top: 5px;
        display: block;
        text-align: right;
    }

    .auth-card-admin .captcha-wrapper {
        margin-bottom: 0;
    }

    .auth-card-admin .captcha-image {
        position: relative;
        display: inline-block;
        width: 100%;
        margin-bottom: 10px;
    }

    .auth-card-admin .captcha-img {
        width: 100%;
        height: 60px;
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .auth-card-admin .captcha-img:hover {
        border-color: #f5b754;
    }

    .auth-card-admin .btn-refresh-captcha {
        position: absolute;
        top: 5px;
        left: 5px;
        background: rgba(245, 183, 84, 0.9);
        color: #000000;
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 16px;
    }

    .auth-card-admin .btn-refresh-captcha:hover {
        background: rgba(245, 183, 84, 1);
        transform: rotate(180deg);
    }

    .auth-card-admin .btn-login {
        background: #f5b754;
        border: none;
        color: #000000;
        padding: 14px 30px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(245, 183, 84, 0.4);
        cursor: pointer;
    }

    .auth-card-admin .btn-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(245, 183, 84, 0.5);
        background: #f5b754;
        opacity: 0.9;
    }

    .auth-card-admin .btn-login:active {
        transform: translateY(0);
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .auth-card-admin {
        animation: fadeInUp 0.5s ease;
    }

    @media (max-width: 768px) {
        .auth-container-admin {
            padding: 20px 15px;
        }

        .auth-card-admin {
            border-radius: 15px;
        }

        .auth-card-admin .card-body {
            padding: 30px 20px;
        }

        .auth-card-admin .card-header .brand h2 {
            font-size: 20px;
        }
    }
</style>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH /home/tajhizta/web/Modules/Auth/resources/views/admin/login_password.blade.php ENDPATH**/ ?>