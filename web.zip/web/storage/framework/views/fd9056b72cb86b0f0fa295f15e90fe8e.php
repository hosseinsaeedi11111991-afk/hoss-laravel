<?php $__env->startSection('title', 'ویرایش: <?php echo e($permission->guard_name); ?> - <?php echo e($permission->name); ?>'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.permission.index')); ?>">لیست دسترسی ها/</a></span>
    <span>ویرایش: <?php echo e($permission->guard_name); ?> - <?php echo e($permission->name); ?></span>
</h4>

<?php echo $__env->make('permission::admin.permission.partials.form', [
    'permission' => $permission,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Permission/resources/views/admin/permission/edit.blade.php ENDPATH**/ ?>