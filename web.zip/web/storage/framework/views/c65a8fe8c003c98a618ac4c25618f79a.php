<script src="<?php echo e(asset('admin/ckeditor/ckeditor5.js')); ?>"></script>
<script>

    document.addEventListener('DOMContentLoaded', () => {
        class MyUploadAdapter {

            constructor(loader) {
                this.loader = loader;
            }

            upload() {
                return this.loader.file.then(file => {
                    const data = new FormData();
                    data.append('upload', file);
                    // console.log(data.getAll('upload'))
                    return fetch("<?php echo e(route($route)); ?>", {
                        method: 'POST',
                        body: data,
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        }
                    })
                        .then(response => response.json())
                        .then(data => {
                            debugger
                            if (!data.uploaded) {
                                throw new Error(data.error);
                            }
                            return {default: data.url};
                        });
                });
            }
        }

        function MyCustomUploadAdapterPlugin(editor) {
            editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
                return new MyUploadAdapter(loader);
            };
        }
        ClassicEditor
            .create(document.getElementById('editor'), {
                extraPlugins: [MyCustomUploadAdapterPlugin]
            })
            .catch(error => {
                console.error(error);
            });
    });
</script>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/components/editor/ckeditor.blade.php ENDPATH**/ ?>