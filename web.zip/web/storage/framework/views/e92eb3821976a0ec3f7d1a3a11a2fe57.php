<?php $__env->startSection('title', 'افزودن <?php echo e($menu->name); ?>'); ?>

<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.menu.index', $menu->position)); ?>">لیست منوها/</a></span>
        <span>افزودن <?php echo e($menu->name); ?></span>
    </h4>

    <?php echo $__env->make('menu::admin.menu.partials.form', [
        'menu' => $menu,
        'position' => $menu->position,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Menu/resources/views/admin/menu/edit.blade.php ENDPATH**/ ?>