<?php $__env->startSection('title', 'ورود با شماره موبایل'); ?>

<?php $__env->startSection('main'); ?>
    <div class="auth-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-7 col-12 mx-auto">
                    <div class="card auth-card">
                        <div class="card-header">
                            <div class="brand">
                                <img class="d-block mx-auto img-fluid" src="<?php echo e(asset('site/images/_logo.png')); ?>"
                                     alt="logo">
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h3>ورود به حساب</h3>
                                <div class="form-note">لطفا شماره موبایل خود را وارد کنید</div>
                            </div>

                            <form method="POST" action="<?php echo e(route('auth.login.submit')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <input id="mobile" class="form-control" name="mobile" type="text"
                                               placeholder="شماره موبایل" value="<?php echo e(old('mobile')); ?>"/>
                                    </div>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="mt-3 text-primary">
                                        <a href="<?php echo e(route('auth.pass.login.form')); ?>">
                                            <i class="fa fa-key"></i>
                                            <span>ورود با رمز</span>
                                        </a>
                                    </div>
                                </div>

                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-outline w-100">ارسال کد</button>
                                </div>
                            </form>

                            <hr/>
                            <p class="small text-center text-muted mb-0">
                                <span>با ورود شما </span>
                                <a href="<?php echo e(route('home')); ?>">قوانین و حریم خصوصی</a>
                                <span>را پذیرفته‌ اید</span>
                            </p>

                            <div class="auth-link">
                                <span>حساب کاربری ندارید؟ </span>
                                <a href="<?php echo e(route('auth.register.form')); ?>">ثبت نام کنید</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('Shared::layouts.site.auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Auth/resources/views/site/login.blade.php ENDPATH**/ ?>