<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.neshan-locations.index')); ?>">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        ویرایش موقعیت
    </h4>

    <form action="<?php echo e(route('admin.neshan-locations.update', $neshan_location)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">رزرو</label>
                <select name="reservation_id" class="form-select">
                    <option value="">— انتخاب —</option>
                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('reservation_id', $neshan_location->reservation_id) == $id ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['reservation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Latitude <span class="text-danger">*</span></label>
                <input type="text" name="latitude" class="form-control" value="<?php echo e(old('latitude', $neshan_location->latitude)); ?>" required>
                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Longitude <span class="text-danger">*</span></label>
                <input type="text" name="longitude" class="form-control" value="<?php echo e(old('longitude', $neshan_location->longitude)); ?>" required>
                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-12 mb-3">
                <label class="form-label">آدرس <span class="text-danger">*</span></label>
                <input type="text" name="address_text" class="form-control" value="<?php echo e(old('address_text', $neshan_location->address_text)); ?>" required>
                <?php $__errorArgs = ['address_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">نوع <span class="text-danger">*</span></label>
                <select name="type" class="form-select" required>
                    <option value="origin" <?php echo e(old('type', $neshan_location->type) == 'origin' ? 'selected' : ''); ?>>مبدا</option>
                    <option value="destination" <?php echo e(old('type', $neshan_location->type) == 'destination' ? 'selected' : ''); ?>>مقصد</option>
                </select>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">اصلی</label>
                <select name="is_primary" class="form-select">
                    <option value="0" <?php echo e(old('is_primary', (int)$neshan_location->is_primary) == 0 ? 'selected' : ''); ?>>خیر</option>
                    <option value="1" <?php echo e(old('is_primary', (int)$neshan_location->is_primary) == 1 ? 'selected' : ''); ?>>بله</option>
                </select>
                <?php $__errorArgs = ['is_primary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Neshan/resources/views/admin/neshan_locations/edit.blade.php ENDPATH**/ ?>