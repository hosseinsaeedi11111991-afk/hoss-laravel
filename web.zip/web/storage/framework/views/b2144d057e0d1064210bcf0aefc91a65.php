
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">قوانین قیمت‌گذاری/</a></span>
        ویرایش قانون
    </h4>

    <form action="<?php echo e(route('admin.pricing_rules.update', $pricingRule)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">شهر مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_city" class="form-control" value="<?php echo e(old('origin_city', $pricingRule->origin_city)); ?>" required>
                <?php $__errorArgs = ['origin_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">شهر مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_city" class="form-control" value="<?php echo e(old('destination_city', $pricingRule->destination_city)); ?>" required>
                <?php $__errorArgs = ['destination_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">انتخاب کنید (اختیاری)</option>
                    <?php $__currentLoopData = $carCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('car_category_id', $pricingRule->car_category_id) == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['car_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="fixed" <?php echo e(old('pricing_type', $pricingRule->pricing_type) == 'fixed' ? 'checked' : ''); ?> required>
                        <span class="form-check-label">قیمت ثابت</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="per_km" <?php echo e(old('pricing_type', $pricingRule->pricing_type) == 'per_km' ? 'checked' : ''); ?>>
                        <span class="form-check-label">قیمت به ازای کیلومتر</span>
                    </label>
                </div>
                <?php $__errorArgs = ['pricing_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">اولویت <span class="text-danger">*</span></label>
                <select name="priority" class="form-select" required>
                    <option value="high" <?php echo e(old('priority', $pricingRule->priority) == 'high' ? 'selected' : ''); ?>>بالا</option>
                    <option value="medium" <?php echo e(old('priority', $pricingRule->priority) == 'medium' ? 'selected' : ''); ?>>متوسط</option>
                    <option value="low" <?php echo e(old('priority', $pricingRule->priority) == 'low' ? 'selected' : ''); ?>>پایین</option>
                </select>
                <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="fixed_price" class="form-control price-input" value="<?php echo e(old('fixed_price', number_format($pricingRule->fixed_price, 0, '.', ','))); ?>" required>
                <input type="hidden" name="fixed_price" id="fixed_price_raw" value="<?php echo e(old('fixed_price', $pricingRule->fixed_price)); ?>">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="fixed_price_display" class="text-success"><?php echo e(number_format($pricingRule->fixed_price, 0, '.', ',')); ?></span> تومان</strong>
                </div>
                <?php $__errorArgs = ['fixed_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="per_km_price" class="form-control price-input" value="<?php echo e(old('per_km_price', number_format($pricingRule->per_km_price, 0, '.', ','))); ?>" required>
                <input type="hidden" name="per_km_price" id="per_km_price_raw" value="<?php echo e(old('per_km_price', $pricingRule->per_km_price)); ?>">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="per_km_price_display" class="text-success"><?php echo e(number_format($pricingRule->per_km_price, 0, '.', ',')); ?></span> تومان</strong>
                </div>
                <?php $__errorArgs = ['per_km_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-12 mb-3">
                <div class="alert alert-info">
                    <strong>محاسبه قیمت:</strong>
                    <div class="mt-2">
                        <span id="price_calculation_display" class="text-primary">-</span>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $pricingRule->is_active) ? 'checked' : ''); ?>>
                    <label class="form-check-label">فعال</label>
                </div>
                <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const fixedPriceInput = document.getElementById('fixed_price');
                const fixedPriceRaw = document.getElementById('fixed_price_raw');
                const fixedPriceDisplay = document.getElementById('fixed_price_display');

                const perKmPriceInput = document.getElementById('per_km_price');
                const perKmPriceRaw = document.getElementById('per_km_price_raw');
                const perKmPriceDisplay = document.getElementById('per_km_price_display');

                const pricingTypeInputs = document.querySelectorAll('input[name="pricing_type"]');
                const priceCalculationDisplay = document.getElementById('price_calculation_display');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                function updatePriceCalculation() {
                    const pricingType = document.querySelector('input[name="pricing_type"]:checked')?.value || 'fixed';
                    const fixedPrice = parseNumber(fixedPriceRaw.value);
                    const perKmPrice = parseNumber(perKmPriceRaw.value);

                    if (pricingType === 'fixed') {
                        priceCalculationDisplay.textContent = `قیمت ثابت: ${formatNumber(Math.floor(fixedPrice))} تومان`;
                    } else {
                        priceCalculationDisplay.textContent = `قیمت به ازای هر کیلومتر: ${formatNumber(Math.floor(perKmPrice))} تومان (مثال: برای 10 کیلومتر = ${formatNumber(Math.floor(perKmPrice * 10))} تومان)`;
                    }
                }

                function setupPriceInput(input, rawInput, display) {
                    input.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/,/g, '');
                        if (value === '') {
                            value = '0';
                        }
                        const numValue = parseFloat(value) || 0;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                        updatePriceCalculation();
                    });
                }

                // Setup price inputs
                setupPriceInput(fixedPriceInput, fixedPriceRaw, fixedPriceDisplay);
                setupPriceInput(perKmPriceInput, perKmPriceRaw, perKmPriceDisplay);

                // Update calculation when pricing type changes
                pricingTypeInputs.forEach(input => {
                    input.addEventListener('change', updatePriceCalculation);
                });

                // Initialize on page load
                [fixedPriceInput, perKmPriceInput].forEach(input => {
                    if (input.value) {
                        const numValue = parseNumber(input.value);
                        const rawInput = input.id === 'fixed_price' ? fixedPriceRaw : perKmPriceRaw;
                        const display = input.id === 'fixed_price' ? fixedPriceDisplay : perKmPriceDisplay;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                    }
                });

                updatePriceCalculation();
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/pricing_rules/edit.blade.php ENDPATH**/ ?>