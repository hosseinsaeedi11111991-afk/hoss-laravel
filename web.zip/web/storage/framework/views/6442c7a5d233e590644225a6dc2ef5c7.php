<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-comment.index')); ?>">دیدگاه‌ها/</a></span>
        ایجاد دیدگاه جدید
    </h4>

    <form action="<?php echo e(route('admin.blog-comment.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">نام *</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">ایمیل *</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">مطلب *</label>
            <select name="blog_post_id" class="form-select" required>
                <option value="">انتخاب کنید</option>
                <?php $__currentLoopData = \Modules\Blog\Models\BlogPost::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($post->id); ?>" <?php echo e(old('blog_post_id') == $post->id ? 'selected' : ''); ?>><?php echo e($post->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">والد (اختیاری)</label>
            <select name="parent_id" class="form-select">
                <option value="">بدون والد</option>
                <?php $__currentLoopData = \Modules\Blog\Models\BlogComment::whereNull('parent_id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($comment->id); ?>" <?php echo e(old('parent_id') == $comment->id ? 'selected' : ''); ?>><?php echo e($comment->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">متن دیدگاه *</label>
            <textarea name="description" class="form-control" rows="4" required><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="mb-3 form-check">
            <input class="form-check-input" type="checkbox" name="is_active" value="1" <?php echo e(old('is_active') ? 'checked' : ''); ?>>
            <label class="form-check-label">فعال باشد</label>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_comment/create.blade.php ENDPATH**/ ?>