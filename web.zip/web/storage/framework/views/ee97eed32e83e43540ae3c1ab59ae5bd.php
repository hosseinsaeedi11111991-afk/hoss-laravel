<?php if (isset($component)) { $__componentOriginalb00364874f5424ad297015ad78c06f15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb00364874f5424ad297015ad78c06f15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'reservation::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reservation::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('reservation.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb00364874f5424ad297015ad78c06f15)): ?>
<?php $attributes = $__attributesOriginalb00364874f5424ad297015ad78c06f15; ?>
<?php unset($__attributesOriginalb00364874f5424ad297015ad78c06f15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb00364874f5424ad297015ad78c06f15)): ?>
<?php $component = $__componentOriginalb00364874f5424ad297015ad78c06f15; ?>
<?php unset($__componentOriginalb00364874f5424ad297015ad78c06f15); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/index.blade.php ENDPATH**/ ?>