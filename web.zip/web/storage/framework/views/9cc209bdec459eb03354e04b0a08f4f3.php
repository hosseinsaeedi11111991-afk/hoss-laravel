<div class="mb-3">
    <label for="select2Tags" class="form-label"><?php echo e($labelName); ?> <?php echo e($is_required); ?></label>
    <div class="select2-primary">
        <select id="select2Tags" name="<?php echo e($name); ?>[]"  class="select2 form-select" multiple>
           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option <?php if(isset($update)): ?> <?php $__currentLoopData = $update; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $updateData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($updateData->id == $row->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?> value="<?php echo e($row->id); ?>"><?php echo e($row->$modeName); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#select2Tags').select2({
            tags: true,
            tokenSeparators: [',', ' '],
            createTag: function(params) {
                var term = $.trim(params.term);

                if (term === '') {
                    return null;
                }

                return {
                    id: term,
                    text: term,
                    newTag: true // اضافه کردن پراپرتی برای شناسایی تگ‌های جدید
                };
            }
        });

        // ارسال داده‌ها هنگام فرم سابمیت
        $('form').on('submit', function() {
            var selectedTags = $('#select2Tags').val() || [];
            var newTags = [];

            // بررسی تگ‌های جدید
            $('#select2Tags option').each(function() {
                if ($(this).data('newTag') && selectedTags.includes($(this).val())) {
                    newTags.push($(this).val());
                }
            });

            // اضافه کردن فیلد مخفی برای تگ‌های جدید
            if (newTags.length > 0) {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'new_tags',
                    value: JSON.stringify(newTags)
                }).appendTo('form');
            }
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/components/inputs/select2Multiple.blade.php ENDPATH**/ ?>