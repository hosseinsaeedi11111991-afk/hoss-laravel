<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">خودروها/</a></span>
        مشاهده خودرو
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات خودرو</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>عنوان:</strong> <?php echo e($car->title); ?></li>
                        <li class="list-group-item"><strong>دسته‌بندی:</strong> <?php echo e($car->category->title); ?></li>
                        <li class="list-group-item"><strong>ظرفیت سرنشین:</strong> <?php echo e($car->passenger_capacity); ?></li>
                        <li class="list-group-item"><strong>ظرفیت بار:</strong> <?php echo e($car->cargo_capacity ?: '-'); ?></li>
                        <li class="list-group-item"><strong>وزن بار مجاز:</strong> <?php echo e($car->cargo_weight ? $car->cargo_weight . ' kg' : '-'); ?></li>
                        <li class="list-group-item"><strong>وضعیت:</strong>
                            <span class="badge bg-<?php echo e($car->status == 'available' ? 'success' : ($car->status == 'rented' ? 'warning' : 'danger')); ?>">
                                 <?php echo e($car->status == 'available' ? 'موجود' : ($car->status == 'rented' ? 'اجاره داده‌شده' : 'در تعمیر')); ?>

                            </span>
                        </li>
                        <li class="list-group-item"><strong>بیمه:</strong> <?php echo e($car->is_insurance == 'yes' ? 'دارد' : 'ندارد'); ?></li>
                        <li class="list-group-item">
                            <strong>تصویر:</strong><br>
                            <?php if($car->avatar): ?>
                                <img src="<?php echo e(Storage::url($car->avatar)); ?>" width="150" class="rounded mt-2 border">
                            <?php else: ?>
                                <span class="text-muted">بدون تصویر</span>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($car->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($car->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/cars/show.blade.php ENDPATH**/ ?>