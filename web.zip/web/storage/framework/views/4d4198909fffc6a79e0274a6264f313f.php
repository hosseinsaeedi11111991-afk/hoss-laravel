<?php $__env->startSection('title', 'معرفی صفحه اصلی'); ?>

<?php $__env->startSection('main'); ?>
    <?php
        $source = $section ?: (object) $data;
        $features = old('features', implode(PHP_EOL, $section?->features ?: ($data['features'] ?? [])));
    ?>

    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            معرفی صفحه اصلی
        </h4>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($tableMissing): ?>
        <div class="alert alert-warning">
            جدول بخش معرفی صفحه اصلی هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و صفحه اصلی فعلاً از محتوای قبلی استفاده می‌کند.
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">ویرایش سکشن معرفی</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.home-about.update')); ?>" enctype="multipart/form-data" class="row g-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col-md-4">
                    <label class="form-label">زیرعنوان</label>
                    <input type="text" name="subtitle" value="<?php echo e(old('subtitle', $source->subtitle ?? '')); ?>" class="form-control" maxlength="120" required <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label">عنوان اصلی</label>
                    <input type="text" name="title" value="<?php echo e(old('title', $source->title ?? '')); ?>" class="form-control" maxlength="160" required <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label">عنوان طلایی/تکمیلی</label>
                    <input type="text" name="highlight_title" value="<?php echo e(old('highlight_title', $source->highlight_title ?? '')); ?>" class="form-control" maxlength="160" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-12">
                    <label class="form-label">متن</label>
                    <textarea name="body" rows="6" class="form-control" maxlength="2500" required <?php if($tableMissing): echo 'disabled'; endif; ?>><?php echo e(old('body', $source->body ?? '')); ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">آیتم‌های تیک‌دار</label>
                    <textarea name="features" rows="4" class="form-control" maxlength="1000" placeholder="هر آیتم در یک خط" <?php if($tableMissing): echo 'disabled'; endif; ?>><?php echo e($features); ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">لینک ویدئو</label>
                    <input type="text" name="video_url" value="<?php echo e(old('video_url', $source->video_url ?? '')); ?>" class="form-control" maxlength="255" dir="ltr" <?php if($tableMissing): echo 'disabled'; endif; ?>>

                    <label class="form-label mt-3">ALT عکس</label>
                    <input type="text" name="image_alt" value="<?php echo e(old('image_alt', $source->image_alt ?? ($source->image_alt ?? ''))); ?>" class="form-control" maxlength="255" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-md-6">
                    <label class="form-label">عکس جدید</label>
                    <input type="file" name="image" class="form-control" accept="image/*" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                    <div class="form-check mt-2">
                        <input type="checkbox" name="remove_image" value="1" class="form-check-input" <?php if($tableMissing || ! $section?->image_path): echo 'disabled'; endif; ?>>
                        <label class="form-check-label">حذف عکس اختصاصی و استفاده از عکس پیش‌فرض</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">پیش‌نمایش عکس فعلی</label>
                    <div>
                        <img src="<?php echo e($section?->image_url ?? ($data['image_url'] ?? asset('site/img/about.webp'))); ?>" alt="<?php echo e($section?->display_alt ?? ($data['image_alt'] ?? 'تاکسی بین شهری')); ?>" style="max-width: 260px; border-radius: 8px;">
                    </div>
                </div>
                <div class="col-12 text-end">
                    <button class="btn btn-primary" type="submit" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-save"></i>
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/home_about/edit.blade.php ENDPATH**/ ?>