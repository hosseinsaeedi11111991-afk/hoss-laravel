<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-comment.index')); ?>">دیدگاه‌ها/</a></span>
        مشاهده دیدگاه
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات دیدگاه</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>نام:</strong> <?php echo e($blogComment->name); ?></li>
                        <li class="list-group-item"><strong>ایمیل:</strong> <?php echo e($blogComment->email); ?></li>
                        <li class="list-group-item"><strong>مطلب:</strong>
                            <a href="<?php echo e(route('admin.blog-post.show', $blogComment->post)); ?>" target="_blank">
                                <?php echo e($blogComment->post->title ?? '-'); ?>

                            </a>
                        </li>
                        <li class="list-group-item"><strong>وضعیت:</strong>
                            <?php if($blogComment->is_active): ?>
                                <span class="badge bg-success">فعال</span>
                            <?php else: ?>
                                <span class="badge bg-danger">غیرفعال</span>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item"><strong>متن دیدگاه:</strong>
                            <p class="mt-2"><?php echo e($blogComment->description); ?></p>
                        </li>
                        <?php if($blogComment->parent): ?>
                            <li class="list-group-item"><strong>در پاسخ به:</strong>
                                <?php echo e($blogComment->parent->name); ?>

                            </li>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.blog-comment.reply', $blogComment)); ?>" class="btn btn-success">
                            <i class="bx bx-reply"></i> پاسخ به این دیدگاه
                        </a>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($blogComment->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($blogComment->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_comment/show.blade.php ENDPATH**/ ?>