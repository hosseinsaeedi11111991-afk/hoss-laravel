<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <?php echo $__env->make('Shared::layouts.site.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="bg-gray">

    <?php echo $__env->make('Shared::layouts.site.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main-style">
    <?php $__env->startSection('main'); ?>



    <?php echo $__env->yieldSection(); ?>
    </main>
    <?php echo $__env->make('Shared::layouts.site.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>
<?php echo $__env->make('Shared::layouts.site.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/site/main.blade.php ENDPATH**/ ?>