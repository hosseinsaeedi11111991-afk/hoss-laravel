
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discount-usages.index')); ?>">پنل/</a></span>
        گزارش استفاده از تخفیف‌ها
    </h4>

    <!-- فرم فیلتر -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">فیلتر</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.discount-usages.index')); ?>">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تخفیف</label>
                        <input type="number" name="discount_id" class="form-control" value="<?php echo e(request('discount_id')); ?>" placeholder="ID تخفیف">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">کاربر</label>
                        <input type="number" name="user_id" class="form-control" value="<?php echo e(request('user_id')); ?>" placeholder="ID کاربر">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تاریخ از</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تاریخ تا</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">جستجو</button>
                        <a href="<?php echo e(route('admin.discount-usages.index')); ?>" class="btn btn-secondary">پاک کردن</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>تخفیف</th>
                <th>کاربر</th>
                <th>رزرو</th>
                <th>مبلغ تخفیف</th>
                <th>قیمت اولیه</th>
                <th>قیمت نهایی</th>
                <th>نحوه اعمال</th>
                <th>تاریخ استفاده</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($usages->currentPage() - 1) * $usages->perPage() + $key + 1); ?></td>
                    <td><?php echo e($usage->discount->title); ?></td>
                    <td><?php echo e($usage->user->username ?? '-'); ?></td>
                    <td>#<?php echo e($usage->reservation_id ?? '-'); ?></td>
                    <td><?php echo e(number_format($usage->discount_amount)); ?> تومان</td>
                    <td><?php echo e(number_format($usage->original_price)); ?> تومان</td>
                    <td><?php echo e(number_format($usage->final_price)); ?> تومان</td>
                    <td><?php echo e($usage->applied_via == 'automatic' ? 'خودکار' : 'کد'); ?></td>
                    <td><?php echo e(verta($usage->used_at)->format('Y/m/d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($usages->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Discount/resources/views/admin/discount_usages/index.blade.php ENDPATH**/ ?>