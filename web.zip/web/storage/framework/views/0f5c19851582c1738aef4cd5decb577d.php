<?php use Modules\Menu\Models\Menu; ?>
<form method="POST" enctype="multipart/form-data"
    action="<?php if($menu): ?> <?php echo e(route('admin.menu.update', ['menu' => $menu])); ?>

      <?php else: ?> <?php echo e(route('admin.menu.store')); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($menu): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if(!$menu): ?>
        <input type="hidden" name="position" value="<?php echo e($position); ?>">
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-2 col-md-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="text" name="sort_order" class="form-control"
                    value="<?php echo e(old('sort_order', $menu ? $menu->sort_order : '')); ?>">
            </div>
            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="name">
                <span>نام</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="<?php echo e(old('name', $menu ? $menu->name : '')); ?>">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-3 col-md-4">
            <label class="form-label" for="icon">
                <span>آیکن</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="icon" type="text" name="icon" class="form-control"
                    value="<?php echo e(old('icon', $menu ? $menu->icon : '')); ?>">
            </div>
            <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-8 col-md-8">
            <label class="form-label" for="style">
                <span>استایل</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="style" type="text" name="style" class="form-control"
                    value="<?php echo e(old('style', $menu ? $menu->style : '')); ?>">
            </div>
            <?php $__errorArgs = ['style'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <?php if(($menu && $menu->position == Menu::POSITION_HEADER) || $position == Menu::POSITION_HEADER): ?>
        <div class="form-check form-switch">
            <input type="hidden" name="mega_menu" value="0">
            <input 
                class="form-check-input" 
                type="checkbox" 
                role="switch" 
                id="mega_menu" 
                name="mega_menu" 
                value="1"
                <?php if($menu && $menu->mega_menu): echo 'checked'; endif; ?>>

            <label class="form-check-label ms-2" for="mega_menu">
                مگامنو؟
            </label>
        </div>
    <?php endif; ?>

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Menu/resources/views/admin/menu/partials/form.blade.php ENDPATH**/ ?>