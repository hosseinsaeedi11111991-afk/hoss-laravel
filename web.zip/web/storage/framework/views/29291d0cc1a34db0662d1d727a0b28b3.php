<?php if (isset($component)) { $__componentOriginal80f8ec251207dc74850dad0e81bd3f39 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80f8ec251207dc74850dad0e81bd3f39 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'faq::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('faq::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('faq.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80f8ec251207dc74850dad0e81bd3f39)): ?>
<?php $attributes = $__attributesOriginal80f8ec251207dc74850dad0e81bd3f39; ?>
<?php unset($__attributesOriginal80f8ec251207dc74850dad0e81bd3f39); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80f8ec251207dc74850dad0e81bd3f39)): ?>
<?php $component = $__componentOriginal80f8ec251207dc74850dad0e81bd3f39; ?>
<?php unset($__componentOriginal80f8ec251207dc74850dad0e81bd3f39); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/index.blade.php ENDPATH**/ ?>