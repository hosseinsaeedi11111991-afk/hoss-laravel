<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.default_pricings.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.default_pricings.index')); ?>">قیمت‌گذاری پیش‌فرض/</a></span>
        جزئیات قیمت پیش‌فرض
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قیمت‌گذاری پیش‌فرض</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p>
                        <span class="badge bg-primary fs-6">
                            <?php echo e($defaultPricing->getFormattedPrice()); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-<?php echo e($defaultPricing->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($defaultPricing->is_active ? 'فعال' : 'غیرفعال'); ?>

                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted"><?php echo e($defaultPricing->created_at->format('Y/m/d H:i')); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted"><?php echo e($defaultPricing->updated_at->format('Y/m/d H:i')); ?></p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (100 کیلومتر):</strong>
                    <p class="text-success fs-5">
                        <?php echo e(number_format($defaultPricing->calculatePrice(100))); ?> تومان
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (50 کیلومتر):</strong>
                    <p class="text-info fs-5">
                        <?php echo e(number_format($defaultPricing->calculatePrice(50))); ?> تومان
                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('admin.default_pricings.edit', $defaultPricing)); ?>" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="<?php echo e(route('admin.default_pricings.index')); ?>" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/default_pricings/show.blade.php ENDPATH**/ ?>