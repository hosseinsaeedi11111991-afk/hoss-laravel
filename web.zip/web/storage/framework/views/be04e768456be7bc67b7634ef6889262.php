<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">خودروها/</a></span>
        لیست خودروها
    </h4>

    <a href="<?php echo e(route('admin.cars.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن خودرو</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>تصویر</th>
                <th>عنوان</th>
                <th>دسته‌بندی</th>
                <th>نحوه محاسبه</th>
                <th>قیمت ثابت</th>
                <th>قیمت هر کیلومتر</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td>
                        <?php if($car->avatar): ?>
                            <img src="<?php echo e(Storage::url($car->avatar)); ?>" width="60" class="rounded">
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($car->title); ?></td>
                    <td><?php echo e($car->category->title); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($car->pricing_type == 'fixed' ? 'primary' : 'info'); ?>">
                            <?php echo e($car->getPricingTypeLabel()); ?>

                        </span>
                    </td>
                    <td><?php echo e(number_format($car->fixed_price)); ?> تومان</td>
                    <td><?php echo e(number_format($car->per_km_price)); ?> تومان</td>
                    <td>
                         <span class="badge bg-<?php echo e($car->status == 'available' ? 'success' : ($car->status == 'rented' ? 'warning' : 'danger')); ?>">
                            <?php echo e($car->status == 'available' ? 'موجود' : ($car->status == 'rented' ? 'اجاره داده‌شده' : 'در تعمیر')); ?>

                         </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.cars.show', $car)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.cars.edit', $car)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.cars.destroy', $car)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($cars->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/cars/index.blade.php ENDPATH**/ ?>