    <h1>Hello World</h1>

    <p>Module: <?php echo config('shared.name'); ?></p>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/index.blade.php ENDPATH**/ ?>