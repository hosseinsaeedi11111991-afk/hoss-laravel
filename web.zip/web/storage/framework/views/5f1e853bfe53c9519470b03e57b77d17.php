<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.popular-routes.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.popular-routes.index')); ?>">مسیرهای پرطرفدار/</a></span>
        ویرایش مسیر پرطرفدار
    </h4>

    <form action="<?php echo e(route('admin.popular-routes.update', $popularRoute)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-12 mb-3">
                <label class="form-label">عنوان <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $popularRoute->title)); ?>" required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_address" class="form-control" value="<?php echo e(old('origin_address', $popularRoute->origin_address)); ?>" required>
                <?php $__errorArgs = ['origin_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_address" class="form-control" value="<?php echo e(old('destination_address', $popularRoute->destination_address)); ?>" required>
                <?php $__errorArgs = ['destination_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">عرض جغرافیایی مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_lat" class="form-control" value="<?php echo e(old('origin_lat', $popularRoute->origin_lat)); ?>" required>
                <?php $__errorArgs = ['origin_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">طول جغرافیایی مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_lng" class="form-control" value="<?php echo e(old('origin_lng', $popularRoute->origin_lng)); ?>" required>
                <?php $__errorArgs = ['origin_lng'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">عرض جغرافیایی مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_lat" class="form-control" value="<?php echo e(old('destination_lat', $popularRoute->destination_lat)); ?>" required>
                <?php $__errorArgs = ['destination_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">طول جغرافیایی مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_lng" class="form-control" value="<?php echo e(old('destination_lng', $popularRoute->destination_lng)); ?>" required>
                <?php $__errorArgs = ['destination_lng'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">تصویر</label>
                <?php if($popularRoute->image): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(Storage::url($popularRoute->image)); ?>" alt="<?php echo e($popularRoute->title); ?>" class="img-thumbnail" style="max-height: 80px;">
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/*">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ترتیب نمایش</label>
                <input type="number" name="sort_order" class="form-control" value="<?php echo e(old('sort_order', $popularRoute->sort_order)); ?>" min="0">
                <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3 d-flex align-items-end">
                <div class="form-check">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" class="form-check-input" value="1" id="is_active" <?php echo e(old('is_active', $popularRoute->is_active) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="is_active">فعال</label>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/popular-routes/edit.blade.php ENDPATH**/ ?>