<?php if (isset($component)) { $__componentOriginal502ae2032a3179cd41ed4f11ff1c2276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal502ae2032a3179cd41ed4f11ff1c2276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'neshan::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('neshan::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('neshan.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal502ae2032a3179cd41ed4f11ff1c2276)): ?>
<?php $attributes = $__attributesOriginal502ae2032a3179cd41ed4f11ff1c2276; ?>
<?php unset($__attributesOriginal502ae2032a3179cd41ed4f11ff1c2276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal502ae2032a3179cd41ed4f11ff1c2276)): ?>
<?php $component = $__componentOriginal502ae2032a3179cd41ed4f11ff1c2276; ?>
<?php unset($__componentOriginal502ae2032a3179cd41ed4f11ff1c2276); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Neshan/resources/views/index.blade.php ENDPATH**/ ?>