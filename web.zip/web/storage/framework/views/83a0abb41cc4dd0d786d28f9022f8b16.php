<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-comment.index')); ?>">دیدگاه‌ها/</a></span>
        لیست دیدگاه‌ها
    </h4>

    <a href="<?php echo e(route('admin.blog-comment.create')); ?>" class="btn rounded-pill btn-success mb-3">دیدگاه جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>نام</th>
                <th>ایمیل</th>
                <th>مطلب</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($comment->name); ?></td>
                    <td><?php echo e($comment->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.blog-post.show', $comment->post)); ?>" target="_blank">
                            <?php echo e($comment->post->title ?? '-'); ?>

                        </a>
                    </td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input toggle-status"
                                   type="checkbox"
                                   data-id="<?php echo e($comment->id); ?>"
                                <?php echo e($comment->is_active ? 'checked' : ''); ?>>
                        </div>
                    </td>
                    <td>
                        <div class="btn-group flex-wrap gap-2">
                            <a href="<?php echo e(route('admin.blog-comment.show', $comment)); ?>" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="<?php echo e(route('admin.blog-comment.edit', $comment)); ?>" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <a href="<?php echo e(route('admin.blog-comment.reply', $comment)); ?>" class="btn btn-sm btn-success" title="پاسخ">
                                <i class="bx bx-reply"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.blog-comment.destroy', $comment)); ?>" class="delete-form d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($comments->links('pagination::bootstrap-5')); ?>

    </div>

    <?php $__env->startPush('scripts'); ?>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <script>
            $('.toggle-status').on('change', function () {
                let id   = $(this).data('id');
                let url  = '<?php echo e(route("admin.blog-comment.toggle.status")); ?>';
                let token = $('meta[name="csrf-token"]').attr('content');

                $.post(url, { _token: token, id: id })
                    .done(res => {
                        if (res.success) {
                            toastr.success('وضعیت دیدگاه تغییر کرد.');
                        }
                    })
                    .fail(() => toastr.error('خطا در تغییر وضعیت!'));
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_comment/index.blade.php ENDPATH**/ ?>