<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.blog-post.index')); ?>"> مقالات/</a></span>
        نمایش مقاله
    </h4>

    <div class="card">
        <div class="card-body">
            <h2><?php echo e($blog_post->title); ?></h2>
            <p><strong>نامک فارسی:</strong> <?php echo e($blog_post->fa_slug); ?></p>
            <p><strong>نامک انگلیسی:</strong> <?php echo e($blog_post->en_slug); ?></p>
            <p><strong>خلاصه:</strong> <?php echo e($blog_post->summary); ?></p>
            <p><strong>محتوا:</strong></p>
            <div><?php echo $blog_post->body; ?></div>

            <p><strong>تصویر شاخص:</strong></p>
            <?php if($blog_post->thumbnail): ?>
                <img src="<?php echo e(asset('storage/' . $blog_post->thumbnail)); ?>" alt="تصویر شاخص" style="max-width: 300px; max-height: 200px;">
                <p>نامک تصویر شاخص: <?php echo e($blog_post->thumbnail_tag); ?></p>
            <?php else: ?>
                <p>تصویر شاخص وجود ندارد</p>
            <?php endif; ?>

            <p><strong>تصویر اصلی:</strong></p>
            <?php if($blog_post->image): ?>
                <img src="<?php echo e(asset('storage/' . $blog_post->image)); ?>" alt="تصویر اصلی" style="max-width: 300px; max-height: 200px;">
                <p>نامک تصویر اصلی: <?php echo e($blog_post->image_tag); ?></p>
            <?php else: ?>
                <p>تصویر اصلی وجود ندارد</p>
            <?php endif; ?>

            <p><strong>وضعیت نمایش:</strong> <?php echo e($blog_post->is_active ? 'فعال' : 'غیرفعال'); ?></p>
            <p><strong>قابل کامنت گذاری:</strong> <?php echo e($blog_post->is_commentable ? 'بله' : 'خیر'); ?></p>
            <p><strong>وضعیت کلی:</strong> <?php echo e($blog_post->status); ?></p>
            <p><strong>تاریخ نمایش:</strong> <?php echo e(verta($blog_post->published_at)->format('Y-n-j H:i:s')); ?></p>

            <p><strong>دسته بندی:</strong> <?php echo e($blog_post->category->name ?? '-'); ?></p>

            <p><strong>تگ ها:</strong>
                <?php $__currentLoopData = $blog_post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge bg-primary"><?php echo e($tag->tag_title); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>

            <hr>

            <h4>SEO</h4>
            <p><strong>نام صفحه (title):</strong> <?php echo e($seo->title); ?></p>
            <p><strong>کلمه کلیدی:</strong> <?php echo e($seo->focus_keyword); ?></p>
            <p><strong>توضیحات:</strong> <?php echo e($seo->description); ?></p>
            <p><strong>schema_markup:</strong></p>
            <pre><?php echo e($seo->schema_markup); ?></pre>
            <p><strong>کلمات کلیدی:</strong> <?php echo e($seo->keywords); ?></p>
            <p><strong>مدت زمان مطالعه:</strong> <?php echo e($seo->reading_time); ?></p>

            <a href="<?php echo e(route('admin.blog-post.edit', $blog_post->id)); ?>" class="btn btn-warning mt-3">ویرایش مقاله</a>
            <a href="<?php echo e(route('admin.blog-post.index')); ?>" class="btn btn-secondary mt-3">بازگشت به لیست</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Blog/resources/views/admin/blog_post/show.blade.php ENDPATH**/ ?>