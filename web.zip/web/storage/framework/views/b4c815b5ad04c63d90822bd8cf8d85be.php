<?php use Modules\Page\Models\Page; ?>


<?php $__env->startSection('title', 'لیست صفحات'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span>لیست صفحات</span>
</h4>

<a href="<?php echo e(route('admin.page.create')); ?>" type="button" class="btn rounded-pill me-2 btn-success">افزودن صفحه جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>صفحه والد</th>
                <th>نام صفحه</th>
                <th>عنوان صفحه</th>
                <th>آدرس url</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td>
                    <?php if($row->parent): ?>
                        <?php echo e($row->parent->name); ?>

                    <?php else: ?>
                        (هیچکدام)
                    <?php endif; ?>
                </td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->title); ?></td>
                <td><?php echo e($row->getFullPath()); ?></td>
                <td>
                    <?php
                    switch ($row->status) {
                        case Page::STATUS_PUBLISHED:
                            echo '<span class="text-success">انتشار یافته</span>';
                            break;
                        case Page::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case Page::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case Page::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    ?>
                </td>
                <td><?php echo e(Verta::instance($row->updated_at)->format('Y/m/d')); ?></td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('admin.page.edit', $row->id)); ?>"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="<?php echo e(route('admin.page.toggle_status', $row->id)); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="<?php echo e(route('admin.page.destroy', $row->id)); ?>"
                            class="delete-form d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-4">
    <?php echo e($pages->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Page/resources/views/admin/index.blade.php ENDPATH**/ ?>