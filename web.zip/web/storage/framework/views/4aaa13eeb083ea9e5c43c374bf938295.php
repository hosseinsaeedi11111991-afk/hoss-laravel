<form method="POST" action="<?php echo e($redirect->exists ? route('admin.seo.redirects.update', $redirect) : route('admin.seo.redirects.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($redirect->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6 mb-3">
                    <label class="form-label" for="source_path">آدرس مبدا</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="bx bx-link"></i></span>
                        <input id="source_path" dir="ltr" type="text" name="source_path" class="form-control" value="<?php echo e(old('source_path', $redirect->source_path)); ?>" placeholder="/old-url">
                    </div>
                    <small class="text-muted">فقط مسیر را وارد کنید. مثال: /old-page</small>
                    <?php $__errorArgs = ['source_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6 mb-3">
                    <label class="form-label" for="target_url">آدرس مقصد</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="bx bx-link-external"></i></span>
                        <input id="target_url" dir="ltr" type="text" name="target_url" class="form-control" value="<?php echo e(old('target_url', $redirect->target_url)); ?>" placeholder="/new-url یا https://example.com/new-url">
                    </div>
                    <small class="text-muted">برای 410 می‌توانید مقصد را خالی بگذارید.</small>
                    <?php $__errorArgs = ['target_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4 mb-3">
                    <label class="form-label" for="status_code">نوع ریدایرکت</label>
                    <select id="status_code" name="status_code" class="form-select">
                        <?php $__currentLoopData = \App\Models\SeoRedirect::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($code); ?>" <?php if((int) old('status_code', $redirect->status_code) === (int) $code): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['status_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4 mb-3 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input type="hidden" name="is_active" value="0">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" <?php if(old('is_active', $redirect->is_active ?? true)): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="is_active">فعال باشد</label>
                    </div>
                </div>

                <div class="col-12 mb-3">
                    <label class="form-label" for="notes">یادداشت</label>
                    <textarea id="notes" name="notes" class="form-control" rows="3"><?php echo e(old('notes', $redirect->notes)); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bx bx-save"></i>
                    ذخیره
                </button>
                <a href="<?php echo e(route('admin.seo.redirects.index')); ?>" class="btn btn-outline-secondary">بازگشت</a>
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/tajhizta/web/resources/views/admin/seo_redirects/partials/form.blade.php ENDPATH**/ ?>