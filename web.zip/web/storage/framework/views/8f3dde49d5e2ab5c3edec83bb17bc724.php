<?php $__env->startSection('title', 'اکشن‌های موبایل'); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            اکشن‌های موبایل
        </h4>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($contactsTableMissing || $linksTableMissing): ?>
        <div class="alert alert-warning">
            جدول تنظیمات تماس یا لینک‌های موبایل هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت کامل فعال می‌شود و سایت تا آن زمان از دکمه‌های قبلی استفاده می‌کند.
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">تنظیم شماره تماس و واتساپ</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.mobile-actions.contact.update')); ?>" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">شماره تماس</label>
                    <input type="text" name="phone_number" value="<?php echo e(old('phone_number', $contact->phone_number ?? '09120983462')); ?>" class="form-control" maxlength="40" dir="ltr" required <?php if($contactsTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">شماره واتساپ</label>
                    <input type="text" name="whatsapp_number" value="<?php echo e(old('whatsapp_number', $contact->whatsapp_number ?? '09120983462')); ?>" class="form-control" maxlength="40" dir="ltr" required <?php if($contactsTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نمایش شماره</label>
                    <input type="text" name="display_phone" value="<?php echo e(old('display_phone', $contact->display_phone ?? '+98 912 098 3462')); ?>" class="form-control" maxlength="80" dir="ltr" required <?php if($contactsTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-2 col-md-6">
                    <button class="btn btn-primary w-100" type="submit" <?php if($contactsTableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-save"></i>
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن آیتم نوار پایین موبایل</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.mobile-actions.store')); ?>" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" maxlength="120" required <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">نوع لینک</label>
                    <select name="link_type" class="form-select" required <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                        <?php $__currentLoopData = $linkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('link_type', 'custom') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">آیکون</label>
                    <select name="icon_key" class="form-select" required <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                        <?php $__currentLoopData = $iconKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('icon_key', 'custom') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="text" name="url" value="<?php echo e(old('url')); ?>" class="form-control" maxlength="255" dir="ltr" placeholder="خالی بماند تا از نوع لینک ساخته شود" <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-1 col-md-4">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>" class="form-control" min="0" max="9999" <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-1 col-md-4">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label">فعال</label>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="open_in_new_tab" value="1" class="form-check-input" <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label">تب جدید</label>
                    </div>
                </div>
                <div class="col-lg-1 col-md-4">
                    <button class="btn btn-success w-100" type="submit" <?php if($linksTableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if(! $linksTableMissing): ?>
        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>نوع/آیکون</th>
                        <th>لینک دستی</th>
                        <th>ترتیب</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td colspan="6">
                                <form method="POST" action="<?php echo e(route('admin.mobile-actions.update', $link)); ?>" class="row g-2 align-items-center">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="col-lg-2 col-md-6">
                                        <input type="text" name="title" value="<?php echo e(old('title', $link->title)); ?>" class="form-control form-control-sm" maxlength="120" required>
                                    </div>
                                    <div class="col-lg-2 col-md-6">
                                        <select name="link_type" class="form-select form-select-sm" required>
                                            <?php $__currentLoopData = $linkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>" <?php if(old('link_type', $link->link_type) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-6">
                                        <select name="icon_key" class="form-select form-select-sm" required>
                                            <?php $__currentLoopData = $iconKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>" <?php if(old('icon_key', $link->icon_key) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <input type="text" name="url" value="<?php echo e(old('url', $link->url)); ?>" class="form-control form-control-sm" maxlength="255" dir="ltr">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $link->sort_order)); ?>" class="form-control form-control-sm" min="0" max="9999">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="is_active" value="1" class="form-check-input" <?php if($link->is_active): echo 'checked'; endif; ?>>
                                            <label class="form-check-label">فعال</label>
                                        </div>
                                        <div class="form-check">
                                            <input type="checkbox" name="open_in_new_tab" value="1" class="form-check-input" <?php if($link->open_in_new_tab): echo 'checked'; endif; ?>>
                                            <label class="form-check-label">تب جدید</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-6">
                                        <button class="btn btn-sm btn-primary w-100" type="submit">
                                            <i class="bx bx-save"></i>
                                        </button>
                                    </div>
                                </form>
                                <form method="POST" action="<?php echo e(route('admin.mobile-actions.destroy', $link)); ?>" class="mt-2" onsubmit="return confirm('این آیتم حذف شود؟')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger" type="submit">
                                        <i class="bx bx-trash"></i>
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                هنوز آیتمی ثبت نشده است. تا زمان ثبت آیتم، سایت از دکمه‌های قبلی استفاده می‌کند.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3">
            <?php echo e($links->links()); ?>

        </div>
    <?php endif; ?>

    <div class="card mt-4">
        <div class="card-header">
            <h5 class="mb-0">دکمه‌های پیش‌فرض فعلی</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>لینک</th>
                        <th>آیکون</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $legacyLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legacyLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($legacyLink['title']); ?></td>
                            <td dir="ltr"><?php echo e($legacyLink['url']); ?></td>
                            <td><?php echo e($legacyLink['icon_key']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/mobile_actions/index.blade.php ENDPATH**/ ?>