<?php if (isset($component)) { $__componentOriginal92a352c4f2442f2ae38a3e7293ff278a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92a352c4f2442f2ae38a3e7293ff278a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'catalog::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('catalog.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92a352c4f2442f2ae38a3e7293ff278a)): ?>
<?php $attributes = $__attributesOriginal92a352c4f2442f2ae38a3e7293ff278a; ?>
<?php unset($__attributesOriginal92a352c4f2442f2ae38a3e7293ff278a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92a352c4f2442f2ae38a3e7293ff278a)): ?>
<?php $component = $__componentOriginal92a352c4f2442f2ae38a3e7293ff278a; ?>
<?php unset($__componentOriginal92a352c4f2442f2ae38a3e7293ff278a); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Catalog/resources/views/index.blade.php ENDPATH**/ ?>