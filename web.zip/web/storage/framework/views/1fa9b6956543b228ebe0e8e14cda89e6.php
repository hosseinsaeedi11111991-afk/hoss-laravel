<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content', 'selected' => null, 'level' => 0, 'name' => 'parent_id', 'label' => 'name']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content', 'selected' => null, 'level' => 0, 'name' => 'parent_id', 'label' => 'name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if (! $__env->hasRenderedOnce('58e9996f-a5a9-4a25-8ad3-2e44a9753b6d')): $__env->markAsRenderedOnce('58e9996f-a5a9-4a25-8ad3-2e44a9753b6d'); ?>
    <?php $__env->startPush('styles'); ?>
        <style>
            ul, #item-tree {
                list-style-type: none;
            }

            #item-tree {
                margin: 20px 0;
                padding: 0;
                border-right: 2px solid #5a8dee;
            }

            .caret {
                cursor: pointer;
                user-select: none;
                color: #5a8dee;
                font-weight: 600;
                transition: color 0.3s ease;
            }

            .caret:hover {
                color: #39da8a;
            }

            .caret::before {
                display: inline-block;
                margin-left: 6px;
                transition: transform 0.3s ease;
            }

            .caret-down::before {
                transform: rotate(-90deg);
            }

            .nested {
                display: none;
                margin-right: 15px;
                border-right: 1px dashed #dbe9ff;
                padding-right: 15px;
            }

            .active {
                display: block;
            }

            .tree-view-form-check {
                margin: 5px 0 !important;
                padding: 5px 10px !important;
                background: #f4f8ff;
                border-radius: 6px;
                border: 1px solid #e1e9ff;
            }

            .tree-view-form-check:hover {
                background-color: #e8f6f2;
            }

            .tree-view-form-check-input {
                margin-right: 10px !important;
                float: right !important;
                accent-color: #39da8a;
            }

            .form-label span {
                font-weight: bold;
                color: #5a8dee;
            }

            .bx-minus, .bxs-chevron-left {
                color: #39da8a;
                font-size: 16px;
                margin-right: 6px;
            }

            label > span {
                color: #222;
            }
        </style>
    <?php $__env->stopPush(); ?>

<?php endif; ?>

<?php if($level == 0): ?>
    <ul id="item-tree" class="px-4">
        <label class="form-label">
            <span>لطفا انتخاب کنید</span>
            <i class="bx bx-health font-size-1 text-danger mx-2"></i>
        </label>

        <?php if($name == 'parent_id'): ?>
            <li class="tree-view-form-check">
                <label>
                    <i class="bx bx-minus"></i>
                    <span>(هیچکدام)</span>
                    <input type="radio" name="<?php echo e($name); ?>" class="tree-view-form-check-input" value="">
                </label>
            </li>
        <?php endif; ?>
<?php endif; ?>

<?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $hasChildren = $item->children && $item->children->count(); ?>
    <li class="tree-view-form-check">
        <label>
            <?php if($hasChildren): ?> <i class="bx bxs-chevron-left caret"></i> <?php else: ?> <i class="bx bx-minus"></i> <?php endif; ?>   
            <span><?php echo e($item->$label); ?></span>
            <input type="radio" class="tree-view-form-check-input" name="<?php echo e($name); ?>" value="<?php echo e($item->id); ?>" <?php if($selected == $item->id): echo 'checked'; endif; ?>>
        </label>
        <?php if($hasChildren): ?>
            <ul class="nested">
                <?php echo $__env->make('page::admin.components.tree_view', [
                    'content' => $item->children,
                    'selected' => $selected,
                    'level' => $level + 1
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($level == 0): ?>
    </ul>
<?php endif; ?>

<?php if (! $__env->hasRenderedOnce('dd90622a-296c-4adc-9752-598f943ea8be')): $__env->markAsRenderedOnce('dd90622a-296c-4adc-9752-598f943ea8be'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            let toggleList = document.getElementsByClassName("caret");
            for (let i = 0; i < toggleList.length; i++) {
                toggleList[i].addEventListener("click", function() {
                    this.parentElement.querySelector(".nested").classList.toggle("active");
                    this.classList.toggle("caret-down");
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/resources/views/admin/components/tree_view.blade.php ENDPATH**/ ?>