<?php if (isset($component)) { $__componentOriginal5cdb55af56bdf84004abe4fe41d493ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5cdb55af56bdf84004abe4fe41d493ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'menu::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('menu.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5cdb55af56bdf84004abe4fe41d493ba)): ?>
<?php $attributes = $__attributesOriginal5cdb55af56bdf84004abe4fe41d493ba; ?>
<?php unset($__attributesOriginal5cdb55af56bdf84004abe4fe41d493ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5cdb55af56bdf84004abe4fe41d493ba)): ?>
<?php $component = $__componentOriginal5cdb55af56bdf84004abe4fe41d493ba; ?>
<?php unset($__componentOriginal5cdb55af56bdf84004abe4fe41d493ba); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Menu/resources/views/index.blade.php ENDPATH**/ ?>