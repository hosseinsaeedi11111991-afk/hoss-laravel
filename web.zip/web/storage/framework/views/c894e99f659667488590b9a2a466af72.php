<?php $__env->startSection('title', 'ثبت نام'); ?>

<?php $__env->startSection('main'); ?>
    <div class="auth-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                    <div class="card auth-card">
                        <div class="card-header">
                            <div class="brand">
                                <img class="d-block mx-auto img-fluid" src="<?php echo e(asset('site/images/_logo.png')); ?>"
                                     alt="logo">
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h3>ثبت نام</h3>
                                <div class="form-note">لطفا اطلاعات زیر را وارد کنید</div>
                            </div>

                            <form method="POST" action="<?php echo e(route('auth.register.submit')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="first_name" class="form-control" name="first_name" type="text"
                                                       placeholder="نام" value="<?php echo e(old('first_name')); ?>"/>
                                            </div>
                                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="last_name" class="form-control" name="last_name" type="text"
                                                       placeholder="نام خانوادگی" value="<?php echo e(old('last_name')); ?>"/>
                                            </div>
                                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="national_code" class="form-control" name="national_code" type="text"
                                                       placeholder="کد ملی" value="<?php echo e(old('national_code')); ?>"/>
                                            </div>
                                            <?php $__errorArgs = ['national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="email" class="form-control" name="email" type="email"
                                                       placeholder="ایمیل" value="<?php echo e(old('email')); ?>"/>
                                            </div>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="password" class="form-control" name="password" type="password"
                                                       placeholder="رمز عبور" value="<?php echo e(old('password')); ?>"/>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger text-sm"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="password_confirmation" class="form-control" name="password_confirmation" type="password"
                                                       placeholder="تکرار رمز عبور"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-outline w-100">ثبت نام</button>
                                </div>
                            </form>

                            <hr/>
                            <div class="auth-link">
                                <span>قبلا ثبت نام کرده‌اید؟ </span>
                                <a href="<?php echo e(route('auth.login.form')); ?>">وارد شوید</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('Shared::layouts.site.auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Auth/resources/views/site/register.blade.php ENDPATH**/ ?>