<?php $__env->startSection('title', 'لوگوهای برند'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .client-logo-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 1rem;
        }
        .client-logo-card {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }
        .client-logo-preview {
            height: 140px;
            background: #f5f6fa;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .client-logo-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .client-logo-body {
            padding: .9rem;
        }
        @media (max-width: 1199px) {
            .client-logo-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 767px) {
            .client-logo-grid { grid-template-columns: 1fr; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            لوگوهای برند
        </h4>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($tableMissing): ?>
        <div class="alert alert-warning">
            جدول لوگوهای برند هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و صفحه اصلی فعلاً از لوگوهای قبلی استفاده می‌کند.
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن لوگو</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.client-logos.store')); ?>" enctype="multipart/form-data" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" maxlength="120" required <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">ALT تصویر</label>
                    <input type="text" name="alt" value="<?php echo e(old('alt')); ?>" class="form-control" maxlength="255" placeholder="اگر خالی باشد عنوان استفاده می‌شود" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="url" name="link_url" value="<?php echo e(old('link_url')); ?>" class="form-control" maxlength="255" dir="ltr" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-1 col-md-3">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>" class="form-control" min="0" max="9999" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">تصویر</label>
                    <input type="file" name="image" class="form-control" accept="image/*" required <?php if($tableMissing): echo 'disabled'; endif; ?>>
                </div>
                <div class="col-lg-1 col-md-3">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <label class="form-check-label">فعال</label>
                    </div>
                    <button class="btn btn-success w-100" type="submit" <?php if($tableMissing): echo 'disabled'; endif; ?>>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(! $tableMissing): ?>
        <div class="client-logo-grid">
            <?php $__empty_1 = true; $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="client-logo-card">
                    <div class="client-logo-preview">
                        <img src="<?php echo e($logo->image_url); ?>" alt="<?php echo e($logo->display_alt); ?>">
                    </div>
                    <div class="client-logo-body">
                        <form method="POST" action="<?php echo e(route('admin.client-logos.update', $logo)); ?>" enctype="multipart/form-data" class="row g-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="col-12">
                                <label class="form-label">عنوان</label>
                                <input type="text" name="title" value="<?php echo e(old('title', $logo->title)); ?>" class="form-control form-control-sm" maxlength="120" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">ALT تصویر</label>
                                <input type="text" name="alt" value="<?php echo e(old('alt', $logo->alt)); ?>" class="form-control form-control-sm" maxlength="255">
                            </div>
                            <div class="col-8">
                                <label class="form-label">لینک</label>
                                <input type="url" name="link_url" value="<?php echo e(old('link_url', $logo->link_url)); ?>" class="form-control form-control-sm" maxlength="255" dir="ltr">
                            </div>
                            <div class="col-4">
                                <label class="form-label">ترتیب</label>
                                <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $logo->sort_order)); ?>" class="form-control form-control-sm" min="0" max="9999">
                            </div>
                            <div class="col-12">
                                <label class="form-label">تعویض تصویر</label>
                                <input type="file" name="image" class="form-control form-control-sm" accept="image/*">
                            </div>
                            <div class="col-6">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="is_active" value="1" class="form-check-input" <?php if($logo->is_active): echo 'checked'; endif; ?>>
                                    <label class="form-check-label">فعال</label>
                                </div>
                            </div>
                            <div class="col-6 text-end">
                                <button class="btn btn-sm btn-primary" type="submit">
                                    <i class="bx bx-save"></i>
                                    ذخیره
                                </button>
                            </div>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.client-logos.destroy', $logo)); ?>" class="mt-2" onsubmit="return confirm('این لوگو حذف شود؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger w-100" type="submit">
                                <i class="bx bx-trash"></i>
                                حذف
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-info mb-0">
                    هنوز لوگویی ثبت نشده است. تا زمان ثبت لوگو، صفحه اصلی از لوگوهای قبلی فایل‌سیستمی استفاده می‌کند.
                </div>
            <?php endif; ?>
        </div>

        <div class="mt-3">
            <?php echo e($logos->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/client_logos/index.blade.php ENDPATH**/ ?>