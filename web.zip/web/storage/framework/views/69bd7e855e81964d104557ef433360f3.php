<?php use Modules\Billboard\Models\Billboard; ?>


<?php $__env->startSection('title', 'عکس های بیلبورد'); ?>

<?php $__env->startSection('main'); ?>
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
    <span><a class="text-muted fw-light" href="<?php echo e(route('admin.billboard.index')); ?>">لیست بیلبوردها/</a></span>
    <span>تصاویر <?php echo e($billboard->name); ?></span>
</h4>

<a href="<?php echo e(route('admin.billboard.image.create', $billboard)); ?>" type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>تصویر</th>
                <th>متن جایگزین عکس</th>
                <th>کپشن</th>
                <th>لینک عکس</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $attachments->items(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td>
                    <img src="<?php echo e(asset('storage/' . $row['thumbnails']['small'])); ?>">
                </td>
                <td><?php echo e($row['meta']['image_alt']); ?></td>
                <td><?php echo e($row['meta']['caption']); ?></td>
                <td><?php echo e($row['meta']['link']); ?></td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('admin.billboard.image.edit', ['billboard' => $billboard, 'billboard_image' => $row['attachment_id']])); ?>"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="<?php echo e(route('admin.billboard.image.destroy', ['billboard' => $billboard, 'billboard_image' => $row['attachment_id']])); ?>"
                            class="delete-form d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-4">
    <?php echo e($attachments->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Billboard/resources/views/admin/billboard_image/index.blade.php ENDPATH**/ ?>