<?php $__env->startSection('title', 'لاگ سیستم'); ?>

<?php $__env->startSection('main'); ?>
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
            لاگ سیستم
        </h4>
    </div>

    <div class="alert alert-info">
        این صفحه فقط برای مشاهده لاگ‌هاست. مقدارهای حساس مثل API key، token و password قبل از نمایش ماسک می‌شوند.
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">فیلتر لاگ‌ها</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.logs.index')); ?>" class="row g-3">
                <div class="col-lg-3 col-md-6">
                    <label class="form-label" for="file">فایل لاگ</label>
                    <select id="file" name="file" class="form-select">
                        <?php $__empty_1 = true; $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($file['name']); ?>" <?php if($selectedFile === $file['name']): echo 'selected'; endif; ?>>
                                <?php echo e($file['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">فایلی وجود ندارد</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="col-lg-2 col-md-6">
                    <label class="form-label" for="level">سطح</label>
                    <select id="level" name="level" class="form-select">
                        <option value="">همه</option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level); ?>" <?php if($selectedLevel === $level): echo 'selected'; endif; ?>><?php echo e(strtoupper($level)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-lg-2 col-md-6">
                    <label class="form-label" for="lines">تعداد خطوط</label>
                    <select id="lines" name="lines" class="form-select">
                        <?php $__currentLoopData = [100, 300, 500, 1000, 2000]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>" <?php if($lines === $option): echo 'selected'; endif; ?>><?php echo e($option); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-lg-3 col-md-6">
                    <label class="form-label" for="q">جستجو</label>
                    <input
                        id="q"
                        name="q"
                        type="search"
                        value="<?php echo e($query); ?>"
                        class="form-control"
                        placeholder="مثلاً SMS یا Faraz"
                    >
                </div>

                <div class="col-lg-2 col-md-12 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bx bx-search"></i>
                        نمایش
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between gap-3 flex-wrap">
            <h5 class="mb-0">نتیجه لاگ</h5>
            <?php if($selectedFile): ?>
                <span class="badge bg-label-secondary" dir="ltr"><?php echo e($selectedFile); ?></span>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <?php if($files->isEmpty()): ?>
                <div class="alert alert-warning mb-0">هیچ فایل لاگی در مسیر storage/logs پیدا نشد.</div>
            <?php elseif(empty($logLines)): ?>
                <div class="alert alert-warning mb-0">برای فیلتر انتخاب‌شده خطی پیدا نشد.</div>
            <?php else: ?>
                <div class="log-viewer" dir="ltr">
                    <?php $__currentLoopData = $logLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <pre class="mb-1 p-2 rounded bg-light text-dark border" style="white-space: pre-wrap; word-break: break-word; font-size: 12px;"><?php echo e($line); ?></pre>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/admin/logs/index.blade.php ENDPATH**/ ?>