
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.pricing_rules.index')); ?>">قوانین قیمت‌گذاری/</a></span>
        حذف دسته‌ای قوانین
    </h4>

    <div class="alert alert-warning mb-4">
        <strong>هشدار:</strong> با حذف قوانین، این عملیات غیرقابل بازگشت است. لطفا با دقت قوانین مورد نظر را انتخاب کنید.
    </div>

    <form method="GET" action="<?php echo e(route('admin.pricing_rules.bulk.delete')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-6">
                <label class="form-label">استان</label>
                <select name="province_id" id="province_id" class="form-select" onchange="this.form.submit()">
                    <option value="">انتخاب استان</option>
                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($province->id); ?>" <?php echo e($provinceId == $province->id ? 'selected' : ''); ?>>
                            <?php echo e($province->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </form>

    <?php if($provinceId && $pricingRules->count() > 0): ?>
        <form action="<?php echo e(route('admin.pricing_rules.bulk.destroy')); ?>" method="POST" id="bulkDeleteForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">قوانین استان: <?php echo e($provinces->firstWhere('id', $provinceId)->title ?? ''); ?></h5>
                    <div>
                        <button type="button" class="btn btn-sm btn-primary" id="select_all_rules">انتخاب همه</button>
                        <button type="button" class="btn btn-sm btn-secondary" id="deselect_all_rules">لغو انتخاب همه</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-striped table-hover">
                            <thead class="table-light sticky-top">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select_all_checkbox" title="انتخاب همه">
                                    </th>
                                    <th>شهر مبدا</th>
                                    <th>شهر مقصد</th>
                                    <th>دسته‌بندی ماشین</th>
                                    <th>نحوه محاسبه</th>
                                    <th>قیمت ثابت</th>
                                    <th>قیمت هر کیلومتر</th>
                                    <th>اولویت</th>
                                    <th>وضعیت</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pricingRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="rule_ids[]" value="<?php echo e($rule->id); ?>" class="rule-checkbox">
                                        </td>
                                        <td><?php echo e($rule->origin_city); ?></td>
                                        <td><?php echo e($rule->destination_city); ?></td>
                                        <td>
                                            <?php if($rule->carCategory): ?>
                                                <span class="badge bg-secondary"><?php echo e($rule->carCategory->title); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($rule->pricing_type == 'fixed' ? 'primary' : 'info'); ?>">
                                                <?php echo e($rule->getPricingTypeLabel()); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(number_format($rule->fixed_price)); ?> تومان</td>
                                        <td><?php echo e(number_format($rule->per_km_price)); ?> تومان</td>
                                        <td>
                                            <span class="badge bg-<?php echo e($rule->priority == 'high' ? 'danger' : ($rule->priority == 'medium' ? 'warning' : 'secondary')); ?>">
                                                <?php echo e($rule->getPriorityLabel()); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($rule->is_active ? 'success' : 'danger'); ?>">
                                                <?php echo e($rule->is_active ? 'فعال' : 'غیرفعال'); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">
                        <strong>تعداد قوانین انتخاب شده: <span id="selected_count">0</span></strong>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-danger" id="submit_btn">حذف قوانین انتخاب شده</button>
                <a href="<?php echo e(route('admin.pricing_rules.index')); ?>" class="btn btn-secondary">انصراف</a>
            </div>
        </form>
    <?php elseif($provinceId && $pricingRules->count() == 0): ?>
        <div class="alert alert-warning">
            هیچ قانونی برای این استان یافت نشد.
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            لطفا یک استان انتخاب کنید.
        </div>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectAllCheckbox = document.getElementById('select_all_checkbox');
            const ruleCheckboxes = document.querySelectorAll('.rule-checkbox');
            const selectAllBtn = document.getElementById('select_all_rules');
            const deselectAllBtn = document.getElementById('deselect_all_rules');
            const selectedCount = document.getElementById('selected_count');
            const bulkDeleteForm = document.getElementById('bulkDeleteForm');
            const submitBtn = document.getElementById('submit_btn');

            function updateSelectedCount() {
                const selected = document.querySelectorAll('.rule-checkbox:checked').length;
                selectedCount.textContent = selected;
                
                if (selectAllCheckbox) {
                    selectAllCheckbox.checked = selected === ruleCheckboxes.length && ruleCheckboxes.length > 0;
                }
            }

            // Select all checkbox
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    updateSelectedCount();
                });
            }

            // Individual checkboxes
            ruleCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateSelectedCount);
            });

            // Select all button
            if (selectAllBtn) {
                selectAllBtn.addEventListener('click', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = true;
                    });
                    if (selectAllCheckbox) selectAllCheckbox.checked = true;
                    updateSelectedCount();
                });
            }

            // Deselect all button
            if (deselectAllBtn) {
                deselectAllBtn.addEventListener('click', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = false;
                    });
                    if (selectAllCheckbox) selectAllCheckbox.checked = false;
                    updateSelectedCount();
                });
            }

            // Form validation
            if (bulkDeleteForm) {
                bulkDeleteForm.addEventListener('submit', function(e) {
                    const selectedRules = document.querySelectorAll('.rule-checkbox:checked');
                    if (selectedRules.length === 0) {
                        e.preventDefault();
                        alert('لطفا حداقل یک قانون را برای حذف انتخاب کنید');
                        return false;
                    }

                    // Confirm deletion
                    const confirmMessage = `آیا از حذف ${selectedRules.length} قانون انتخاب شده اطمینان دارید؟\n\nاین عملیات غیرقابل بازگشت است!`;
                    if (!confirm(confirmMessage)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }

            // Initialize count
            updateSelectedCount();
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/admin/pricing_rules/bulk_delete.blade.php ENDPATH**/ ?>