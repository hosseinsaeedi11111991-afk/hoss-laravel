<?php $__env->startSection('title', 'تاکسی بین شهری - تماس: 09120983462 رزرو آنلاین و تلفنی'); ?>

<?php $__env->startSection('description', 'تاکسی بین شهری VIP اولین و بزرگترین رزرو تاکسی آنلاین بین شهری در ایران با ماشین های ایرانی و خارجی'); ?>


<?php $__env->startSection('meta'); ?>
    <?php
        $homeCanonical = 'https://viptaxiiran.com/';
        $homeTitle = trim($__env->yieldContent('title'));
        $homeDescription = trim($__env->yieldContent('description'));
        $homeSiteName = 'وی آی پی تاکسی ایران';
        $homeImageUrl = 'https://viptaxiiran.com/site/img/gold_logo.webp';
        $homeImageWidth = 95;
        $homeImageHeight = 96;
        $homePublishedAt = '2024-12-15T11:57:15+00:00';
        $homeModifiedAt = '2026-07-17T00:00:00+03:30';
        $homeOrganizationId = $homeCanonical . '#organization';
        $homeWebsiteId = $homeCanonical . '#website';
        $homeWebpageId = $homeCanonical . '#webpage';
        $homePrimaryImageId = $homeCanonical . '#primaryimage';
        $homeLogoId = $homeCanonical . '#logo';

        $homeSchema = [
            '@context' => 'https://schema.org',
            '@graph' => [
                [
                    '@type' => 'WebPage',
                    '@id' => $homeWebpageId,
                    'url' => $homeCanonical,
                    'name' => $homeTitle,
                    'isPartOf' => ['@id' => $homeWebsiteId],
                    'about' => ['@id' => $homeOrganizationId],
                    'primaryImageOfPage' => ['@id' => $homePrimaryImageId],
                    'image' => ['@id' => $homePrimaryImageId],
                    'thumbnailUrl' => $homeImageUrl,
                    'datePublished' => $homePublishedAt,
                    'dateModified' => $homeModifiedAt,
                    'description' => $homeDescription,
                    'breadcrumb' => ['@id' => $homeCanonical . '#breadcrumb'],
                    'inLanguage' => 'fa-IR',
                    'potentialAction' => [
                        [
                            '@type' => 'ReadAction',
                            'target' => [$homeCanonical],
                        ],
                    ],
                ],
                [
                    '@type' => 'ImageObject',
                    'inLanguage' => 'fa-IR',
                    '@id' => $homePrimaryImageId,
                    'url' => $homeImageUrl,
                    'contentUrl' => $homeImageUrl,
                    'width' => $homeImageWidth,
                    'height' => $homeImageHeight,
                    'caption' => $homeTitle,
                ],
                [
                    '@type' => 'BreadcrumbList',
                    '@id' => $homeCanonical . '#breadcrumb',
                    'itemListElement' => [
                        [
                            '@type' => 'ListItem',
                            'position' => 1,
                            'name' => 'خانه',
                            'item' => $homeCanonical,
                        ],
                    ],
                ],
                [
                    '@type' => 'WebSite',
                    '@id' => $homeWebsiteId,
                    'url' => $homeCanonical,
                    'name' => $homeSiteName,
                    'description' => $homeDescription,
                    'publisher' => ['@id' => $homeOrganizationId],
                    'alternateName' => 'تاکسی آنلاین برون شهری وی آی پی',
                    'inLanguage' => 'fa-IR',
                ],
                [
                    '@type' => 'Organization',
                    '@id' => $homeOrganizationId,
                    'name' => $homeSiteName,
                    'url' => $homeCanonical,
                    'logo' => [
                        '@type' => 'ImageObject',
                        'inLanguage' => 'fa-IR',
                        '@id' => $homeLogoId,
                        'url' => $homeImageUrl,
                        'contentUrl' => $homeImageUrl,
                        'width' => $homeImageWidth,
                        'height' => $homeImageHeight,
                        'caption' => $homeSiteName,
                    ],
                    'image' => ['@id' => $homeLogoId],
                ],
            ],
        ];
    ?>

    <link rel="canonical" href="<?php echo e($homeCanonical); ?>" />

    <meta property="og:locale" content="fa_IR" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo e($homeTitle); ?>" />
    <meta property="og:description" content="<?php echo e($homeDescription); ?>" />
    <meta property="og:url" content="<?php echo e($homeCanonical); ?>" />
    <meta property="og:site_name" content="<?php echo e($homeSiteName); ?>" />
    <meta property="og:updated_time" content="<?php echo e($homeModifiedAt); ?>" />
    <meta property="og:image" content="<?php echo e($homeImageUrl); ?>" />
    <meta property="og:image:secure_url" content="<?php echo e($homeImageUrl); ?>" />
    <meta property="og:image:url" content="<?php echo e($homeImageUrl); ?>" />
    <meta property="og:image:width" content="<?php echo e($homeImageWidth); ?>" />
    <meta property="og:image:height" content="<?php echo e($homeImageHeight); ?>" />
    <meta property="og:image:type" content="image/webp" />
    <meta property="og:image:alt" content="<?php echo e($homeTitle); ?>" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo e($homeTitle); ?>" />
    <meta name="twitter:description" content="<?php echo e($homeDescription); ?>" />
    <meta name="twitter:image" content="<?php echo e($homeImageUrl); ?>" />
    <meta name="twitter:image:alt" content="<?php echo e($homeTitle); ?>" />

    <script type="application/ld+json"><?php echo json_encode($homeSchema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, 512) ?></script>

    <?php if(!empty($homeFaqSchema)): ?>
        <script type="application/ld+json"><?php echo json_encode($homeFaqSchema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, 512) ?></script>
    <?php endif; ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('preload-lcp'); ?>
    <!-- Preload only the central Neshan map tile; other tiles load on demand. -->
    <link rel="preload" as="image" href="https://api.neshan.org/v1/map/12/2632/1612?key=web.3d4ed3ed30194ca89c2c8dfc43f074d5" fetchpriority="low">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('map/leaflet.css')); ?>"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <style>
        .bg-gray {
            background-color: white !important;
        }

        :root {
            /* Primary Colors - هماهنگ با تمپلیت */
            --primary-color: #f5b754;
            --primary-dark: #e0a543;
            --primary-light: rgba(245, 183, 84, 0.1);

            /* Secondary Colors */
            --secondary-color: #ff6b6b;
            --secondary-dark: #ee5a52;

            /* Success Colors */
            --success-color: #f5b754;
            --success-dark: #e0a543;

            /* Warning Colors */
            --warning-color: #fdcb6e;
            --warning-dark: #e17055;
            --warning-light: rgba(253, 203, 110, 0.1);

            /* Info Colors */
            --info-color: #74b9ff;
            --info-dark: #0984e3;

            /* Search Colors */
            --search-color: #f5b754;
            --search-dark: #e0a543;

            /* Text Colors - هماهنگ با تمپلیت */
            --text-primary: #1b1b1b;
            --text-secondary: #555;
            --text-muted: #555;

            /* Background Colors */
            --bg-white: #ffffff;
            --bg-light: #f8f9fa;
            --bg-overlay: rgba(255, 255, 255, 0.98);
            --bg-glass: rgba(255, 255, 255, 0.95);

            /* Border Colors */
            --border-light: #f0f0f0;
            --border-medium: #dee2e6;
            --border-dark: #ced4da;

            /* Shadow Colors */
            --shadow-light: rgba(0, 0, 0, 0.05);
            --shadow-medium: rgba(0, 0, 0, 0.12);
            --shadow-dark: rgba(0, 0, 0, 0.15);
            --shadow-darker: rgba(0, 0, 0, 0.2);

            /* Spacing */
            --spacing-xs: 4px;
            --spacing-sm: 8px;
            --spacing-md: 12px;
            --spacing-lg: 16px;
            --spacing-xl: 20px;
            --spacing-xxl: 24px;

            /* Border Radius - هماهنگ با تمپلیت */
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 30px;
            --radius-xl: 30px;
            --radius-full: 50%;

            /* Font Sizes */
            --font-xs: 12px;
            --font-sm: 14px;
            --font-md: 16px;
            --font-lg: 18px;
            --font-xl: 20px;

            /* Font Sizes for Mobile */
            --font-xs-mobile: 14px;
            --font-sm-mobile: 16px;
            --font-md-mobile: 18px;
            --font-lg-mobile: 20px;
            --font-xl-mobile: 22px;

            /* Transitions */
            --transition-fast: 0.2s ease;
            --transition-normal: 0.3s ease;
            --transition-slow: 0.5s ease;

            /* Z-index */
            --z-dropdown: 1000;
            --z-modal: 2000;
            --z-tooltip: 10000;
        }

        .leaflet-top.leaflet-left {
            display: none;
        }

        .leaflet-bottom.leaflet-right {
            display: none;
        }

        /* استایل‌های Leaflet Popup - هماهنگ با تمپلیت */
        .leaflet-popup-content-wrapper {
            border-radius: var(--radius-md);
            font-family: 'peyda', sans-serif;
            box-shadow: 0 8px var(--spacing-xxl) var(--shadow-dark);
        }

        .leaflet-popup-content {
            margin: 0;
            padding: 0;
            font-family: 'peyda', sans-serif;
            font-size: var(--font-sm);
            color: var(--text-primary);
        }

        @media (max-width: 768px) {
            .leaflet-popup-content {
                font-size: 16px; /* افزایش اندازه فونت popup در موبایل */
            }
        }

        .leaflet-popup-tip {
            background: var(--bg-white);
        }

        .leaflet-container a.leaflet-popup-close-button {
            color: var(--text-secondary);
            font-size: 20px;
            padding: 8px;
        }

        .leaflet-container a.leaflet-popup-close-button:hover {
            color: var(--text-primary);
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        body {
            font-family: 'peyda', sans-serif;
            direction: rtl;
            text-align: right;
            padding: 0;
            margin: 0;
        }

        @media (max-width: 768px) {
            html, body {
                height: 100%;
                overflow-x: hidden;
                overflow-y: auto;
            }

            body {
                position: relative;
                width: 100%;
                min-height: 100vh;
                min-height: 100dvh;
            }
        }

        /* استایل اصلی برای دسکتاپ */
        @media (min-width: 769px) {
            #map {
                height: 480px;
                width: 100%;
                border-radius: var(--radius-md);
                overflow: hidden;
                box-shadow: 0 4px 20px var(--shadow-medium);
            }
        }

        /* استایل پیش‌فرض برای موبایل (قبل از media query موبایل) */
        #map {
            height: 65vh;
            height: 65dvh;
            width: 100%;
            border-radius: 0;
            overflow: hidden;
            box-shadow: none;
        }

        .map-wrap {
            /*margin-top: 102px;*/
            position: relative;
            height: 75vh;
            height: 75dvh;
            
        }

        /* Override برای دسکتاپ */
        @media (min-width: 769px) {
            .map-wrap {
                height: auto;
            }
        }

        .map-actions {
            position: absolute;
            left: 50%;
            bottom: var(--spacing-xl);
            transform: translateX(-50%);
            display: flex;
            gap: var(--spacing-md);
            background: var(--bg-overlay);
            padding: var(--spacing-sm) var(--spacing-md);
            border-radius: var(--radius-xl);
            box-shadow: 0 8px var(--spacing-xxl) var(--shadow-medium), 0 0 0 1px var(--shadow-light);
            z-index: 500;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .map-actions .btn {
            width: auto;
            padding: 14px 24px;
            height: auto;
            font-weight: 300;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }

        .map-search {
            position: absolute;
            top: var(--spacing-xl);
            left: var(--spacing-xl);
            display: flex;
            gap: var(--spacing-xs);
            align-items: center;
            background: var(--bg-overlay);
            padding: 6px 10px;
            border-radius: var(--radius-xl);
            box-shadow: 0 4px 12px var(--shadow-medium), 0 0 0 1px var(--shadow-light);
            z-index: 500;
            backdrop-filter: blur(10px);
            transition: var(--transition-normal);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .map-search:hover {
            transform: translate3d(0px, -2px, 0.01px);
            box-shadow: 0 8px 20px var(--shadow-dark), 0 0 0 1px var(--shadow-light);
        }

        .map-search .btn {
            width: 36px;
            height: 36px;
            padding: 0;
            min-width: 36px;
        }

        .map-search .btn span {
            font-size: 16px !important;
        }

        .map-search .search-input {
            width: 240px;
            padding: 10px 14px;
            font-size: 13px;
            border: 1px solid var(--border-medium);
            border-radius: var(--radius-lg);
        }

        .map-search .search-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px var(--primary-light);
        }

        .map-locate {
            position: absolute;
            top: var(--spacing-xl);
            right: var(--spacing-xl);
            display: flex;
            gap: var(--spacing-xs);
            align-items: center;
            background: var(--bg-overlay);
            padding: 6px;
            border-radius: var(--radius-xl);
            box-shadow: 0 4px 12px var(--shadow-medium), 0 0 0 1px var(--shadow-light);
            z-index: 500;
            backdrop-filter: blur(10px);
            transition: var(--transition-normal);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .map-locate:hover {
            transform: translate3d(0px, -2px, 0.01px);
            box-shadow: 0 8px 20px var(--shadow-dark), 0 0 0 1px var(--shadow-light);
        }

        .map-locate .btn {
            width: 36px;
            height: 36px;
            padding: 0;
            min-width: 36px;
        }

        .map-locate .btn span {
            font-size: 16px !important;
        }

        .search-input {
            width: 280px;
            padding: 14px 20px;
            border: 1px solid var(--border-medium);
            border-radius: var(--radius-lg);
            font-size: var(--font-sm);
            outline: none;
            background: var(--bg-white);
            transition: var(--transition-normal);
            font-family: 'peyda', sans-serif;
            color: var(--text-primary);
            font-weight: 300;
        }

        @media (max-width: 768px) {
            .search-input {
                font-size: 12px; /* افزایش اندازه فونت در موبایل */
            }
        }

        .search-input::placeholder {
            color: var(--text-secondary);
            font-family: 'peyda', sans-serif;
            font-size: var(--font-sm);
            font-weight: 300;
        }

        @media (max-width: 768px) {
            .search-input::placeholder {
                font-size: 16px; /* افزایش اندازه placeholder در موبایل */
            }
        }

        .search-input:focus {
            border-color: var(--primary-color);
            background: var(--bg-white);
            box-shadow: 0 0 0 3px var(--primary-light);
        }

        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--bg-white);
            border-radius: var(--radius-md);
            box-shadow: 0 8px var(--spacing-xxl) var(--shadow-dark);
            max-height: 300px;
            overflow-y: auto;
            z-index: var(--z-dropdown);
            margin-top: var(--spacing-xs);
            display: none;
        }

        .search-result-item {
            padding: var(--spacing-md) var(--spacing-lg);
            cursor: pointer;
            border-bottom: 1px solid var(--border-light);
            transition: var(--transition-fast);
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
        }

        .search-result-item:hover {
            background-color: var(--bg-light);
        }

        .search-result-item:last-child {
            border-bottom: none;
        }

        .search-result-icon {
            font-size: var(--font-lg);
            color: var(--text-secondary);
        }

        .search-result-content {
            flex: 1;
        }

        .search-result-name {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: var(--spacing-xs);
            font-family: 'peyda', sans-serif;
        }

        .search-result-address {
            font-size: var(--font-xs);
            color: var(--text-secondary);
            font-family: 'peyda', sans-serif;
            font-weight: 300;
        }

        .search-loading {
            padding: var(--spacing-md) var(--spacing-lg);
            text-align: center;
            color: var(--text-secondary);
            font-size: var(--font-sm);
            font-family: 'peyda', sans-serif;
            font-weight: 300;
        }


        .btn {
            padding: var(--spacing-md);
            margin: 0;
            border: 1px solid transparent;
            border-radius: var(--radius-lg);
            cursor: pointer;
            font-size: var(--font-sm);
            font-weight: 300;
            transition: border-color 300ms ease, transform 300ms ease, background-color 300ms ease, color 300ms ease;
            text-transform: none;
            letter-spacing: 0;
            position: relative;
            overflow: hidden;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'peyda', sans-serif;
            transform-style: preserve-3d;
        }

        @media (max-width: 768px) {
            .btn {
                font-size: 16px; /* افزایش اندازه فونت دکمه‌ها در موبایل */
            }
        }

        .btn:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: var(--transition-slow);
        }

        .btn:hover:before {
            left: 100%;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: var(--text-primary);
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
        }

        .btn-primary:hover {
            transform: translate3d(0px, -6px, 0.01px);
            border-color: var(--primary-dark);
            background-color: var(--primary-dark);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.4);
        }

        .btn-danger {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: var(--bg-white);
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
        }

        .btn-danger:hover {
            transform: translate3d(0px, -6px, 0.01px);
            border-color: var(--secondary-dark);
            background-color: var(--secondary-dark);
            box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
        }

        .btn-success {
            background-color: var(--success-color);
            border-color: var(--success-color);
            color: var(--text-primary);
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
        }

        .btn-success:hover {
            transform: translate3d(0px, -6px, 0.01px);
            border-color: var(--success-dark);
            background-color: var(--success-dark);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.4);
        }

        .btn-warning {
            background-color: var(--warning-color);
            border-color: var(--warning-color);
            color: var(--text-primary);
            box-shadow: 0 4px 15px rgba(253, 203, 110, 0.3);
        }

        .btn-warning:hover {
            transform: translate3d(0px, -6px, 0.01px);
            border-color: var(--warning-dark);
            background-color: var(--warning-dark);
            box-shadow: 0 8px 25px rgba(253, 203, 110, 0.4);
        }


        /* custom marker styles - Snap-like design */
        .custom-marker {
            position: relative;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15), 0 0 0 3px rgba(255, 255, 255, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
        }

        .custom-marker:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2), 0 0 0 4px rgba(255, 255, 255, 0.9);
        }

        .custom-marker .glyph {
            font-size: 18px;
            color: white;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        }

        .marker-origin {
            background: var(--primary-color);
            border: 3px solid rgba(255, 255, 255, 0.9);
        }

        .marker-destination {
            background: var(--secondary-color);
            border: 3px solid rgba(255, 255, 255, 0.9);
        }

        .marker-search {
            background: var(--search-color);
            border: 3px solid rgba(255, 255, 255, 0.9);
        }

        .marker-locate {
            background: var(--info-color);
            border: 3px solid rgba(255, 255, 255, 0.9);
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15), 0 0 0 3px rgba(255, 255, 255, 0.9);
            }
            50% {
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15), 0 0 0 6px rgba(255, 255, 255, 0.4);
            }
            100% {
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15), 0 0 0 3px rgba(255, 255, 255, 0.9);
            }
        }

        /* popup choice buttons - هماهنگ با تمپلیت */
        .choice-wrap {
            min-width: 200px;
            text-align: center;
            padding: 16px;
            font-family: 'peyda', sans-serif;
        }

        .choice-actions {
            display: flex;
            gap: var(--spacing-lg);
            justify-content: center;
            align-items: center;
        }

        .choice-btn-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: var(--spacing-sm);
        }

        .choice-label {
            font-family: 'peyda', sans-serif;
            font-size: var(--font-xs);
            font-weight: 300;
            color: var(--text-primary);
            margin-top: 4px;
        }

        .choice-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: var(--spacing-sm);
            padding: var(--spacing-md);
            border-radius: var(--radius-lg);
            color: var(--text-primary);
            border: 1px solid transparent;
            cursor: pointer;
            font-weight: 300;
            font-size: var(--font-sm);
            transition: border-color 300ms ease, transform 300ms ease, background-color 300ms ease, color 300ms ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            width: 50px;
            height: 50px;
            font-family: 'peyda', sans-serif;
            transform-style: preserve-3d;
        }

        .choice-btn:hover {
            transform: translate3d(0px, -6px, 0.01px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .choice-btn.origin {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .choice-btn.origin:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .choice-btn.destination {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: var(--bg-white);
        }

        .choice-btn.destination:hover {
            background-color: var(--secondary-dark);
            border-color: var(--secondary-dark);
        }

        .choice-icon {
            font-size: var(--font-lg);
        }

        /* preloader overlay */
        .preloader-overlay {
            position: fixed;
            inset: 0;
            background: rgba(255, 255, 255, 0.95);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            backdrop-filter: blur(5px);
            transition: opacity 0.3s ease;
        }

        .preloader-box {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: var(--spacing-md);
            padding: var(--spacing-xl) var(--spacing-xxl);
            background: var(--bg-white);
            border-radius: var(--radius-md);
            box-shadow: 0 8px var(--spacing-xxl) var(--shadow-dark);
            border: 1px solid var(--border-medium);
        }

        .preloader-box > div:last-child {
            font-family: 'peyda', sans-serif;
            font-weight: 300;
            color: var(--text-primary);
            font-size: var(--font-md);
        }

        .spinner {
            width: 42px;
            height: 42px;
            border: 4px solid var(--border-medium);
            border-top-color: var(--primary-color);
            border-radius: var(--radius-full);
            animation: spin 0.9s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* نوار اسکرول زیر نقشه - در همه حالت‌ها */
        .scroll-indicator {
            position: relative;
            width: 100%;
            height: 60px;
            background: linear-gradient(to top, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.7));
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 999;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
            padding: 8px var(--spacing-md);
            margin-top: 0;
        }

        .scroll-indicator-btn {
            background-color: var(--primary-color);
            border: 1px solid var(--primary-color);
            color: var(--text-primary);
            padding: 10px 24px;
            border-radius: var(--radius-lg);
            font-family: 'peyda', sans-serif;
            font-size: 14px;
            font-weight: 300;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: border-color 300ms ease, transform 300ms ease, background-color 300ms ease, color 300ms ease;
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
            transform-style: preserve-3d;
            min-width: 160px;
            margin: 0 auto;
        }

        @media (max-width: 768px) {
            .scroll-indicator-btn {
                font-size: 16px; /* افزایش اندازه فونت در موبایل */
                padding: 12px 24px; /* افزایش padding برای لمس بهتر */
            }
        }

        .scroll-indicator-btn:hover {
            transform: translate3d(0px, -4px, 0.01px);
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.4);
        }

        .scroll-indicator-btn::before {
            content: '↓';
            font-size: 18px;
            display: inline-block;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-10px);
            }
            60% {
                transform: translateY(-5px);
            }
        }

        /* Responsive Styles - موبایل */
        @media (max-width: 768px) {
            /* افزایش اندازه فونت‌ها در موبایل */
            :root {
                --font-xs: var(--font-xs-mobile);
                --font-sm: var(--font-sm-mobile);
                --font-md: var(--font-md-mobile);
                --font-lg: var(--font-lg-mobile);
                --font-xl: var(--font-xl-mobile);
            }

            body {
                font-size: 16px; /* حداقل اندازه فونت برای خوانایی بهتر */
            }

            #map {
                height: 72vh !important;
                height: 72dvh !important; /* برای مرورگرهای جدید */
                min-height: 69vh !important;
                border-radius: 0 !important;
                box-shadow: none !important;
            }

            .map-wrap {
                height: 42vh !important;
                height: 42vh !important;
                min-height:69vh !important;
                position: relative;
                margin-top: -55px;
            }

            .map-search {
                top: var(--spacing-sm);
                left: var(--spacing-sm);
                right: var(--spacing-sm);
                width: auto;
                padding: 8px 12px;
                flex-wrap: nowrap;
            }

            .map-search .search-input {
                width: 100%;
                flex: 1;
                min-width: 0;
                padding: 10px 12px;
                font-size: 16px; /* افزایش از 14px به 16px */
            }

            .map-search .btn {
                width: 40px;
                height: 40px;
                flex-shrink: 0;
            }

            .map-locate {
                top: auto;
                bottom: 140px; /* فاصله از دکمه‌های action و نوار اسکرول */
                right: var(--spacing-sm);
                padding: 8px;
                z-index: 501; /* بالاتر از map-actions */
            }

            .map-locate .btn {
                width: 48px;
                height: 48px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            }

            .map-locate .btn span {
                font-size: 20px !important;
            }

            .map-locate .btn:active {
                transform: scale(0.95);
            }

            .map-actions {
                left: var(--spacing-sm);
                right: var(--spacing-sm);
                bottom: 5px; /* فاصله از نوار اسکرول */
                transform: none;
                width: auto;
                flex-direction: column;
                gap: var(--spacing-sm);
                padding: var(--spacing-sm);
            }

            .map-actions .btn {
                width: 100%;
                padding: 12px 20px;
                justify-content: center;
                font-size: 16px; /* افزایش از 14px به 16px */
            }

            .search-results {
                max-height: 200px;
                border-radius: var(--radius-md);
            }

            .search-result-item {
                padding: var(--spacing-sm) var(--spacing-md);
            }

            .search-result-name {
                font-size: 16px !important; /* افزایش اندازه فونت نام */
            }

            .search-result-address {
                font-size: 14px !important; /* افزایش اندازه فونت آدرس */
            }

            .choice-wrap {
                min-width: 180px;
                padding: 12px;
            }

            .choice-btn {
                width: 45px;
                height: 45px;
            }

            .choice-label {
                font-size: 13px; /* افزایش از 11px به 13px */
            }

            /* نمایش بخش‌های پایین صفحه برای اسکرول */
            .map-wrap ~ section,
            .map-wrap ~ div:not(.preloader-overlay) {
                display: block !important;
                position: relative;
                z-index: 1;
            }

        }

        @media (max-width: 480px) {
            body {
                font-size: 15px; /* حداقل اندازه فونت برای صفحه‌های کوچک */
            }

            .map-search {
                top: var(--spacing-xs);
                left: var(--spacing-xs);
                right: var(--spacing-xs);
                padding: 6px 10px;
            }

            .map-search .search-input {
                padding: 8px 10px;
                font-size: 15px; /* افزایش از 13px به 15px */
            }

            .map-search .btn {
                width: 36px;
                height: 36px;
            }

            .map-locate {
                bottom: 130px; /* فاصله از دکمه‌های action و نوار اسکرول */
                right: var(--spacing-xs);
                padding: 6px;
                z-index: 501; /* بالاتر از map-actions */
            }

            .map-locate .btn {
                width: 44px;
                height: 44px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            }

            .map-locate .btn span {
                font-size: 18px !important;
            }

            .map-locate .btn:active {
                transform: scale(0.95);
            }

            .map-actions {
                left: var(--spacing-xs);
                right: var(--spacing-xs);
                bottom: 5px; /* فاصله از نوار اسکرول */
                padding: 8px;
            }

            .map-actions .btn {
                padding: 10px 16px;
                font-size: 15px; /* افزایش از 13px به 15px */
            }

            .choice-wrap {
                min-width: 160px;
                padding: 10px;
            }

            .choice-btn {
                width: 40px;
                height: 40px;
            }

            .choice-label {
                font-size: 12px; /* افزایش اندازه label */
            }

            .choice-icon {
                font-size: 18px; /* افزایش از 16px به 18px */
            }
        }


        /* برای حالت landscape در موبایل */
        @media (max-width: 768px) and (orientation: landscape) {
            #map {
                height: 65vh !important;
                height: 42dvh !important;
            }

            .map-wrap {
                height: 72vh !important;
                height: 72dvh !important;
            }

            .map-search {
                top: var(--spacing-xs);
            }

            .map-locate {
                bottom: 60px;
                z-index: 501;
            }

            .map-locate .btn {
                width: 48px;
                height: 48px;
            }

            .map-locate .btn span {
                font-size: 20px !important;
            }

            .map-actions {
                bottom: var(--spacing-xs);
                flex-direction: row;
                justify-content: center;
            }

            .map-actions .btn {
                width: auto;
                flex: 1;
                min-width: 0;
            }
        }

        /* Mobile Bottom Header */
        .mobile-bottom-header {
            display: none;
            position: fixed !important;
            bottom: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            background: var(--primary-color);
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.15);
            z-index: 10000;
            padding: 12px 8px;
            direction: rtl;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            transform: translateZ(0);
            -webkit-transform: translateZ(0);
            will-change: transform;
        }

        .mobile-bottom-header .header-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            width: 100%;
            max-width: 100%;
        }

        .mobile-header-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 2px 3px;
            text-decoration: none;
            color: var(--text-primary);
            transition: all 0.2s ease;
            flex: 1;
            min-width: 0;
            border-radius: 8px;
            margin: 0 2px;
        }

        .mobile-header-item:active {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(0.96);
        }

        .mobile-header-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            font-size: 22px;
            color: var(--text-primary);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .mobile-header-text {
            font-size: 12px;
            font-weight: 500;
            color: var(--text-primary);
            font-family: 'peyda', sans-serif;
            white-space: nowrap;
            text-align: center;
        }

        /* نمایش فقط در موبایل */
        @media (min-width: 769px) {
            .mobile-bottom-header {
                display: none !important;
            }
        }

        /* برای موبایل */
        @media (max-width: 768px) {
            .mobile-bottom-header {
                display: block !important;
                position: fixed !important;
                bottom: 0 !important;
                left: 0 !important;
                right: 0 !important;
                width: 100% !important;
            }

            html, body {
                position: relative;
            }

            /* اضافه کردن padding به body برای جلوگیری از پوشیده شدن محتوا */
            body {
                padding-bottom: 75px;
            }
        }

        @media (max-width: 480px) {
            .mobile-header-icon {
                width: 36px;
                height: 36px;
                font-size: 20px;
            }

            .mobile-header-text {
                font-size: 11px;
            }

            .mobile-header-item {
                padding: 6px 8px;
                gap: 5px;
            }

            .mobile-bottom-header {
                padding: 10px 6px;
            }
        }

        /* Car Categories with Pricing Styles */
        .car-categories-pricing {
            background: var(--bg-light);
        }

        .category-pricing-card {
            background: var(--bg-white);
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: 0 4px 20px var(--shadow-medium);
            transition: var(--transition-normal);
            height: 100%;
            display: flex;
            flex-direction: column;
            font-family: 'peyda', sans-serif;
        }

        .category-pricing-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 30px var(--shadow-dark);
        }

        .category-pricing-image {
            width: 100%;
            height: 220px;
            overflow: hidden;
            background: var(--bg-light);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .category-pricing-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition-normal);
        }

        .category-pricing-card:hover .category-pricing-image img {
            transform: scale(1.05);
        }

        .category-pricing-placeholder {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--bg-white);
            font-size: 64px;
        }

        .category-pricing-content {
            padding: var(--spacing-lg);
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: var(--spacing-md);
        }

        .category-pricing-title {
            font-size: var(--font-lg);
            font-weight: 700;
            color: var(--text-primary);
            margin: 0;
            text-align: center;
            font-family: 'peyda', sans-serif;
        }

        .category-pricing-description {
            font-size: var(--font-sm);
            color: var(--text-secondary);
            text-align: center;
            margin: 0;
            font-family: 'peyda', sans-serif;
            font-weight: 300;
            line-height: 1.6;
        }

        .category-pricing-type {
            display: inline-block;
            padding: 6px 12px;
            background: var(--primary-light);
            color: var(--primary-dark);
            border-radius: var(--radius-sm);
            font-size: var(--font-xs);
            font-weight: 600;
            text-align: center;
            align-self: center;
            font-family: 'peyda', sans-serif;
        }

        .category-pricing-prices {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-sm);
            margin-top: auto;
        }

        .price-item {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            padding: var(--spacing-md);
            background: var(--bg-light);
            border-radius: var(--radius-sm);
            transition: var(--transition-fast);
        }

        .price-item:hover {
            background: var(--primary-light);
        }

        .price-item.price-negotiable {
            background: var(--warning-light);
        }

        .price-item.price-negotiable:hover {
            background: var(--warning-color);
        }

        .price-item.price-negotiable .price-value {
            color: var(--warning-dark);
            font-size: var(--font-sm);
        }

        .price-label {
            font-size: var(--font-sm);
            color: var(--text-secondary);
            font-weight: 500;
            font-family: 'peyda', sans-serif;
        }

        .price-value {
            color: var(--primary-color);
            font-size: var(--font-md);
            font-weight: 700;
            font-family: 'peyda', sans-serif;
        }

        @media (max-width: 768px) {
            .category-pricing-image {
                height: 180px;
            }

            .category-pricing-content {
                padding: var(--spacing-md);
            }

            .category-pricing-title {
                font-size: var(--font-md);
            }

            .category-pricing-description {
                font-size: var(--font-xs);
            }

            .price-item {
                flex-direction: column;
                gap: var(--spacing-xs);
                text-align: center;
            }

            .price-label {
                font-size: var(--font-xs);
            }

            .price-value {
                font-size: var(--font-sm);
            }
        }

        /* Phone Modal Styles */
        .phone-modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 100000;
            backdrop-filter: blur(5px);
            transition: opacity 0.3s ease;
        }

        .phone-modal-overlay.show {
            display: flex;
        }

        .phone-modal-box {
            background: var(--bg-white);
            border-radius: var(--radius-md);
            padding: var(--spacing-xxl);
            max-width: 400px;
            width: 90%;
            box-shadow: 0 8px var(--spacing-xxl) var(--shadow-dark);
            border: 1px solid var(--border-medium);
            font-family: 'peyda', sans-serif;
            direction: rtl;
        }

        .phone-modal-title {
            font-size: var(--font-lg);
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: var(--spacing-md);
            text-align: center;
        }

        .phone-modal-description {
            font-size: var(--font-sm);
            color: var(--text-secondary);
            margin-bottom: var(--spacing-lg);
            text-align: center;
        }

        .phone-modal-input {
            width: 100%;
            padding: var(--spacing-md) var(--spacing-lg);
            border: 1px solid var(--border-medium);
            border-radius: var(--radius-lg);
            font-size: var(--font-md);
            font-family: 'peyda', sans-serif;
            text-align: center;
            direction: ltr;
            margin-bottom: var(--spacing-md);
            transition: var(--transition-normal);
        }

        .phone-modal-input:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px var(--primary-light);
        }

        .phone-modal-input.error {
            border-color: var(--secondary-color);
        }

        .phone-modal-error {
            color: var(--secondary-color);
            font-size: var(--font-xs);
            margin-bottom: var(--spacing-md);
            text-align: center;
            display: none;
        }

        .phone-modal-error.show {
            display: block;
        }

        .phone-modal-actions {
            display: flex;
            gap: var(--spacing-md);
            justify-content: center;
        }

        .phone-modal-btn {
            padding: var(--spacing-md) var(--spacing-xl);
            border-radius: var(--radius-lg);
            font-size: var(--font-sm);
            font-weight: 300;
            cursor: pointer;
            transition: var(--transition-normal);
            border: 1px solid transparent;
            font-family: 'peyda', sans-serif;
        }

        .phone-modal-btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: var(--text-primary);
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
        }

        .phone-modal-btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.4);
        }

        .phone-modal-btn-secondary {
            background-color: var(--bg-light);
            border-color: var(--border-medium);
            color: var(--text-secondary);
        }

        .phone-modal-btn-secondary:hover {
            background-color: var(--border-light);
        }

        @media (max-width: 768px) {
            .phone-modal-box {
                padding: var(--spacing-lg);
                max-width: 90%;
            }

            .phone-modal-title {
                font-size: var(--font-md);
            }

            .phone-modal-input {
                font-size: 16px;
                padding: 14px 18px;
            }

            .phone-modal-btn {
                font-size: 16px;
                padding: 12px 20px;
            }
        }
        
        @media (max-width: 768px) {
    .map-actions {
        display: flex;
        flex-direction: row;   /* دکمه‌ها کنار هم */
        gap: 8px;
        justify-content: center;
    }

    .map-actions .btn {
        flex: 1;               /* هم عرض شدن */
        white-space: nowrap;   /* نشکستن متن */
    }
}


    </style>


    <script>
        const csrfMeta = document.querySelector('meta[name="csrf-token"]');
        window.csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
        // مخفی کردن preloader بلافاصله
        (function () {
            const preloader = document.getElementById('preloader_1');
            if (preloader) {
                preloader.style.display = 'none';
            }
        })();
    </script>
    <!-- Preload Leaflet.js for faster map initialization -->
    <?php $__env->startPush('preload-leaflet'); ?>
        <link rel="preload" as="script" href="<?php echo e(asset('map/leaflet.js')); ?>" fetchpriority="high">
        <link rel="preload" as="style" href="<?php echo e(asset('map/leaflet.css')); ?>" fetchpriority="high">
    <?php $__env->stopPush(); ?>

    <script>
        // Load Leaflet immediately (not waiting for DOMContentLoaded)
        if (!window.LeafletLoaded) {
            const s = document.createElement('script');
            s.src = '<?php echo e(asset('map/leaflet.js')); ?>';
            s.async = false; // Load synchronously for faster initialization
            s.onload = () => {
                window.LeafletLoaded = true;
                // Initialize map immediately if DOM is ready
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', initMapIfReady);
                } else {
                    initMapIfReady();
                }
            };
            document.head.appendChild(s);
        }

        function initMapIfReady() {
            if (typeof L !== 'undefined' && !window.mapInitialized) {
                window.mapInitialized = true;
                if (typeof initMap === 'function') {
                    initMap();
                }
            }
        }
    </script>

    <?php $__env->startPush('styles'); ?>
        <style>
            .card-title {
                font-size: 1.1rem;
                white-space: nowrap;
            }

            .card-body p {
                font-size: 0.95rem;
                white-space: nowrap;
            }

            .card i {
                font-size: 1.1rem;
            }

            .section-title {
                font-size: 1.5rem;
                font-weight: 700;
                color: #333;
                margin-bottom: 1rem;
            }

            .section-title i {
                font-size: 1.9rem;
                color: #007bff; /* آبی بوت‌استرپ */
            }

            /* استایل برای عنوان اصلی زیر نقشه */
            .main-title-section {
                text-align: center;
                padding-top: 40px;
                padding-bottom: 20px;
            }

            .main-title-below-map {
                font-size: 2.5rem;
                font-weight: 700;
                color: var(--text-primary);
                margin-bottom: 0;
                font-family: 'peyda', sans-serif;
                direction: rtl;
            }

            /* بهبود ریسپانسیو برای موبایل */
            @media (max-width: 768px) {
                .card-title {
                    font-size: 1.3rem; /* افزایش اندازه */
                }

                .card-body p {
                    font-size: 1.05rem; /* افزایش اندازه */
                    white-space: normal; /* اجازه wrap شدن */
                }

                .card i {
                    font-size: 1.3rem; /* افزایش اندازه */
                }

                .section-title {
                    font-size: 1.8rem; /* افزایش اندازه */
                }

                .section-title i {
                    font-size: 2.2rem; /* افزایش اندازه */
                }

                /* بهبود خوانایی متن‌های عمومی */
                p, span, div, a, li {
                    font-size: 12px !important; /* حداقل اندازه برای خوانایی */
                }

                h1, h2, h3, h4, h5, h6 {
                    font-size: 1.5em !important; /* افزایش اندازه عناوین */
                }

                /* استایل h1 زیر نقشه برای موبایل */
                .main-title-below-map {
                    font-size: 1.8rem !important;
                }
            }

 @media (max-width: 768px) {

    .map-actions {
        position: fixed;
        bottom: 10px;
        left: 10px;
        right: 10px;
        z-index: 999;

        display: flex;
        flex-direction: row;
        gap: 8px;

        background: #fff;
        padding: 8px;
        border-radius: 14px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }

    .map-actions .btn {
        flex: 1;
        padding: 12px 8px;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px;
        white-space: nowrap;
    }
}
        </style>
    <?php $__env->stopPush(); ?>




    <!-- Preloader -->
    <div id="preloader_1" class="preloader-overlay">
        <div class="preloader-box">
            <div class="spinner"></div>
            <div id="preloader-text">در حال محاسبه مسیرها...</div>
        </div>
    </div>

    <!-- Phone Modal -->
    <div id="phoneModal" class="phone-modal-overlay">
        <div class="phone-modal-box">
            <h3 class="phone-modal-title">لطفاً شماره تلفن خود را وارد کنید</h3>
            <p class="phone-modal-description">برای ادامه رزرو، شماره موبایل خود را وارد کنید</p>
            <input type="tel" id="phoneModalInput" class="phone-modal-input" placeholder="09123456789" maxlength="11">
            <div id="phoneModalError" class="phone-modal-error">شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود</div>
            <div class="phone-modal-actions">
                <button type="button" class="phone-modal-btn phone-modal-btn-secondary" onclick="closePhoneModal()">انصراف</button>
                <button type="button" class="phone-modal-btn phone-modal-btn-primary" onclick="submitPhoneAndCalculate()">ادامه</button>
            </div>
        </div>
    </div>

    <!-- Popular Route Phone Modal -->
    <div id="popularRoutePhoneModal" class="phone-modal-overlay">
        <div class="phone-modal-box">
            <h3 class="phone-modal-title">لطفاً شماره تلفن خود را وارد کنید</h3>
            <p class="phone-modal-description">برای رزرو این مسیر، شماره موبایل خود را وارد کنید</p>
            <form id="popularRoutePhoneForm" method="POST" action="">
                <?php echo csrf_field(); ?>
                <input type="tel" name="phone" id="popularRoutePhoneInput" class="phone-modal-input" placeholder="09123456789" maxlength="11">
                <div id="popularRoutePhoneError" class="phone-modal-error">شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود</div>
                <div class="phone-modal-actions">
                    <button type="button" class="phone-modal-btn phone-modal-btn-secondary" onclick="closePopularRoutePhoneModal()">انصراف</button>
                    <button type="submit" class="phone-modal-btn phone-modal-btn-primary">ادامه</button>
                </div>
            </form>
        </div>
    </div>

    <div class="map-wrap">
        <div id="map"></div>
        <div class="map-search">
            <div style="position: relative; flex: 1;">
                <input id="place-search" class="search-input" type="text" placeholder="جستجوی محله یا منطقه..."/>
                <div id="search-results" class="search-results"></div>
            </div>
            <button class="btn btn-primary" onclick="searchPlace()">
                <span class="material-icons" style="font-size: 18px;">🔍</span>
            </button>
        </div>
        <div class="map-locate text-center mt-3">
            <button id="btn-locate" class="btn btn-success d-flex align-items-center gap-2 px-4 py-2"
                    onclick="locateMe()">
                <span class="material-icons">📍</span>
            </button>
            موقعیت مکانی من
        </div>

        <div class="map-actions">
            <button class="btn btn-primary" onclick="calculateAllRoutes()"
                    style="width: auto; padding: 12px 20px; gap: 8px;">
                <span class="material-icons" style="font-size: 18px;">🚗</span>
                محاسبه مسیر
            </button>
            <button class="btn btn-danger" onclick="clearAll()" style="width: auto; padding: 12px 20px; gap: 8px;">
                <span class="material-icons" style="font-size: 18px;">🗑️</span>
                پاک کردن
            </button>
        </div>
    </div>

    <!-- نوار اسکرول زیر نقشه -->
    <div class="scroll-indicator">
        <a href="#nextSection" class="scroll-indicator-btn" onclick="scrollToNextSection()">
            اسکرول کنید
        </a>
    </div>

    <!-- عنوان اصلی زیر نقشه -->
    <section class="section-padding main-title-section">
        <div class="container">
            <h1 class="main-title-below-map">
                رزرو آنلاین تاکسی بین شهری
            </h1>
        </div>
    </section>

    <?php if(isset($popularRoutes) && $popularRoutes->isNotEmpty()): ?>
    <!-- مسیرهای پرطرفدار -->
    <section class="section-padding popular-routes-section" id="popularRoutesSection">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">مسیرهای پرتردد</div>
                    <div class="section-title">مسیرهای <span>پرطرفدار</span></div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $popularRoutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 popular-route-card shadow-sm">
                        <?php if($route->image): ?>
                            <img src="<?php echo e(Storage::url($route->image)); ?>" class="card-img-top" alt="<?php echo e($route->title); ?>" style="height: 160px; object-fit: cover;">
                        <?php else: ?>
                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 160px;">
                                <span class="ti-map-alt text-muted" style="font-size: 3rem;"></span>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($route->title); ?></h5>
                            <p class="card-text text-muted small mb-1"><strong>مبدا:</strong> <?php echo e(Str::limit($route->origin_address, 40)); ?></p>
                            <p class="card-text text-muted small mb-2"><strong>مقصد:</strong> <?php echo e(Str::limit($route->destination_address, 40)); ?></p>
                            <button type="button" class="btn btn-primary btn-sm w-100 popular-route-start-btn" data-start-url="<?php echo e(route('site.popular-route.start', $route)); ?>" title="رزرو این مسیر">
                                رزرو این مسیر
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- About -->
    <section id="nextSection" class="about section-padding">
        <div class="container">
            <div class="row justify-content-between" dir="rtl">
                <div class="col-lg-6 col-md-12 mb-30">
                    <div class="content">
                        <div class="section-subtitle"><?php echo e($homeAboutSection['subtitle']); ?></div>
                        <div class="section-title"><?php echo e($homeAboutSection['title']); ?> <br><span><?php echo e($homeAboutSection['highlight_title']); ?></span></div>
                        <p class="mb-30"><?php echo e($homeAboutSection['body']); ?></p>
                        <?php if(!empty($homeAboutSection['features'])): ?>
                            <ul class="list-unstyled list mb-30">
                                <?php $__currentLoopData = $homeAboutSection['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="list-icon"><span class="ti-check"></span></div>
                                        <div class="list-text">
                                            <p><?php echo e($feature); ?></p>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12" dir="rtl">
                    <div class="item">
                        <img alt="<?php echo e($homeAboutSection['image_alt']); ?>" class="img-fluid" src="<?php echo e($homeAboutSection['image_url']); ?>"/>
                        <div class="curv-butn icon-bg">
                            <a class="vid" href="<?php echo e($homeAboutSection['video_url']); ?>">
                                <div class="icon"><i class="ti-control-play"></i></div>
                            </a>
                            <div class="br-left-top">
                                <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#ffffff"></path>
                                </svg>
                            </div>
                            <div class="br-right-bottom">
                                <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#ffffff"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Services 1 -->
    <!-- Services 1 -->
    <section class="services1 section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">کاری که ما انجام می دهیم</div>
                    <div class="section-title">خدمات<span>ما</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="item">
                            <div class="text">
                                <h3>تاکسی شرکتی</h3>
                                <p>سرویس حمل و نقل سازمانی یا «تاکسی قراردادی یکی دیگر از خدمات تخصصی ما است و سازمان ها و شرکت ها می توانند برای حضور به موقع در جلسات مهم یا سفرهای کاری خود در داخل یا خارج از شهر از این خدمات ما استفاده کنند. </p>

                            </div>
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="<?php echo e(url('/')); ?>#nextSection" title="شروع رزرو">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                          
                          <div class="text">
                                <h3>تاکسی با راننده اختصاصی</h3>
                                  <p>ما برای یک بازه زمانی مشخص که راننده و خودرو را به صورت کاملاً اختصاصی در اختیار مشتریان خود قرار می دهیم تا آنها بتوانند بدون دغدغه به مقصدی که مدنظرشان است بروند.</p>
                            </div>
                          
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="<?php echo e(url('/')); ?>#nextSection" title="شروع رزرو">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="text">
                                <h3>تاکسی فرودگاهی</h3>
                         <p>سرویس تاکسی فرودگاهی برای حمل مسافران از مبدا مورد نظر به فرودگاه و یا برعکس از فرودگاه به مبدا مورد نظر ارائه می شود. ما برای ارائه این سرویس  علاوه بر خودروهای لوکس از رانندگان مجرب کمک می گیریم تا مشتریان به موقع به پرواز خود برسند.</p>
                            </div>
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="https://viptaxiiran.com/imam-khomeini-airport" title="تاکسی فرودگاهی" target="_blank" rel="noopener">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="text">
                             <h3>رزرو تاکسی برون شهری</h3>
                               <p>در حال حاضر هموطنان عزیز می توانند علاوه بر تماس تلفنی از طریق اپلیکیشن یا وب سایت نیز برای رزرو تاکسی بین شهری اقدام کنند. برای این منظور فقط کافی است که وارد سایت یا اپلیکیشن شوند و پس از انتخاب مسیر، زمان و نوع خودرو مورد نظر درخواست خود را به صورت اینترنتی ثبت کنند.</p>
                            </div>
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="<?php echo e(route('site.reservation.index')); ?>" title="رزرو تاکسی برون شهری">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                           
                                   <div class="text">
                                <h3>سرویس وی آی پی و ویژه</h3>
                                <p>ما خدمات و سرویس وی آی پی خود را با استفاده از خودروهای کاملاً لوکس راحت و بسیار تمیز به همراه رانندگانی کاملاً مجرب ارائه می دهیم و یک سفر بسیار ایمن، راحت و با بالاترین کیفیت را برای مشتریان خود تدارک می بینیم.</p>
                            </div>
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="<?php echo e(url('/')); ?>#nextSection" title="شروع رزرو">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                         
                           <div class="text">
                                <h3>تاکسی بین شهری خصوصی</h3>
                                <p>مشتریان عزیز ما برای استفاده از خدمات تاکسی خصوصی می توانند یک تاکسی را به صورت کاملاً اختصاصی فقط برای خود رزرو نمایند و رانندگان ما اجازه ندارند در طول مسیر مسافر دیگری را سوار کنند. در واقع  رانندگان تاکسی خصوصی ما موظف هستند بر اساس نیازهای شخصی مشتری زمان سفر را تنظیم کنند.</p>
                            </div>
                            <div class="numb">
                                <div class="numb-curv">
                                    <a href="<?php echo e(url('/')); ?>#nextSection" title="شروع رزرو">
                                        <div class="number"><i class="ti-arrow-top-right" aria-hidden="true"></i></div>
                                    </a>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                             class="w-11 h-11">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Car Categories with Pricing -->
    <section class="car-categories-pricing section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">دسته‌بندی و نرخ‌ها</div>
                    <div class="section-title">دسته‌بندی تاکسی‌ها و نرخ محاسبه قیمت<span>سال 1404</span></div>
                </div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $carCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 mb-30">
                        <div class="category-pricing-card">
                            <div class="category-pricing-image">
                                <?php if($category->logo): ?>
                                    <img src="<?php echo e(Storage::url($category->logo)); ?>" alt="<?php echo e($category->title); ?>" class="img-fluid">
                                <?php else: ?>
                                    <div class="category-pricing-placeholder">
                                        <i class="fa-solid fa-car"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="category-pricing-content">
                                <h4 class="category-pricing-title"><?php echo e($category->title); ?></h4>
                                <?php if($category->description): ?>
                                    <p class="category-pricing-description"><?php echo e($category->description); ?></p>
                                <?php endif; ?>
                                <?php if($category->type): ?>
                                    <span class="category-pricing-type"><?php echo e(\Modules\Cars\Models\CarCategory::TYPES[$category->type] ?? $category->type); ?></span>
                                <?php endif; ?>
                                <div class="category-pricing-prices">
                                    <?php if($category->fixed_price): ?>
                                        <div class="price-item">
                                            <span class="price-label">قیمت ثابت:</span>
                                            <span class="price-value"><?php echo e(number_format($category->fixed_price)); ?> تومان</span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($category->price_per_km): ?>
                                        <div class="price-item">
                                            <span class="price-label">قیمت کیلومتری:</span>
                                            <span class="price-value"><?php echo e(number_format($category->price_per_km)); ?> تومان/کیلومتر</span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($category->price_type === \Modules\Cars\Models\CarCategory::PRICE_TYPE_NEGOTIABLE): ?>
                                        <div class="price-item price-negotiable">
                                            <span class="price-label">قیمت توافقی:</span>
                                            <span class="price-value">تماس بگیرید</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <div class="text-center">
                            <p class="text-muted">دسته‌بندی‌ای یافت نشد</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Process -->
    <section class="process section-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">قدم ها</div>
                    <div class="section-title"><h3>فرایند رزرو تاکسی</h3></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-30">
                    <div class="item">
                        <div class="text">
                             <h4>رسیدن راننده و شروع سفر</h4>
                            <p>پس از تایید رزرو، تاکسی در محل مورد نظر شما حاضر می‌شود. راننده با شما تماس می‌گیرد و شما می‌توانید سفر راحت و بی‌دردسری را آغاز کنید.</p>
                        </div>
                        <div class="numb">
                            <div class="numb-curv">
                                <div class="number">03.</div>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-30">
                    <div class="item">
                        <div class="text">
                            <h4>انتخاب نوع تاکسی و تکمیل رزرو</h4>
                            <p>نوع تاکسی مورد نظر خود را از دسته‌بندی‌های موجود انتخاب کنید و اطلاعات رزرو را تکمیل نمایید. پس از ثبت رزرو، تیم ما با شما تماس خواهد گرفت.</p>
                        </div>
                        <div class="numb">
                            <div class="numb-curv">
                                <div class="number">02.</div>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-30">
                    <div class="item">
                        <div class="text">
                            <h4>انتخاب مبدا و مقصد</h4>
                            <p>از طریق نقشه تعاملی، مبدا و مقصد سفر خود را انتخاب کنید. می‌توانید با کلیک روی نقشه یا جستجوی آدرس، مسیر خود را مشخص نمایید.</p>
                        </div>
                        <div class="numb">
                            <div class="numb-curv">
                                <div class="number">01.</div>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12 text-center mt-15" dir="rtl">
                    <p><span class="ti-info"></span>فرآیند رزرو ساده و سریع است. اگر سوالی دارید، تیم پشتیبانی ما آماده کمک به شماست.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Clients -->
    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $clientLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="clients-logo">
                                <a href="<?php echo e($logo['link_url'] ?: '#'); ?>"><img src="<?php echo e($logo['image_url']); ?>" alt="<?php echo e($logo['alt']); ?>" loading="lazy" decoding="async"></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonials -->
    <section class="testimonials section-padding mt-15">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">توصیفات</div>
                    <div class="section-title">رضایت برخی مشتریان</div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('partials.testimonial_item', ['testimonial' => $testimonial], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(false): ?>
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>خدمات فوق‌العاده و رانندگان خوش برخورد. سفر من از تهران به اصفهان با VIP Taxi Iran تجربه‌ای بسیار راحت و لذت‌بخش بود. تاکسی تمیز و راحت بود و قیمت‌ها هم کاملاً منصفانه بود. حتماً دوباره استفاده می‌کنم و به دوستانم هم معرفی می‌کنم.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="تاکسی برون شهری" src="<?php echo e(asset('site/img/team/1.webp')); ?>"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>پوریا میرزایی</h6>
                                    <p>مشتری</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>برای سفرم به شمال از خدمات ترانسفر فرودگاهی VIP Taxi Iran استفاده کردم. راننده بسیار وقت‌شناس بود و در زمان مقرر در فرودگاه حاضر شد. تاکسی تمیز و مجهز بود و سفر خیلی راحتی داشتم. قیمت‌ها هم نسبت به کیفیت خدماتی که دریافت کردم بسیار مناسب بود.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="رزرو تاکسی بین شهری" src="<?php echo e(asset('site/img/team/4.webp')); ?>"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>نسترن سلطانی</h6>
                                    <p>مشتری</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                            class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>ما برای مراسم عروسی از خدمات VIP Taxi Iran استفاده کردیم. تاکسی‌های لوکس و رانندگان خوش پوش و مودب بودند. خدمات بسیار حرفه‌ای و به موقع بود. مهمان‌های ما از کیفیت خدمات خیلی راضی بودند. واقعاً بهترین انتخاب بود.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="نظر مشتری تاکسی بین شهری" src="<?php echo e(asset('site/img/team/6.webp')); ?>"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>فروغ فدایی</h6>
                                    <p>مشتری</p>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <?php if($homeFaqs->isNotEmpty()): ?>
        <!-- FAQs -->
        <section class="faqs section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center mb-30">
                        <div class="section-subtitle">سوالات متداول</div>
                        <div class="section-title">پرسش‌های <span>رایج</span></div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <ul class="accordion-box clearfix">
                            <?php $__currentLoopData = $homeFaqs->take(ceil($homeFaqs->count() / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="accordion block">
                                    <div class="acc-btn"><span class="count"><?php echo e($loop->iteration); ?>.</span> <?php echo e($faq['question']); ?></div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text"><?php echo nl2br(e($faq['answer'])); ?></div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <img src="<?php echo e(asset('site/img/aboutt.webp')); ?>" class="img-fluid" alt="سوالات متداول تاکسی بین شهری">
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <ul class="accordion-box clearfix">
                            <?php $__currentLoopData = $homeFaqs->slice(ceil($homeFaqs->count() / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="accordion block">
                                    <div class="acc-btn"><span class="count"><?php echo e($loop->iteration + ceil($homeFaqs->count() / 2)); ?>.</span> <?php echo e($faq['question']); ?></div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <div class="text"><?php echo nl2br(e($faq['answer'])); ?></div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- Blog 1 -->
    <section class="blog1 section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">مقالات ما</div>
                    <div class="section-title">آخرین<span>اخبار</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <?php $__empty_1 = true; $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="item">
                                <div class="img">
                                    <?php if($post->thumbnail): ?>
                                        <img src="<?php echo e(Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>">
                                    <?php elseif($post->image): ?>
                                        <img src="<?php echo e(Storage::url($post->image)); ?>" alt="<?php echo e($post->title); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('site/img/blog/03.webp')); ?>" alt="<?php echo e($post->title); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="wrapper">
                                    <div class="date">
                                        <a href="#">
                                            <?php if($post->published_at): ?>
                                                <?php echo e(\Verta::instance($post->published_at)->format('j F Y')); ?>

                                            <?php elseif($post->created_at): ?>
                                                <?php echo e(\Verta::instance($post->created_at)->format('j F Y')); ?>

                                            <?php else: ?>
                                                <?php echo e(\Verta::now()->format('j F Y')); ?>

                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="con">
                                        <div class="category">
                                            <?php if($post->author): ?>
                                                <a href="#"><i class="ti-user"></i><?php echo e($post->author); ?></a>
                                            <?php elseif($post->user && $post->user->name): ?>
                                                <a href="#"><i class="ti-user"></i><?php echo e($post->user->name); ?></a>
                                            <?php endif; ?>
                                            <a href="#">
                                                <i class="ti-comment"></i>
                                                <?php echo e($post->comments->where('is_active', true)->count() ?? 0); ?> کامنت
                                            </a>
                                        </div>
                                        <div class="text">
                                            <a href="<?php echo e(($post->en_slug || $post->fa_slug) ? route('blog.show', $post->en_slug ?? $post->fa_slug) : '#'); ?>"><?php echo e($post->title); ?></a>
                                        </div>
                                        <a href="<?php echo e(($post->en_slug || $post->fa_slug) ? route('blog.show', $post->en_slug ?? $post->fa_slug) : '#'); ?>" class="icon-btn">
                                            <i class="ti-arrow-top-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="item">
                                <div class="img">
                                    <img src="<?php echo e(asset('site/img/blog/03.webp')); ?>" alt="مقاله‌ای یافت نشد">
                                </div>
                                <div class="wrapper">
                                    <div class="date"><a href="#"><?php echo e(\Verta::now()->format('j F Y')); ?></a></div>
                                    <div class="con">
                                        <div class="category">
                                            <a href="#"><i class="ti-user"></i>سیستم</a>
                                            <a href="#"><i class="ti-comment"></i>۰ کامنت</a>
                                        </div>
                                        <div class="text">
                                            <a href="#">مقاله‌ای یافت نشد</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>

    <?php $__env->startPush('scripts'); ?>

        <script>
            let map;
            let origins = [];
            let destinations = [];
            let markers = [];
            let polylines = [];
            let currentMode = 'origin'; // 'origin' or 'destination'
            let originDivIcon;
            let destinationDivIcon;
            let searchDivIcon;
            let searchMarker = null;
            let locateDivIcon;
            let locateMarker = null;
            let searchTimeout = null;
            let currentSearchResults = [];
            let userLocationMarker = null;
            let originMarker = null; // نگهداری marker مبدا
            let destinationMarker = null; // نگهداری marker مقصد
            const neshanApiKey = 'web.3d4ed3ed30194ca89c2c8dfc43f074d5';
            
            
            
            function initMap() {
                // لوکیشن پیش‌فرض (تهران) - فقط در صورت عدم دسترسی به geolocation
                const defaultLocation = [35.6892, 51.3890];
                const defaultZoom = 12;

                // ابتدا نقشه را با لوکیشن پیش‌فرض ایجاد می‌کنیم
                map = L.map('map').setView(defaultLocation, defaultZoom);

                // استفاده از نقشه نشان
                // برای نشان با Leaflet باید از این فرمت استفاده کنیم
          const neshanLayer = L.tileLayer(
             'https://api.neshan.org/v2/tiles/{z}/{x}/{y}?key='+neshanApiKey,
             {
               maxZoom:19,
               bounds:[[24,44],[40,64]],
               noWrap:true
             }
            ).addTo(map);

           // تنظیم اولویت بالا برای tile مرکزی (LCP optimization)
                neshanLayer.on('tileload', function(e) {
                    const img = e.tile;
                    if (img && img.tagName === 'IMG') {
                        // محاسبه tile مرکزی
                        const center = map.getCenter();
                        const tilePoint = map.project(center, map.getZoom()).divideBy(256).floor();
                        const tileCoords = e.coords;

                        // اگر این tile مرکزی است، اولویت بالا بده
                        if (tileCoords.x === Math.floor(tilePoint.x) && tileCoords.y === Math.floor(tilePoint.y)) {
                            img.fetchPriority = 'high';
                        }
                    }
                });

                // اضافه کردن نقشه نشان
                neshanLayer.addTo(map);

                // اگر tile لود نشد، از OpenStreetMap استفاده می‌کنیم (fallback)
                let fallbackAdded = false;
                neshanLayer.on('tileerror', function(error, tile) {
                    console.warn('خطا در لود کردن tile نشان:', error);
                    if (!fallbackAdded) {
                        fallbackAdded = true;
                        // اضافه کردن OpenStreetMap به عنوان fallback
                        const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '&copy; OpenStreetMap contributors',
                            opacity: 0.5
                        });

                        // تنظیم اولویت بالا برای tile مرکزی OpenStreetMap (LCP optimization)
                        osmLayer.on('tileload', function(e) {
                            const img = e.tile;
                            if (img && img.tagName === 'IMG') {
                                // محاسبه tile مرکزی
                                const center = map.getCenter();
                                const tilePoint = map.project(center, map.getZoom()).divideBy(256).floor();
                                const tileCoords = e.coords;

                                // اگر این tile مرکزی است، اولویت بالا بده
                                if (tileCoords.x === Math.floor(tilePoint.x) && tileCoords.y === Math.floor(tilePoint.y)) {
                                    img.fetchPriority = 'high';
                                }
                            }
                        });

                        osmLayer.addTo(map);
                    }
                });

                // prepare pretty icons for markers - Snap-like design (قبل از geolocation)
                originDivIcon = L.divIcon({
                    className: '',
                    html: '<div class="custom-marker marker-origin"><div class="glyph">🚗</div></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -20]
                });
                destinationDivIcon = L.divIcon({
                    className: '',
                    html: '<div class="custom-marker marker-destination"><div class="glyph">🏁</div></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -20]
                });

                searchDivIcon = L.divIcon({
                    className: '',
                    html: '<div class="custom-marker marker-search"><div class="glyph">🔍</div></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -20]
                });

                locateDivIcon = L.divIcon({
                    className: '',
                    html: '<div class="custom-marker marker-locate"><div class="glyph">📍</div></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -20]
                });

                // تلاش برای دریافت لوکیشن کاربر به صورت پیش‌فرض
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        function (position) {
                            const userLat = position.coords.latitude;
                            const userLng = position.coords.longitude;
                            const userLocation = [userLat, userLng];

                            // انتقال نقشه به لوکیشن کاربر
                            map.setView(userLocation, 14);

                            // اضافه کردن marker برای لوکیشن کاربر
                            if (userLocationMarker) {
                                map.removeLayer(userLocationMarker);
                            }
                            userLocationMarker = L.marker(userLocation, {icon: locateDivIcon}).addTo(map);
                            userLocationMarker.bindPopup('موقعیت فعلی شما').openPopup();
                        },
                        function (error) {
                            // در صورت خطا، از لوکیشن پیش‌فرض استفاده می‌شود
                            console.log('خطا در دریافت لوکیشن:', error.message);
                        },
                        {
                            enableHighAccuracy: true,
                            timeout: 10000,
                            maximumAge: 0
                        }
                    );
                }

                map.on('click', function (e) {
                    showChoicePopup(e.latlng);
                });
            }

            function searchPlace() {
                const input = document.getElementById('place-search');
                const q = (input.value || '').trim();
                if (!q) {
                    alert('متن جستجو را وارد کنید');
                    return;
                }
                const center = map.getCenter();
                const params = new URLSearchParams({q});
                if (center && typeof center.lat === 'number' && typeof center.lng === 'number') {
                    params.set('lat', center.lat);
                    params.set('lng', center.lng);
                }

                fetch('/api/neshan/search?' + params.toString(), {
                    headers: {'Accept': 'application/json'}
                })
                    .then(r => r.json())
                    .then(data => {
                        const results = (data && data.results) ? data.results : [];
                        if (!results.length) {
                            alert('موردی یافت نشد');
                            return;
                        }
                        const first = results[0];
                        const latlng = L.latLng(first.lat, first.lng);
                        map.setView(latlng, 14);

                        if (searchMarker) {
                            map.removeLayer(searchMarker);
                            searchMarker = null;
                        }
                        searchMarker = L.marker(latlng, {icon: searchDivIcon}).addTo(map);

                        const uid = Date.now().toString();
                        const addOrgId = `add-org-${uid}`;
                        const addDstId = `add-dst-${uid}`;
                        const html = `
                    <div style="min-width:200px; text-align:right">
                        <div style="font-weight:bold; margin-bottom:6px">${first.name || 'نتیجه'}</div>
                        <div style="font-size:12px; color:#555; margin-bottom:8px">${first.address || ''}</div>
                        <div style="display:flex; gap:6px; justify-content:flex-start">
                            <button id="${addOrgId}" class="btn btn-primary" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🚗</button>
                            <button id="${addDstId}" class="btn btn-danger" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🏁</button>
                        </div>
                    </div>`;
                        searchMarker.bindPopup(html).openPopup();

                        setTimeout(() => {
                            const addOrg = document.getElementById(addOrgId);
                            const addDst = document.getElementById(addDstId);
                            if (addOrg) {
                                addOrg.addEventListener('click', () => {
                                    addOrigin(latlng);
                                    if (searchMarker) {
                                        map.removeLayer(searchMarker);
                                        searchMarker = null;
                                    }
                                });
                            }
                            if (addDst) {
                                addDst.addEventListener('click', () => {
                                    addDestination(latlng);
                                    if (searchMarker) {
                                        map.removeLayer(searchMarker);
                                        searchMarker = null;
                                    }
                                });
                            }
                        }, 0);
                    })
                    .catch(err => {
                        alert('خطا در جستجو: ' + err.message);
                    });
            }

            // Real-time search functionality
            document.addEventListener('DOMContentLoaded', function () {
                const input = document.getElementById('place-search');
                const resultsContainer = document.getElementById('search-results');

                if (input) {
                    // Real-time search on input
                    input.addEventListener('input', function (e) {
                        const query = e.target.value.trim();

                        // Clear previous timeout
                        if (searchTimeout) {
                            clearTimeout(searchTimeout);
                        }

                        if (query.length < 2) {
                            hideSearchResults();
                            return;
                        }

                        // Debounce search - wait 300ms after user stops typing
                        searchTimeout = setTimeout(() => {
                            performRealTimeSearch(query);
                        }, 300);
                    });

                    // Enter key triggers search
                    input.addEventListener('keydown', function (ev) {
                        if (ev.key === 'Enter') {
                            ev.preventDefault();
                            searchPlace();
                        }
                    });

                    // Hide results when clicking outside
                    document.addEventListener('click', function (e) {
                        if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                            hideSearchResults();
                        }
                    });
                }
            });

            function performRealTimeSearch(query) {
                const resultsContainer = document.getElementById('search-results');
                const center = map.getCenter();

                // Show loading
                resultsContainer.innerHTML = '<div class="search-loading">در حال جستجو...</div>';
                resultsContainer.style.display = 'block';

                const params = new URLSearchParams({q: query});
                if (center && typeof center.lat === 'number' && typeof center.lng === 'number') {
                    params.set('lat', center.lat);
                    params.set('lng', center.lng);
                }

                fetch('/api/neshan/search?' + params.toString(), {
                    headers: {'Accept': 'application/json'}
                })
                    .then(r => r.json())
                    .then(data => {
                        const results = (data && data.results) ? data.results : [];
                        currentSearchResults = results;
                        displaySearchResults(results);
                    })
                    .catch(err => {
                        console.error('Search error:', err);
                        resultsContainer.innerHTML = '<div class="search-loading">خطا در جستجو</div>';
                    });
            }

            function displaySearchResults(results) {
                const resultsContainer = document.getElementById('search-results');

                if (!results.length) {
                    resultsContainer.innerHTML = '<div class="search-loading">موردی یافت نشد</div>';
                    return;
                }

                let html = '';
                results.forEach((result, index) => {
                    html += `
                    <div class="search-result-item" onclick="selectSearchResult(${index})">
                        <div class="search-result-icon">📍</div>
                        <div class="search-result-content">
                            <div class="search-result-name">${result.name || 'نتیجه'}</div>
                            <div class="search-result-address">${result.address || ''}</div>
                        </div>
                    </div>
                `;
                });

                resultsContainer.innerHTML = html;
            }

            function selectSearchResult(index) {
                const result = currentSearchResults[index];
                if (!result) return;

                const latlng = L.latLng(result.lat, result.lng);
                map.setView(latlng, 14);

                // Clear previous search marker
                if (searchMarker) {
                    map.removeLayer(searchMarker);
                    searchMarker = null;
                }

                // Add new marker
                searchMarker = L.marker(latlng, {icon: searchDivIcon}).addTo(map);

                // Show popup with add buttons
                const uid = Date.now().toString();
                const addOrgId = `add-org-${uid}`;
                const addDstId = `add-dst-${uid}`;
                const html = `
            <div style="min-width:200px; text-align:right">
                <div style="font-weight:bold; margin-bottom:6px">${result.name || 'نتیجه'}</div>
                <div style="font-size:12px; color:#555; margin-bottom:8px">${result.address || ''}</div>
                <div style="display:flex; gap:6px; justify-content:flex-start">
                    <button id="${addOrgId}" class="btn btn-primary" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🚗</button>
                    <button id="${addDstId}" class="btn btn-danger" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🏁</button>
                </div>
            </div>`;
                searchMarker.bindPopup(html).openPopup();

                setTimeout(() => {
                    const addOrg = document.getElementById(addOrgId);
                    const addDst = document.getElementById(addDstId);
                    if (addOrg) {
                        addOrg.addEventListener('click', () => {
                            addOrigin(latlng);
                            if (searchMarker) {
                                map.removeLayer(searchMarker);
                                searchMarker = null;
                            }
                            hideSearchResults();
                        });
                    }
                    if (addDst) {
                        addDst.addEventListener('click', () => {
                            addDestination(latlng);
                            if (searchMarker) {
                                map.removeLayer(searchMarker);
                                searchMarker = null;
                            }
                            hideSearchResults();
                        });
                    }
                }, 0);

                // Hide search results
                hideSearchResults();

                // Clear input
                document.getElementById('place-search').value = '';
            }

            function hideSearchResults() {
                const resultsContainer = document.getElementById('search-results');
                resultsContainer.style.display = 'none';
            }

            function locateMe() {
                const btn = document.getElementById('btn-locate');
                if (!navigator.geolocation) {
                    alert('مرورگر شما از مکان‌یابی پشتیبانی نمی‌کند');
                    return;
                }
                if (btn) {
                    btn.disabled = true;
                    const btnText = btn.nextSibling;
                    if (btnText && btnText.nodeType === 3) {
                        btnText.textContent = 'در حال یافتن...';
                    }
                }
                navigator.geolocation.getCurrentPosition(function (pos) {
                    const lat = pos.coords.latitude;
                    const lng = pos.coords.longitude;
                    const latlng = L.latLng(lat, lng);
                    map.setView(latlng, 15);

                    // پاک کردن markerهای قبلی
                    if (locateMarker) {
                        map.removeLayer(locateMarker);
                        locateMarker = null;
                    }
                    if (userLocationMarker) {
                        map.removeLayer(userLocationMarker);
                        userLocationMarker = null;
                    }
                    locateMarker = L.marker(latlng, {icon: locateDivIcon}).addTo(map);

                    const uid = Date.now().toString();
                    const addOrgId = `loc-org-${uid}`;
                    const addDstId = `loc-dst-${uid}`;
                    const html = `
                <div style="min-width:200px; text-align:right">
                    <div style="font-weight:bold; margin-bottom:6px">موقعیت فعلی شما</div>
                    <div style="font-size:12px; color:#555; margin-bottom:8px">${lat.toFixed(5)}, ${lng.toFixed(5)}</div>
                    <div style="display:flex; gap:6px; justify-content:flex-start">
                        <button id="${addOrgId}" class="btn btn-primary" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🚗</button>
                        <button id="${addDstId}" class="btn btn-danger" style="padding:6px; width:40px; height:40px; display:flex; align-items:center; justify-content:center">🏁</button>
                    </div>
                </div>`;
                    locateMarker.bindPopup(html).openPopup();

                    setTimeout(() => {
                        const addOrg = document.getElementById(addOrgId);
                        const addDst = document.getElementById(addDstId);
                        if (addOrg) {
                            addOrg.addEventListener('click', () => {
                                addOrigin(latlng);
                                if (locateMarker) {
                                    map.removeLayer(locateMarker);
                                    locateMarker = null;
                                }
                            });
                        }
                        if (addDst) {
                            addDst.addEventListener('click', () => {
                                addDestination(latlng);
                                if (locateMarker) {
                                    map.removeLayer(locateMarker);
                                    locateMarker = null;
                                }
                            });
                        }
                    }, 0);

                    if (btn) {
                        btn.disabled = false;
                        const btnText = btn.nextSibling;
                        if (btnText && btnText.nodeType === 3) {
                            btnText.textContent = 'موقعیت مکانی من';
                        }
                    }
                }, function (err) {
                    alert('خطا در مکان‌یابی: ' + err.message);
                    if (btn) {
                        btn.disabled = false;
                        const btnText = btn.nextSibling;
                        if (btnText && btnText.nodeType === 3) {
                            btnText.textContent = 'موقعیت مکانی من';
                        }
                    }
                }, {
                    enableHighAccuracy: true,
                    timeout: 12000,
                    maximumAge: 0
                });
            }

            function showChoicePopup(latlng) {
                const uid = Date.now().toString();
                const originBtnId = `origin-btn-${uid}`;
                const destBtnId = `dest-btn-${uid}`;

                const html = `
            <div class="choice-wrap">
                <div class="choice-actions">
                    <div class="choice-btn-wrapper">
                        <button id="${originBtnId}" class="choice-btn origin"><span class="choice-icon">🚗</span></button>
                        <span class="choice-label">مبدا</span>
                    </div>
                    <div class="choice-btn-wrapper">
                        <button id="${destBtnId}" class="choice-btn destination"><span class="choice-icon">🏁</span></button>
                        <span class="choice-label">مقصد</span>
                    </div>
                </div>
            </div>`;

                const popup = L.popup({closeButton: true})
                    .setLatLng(latlng)
                    .setContent(html)
                    .openOn(map);

                // Attach handlers after popup is added to DOM
                setTimeout(() => {
                    const originBtn = document.getElementById(originBtnId);
                    const destBtn = document.getElementById(destBtnId);
                    if (originBtn) {
                        originBtn.addEventListener('click', () => {
                            addOrigin(latlng);
                            map.closePopup(popup);
                        });
                    }
                    if (destBtn) {
                        destBtn.addEventListener('click', () => {
                            addDestination(latlng);
                            map.closePopup(popup);
                        });
                    }
                }, 0);
            }


            function addOrigin(latlng) {
                // حذف مبدا قبلی اگر وجود داشته باشد
                if (originMarker) {
                    map.removeLayer(originMarker);
                    const index = markers.indexOf(originMarker);
                    if (index > -1) {
                        markers.splice(index, 1);
                    }
                    originMarker = null;
                }

                // پاک کردن آرایه origins و اضافه کردن مبدا جدید
                origins = [];
                origins.push(latlng);

                // اضافه کردن marker جدید
                originMarker = L.marker(latlng, {icon: originDivIcon}).addTo(map);
                originMarker.bindPopup('مبدا');
                markers.push(originMarker);
            }

            function addDestination(latlng) {
                // حذف مقصد قبلی اگر وجود داشته باشد
                if (destinationMarker) {
                    map.removeLayer(destinationMarker);
                    const index = markers.indexOf(destinationMarker);
                    if (index > -1) {
                        markers.splice(index, 1);
                    }
                    destinationMarker = null;
                }

                // پاک کردن آرایه destinations و اضافه کردن مقصد جدید
                destinations = [];
                destinations.push(latlng);

                // اضافه کردن marker جدید
                destinationMarker = L.marker(latlng, {icon: destinationDivIcon}).addTo(map);
                destinationMarker.bindPopup('مقصد');
                markers.push(destinationMarker);
            }

            function addMarker(latlng, label, icon) {
                const marker = L.marker(latlng, {icon: icon}).addTo(map);
                marker.bindPopup(label);
                markers.push(marker);
            }

            function clearAll() {
                // پاک کردن مارکرها و خطوط
                markers.forEach(m => map.removeLayer(m));
                polylines.forEach(p => map.removeLayer(p));
                markers = [];
                polylines = [];

                // پاک کردن آرایه‌ها و markerهای خاص
                origins = [];
                destinations = [];
                originMarker = null;
                destinationMarker = null;
                currentMode = 'origin';
            }


            // متغیر برای ذخیره routes و phone
            let pendingRoutes = null;
            let pendingPhone = null;
            const requirePhoneBeforeRouteCalculation = <?php echo json_encode(app(\App\Services\SmsSettingsService::class)->requirePhoneBeforeRouteCalculation(), 15, 512) ?>;

            function calculateAllRoutes() {
                if (origins.length === 0) {
                    alert('هیچ مبدایی انتخاب نشده است.');
                    return;
                }

                if (destinations.length === 0) {
                    alert('هیچ مقصدی انتخاب نشده است.');
                    return;
                }

                // ایجاد تمام ترکیب‌های ممکن مبدا-مقصد
                const routes = [];
                origins.forEach((origin, originIndex) => {
                    destinations.forEach((destination, destIndex) => {
                        routes.push({
                            origin_lat: origin.lat,
                            origin_lng: origin.lng,
                            destination_lat: destination.lat,
                            destination_lng: destination.lng,
                            origin_index: originIndex,
                            destination_index: destIndex
                        });
                    });
                });

                // ذخیره routes برای استفاده بعد از گرفتن شماره
                pendingRoutes = routes;

                console.log('Routes prepared:', {
                    routesCount: routes.length,
                    pendingRoutes: pendingRoutes ? pendingRoutes.length : 0
                });

                if (requirePhoneBeforeRouteCalculation) {
                    showPhoneModal();
                    return;
                }

                pendingPhone = null;
                showPreloader(`در حال محاسبه ${routes.length} مسیر... لطفاً صبر کنید`);
                setTimeout(() => {
                    submitRoutesWithPhone();
                }, 300);
            }

            function showPhoneModal() {
                const modal = document.getElementById('phoneModal');
                const input = document.getElementById('phoneModalInput');
                const error = document.getElementById('phoneModalError');

                if (modal && input) {
                    modal.classList.add('show');
                    input.value = '';
                    input.classList.remove('error');
                    if (error) {
                        error.classList.remove('show');
                    }
                    // Focus on input
                    setTimeout(() => input.focus(), 100);
                }
            }

            function closePhoneModal(clearData = true) {
                const modal = document.getElementById('phoneModal');
                if (modal) {
                    modal.classList.remove('show');
                }
                // فقط در صورت انصراف، pendingRoutes را null می‌کنیم
                if (clearData) {
                    pendingRoutes = null;
                    pendingPhone = null;
                }
            }

            function validatePhone(phone) {
                // فرمت: 09XXXXXXXXX (11 رقم، شروع با 09)
                const phoneRegex = /^09\d{9}$/;
                return phoneRegex.test(phone);
            }

            // مسیرهای پرطرفدار: باز کردن مودال و ارسال فرم
            document.querySelectorAll('.popular-route-start-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const url = this.getAttribute('data-start-url');
                    if (!requirePhoneBeforeRouteCalculation) {
                        submitPopularRouteStart(url);
                        return;
                    }

                    const form = document.getElementById('popularRoutePhoneForm');
                    const modal = document.getElementById('popularRoutePhoneModal');
                    const input = document.getElementById('popularRoutePhoneInput');
                    const errEl = document.getElementById('popularRoutePhoneError');
                    if (form && modal && url) {
                        form.action = url;
                        if (input) { input.value = ''; input.classList.remove('error'); }
                        if (errEl) { errEl.classList.remove('show'); }
                        modal.classList.add('show');
                        setTimeout(function() { if (input) input.focus(); }, 100);
                    }
                });
            });

            function closePopularRoutePhoneModal() {
                const modal = document.getElementById('popularRoutePhoneModal');
                if (modal) modal.classList.remove('show');
            }

            function submitPopularRouteStart(url, phone = null) {
                if (!url) {
                    return;
                }

                const form = document.createElement('form');
                form.method = 'POST';
                form.action = url;

                const csrf = document.createElement('input');
                csrf.type = 'hidden';
                csrf.name = '_token';
                csrf.value = window.csrfToken;
                form.appendChild(csrf);

                if (phone) {
                    const phoneInput = document.createElement('input');
                    phoneInput.type = 'hidden';
                    phoneInput.name = 'phone';
                    phoneInput.value = phone;
                    form.appendChild(phoneInput);
                }

                document.body.appendChild(form);
                form.submit();
            }

            document.getElementById('popularRoutePhoneForm') && document.getElementById('popularRoutePhoneForm').addEventListener('submit', function(e) {
                const input = document.getElementById('popularRoutePhoneInput');
                const errEl = document.getElementById('popularRoutePhoneError');
                const phone = input && input.value.trim();
                if (!requirePhoneBeforeRouteCalculation) {
                    return;
                }

                if (!phone) {
                    e.preventDefault();
                    if (errEl) { errEl.textContent = 'لطفاً شماره موبایل را وارد کنید'; errEl.classList.add('show'); }
                    if (input) input.classList.add('error');
                    return;
                }
                if (!validatePhone(phone)) {
                    e.preventDefault();
                    if (errEl) { errEl.textContent = 'شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود'; errEl.classList.add('show'); }
                    if (input) input.classList.add('error');
                    return;
                }
                if (errEl) errEl.classList.remove('show');
                if (input) input.classList.remove('error');
            });

            document.getElementById('popularRoutePhoneModal') && document.getElementById('popularRoutePhoneModal').addEventListener('click', function(e) {
                if (e.target === this) closePopularRoutePhoneModal();
            });

            function submitPhoneAndCalculate() {
                const input = document.getElementById('phoneModalInput');
                const error = document.getElementById('phoneModalError');

                if (!input) return;

                const phone = input.value.trim();

                // Validation
                if (!phone) {
                    if (error) {
                        error.textContent = 'لطفاً شماره موبایل را وارد کنید';
                        error.classList.add('show');
                    }
                    input.classList.add('error');
                    return;
                }

                if (!validatePhone(phone)) {
                    if (error) {
                        error.textContent = 'شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود';
                        error.classList.add('show');
                    }
                    input.classList.add('error');
                    return;
                }

                // بررسی اینکه pendingRoutes موجود است
                if (!pendingRoutes || pendingRoutes.length === 0) {
                    if (error) {
                        error.textContent = 'خطا: مسیرها یافت نشد. لطفاً دوباره تلاش کنید.';
                        error.classList.add('show');
                    }
                    input.classList.add('error');
                    return;
                }

                // پاک کردن خطا
                if (error) {
                    error.classList.remove('show');
                }
                input.classList.remove('error');

                // ذخیره شماره
                pendingPhone = phone;

                console.log('Phone validated and saved:', {
                    phone: pendingPhone,
                    pendingRoutesCount: pendingRoutes ? pendingRoutes.length : 0
                });

                // بستن مدال بدون پاک کردن داده‌ها
                closePhoneModal(false);

                // بررسی مجدد pendingRoutes قبل از نمایش preloader
                if (!pendingRoutes || pendingRoutes.length === 0) {
                    console.error('pendingRoutes is null or empty after phone validation');
                    alert('خطا: مسیرها یافت نشد. لطفاً دوباره تلاش کنید.');
                    return;
                }

                // نمایش preloader
                const totalRoutes = pendingRoutes.length;
                console.log('Showing preloader for', totalRoutes, 'routes');
                showPreloader(`در حال محاسبه ${totalRoutes} مسیر... لطفاً صبر کنید`);

                // Submit form با شماره
                setTimeout(() => {
                    console.log('Calling submitRoutesWithPhone');
                    submitRoutesWithPhone();
                }, 300);
            }

            function submitRoutesWithPhone() {
                console.log('submitRoutesWithPhone called', {
                    pendingRoutes: pendingRoutes ? pendingRoutes.length : 'null',
                    pendingPhone: pendingPhone
                });

                if (!pendingRoutes || pendingRoutes.length === 0) {
                    console.error('Routes not available', {
                        pendingRoutes: pendingRoutes,
                        origins: origins.length,
                        destinations: destinations.length
                    });
                    hidePreloader();
                    alert('خطا: مسیرها یافت نشد. لطفاً دوباره تلاش کنید.');
                    return;
                }

                // Prefer full-page POST to let server redirect without relying on JS
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '/calculate-multiple-distances';

                const csrf = document.createElement('input');
                csrf.type = 'hidden';
                csrf.name = '_token';
                csrf.value = window.csrfToken;
                form.appendChild(csrf);

                const payload = document.createElement('input');
                payload.type = 'hidden';
                payload.name = 'routes';
                payload.value = JSON.stringify({routes: pendingRoutes});
                form.appendChild(payload);

                if (pendingPhone) {
                    const phoneInput = document.createElement('input');
                    phoneInput.type = 'hidden';
                    phoneInput.name = 'phone';
                    phoneInput.value = pendingPhone;
                    form.appendChild(phoneInput);
                }

                document.body.appendChild(form);

                // لاگ برای دیباگ
                console.log('Submitting form with:', {
                    routesCount: pendingRoutes.length,
                    phone: pendingPhone,
                    formAction: form.action
                });

                // Submit form
                try {
                    form.submit();
                } catch (error) {
                    console.error('Error submitting form:', error);
                    hidePreloader();
                    alert('خطا در ارسال فرم. لطفاً دوباره تلاش کنید.');
                }

                // پاک کردن متغیرها بعد از submit
                pendingRoutes = null;
                pendingPhone = null;
            }

            // بستن مدال با کلیک روی overlay
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('phoneModal');
                if (modal) {
                    modal.addEventListener('click', function(e) {
                        if (e.target === modal) {
                            closePhoneModal();
                        }
                    });
                }

                // بستن مدال با کلید Escape
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape') {
                        const modal = document.getElementById('phoneModal');
                        if (modal && modal.classList.contains('show')) {
                            closePhoneModal();
                        }
                    }
                });

                // Enter key در input برای submit
                const phoneInput = document.getElementById('phoneModalInput');
                if (phoneInput) {
                    phoneInput.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            submitPhoneAndCalculate();
                        }
                    });
                }
            });

            function showPreloader(text = 'در حال محاسبه مسیرها...') {
                const el = document.getElementById('preloader_1');
                const textEl = document.getElementById('preloader-text');

                if (!el) {
                    console.error('Preloader element not found!');
                    return;
                }

                if (textEl) {
                    textEl.textContent = text;
                }

                // نمایش فوری preloader
                el.style.display = 'flex';
                el.style.opacity = '1';

                // Force reflow برای اطمینان از نمایش
                void el.offsetHeight;
            }

            function hidePreloader() {
                const el = document.getElementById('preloader_1');
                if (el) {
                    el.style.display = 'none';
                    el.style.opacity = '0';
                }
            }

            function drawAllRoutes(routes) {
                // پاک کردن خطوط قبلی
                polylines.forEach(p => map.removeLayer(p));
                polylines = [];

                // رسم خطوط جدید
                routes.forEach((route, index) => {
                    if (route.success) {
                        const origin = origins[route.origin_index];
                        const destination = destinations[route.destination_index];
                        const color = getColorForRoute(index);

                        const polyline = L.polyline([origin, destination], {
                            color: color,
                            weight: 2,
                            opacity: 0.7
                        }).addTo(map);
                        polylines.push(polyline);
                    }
                });
            }

            function getColorForRoute(index) {
                const colors = ['#007bff', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14', '#20c997', '#e83e8c'];
                return colors[index % colors.length];
            }

            // مخفی کردن preloader در ابتدای لود صفحه
            document.addEventListener('DOMContentLoaded', function () {
                hidePreloader();
            });

            // همچنین مطمئن شویم که preloader مخفی است
            window.addEventListener('load', function () {
                hidePreloader();
            });

            // مخفی کردن preloader وقتی کاربر back می‌زند
            window.addEventListener('pageshow', function (event) {
                // اگر صفحه از cache لود شده (back button)
                if (event.persisted) {
                    hidePreloader();
                }
            });

            // مخفی کردن preloader در صورت تغییر history (back/forward)
            window.addEventListener('popstate', function () {
                hidePreloader();
            });

            // Initialize map immediately if Leaflet is loaded
            if (typeof L !== 'undefined') {
                initMap();
            } else {
                // Check more frequently for faster initialization
                const check = setInterval(() => {
                    if (typeof L !== 'undefined') {
                        clearInterval(check);
                        initMap();
                    }
                }, 50); // Reduced from 100ms to 50ms for faster detection

                // Timeout after 5 seconds
                setTimeout(() => {
                    clearInterval(check);
                }, 5000);
            }

        </script>
        <?php $__env->stopPush(); ?>


        </body>
        </html>

        <!-- Bottom Header for Mobile (آیکون‌ها با SVG برای نمایش مطمئن بدون وابستگی به فونت) -->
        <?php
            $mobileBottomLinks = app(\App\Services\SiteContactService::class)->mobileBottomLinks();
        ?>
        <div class="mobile-bottom-header">
            <div class="header-items">
                <?php $__currentLoopData = $mobileBottomLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobileBottomLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($mobileBottomLink['url']); ?>"
                       class="mobile-header-item"
                       title="<?php echo e($mobileBottomLink['title']); ?>"
                       aria-label="<?php echo e($mobileBottomLink['title']); ?>"
                       <?php if($mobileBottomLink['open_in_new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?>>
                        <div class="mobile-header-icon mobile-header-icon-svg">
                            <?php switch($mobileBottomLink['icon_key']):
                                case ('whatsapp'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                    <?php break; ?>

                                <?php case ('home'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22" aria-hidden="true"><path d="M12 3l9 8h-3v9h-5v-6H11v6H6v-9H3l9-8z"/></svg>
                                    <?php break; ?>

                                <?php case ('support'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22" aria-hidden="true"><path d="M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z"/></svg>
                                    <?php break; ?>

                                <?php case ('phone'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22" aria-hidden="true"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                                    <?php break; ?>

                                <?php default: ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22" aria-hidden="true"><path d="M12 2a10 10 0 100 20 10 10 0 000-20z"/></svg>
                            <?php endswitch; ?>
                        </div>
                        <span class="mobile-header-text"></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <script>
            function scrollToReservation() {
                // اسکرول به بخش نقشه
                const mapSection = document.getElementById('map');
                if (mapSection) {
                    mapSection.scrollIntoView({ behavior: 'smooth' });
                } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            }
        </script>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.site.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/map.blade.php ENDPATH**/ ?>