<?php if (isset($component)) { $__componentOriginalf6713c16e0738db52992740951a8baf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6713c16e0738db52992740951a8baf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'pricing::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pricing::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('pricing.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6713c16e0738db52992740951a8baf2)): ?>
<?php $attributes = $__attributesOriginalf6713c16e0738db52992740951a8baf2; ?>
<?php unset($__attributesOriginalf6713c16e0738db52992740951a8baf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6713c16e0738db52992740951a8baf2)): ?>
<?php $component = $__componentOriginalf6713c16e0738db52992740951a8baf2; ?>
<?php unset($__componentOriginalf6713c16e0738db52992740951a8baf2); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Pricing/resources/views/index.blade.php ENDPATH**/ ?>