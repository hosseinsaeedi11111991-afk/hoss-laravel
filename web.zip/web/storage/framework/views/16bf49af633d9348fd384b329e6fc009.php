<?php $__env->startSection('script'); ?>
    <script>
        function deleteRow (e) {
            Swal.fire({
                title: 'هشدار',
                text: "آیا از حذف مطمعا هستید",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'بله حذف کن',
                cancelButtonText: 'خیر',
                customClass: {
                    confirmButton: 'btn btn-primary me-1',
                    cancelButton: 'btn btn-label-secondary'
                },
                buttonsStyling: false
            }).then(function(result) {

                if (result.value) {
                    var form =  e.parentElement.children[3];
                    form.submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/tajhizta/web/Modules/Shared/resources/views/layouts/admin/components/alerts/sweetAlerts/deleteConfirm.blade.php ENDPATH**/ ?>