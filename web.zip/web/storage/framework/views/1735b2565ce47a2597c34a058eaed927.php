<?php if (isset($component)) { $__componentOriginal9058b929c5256b45202b01acf1644c1b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9058b929c5256b45202b01acf1644c1b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'user::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('user.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9058b929c5256b45202b01acf1644c1b)): ?>
<?php $attributes = $__attributesOriginal9058b929c5256b45202b01acf1644c1b; ?>
<?php unset($__attributesOriginal9058b929c5256b45202b01acf1644c1b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9058b929c5256b45202b01acf1644c1b)): ?>
<?php $component = $__componentOriginal9058b929c5256b45202b01acf1644c1b; ?>
<?php unset($__componentOriginal9058b929c5256b45202b01acf1644c1b); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/User/resources/views/index.blade.php ENDPATH**/ ?>