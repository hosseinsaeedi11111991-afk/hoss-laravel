<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.cars.index')); ?>">خودروها/</a></span>
        افزودن خودرو
    </h4>

    <form action="<?php echo e(route('admin.cars.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">عنوان <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">دسته‌بندی <span class="text-danger">*</span></label>
                <select name="car_category_id" class="form-select" required>
                    <option value="">انتخاب کنید...</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('car_category_id') == $id ? 'selected' : ''); ?>><?php echo e($title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['car_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ظرفیت سرنشین <span class="text-danger">*</span></label>
                <input type="number" name="passenger_capacity" class="form-control" value="<?php echo e(old('passenger_capacity', 1)); ?>" min="1" max="99" required>
                <?php $__errorArgs = ['passenger_capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ظرفیت بار</label>
                <input type="number" name="cargo_capacity" class="form-control" value="<?php echo e(old('cargo_capacity', 0)); ?>" min="0" max="99">
                <?php $__errorArgs = ['cargo_capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">وزن بار مجاز (کیلوگرم)</label>
                <input type="number" name="cargo_weight" class="form-control" value="<?php echo e(old('cargo_weight')); ?>" min="0">
                <?php $__errorArgs = ['cargo_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">وضعیت <span class="text-danger">*</span></label>
                <select name="status" class="form-select" required>
                    <option value="available"   <?php echo e(old('status') == 'available' ? 'selected' : ''); ?>>موجود</option>
                    <option value="rented"      <?php echo e(old('status') == 'rented' ? 'selected' : ''); ?>>اجاره داده‌شده</option>
                    <option value="maintenance" <?php echo e(old('status') == 'maintenance' ? 'selected' : ''); ?>>در تعمیر</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">بیمه <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_insurance" value="yes" <?php echo e(old('is_insurance') == 'yes' ? 'checked' : ''); ?> required>
                        <span class="form-check-label">دارد</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_insurance" value="no" <?php echo e(old('is_insurance') == 'no' ? 'checked' : ''); ?>>
                        <span class="form-check-label">ندارد</span>
                    </label>
                </div>
                <?php $__errorArgs = ['is_insurance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">تصویر خودرو</label>
                <input type="file" name="avatar" class="form-control">
                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="fixed" <?php echo e(old('pricing_type', 'fixed') == 'fixed' ? 'checked' : ''); ?> required>
                        <span class="form-check-label">قیمت ثابت</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="per_km" <?php echo e(old('pricing_type') == 'per_km' ? 'checked' : ''); ?>>
                        <span class="form-check-label">قیمت به ازای کیلومتر</span>
                    </label>
                </div>
                <?php $__errorArgs = ['pricing_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                <input type="number" step="0.01" name="fixed_price" class="form-control" value="<?php echo e(old('fixed_price', 0)); ?>" min="0" required>
                <?php $__errorArgs = ['fixed_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان)</label>
                <input type="number" step="0.01" name="per_km_price" class="form-control" value="<?php echo e(old('per_km_price', 0)); ?>" min="0">
                <?php $__errorArgs = ['per_km_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Cars/resources/views/admin/cars/create.blade.php ENDPATH**/ ?>