<form method="POST" enctype="multipart/form-data"
    action="<?php if($faq_content): ?> <?php echo e(route('admin.faq_content.update', ['faq' => $faq, 'faq_content' => $faq_content])); ?>

      <?php else: ?> <?php echo e(route('admin.faq_content.store', $faq)); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($faq_content): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-2 col-md-6 px-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="number" name="sort_order" class="form-control"
                    value="<?php echo e(old('sort_order', $faq_content ? $faq_content->sort_order : '')); ?>">
            </div>
            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="question">
                <span>پرسش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="question" type="text" name="question" class="form-control"
                    value="<?php echo e(old('question', $faq_content ? $faq_content->question : '')); ?>">
            </div>
            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-6 px-4">
            <label class="form-label" for="answer">
                <span>پاسخ</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <textarea id="answer" name="answer" class="form-control" rows="5">
                    <?php echo e(old('answer', $faq_content ? $faq_content->answer : '')); ?>

                </textarea>
            </div>
            <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Faq/resources/views/admin/faq_content/partials/form.blade.php ENDPATH**/ ?>