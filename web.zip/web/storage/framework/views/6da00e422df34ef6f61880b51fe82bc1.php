<?php $__env->startSection('title', 'ویرایش لینک <?php echo e($menu_item->title); ?>'); ?>

<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.home')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.menu_item.index', $menu)); ?>">لینک‌‌های منو/</a></span>
        <span>ویرایش لینک <?php echo e($menu_item->title); ?></span>
    </h4>

    <?php echo $__env->make('menu::admin.menu_item.partials.form', [
        'menu' => $menu,
        'menu_item' => $menu_item,
        'items' => $items,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Menu/resources/views/admin/menu_item/edit.blade.php ENDPATH**/ ?>