<?php $__env->startSection('main'); ?>



    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>

    <!-- Header Banner -->
    <section class="banner-header middle-height section-padding bg-img" data-overlay-dark="6" data-background="<?php echo e(asset('site/img/slider/4.webp')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h6>با ما در ارتباط باشید</h6>
                        <h1>تماس<span>با ما</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Box -->
    <div class="contact-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon omfi-envelope"></span>
                        <h5>ایمیل ما</h5>
                        <p>info@viptaxiiran.com</p> <i class="numb omfi-envelope"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon omfi-location"></span>
                        <h5>آدرس ما</h5>
                        <p>تهران، شهرک راه‌آهن</p> <i class="numb omfi-location"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon ti-time"></span>
                        <h5>ساعات کاری</h5>
                        <p>۲۴ ساعت شبانه روز</p> <i class="numb ti-time"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item active"> <span class="icon omfi-phone"></span>
                        <h5>شماره تماس</h5>
                        <p dir="ltr">
                            <a href="tel:+989120983462" style="color: inherit; text-decoration: none;">+98 912 098 3462</a><br>
                            <a href="tel:+989026665822" style="color: inherit; text-decoration: none;">+98 902 666 5822</a><br>
                            <a href="tel:+982156281778" style="color: inherit; text-decoration: none;">+98 21 5628 1778</a>
                        </p> <i class="numb omfi-phone"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact -->
    <section class="contact section-padding">
        <div class="container">
            <div class="row">
                <!-- Form -->
                <div class="col-lg-6 col-md-12 mb-30">
                    <div class="form-box">
                        <h5>با ما در ارتباط باشید</h5>
                        <form method="post" class="contact__form" action="#">
                            <!-- form message -->
                            <div class="row">
                                <div class="col-12">
                                    <div class="alert alert-success contact__msg" style="display: none" role="alert"> پیام شما با موفقیت ارسال شد.</div>
                                </div>
                            </div>
                            <!-- form elements -->
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <input name="name" type="text" placeholder="نام و نام خانوادگی *" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="email" type="email" placeholder="ایمیل *" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="phone" type="text" placeholder="شماره تماس *" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="subject" type="text" placeholder="موضوع *" required>
                                </div>
                                <div class="col-md-12 form-group">
                                    <textarea name="message" id="message" cols="30" rows="4" placeholder="پیام *" required></textarea>
                                </div>
                                <div class="col-md-12">
                                    <input name="submit" type="submit" value="ارسال">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Map -->
                <div class="col-lg-5 offset-lg-1 col-md-12">
                    <h5>لوکیشن</h5>
                    <div class="google-map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1573147.7480448114!2d-74.84628175962355!3d41.04009641088412!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25856139b3d33%3A0xb2739f33610a08ee!2s1616%20Broadway%2C%20New%20York%2C%20NY%2010019%2C%20Amerika%20Birle%C5%9Fik%20Devletleri!5e0!3m2!1str!2str!4v1646760525018!5m2!1str!2str" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="6" data-background="<?php echo e(asset('site/img/slider/3.webp')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>رزرو آنلاین تاکسی بین شهری</h6>
                    <h5>آماده سفر هستید؟</h5>
                    <p>برای رزرو تاکسی بین شهری با ما تماس بگیرید.</p>
                    <a class="button-2 mt-15 mb-15" data-bs-target="#exampleModal" data-bs-toggle="modal" data-bs-whatever="@mdo" href="#0">الان رزرو کن<span class="ti-arrow-top-right"></span></a><a class="button-1 mt-15 mb-15 me-2" href="https://wa.me/989120983462" target="_blank" dir="ltr"><i class="fa-brands fa-whatsapp"></i>واتس اپ</a>
                </div>
            </div>
        </div>
    </section>
    <!-- Clients -->
    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/1.webp')); ?>" alt="رزرو تاکسی دربستی"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/2.webp')); ?>" alt="تاکسی دربستی بین شهری"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/3.webp')); ?>" alt="تاکسی بین شهری آنلاین"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/4.webp')); ?>" alt="تاکسی آنلاین بین شهری"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/5.webp')); ?>" alt="تاکسی برون شهری"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/6.webp')); ?>" alt="برون شهری تاکسی آنلاین"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/7.webp')); ?>" alt="تاکسی دربستی تهران به اصفهان"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('site/img/clients/8.webp')); ?>" alt="تاکسی بین شهری تهران به مشهد"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.site.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/resources/views/contact-us.blade.php ENDPATH**/ ?>