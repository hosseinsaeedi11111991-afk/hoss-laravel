<?php use Modules\Menu\Models\MenuItem; ?>
<form method="POST" enctype="multipart/form-data"
    action="<?php if($menu_item): ?> <?php echo e(route('admin.menu_item.update', ['menu' => $menu, 'menu_item' => $menu_item])); ?>

      <?php else: ?> <?php echo e(route('admin.menu_item.store', $menu)); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($menu_item): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if(!$menu_item): ?>
        <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <?php echo $__env->make('admin.components.tree_view', [
                'content' => $items,
                'selected' => old('parent_id'),
                'level' => 0,
                'name' => 'parent_id',
                'label' => 'title'
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-2 col-md-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="text" name="sort_order" class="form-control"
                    value="<?php echo e(old('sort_order', $menu_item ? $menu_item->sort_order : '')); ?>">
            </div>
            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="title">
                <span>عنوان</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="title" type="text" name="title" class="form-control"
                    value="<?php echo e(old('title', $menu_item ? $menu_item->title : '')); ?>">
            </div>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="link">
                <span>لینک</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="link" type="text" name="link" class="form-control"
                    value="<?php echo e(old('link', $menu_item ? $menu_item->link : '')); ?>">
            </div>
            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-3 col-md-4">
            <label class="form-label" for="icon">
                <span>آیکن</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="icon" type="text" name="icon" class="form-control"
                    value="<?php echo e(old('icon', $menu_item ? $menu_item->icon : '')); ?>">
            </div>
            <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 col-lg-8 col-md-8">
            <label class="form-label" for="style">
                <span>استایل</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="style" type="text" name="style" class="form-control"
                    value="<?php echo e(old('style', $menu_item ? $menu_item->style : '')); ?>">
            </div>
            <?php $__errorArgs = ['style'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-check form-switch">
        <input type="hidden" name="new_tab" value="0">
        <input 
            class="form-check-input" 
            type="checkbox" 
            role="switch" 
            id="new_tab" 
            name="new_tab" 
            value="1"
            <?php if($menu_item && $menu_item->new_tab): echo 'checked'; endif; ?>>

        <label class="form-check-label ms-2" for="new_tab">
            ایجاد تب جدید
        </label>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Menu/resources/views/admin/menu_item/partials/form.blade.php ENDPATH**/ ?>