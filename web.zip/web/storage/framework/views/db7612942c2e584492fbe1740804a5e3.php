<?php if (isset($component)) { $__componentOriginal96d4fa3a24c933f441cddbcf42c152dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal96d4fa3a24c933f441cddbcf42c152dc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'attachment::components.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('attachment::layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('attachment.name'); ?></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal96d4fa3a24c933f441cddbcf42c152dc)): ?>
<?php $attributes = $__attributesOriginal96d4fa3a24c933f441cddbcf42c152dc; ?>
<?php unset($__attributesOriginal96d4fa3a24c933f441cddbcf42c152dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96d4fa3a24c933f441cddbcf42c152dc)): ?>
<?php $component = $__componentOriginal96d4fa3a24c933f441cddbcf42c152dc; ?>
<?php unset($__componentOriginal96d4fa3a24c933f441cddbcf42c152dc); ?>
<?php endif; ?>
<?php /**PATH /home/tajhizta/web/Modules/Attachment/resources/views/index.blade.php ENDPATH**/ ?>