<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.neshan-locations.index')); ?>">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        لیست موقعیت‌ها
    </h4>

    <a href="<?php echo e(route('admin.neshan-locations.create')); ?>" class="btn btn-success rounded-pill mb-3">+ افزودن موقعیت</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>رزرو</th>
                <th>آدرس</th>
                <th>نوع</th>
                <th>Lat</th>
                <th>Lng</th>
                <th>اصلی؟</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($locations->firstItem() + $key); ?></td>
                    <td><?php echo e($loc->reservation_id ?? '—'); ?></td>
                    <td><?php echo e(Str::limit($loc->address_text, 60)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($loc->type === 'origin' ? 'primary' : 'info'); ?>"><?php echo e($loc->type === 'origin' ? 'مبدا' : 'مقصد'); ?></span>
                    </td>
                    <td><?php echo e($loc->latitude); ?></td>
                    <td><?php echo e($loc->longitude); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($loc->is_primary ? 'success' : 'secondary'); ?>"><?php echo e($loc->is_primary ? 'بله' : 'خیر'); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.neshan-locations.show', $loc)); ?>" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="<?php echo e(route('admin.neshan-locations.edit', $loc)); ?>" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="<?php echo e(route('admin.neshan-locations.destroy', $loc)); ?>" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($locations->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Neshan/resources/views/admin/neshan_locations/index.blade.php ENDPATH**/ ?>