<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.reservations.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.reservations.index')); ?>">رزرو‌ها/</a></span>
        مشاهده رزرو
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات رزرو</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>کاربر:</strong> <?php echo e($reservation->user->full_name ?? '-'); ?></li>
                        <li class="list-group-item"><strong>شماره تماس:</strong> <?php echo e($reservation->phone ?? $reservation->user->mobile ?? '-'); ?></li>
                        <li class="list-group-item"><strong>شماره دوم:</strong> <?php echo e($reservation->second_phone ?? '-'); ?></li>
                        <li class="list-group-item"><strong>دسته‌بندی ماشین:</strong> <?php echo e($reservation->carCategory->title ?? '-'); ?></li>
                        <li class="list-group-item"><strong>خودرو:</strong> <?php echo e($reservation->car->title ?? '-'); ?></li>
                        <li class="list-group-item"><strong>تعداد مسافران:</strong> <?php echo e($reservation->passengers_count ?? 1); ?> نفر</li>
                        <li class="list-group-item"><strong>تاریخ:</strong> <?php echo e($reservation->date ? verta($reservation->date)->format('Y/m/d H:i:s') : '-'); ?></li>
                        <li class="list-group-item"><strong>مسافت:</strong> <?php echo e(number_format($reservation->distance_km, 2)); ?> km</li>
                        <li class="list-group-item"><strong>مبلغ کل:</strong> <?php echo e(number_format($reservation->total_price)); ?> تومان</li>
                        <li class="list-group-item"><strong>آدرس مبدا:</strong> <?php echo e($reservation->origin_address ?? '-'); ?></li>
                        <li class="list-group-item"><strong>آدرس مقصد:</strong> <?php echo e($reservation->destination_address ?? '-'); ?></li>
                        <li class="list-group-item"><strong>مبدا:</strong> <?php echo e($reservation->origin ?? '-'); ?></li>
                        <li class="list-group-item"><strong>مقصد:</strong> <?php echo e($reservation->destination ?? '-'); ?></li>
                        <li class="list-group-item"><strong>زمان حرکت:</strong> <?php echo e($reservation->time ?? '-'); ?></li>
                        <li class="list-group-item"><strong>توضیحات:</strong> <?php echo e($reservation->description ?? 'بدون توضیحات'); ?></li>
                        <li class="list-group-item">
                            <strong>نیاز به فاکتور:</strong>
                            <?php if($reservation->needs_invoice): ?>
                                <span class="badge bg-success">بله</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">خیر</span>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>قیمت توافقی:</strong>
                            <?php if($reservation->is_negotiable): ?>
                                <span class="badge bg-warning">بله</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">خیر</span>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>آپشن‌ها:</strong>
                            <?php if($reservation->options->isEmpty()): ?>
                                <span class="text-muted">—</span>
                            <?php else: ?>
                                <ul class="mt-2">
                                    <?php $__currentLoopData = $reservation->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($opt->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>وضعیت:</strong>
                            <span class="badge bg-primary"><?php echo e($reservation->status_label); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p><?php echo e(verta($reservation->created_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p><?php echo e(verta($reservation->updated_at)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <span class="badge bg-<?php echo e($loc->type === 'origin' ? 'primary' : 'info'); ?>"><?php echo e($loc->type === 'origin' ? 'مبدا' : 'مقصد'); ?></span>
                    <?php if($loc->is_primary): ?>
                        <span class="badge bg-success">اصلی</span>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="https://www.google.com/maps?q=<?php echo e($loc->latitude); ?>,<?php echo e($loc->longitude); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-map-marker-alt"></i> مشاهده در گوگل مپ
                    </a>
                </div>
            </div>
            <div class="card-body">
                <p class="mb-2"><span class="fw-bold">آدرس:</span> <?php echo e($loc->address_text); ?></p>

                <?php if($loc->cities->count()): ?>
                    <div class="table-responsive text-nowrap">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>نام شهر</th>
                                <th>کیلومتر</th>
                                <th>رزرو مرتبط</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $loc->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($idx + 1); ?></td>
                                    <td><?php echo e($city->city_name); ?></td>
                                    <td><?php echo e(number_format($city->distance_km, 2)); ?></td>
                                    <td><?php echo e($city->reservation_id ?? '—'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <span class="text-muted">هیچ شهری ثبت نشده است.</span>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">هیچ لوکیشنی برای این رزرو ثبت نشده است.</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Reservation/resources/views/admin/reservations/show.blade.php ENDPATH**/ ?>