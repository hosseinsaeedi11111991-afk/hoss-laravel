<form method="POST" enctype="multipart/form-data"
    action="<?php if($page): ?> <?php echo e(route('admin.page.update', ['page' => $page])); ?>

      <?php else: ?> <?php echo e(route('admin.page.store')); ?> <?php endif; ?>">
    <?php echo csrf_field(); ?>
    <?php if($page): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <?php echo $__env->make('admin.components.tree_view', [
                'content' => $pages,
                'selected' => old('parent_id'),
                'level' => 0,
                'name' => 'parent_id'
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="name">
                <span>نام صفحه</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control" placeholder="صفحه اصلی، درباره ما و ..."
                    value="<?php echo e(old('name', $page ? $page->name : '')); ?>">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="title">
                <span>عنوان صفحه</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="title" type="text" name="title" class="form-control" placeholder="عنوان صفحه"
                    value="<?php echo e(old('title', $page ? $page->title : '')); ?>">
            </div>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="slug">
                <span>اسلاگ</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="slug" type="text" name="slug" class="form-control" placeholder="slug"
                    value="<?php echo e(old('slug', $page ? $page->slug : '')); ?>">
            </div>
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
</form><?php /**PATH /home/tajhizta/web/Modules/Page/resources/views/admin/partials/form.blade.php ENDPATH**/ ?>