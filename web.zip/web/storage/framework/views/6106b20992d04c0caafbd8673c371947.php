
<?php $__env->startSection('main'); ?>
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">پنل/</a></span>
        <span><a class="text-muted fw-light" href="<?php echo e(route('admin.discounts.index')); ?>">تخفیف‌ها/</a></span>
        نمایش تخفیف
    </h4>

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between">
            <h5>جزئیات تخفیف</h5>
            <div>
                <a href="<?php echo e(route('admin.discounts.edit', $discount)); ?>" class="btn btn-warning btn-sm">ویرایش</a>
                <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-secondary btn-sm">بازگشت</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>عنوان:</strong> <?php echo e($discount->title); ?></p>
                    <p><strong>کد:</strong> <?php echo e($discount->code ?? '-'); ?></p>
                    <p><strong>نوع تخفیف:</strong> <?php echo e($discount->getDiscountTypeLabel()); ?></p>
                    <p><strong>مقدار:</strong> 
                        <?php if($discount->isPercentage()): ?>
                            <?php echo e($discount->discount_value); ?>%
                        <?php else: ?>
                            <?php echo e(number_format($discount->discount_value)); ?> تومان
                        <?php endif; ?>
                    </p>
                    <p><strong>نوع فعال‌سازی:</strong> <?php echo e($discount->getTriggerTypeLabel()); ?></p>
                    <p><strong>اولویت:</strong> <?php echo e($discount->getPriorityLabel()); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>وضعیت:</strong> 
                        <?php if($discount->is_active): ?>
                            <span class="badge bg-success">فعال</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">غیرفعال</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>استفاده شده:</strong> <?php echo e($discount->current_usage_count); ?> / <?php echo e($discount->usage_limit ?? '∞'); ?></p>
                    <p><strong>تاریخ شروع:</strong> <?php echo e(verta($discount->valid_from)->format('Y/m/d H:i')); ?></p>
                    <p><strong>تاریخ پایان:</strong> <?php echo e(verta($discount->valid_until)->format('Y/m/d H:i')); ?></p>
                </div>
            </div>
            <?php if($discount->description): ?>
                <div class="mt-3">
                    <strong>توضیحات:</strong>
                    <p><?php echo e($discount->description); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Shared::layouts.admin.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tajhizta/web/Modules/Discount/resources/views/admin/discounts/show.blade.php ENDPATH**/ ?>