#!/bin/bash

echo "========== Laravel Deploy =========="

git pull --ff-only origin main || exit 1

php artisan optimize:clear || exit 1
php artisan config:cache || exit 1
php artisan view:cache || exit 1

echo "Deployment completed successfully."
