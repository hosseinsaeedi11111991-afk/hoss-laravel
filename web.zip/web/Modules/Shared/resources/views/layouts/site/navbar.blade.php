
<!-- Preloader -->
<div class="preloader-bg"></div>
<div id="preloader">
    <div id="preloader-status">
        <div class="preloader-position loader"> <span></span> </div>
    </div>
</div>

@php
    $siteContact = app(\App\Services\SiteContactService::class)->contact();
    $whatsappNumber = $siteContact['whatsapp_number'];
    $displayPhone = $siteContact['display_phone'];
    $telPhone = $siteContact['tel_phone'];

    $headerMenuItems = app(\App\Services\HeaderMenuService::class)->headerItems();
@endphp

<!-- WhatsApp Floating Button -->
<a href="https://wa.me/{{ $whatsappNumber }}" target="_blank" rel="noopener" class="whatsapp-button" title="تماس با ما در واتساپ" aria-label="واتساپ">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="28" height="28" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>

<!-- ================= هدر شیشه‌ای شناور (Glassmorphism) ================= -->
<header class="tx-gh" id="tx-gh-root" dir="rtl">
    <div class="tx-gh-particles" aria-hidden="true">
        <i class="tx-gh-frost"></i>
        <i class="tx-gh-droplets"></i>
        <i class="tx-gh-streak tx-gh-streak--1"></i>
        <i class="tx-gh-streak tx-gh-streak--2"></i>
        <i class="tx-gh-streak tx-gh-streak--3"></i>
        <i class="tx-gh-streak tx-gh-streak--4"></i>
        <i class="tx-gh-smoke tx-gh-smoke--1"></i>
        <i class="tx-gh-smoke tx-gh-smoke--2"></i>
        <i class="tx-gh-smoke tx-gh-smoke--3"></i>
        <span></span><span></span><span></span><span></span><span></span><span></span>
    </div>
    <div class="tx-gh-container">

        <!-- لوگو -->
        <a href="{{ route('home') }}" class="tx-gh-logo">
            <img src="{{ asset('site/img/vip-logo.webp') }}" alt="وی‌آی‌پی تاکسی ایران">
        </a>

        <!-- منوی اصلی -->
        <nav class="tx-gh-nav" id="tx-gh-nav">
            @if($headerMenuItems->isNotEmpty())
                <ul>
                    @foreach($headerMenuItems as $menuItem)
                        <li class="{{ !empty($menuItem['children']) ? 'tx-gh-has-children' : '' }}">
                            <a href="{{ $menuItem['link'] }}" @if($menuItem['new_tab']) target="_blank" rel="noopener" @endif>
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="7" height="7"><circle cx="12" cy="12" r="5"/></svg>
                                {{ $menuItem['title'] }}
                            </a>
                            @if(!empty($menuItem['children']))
                                <button type="button" class="tx-gh-caret-btn" aria-label="باز کردن زیرمنو {{ $menuItem['title'] }}" aria-expanded="false">
                                    <svg class="tx-gh-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <ul class="tx-gh-submenu">
                                    @foreach($menuItem['children'] as $child)
                                        <li>
                                            <a href="{{ $child['link'] }}" @if($child['new_tab']) target="_blank" rel="noopener" @endif>{{ $child['title'] }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                    @endforeach
                </ul>
            @else
                <!-- منوی پیش‌فرض: تا وقتی از بخش «منوها» در ادمین آیتمی برای موقعیت «هدر» ثبت نشده -->
                <ul>
                    <li>
                        <a href="{{ route('home') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><path d="M4 11l8-7 8 7M6 10v9a1 1 0 001 1h3v-6h4v6h3a1 1 0 001-1v-9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            صفحه اصلی
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('site.reservation.index') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><path d="M3 13l2-6a2 2 0 012-1.5h10A2 2 0 0119 7l2 6M5 13h14M5 13v4a1 1 0 001 1h1a1 1 0 001-1v-1h8v1a1 1 0 001 1h1a1 1 0 001-1v-4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="7.5" cy="16.5" r="1.1"/><circle cx="16.5" cy="16.5" r="1.1"/></svg>
                            رزرو آنلاین
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('blog.category') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><path d="M4 5h13a2 2 0 012 2v11a1 1 0 01-1.55.833L15 17H6a2 2 0 01-2-2V5z" stroke-linejoin="round"/><path d="M7 9h9M7 12.5h6" stroke-linecap="round"/></svg>
                            وبلاگ
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('about-us') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="8" r="3.2"/><path d="M5 20c1-3.5 4-5.5 7-5.5s6 2 7 5.5" stroke-linecap="round"/></svg>
                            درباره ما
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('contact-us') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" fill="currentColor" stroke="none"/></svg>
                            تماس با ما
                        </a>
                    </li>
                </ul>
            @endif
        </nav>

        <!-- دکمه رزرو و همبرگر موبایل -->
        <div class="tx-gh-actions">
            <a href="tel:{{ $telPhone }}" class="tx-gh-book-btn">
                <svg viewBox="0 0 24 24" fill="currentColor" width="17" height="17"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                <span dir="ltr">{{ $displayPhone }}</span>
            </a>

            <button class="tx-gh-toggle" id="tx-gh-toggle" aria-label="منو" aria-expanded="false" aria-controls="tx-gh-nav" type="button">
                <span class="tx-gh-toggle-bar"></span>
                <span class="tx-gh-toggle-bar"></span>
                <span class="tx-gh-toggle-bar"></span>
            </button>
        </div>

    </div>
</header>

<style>
.tx-gh{
    --gh-gold:#FFD700;
    --gh-gold-2:#FFA500;
    --gh-dark:#0a0f1e;
    --gh-white:#ffffff;
    --gh-glass-bg:rgba(10,15,30,0.55);
    --gh-glass-border:rgba(255,215,0,0.18);
    --tx-gh-angle:0deg;

    position:fixed; top:20px; left:50%; transform:translateX(-50%);
    width:95%; max-width:1240px; z-index:1000;
    direction:rtl; font-family:'Vazirmatn','peyda','Segoe UI',Tahoma,sans-serif;

    background:var(--gh-glass-bg);
    backdrop-filter:blur(28px) saturate(140%) contrast(102%);
    -webkit-backdrop-filter:blur(28px) saturate(140%) contrast(102%);
    border:1px solid var(--gh-glass-border);
    border-radius:20px;
    box-shadow:0 8px 32px rgba(0,0,0,0.3);

    padding:10px 22px;
    transition:all .4s ease;
}
.tx-gh *{ box-sizing:border-box; }

@property --tx-gh-angle{
    syntax:'<angle>';
    inherits:false;
    initial-value:0deg;
}

/* نوار نور طلایی چرخان دور لبه هدر */
.tx-gh::before{
    content:"";
    position:absolute;
    inset:-1.5px;
    border-radius:21.5px;
    padding:1.5px;
    background:conic-gradient(from var(--tx-gh-angle),
        rgba(255,215,0,0) 0deg,
        rgba(255,215,0,0.9) 35deg,
        rgba(255,247,200,1) 55deg,
        rgba(255,215,0,0.9) 75deg,
        rgba(255,215,0,0) 130deg,
        rgba(255,215,0,0) 360deg);
    -webkit-mask:linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite:xor;
    mask-composite:exclude;
    animation:tx-gh-border-spin 5s linear infinite;
    pointer-events:none;
    z-index:0;
}
@keyframes tx-gh-border-spin{ to{ --tx-gh-angle:360deg; } }

@media (prefers-reduced-motion:reduce){
    .tx-gh::before{ animation:none; }
}

.tx-gh.is-scrolled{
    padding:7px 22px;
    background:rgba(10,15,30,0.88);
    top:10px;
    border-color:rgba(255,215,0,0.28);
    box-shadow:0 10px 40px rgba(0,0,0,0.5);
}

.tx-gh-container{ display:flex; align-items:center; justify-content:space-between; gap:18px; position:relative; z-index:1; }

/* پارتیکل‌های نرم پس‌زمینه */
.tx-gh-particles{
    position:absolute; inset:0; border-radius:inherit; overflow:hidden;
    pointer-events:none; z-index:0;
}

/* بافت مات/گرین شیشه مه‌گرفته (frosted matte) */
.tx-gh-frost{
    position:absolute; inset:0;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix type='saturate' values='0'/></filter><rect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/></svg>");
    background-size:120px 120px;
    opacity:.05;
    mix-blend-mode:overlay;
}

/* قطره‌های آب ثابت روی شیشه */
.tx-gh-droplets{
    position:absolute; inset:0;
    background-image:
        radial-gradient(circle at 8% 30%,  rgba(255,255,255,0.22) 0%, rgba(255,255,255,0) 60%),
        radial-gradient(circle at 8% 30%,  rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 14%),
        radial-gradient(circle at 18% 68%, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 55%),
        radial-gradient(circle at 18% 68%, rgba(255,255,255,0.35) 0%, rgba(255,255,255,0) 12%),
        radial-gradient(circle at 32% 22%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 50%),
        radial-gradient(circle at 46% 78%, rgba(255,255,255,0.2)  0%, rgba(255,255,255,0) 55%),
        radial-gradient(circle at 46% 78%, rgba(255,255,255,0.38) 0%, rgba(255,255,255,0) 11%),
        radial-gradient(circle at 61% 35%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 48%),
        radial-gradient(circle at 74% 66%, rgba(255,255,255,0.2)  0%, rgba(255,255,255,0) 52%),
        radial-gradient(circle at 74% 66%, rgba(255,255,255,0.4)  0%, rgba(255,255,255,0) 13%),
        radial-gradient(circle at 88% 28%, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 50%),
        radial-gradient(circle at 95% 72%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 45%);
    opacity:.55;
}

/* رگه‌های بارون که به آرومی روی شیشه سر می‌خورن */
.tx-gh-streak{
    position:absolute; top:-20%; width:2px; height:60%;
    background:linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.5) 35%, rgba(255,255,255,0.15) 70%, rgba(255,255,255,0) 100%);
    filter:blur(1px);
    animation:tx-gh-rain-fall linear infinite;
    opacity:.5;
}
.tx-gh-streak--1{ right:14%;  animation-duration:4.5s; animation-delay:0s; }
.tx-gh-streak--2{ right:38%;  animation-duration:6s;   animation-delay:1.6s; }
.tx-gh-streak--3{ right:62%;  animation-duration:5.2s; animation-delay:.8s; }
.tx-gh-streak--4{ right:83%;  animation-duration:6.8s; animation-delay:2.4s; }

@keyframes tx-gh-rain-fall{
    0%{ transform:translateY(-40%); opacity:0; }
    15%{ opacity:.55; }
    85%{ opacity:.4; }
    100%{ transform:translateY(220%); opacity:0; }
}

.tx-gh-particles span{
    position:absolute; border-radius:50%; filter:blur(1px);
    background:radial-gradient(circle, rgba(255,215,0,0.55) 0%, rgba(255,215,0,0) 70%);
    animation:tx-gh-float 9s ease-in-out infinite;
}
.tx-gh-particles span:nth-child(1){ width:6px; height:6px; top:20%; right:8%;  animation-duration:8s;  animation-delay:0s; }
.tx-gh-particles span:nth-child(2){ width:4px; height:4px; top:65%; right:22%; animation-duration:10s; animation-delay:1.2s; background:radial-gradient(circle, rgba(255,255,255,0.5) 0%, rgba(255,255,255,0) 70%); }
.tx-gh-particles span:nth-child(3){ width:5px; height:5px; top:35%; right:40%; animation-duration:11s; animation-delay:2.4s; }
.tx-gh-particles span:nth-child(4){ width:3px; height:3px; top:75%; right:55%; animation-duration:7s;  animation-delay:0.6s; background:radial-gradient(circle, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0) 70%); }
.tx-gh-particles span:nth-child(5){ width:5px; height:5px; top:15%; right:70%; animation-duration:9.5s; animation-delay:3s; }
.tx-gh-particles span:nth-child(6){ width:4px; height:4px; top:55%; right:85%; animation-duration:8.5s; animation-delay:1.8s; background:radial-gradient(circle, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 70%); }

@keyframes tx-gh-float{
    0%, 100%{ transform:translateY(0) translateX(0); opacity:.5; }
    50%{ transform:translateY(-10px) translateX(4px); opacity:1; }
}

/* دود طلایی نرم داخل هدر */
.tx-gh-smoke{
    position:absolute; border-radius:50%; filter:blur(18px);
    background:radial-gradient(circle, rgba(255,215,0,0.4) 0%, rgba(255,165,0,0.15) 45%, rgba(255,215,0,0) 72%);
    mix-blend-mode:screen;
    will-change:transform, opacity;
}
.tx-gh-smoke--1{
    width:170px; height:90px; top:-40px; right:5%;
    animation:tx-gh-smoke-drift-1 13s ease-in-out infinite;
}
.tx-gh-smoke--2{
    width:150px; height:80px; bottom:-50px; right:38%;
    background:radial-gradient(circle, rgba(255,247,200,0.35) 0%, rgba(255,215,0,0.12) 50%, rgba(255,215,0,0) 75%);
    animation:tx-gh-smoke-drift-2 16s ease-in-out infinite;
    animation-delay:2.5s;
}
.tx-gh-smoke--3{
    width:140px; height:85px; top:-30px; right:75%;
    animation:tx-gh-smoke-drift-3 14.5s ease-in-out infinite;
    animation-delay:5s;
}

@keyframes tx-gh-smoke-drift-1{
    0%, 100%{ transform:translate(0,0) scale(1); opacity:.55; }
    50%{ transform:translate(-60px, 14px) scale(1.25); opacity:.85; }
}
@keyframes tx-gh-smoke-drift-2{
    0%, 100%{ transform:translate(0,0) scale(1); opacity:.45; }
    50%{ transform:translate(50px, -10px) scale(1.3); opacity:.75; }
}
@keyframes tx-gh-smoke-drift-3{
    0%, 100%{ transform:translate(0,0) scale(1); opacity:.5; }
    50%{ transform:translate(-40px, -12px) scale(1.2); opacity:.8; }
}

@media (prefers-reduced-motion:reduce){
    .tx-gh-particles span{ animation:none; opacity:.6; }
    .tx-gh-smoke{ animation:none; opacity:.5; }
    .tx-gh-streak{ animation:none; opacity:.25; }
}

/* لوگو */
.tx-gh-logo{ display:flex; align-items:center; flex-shrink:0; }
.tx-gh-logo img{ height:52px; width:auto; border-radius:50%; transition:height .3s ease; }
.tx-gh.is-scrolled .tx-gh-logo img{ height:42px; }

/* منو */
.tx-gh-nav ul{ display:flex; list-style:none; gap:4px; margin:0; padding:0; }
.tx-gh-nav a{
    color:rgba(255,255,255,0.96); text-decoration:none; font-size:14.5px; font-weight:700;
    padding:9px 14px; border-radius:10px; display:flex; align-items:center; gap:7px;
    transition:all .25s ease;
}
.tx-gh-nav a svg{ color:var(--gh-gold); opacity:.85; flex-shrink:0; }
.tx-gh-nav a:hover{ background:rgba(255,255,255,0.1); color:var(--gh-gold); }

/* زیرمنو (دراپ‌داون) برای آیتم‌هایی که فرزند دارند */
.tx-gh-nav li.tx-gh-has-children{ position:relative; display:flex; align-items:center; }
.tx-gh-caret-btn{
    display:flex; align-items:center; justify-content:center;
    width:22px; height:22px; margin-inline-start:-6px; border:none; background:transparent;
    color:rgba(255,255,255,0.65); cursor:pointer; border-radius:6px; flex-shrink:0;
}
.tx-gh-caret-btn:hover{ color:var(--gh-gold); background:rgba(255,255,255,0.08); }
.tx-gh-caret{ transition:transform .2s ease; }
.tx-gh-nav li.tx-gh-has-children:hover .tx-gh-caret,
.tx-gh-caret-btn[aria-expanded="true"] .tx-gh-caret{ transform:rotate(180deg); }

.tx-gh-submenu{
    list-style:none; margin:0; padding:8px; position:absolute; top:calc(100% + 8px); right:0;
    min-width:210px; width:max-content; max-width:260px; background:rgba(10,15,30,0.96);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border:1px solid var(--gh-glass-border); border-radius:14px;
    box-shadow:0 15px 30px rgba(0,0,0,0.45);
    opacity:0; visibility:hidden; transform:translateY(-6px);
    transition:opacity .2s ease, transform .2s ease, visibility .2s ease;
    z-index:20;
}
.tx-gh-nav li.tx-gh-has-children:hover .tx-gh-submenu,
.tx-gh-nav li.tx-gh-has-children.tx-gh-submenu-open .tx-gh-submenu{
    opacity:1; visibility:visible; transform:translateY(0);
}
.tx-gh-submenu li{ margin:0; }
.tx-gh-submenu a{
    display:block; padding:9px 12px; font-size:13px; color:rgba(255,255,255,0.8);
    border-radius:8px; text-decoration:none; transition:background .2s ease, color .2s ease;
    white-space:nowrap;
}
.tx-gh-submenu a:hover{ background:rgba(255,215,0,0.08); color:var(--gh-gold); }

/* اکشن‌ها */
.tx-gh-actions{ display:flex; align-items:center; gap:10px; }

.tx-gh-book-btn{
    display:flex; align-items:center; gap:8px;
    background:linear-gradient(135deg, var(--gh-gold) 0%, var(--gh-gold-2) 100%);
    color:#1a1400 !important; text-decoration:none; font-weight:700; font-size:13.5px;
    padding:10px 20px; border-radius:12px;
    box-shadow:0 4px 15px rgba(255,183,3,0.3);
    transition:all .3s ease; white-space:nowrap;
}
.tx-gh-book-btn:hover{ transform:translateY(-2px); box-shadow:0 6px 20px rgba(255,183,3,0.5); }

.tx-gh-toggle{
    display:none; width:44px; height:44px; border-radius:12px;
    background:rgba(255,215,0,0.12); border:1px solid rgba(255,215,0,0.3);
    cursor:pointer; align-items:center; justify-content:center;
    flex-direction:column; gap:4px; flex-shrink:0; transition:.3s;
}
.tx-gh-toggle:hover{ background:rgba(255,215,0,0.2); }
.tx-gh-toggle-bar{ width:19px; height:2.2px; background:#fff; border-radius:2px; transition:transform .25s ease, opacity .2s ease; }
.tx-gh-toggle.is-open .tx-gh-toggle-bar:nth-child(1){ transform:translateY(6.6px) rotate(45deg); }
.tx-gh-toggle.is-open .tx-gh-toggle-bar:nth-child(2){ opacity:0; }
.tx-gh-toggle.is-open .tx-gh-toggle-bar:nth-child(3){ transform:translateY(-6.6px) rotate(-45deg); }

/* ================= ریسپانسیو ================= */
@media (max-width:992px){
    .tx-gh-nav{
        position:fixed; top:88px; right:15px; left:15px;
        background:rgba(10,15,30,0.96);
        backdrop-filter:blur(25px); -webkit-backdrop-filter:blur(25px);
        border:1px solid var(--gh-glass-border);
        border-radius:20px; padding:16px;
        transform:translateY(-16px); opacity:0; visibility:hidden;
        transition:all .3s ease; box-shadow:0 15px 30px rgba(0,0,0,0.5);
    }
    .tx-gh-nav.is-open{ transform:translateY(0); opacity:1; visibility:visible; }
    .tx-gh-nav ul{ flex-direction:column; gap:4px; }
    .tx-gh-nav a{ padding:12px 14px; font-size:14.5px; }
    .tx-gh-nav a svg{ width:15px; height:15px; }
    .tx-gh-toggle{ display:flex; }

    /* زیرمنو در موبایل به‌صورت آکاردئون باز/بسته می‌شود، نه هاور */
    .tx-gh-nav li.tx-gh-has-children{ flex-wrap:wrap; }
    .tx-gh-nav li.tx-gh-has-children .tx-gh-submenu{
        position:static; opacity:1; visibility:visible; transform:none;
        display:none; width:100%; margin-top:4px; box-shadow:none;
        background:rgba(255,255,255,0.04); border-color:var(--gh-glass-border);
    }
    .tx-gh-nav li.tx-gh-has-children.tx-gh-submenu-open .tx-gh-submenu{ display:block; }
    .tx-gh-caret-btn{ width:36px; height:36px; }
}

@media (max-width:480px){
    .tx-gh{ top:12px; width:94%; padding:8px 16px; border-radius:16px; }
    .tx-gh-book-btn span{ display:none; }
    .tx-gh-book-btn{ padding:10px; }
    .tx-gh-logo img{ height:40px; }
    .tx-gh-nav{ top:74px; }
}
</style>

<!-- فاصله جبرانی برای هدر شناور -->
<div style="height:96px;" aria-hidden="true"></div>

<script>
(function(){
    var header = document.getElementById('tx-gh-root');
    var toggle = document.getElementById('tx-gh-toggle');
    var nav = document.getElementById('tx-gh-nav');

    var lastState = false;
    function onScroll(){
        var scrolled = window.scrollY > 40;
        if (scrolled !== lastState){
            header.classList.toggle('is-scrolled', scrolled);
            lastState = scrolled;
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    function closeNav(){
        nav.classList.remove('is-open');
        toggle.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
    }

    if (toggle){
        toggle.addEventListener('click', function(e){
            e.stopPropagation();
            var willOpen = !nav.classList.contains('is-open');
            nav.classList.toggle('is-open', willOpen);
            toggle.classList.toggle('is-open', willOpen);
            toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
        });
    }

    document.addEventListener('click', function(e){
        if (nav && !nav.contains(e.target) && !toggle.contains(e.target)){
            if (nav.classList.contains('is-open')) closeNav();
        }
    });

    // باز/بسته کردن زیرمنو با دکمه فلش (کلیک، برای موبایل و لمسی)
    var caretButtons = document.querySelectorAll('.tx-gh-caret-btn');
    caretButtons.forEach(function(btn){
        btn.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            var li = btn.closest('li');
            var willOpen = !li.classList.contains('tx-gh-submenu-open');
            document.querySelectorAll('.tx-gh-submenu-open').forEach(function(openLi){
                if (openLi !== li){
                    openLi.classList.remove('tx-gh-submenu-open');
                    var otherBtn = openLi.querySelector('.tx-gh-caret-btn');
                    if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
                }
            });
            li.classList.toggle('tx-gh-submenu-open', willOpen);
            btn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
        });
    });
})();
</script>
