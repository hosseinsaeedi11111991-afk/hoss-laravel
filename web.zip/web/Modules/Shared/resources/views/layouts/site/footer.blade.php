
@php
    $footerServiceLinks = app(\App\Services\FooterServiceLinkService::class)->items();
@endphp

<!-- =========================================================
     VIP TAXI IRAN — Premium Dark Tech Footer
     خطوط مدار با پالس نوری متحرک در پس‌زمینه + بوردر گرادیانی چرخان روی دکمه CTA
========================================================= -->

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<footer class="tx-td-footer" dir="rtl">

    <!-- پس‌زمینه: گرید محو + مدار با پالس نوری + دو Glow -->
    <div class="tx-td-bg" aria-hidden="true">
        <div class="tx-td-grid"></div>

        <svg class="tx-td-circuit" viewBox="0 0 1240 520" preserveAspectRatio="none">
            <path class="tx-td-trace" d="M-20,90 L180,90 L220,50 L460,50 L500,90 L760,90 L800,50 L1080,50 L1120,90 L1300,90"/>
            <path class="tx-td-trace" d="M-20,230 L140,230 L140,190 L360,190 L400,230 L680,230 L720,190 L960,190 L1000,230 L1300,230"/>
            <path class="tx-td-trace tx-td-trace--sub" d="M-20,340 L260,340 L300,380 L620,380 L660,340 L940,340 L980,380 L1300,380"/>
            <circle class="tx-td-pulse tx-td-pulse--1" r="3.2"/>
            <circle class="tx-td-pulse tx-td-pulse--2" r="3.2"/>
            <circle class="tx-td-pulse tx-td-pulse--3" r="2.6"/>
        </svg>

        <div class="tx-td-glow tx-td-glow--top"></div>
        <div class="tx-td-glow tx-td-glow--bottom"></div>
        <div class="tx-td-horizon"></div>
    </div>

    <div class="tx-td-container">

        <!-- نوار تماس بالایی -->
        <div class="tx-td-topbar">
            <a class="tx-td-topbar-item" href="tel:+989120983462">
                <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                <span>۰۹۱۲۰۹۸۳۴۶۲</span>
            </a>
            <a class="tx-td-topbar-item" href="mailto:info@viptaxiiran.com">
                <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg></span>
                <span>info@viptaxiiran.com</span>
            </a>
            <div class="tx-td-topbar-item tx-td-topbar-item--static">
                <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="14" height="14"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                <span>پاسخگویی ۷ روز هفته، ۲۴ ساعت شبانه‌روز</span>
            </div>
        </div>

        <!-- بخش اصلی: چهار ستون -->
        <div class="tx-td-main">

            <div class="tx-td-col tx-td-col--brand">
                <div class="tx-td-status">
                    <span class="tx-td-status-dot"></span>
                    سامانه رزرو هم‌اکنون فعال است
                </div>

                <h3 class="tx-td-brand-title">
                    وی‌آی‌پی تاکسی ایران
                    <span class="tx-td-brand-en">VIP TAXI IRAN</span>
                </h3>

                <p class="tx-td-text">
                    وی‌آی‌پی تاکسی ایران ارائه‌دهنده خدمات جابجایی و سفرهای بین‌شهری با خودروهای لوکس و رانندگان حرفه‌ای است.
                    هدف ما ایجاد تجربه‌ای امن، سریع و مطمئن از سفر با پشتیبانی ۲۴ ساعته است.
                </p>

                <div class="tx-td-socials">
                    <a class="tx-td-social-btn" href="https://www.instagram.com/viptaxiiran?igsh=NHAxdXdzd3hubmg=" target="_blank" rel="noopener" aria-label="اینستاگرام"><svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
                    <a class="tx-td-social-btn" href="https://t.me/viptaxiiran" target="_blank" rel="noopener" aria-label="تلگرام"><svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg></a>
                    <a class="tx-td-social-btn" href="https://wa.me/989120983462" target="_blank" rel="noopener" aria-label="واتساپ"><svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>
                    <a class="tx-td-social-btn" href="https://www.linkedin.com/in/viptaxiiran-viptaxiiran-834754140?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener" aria-label="لینکدین"><svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
                </div>
            </div>

            <div class="tx-td-col">
                <h4 class="tx-td-col-title">دسترسی سریع</h4>
                <ul class="tx-td-links">
                    <li><a href="{{ route('home') }}"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>صفحه اصلی</a></li>
                    <li><a href="{{ route('about-us') }}"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>درباره ما</a></li>
                    <li><a href="{{ route('contact-us') }}"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>تماس با ما</a></li>
                    <li><a href="#"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>قوانین و مقررات</a></li>
                    <li><a href="#"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>پیشنهاد و نظرات مشتریان</a></li>
                    <li><a href="#"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>ثبت نام رانندگان</a></li>
                </ul>
            </div>

            <div class="tx-td-col">
                <h4 class="tx-td-col-title">لیست خدمات</h4>
                <ul class="tx-td-links">
                    @forelse($footerServiceLinks as $footerServiceLink)
                        <li>
                            @if(!empty($footerServiceLink['url']))
                                <a href="{{ $footerServiceLink['url'] }}"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $footerServiceLink['title'] }}</a>
                            @else
                                <span class="tx-td-static-item"><svg class="tx-td-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" width="10" height="10"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $footerServiceLink['title'] }}</span>
                            @endif
                        </li>
                    @empty
                        <li><span class="tx-td-static-item">به‌زودی تکمیل می‌شود</span></li>
                    @endforelse
                </ul>
            </div>

            <div class="tx-td-col tx-td-col--support">
                <h4 class="tx-td-col-title">پشتیبانی و ارتباط با ما</h4>
                <ul class="tx-td-contact-list">
                    <li>
                        <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                        <a dir="ltr" href="tel:+989120983462">۰۹۱۲۰۹۸۳۴۶۲</a>
                    </li>
                    <li>
                        <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                        <a dir="ltr" href="tel:+989026665822">۰۹۰۲۶۶۶۵۸۲۲</a>
                    </li>
                    <li>
                        <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                        <a dir="ltr" href="tel:+982156281778">۰۲۱۵۶۲۸۱۷۷۸</a>
                    </li>
                    <li>
                        <span class="tx-td-ic"><svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg></span>
                        <a dir="ltr" href="mailto:info@viptaxiiran.com">info@viptaxiiran.com</a>
                    </li>
                </ul>

                <a class="tx-td-cta" href="https://wa.me/989120983462" target="_blank" rel="noopener">
                    <span class="tx-td-cta-inner">
                        <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        ارتباط با پشتیبانی
                    </span>
                </a>
            </div>

        </div>

        <!-- خبرنامه -->
        <div class="tx-td-newsletter">
            <span class="tx-td-corner tx-td-corner--tl"></span>
            <span class="tx-td-corner tx-td-corner--br"></span>
            <div class="tx-td-newsletter-info">
                <h4>از تخفیف‌ها و مسیرهای ویژه باخبر شوید</h4>
                <p>عضویت در خبرنامه وی‌آی‌پی تاکسی ایران و دریافت جدیدترین پیشنهادها و تخفیف‌ها</p>
            </div>
            <div class="tx-td-newsletter-form">
                <input type="email" class="tx-td-newsletter-input" placeholder="آدرس ایمیل خود را وارد کنید" required>
                <button type="button" class="tx-td-newsletter-btn">عضویت</button>
            </div>
        </div>

        <!-- اعتماد -->
        <div class="tx-td-trust">
            <div class="tx-td-trust-item">
                <span class="tx-td-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M12 2l8 4v6c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10V6l8-4z" stroke-linejoin="round"/></svg></span>
                <span>سفر امن و بیمه‌شده</span>
            </div>
            <div class="tx-td-trust-item">
                <span class="tx-td-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg></span>
                <span>پرداخت مطمئن</span>
            </div>
            <div class="tx-td-trust-item">
                <span class="tx-td-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M4 13v-1a8 8 0 0116 0v1" stroke-linecap="round"/><rect x="2" y="13" width="4" height="6" rx="2" fill="currentColor" stroke="none"/><rect x="18" y="13" width="4" height="6" rx="2" fill="currentColor" stroke="none"/></svg></span>
                <span>پشتیبانی سریع</span>
            </div>
            <div class="tx-td-trust-item">
                <span class="tx-td-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M6 17c0-6 12-2 12-8" stroke-linecap="round"/></svg></span>
                <span>مسیرهای متنوع</span>
            </div>
        </div>

        <!-- جداکننده و پایین -->
        <div class="tx-td-divider"></div>

        <div class="tx-td-bottom">
            <div class="tx-td-copyright">
                <span class="tx-td-copyright-en">Copyright &copy; {{ \Illuminate\Support\Facades\Date::now()->format('Y') }} VIP TAXI IRAN</span>
                <span class="tx-td-copyright-fa">تمامی حقوق این وب‌سایت متعلق به وی‌آی‌پی تاکسی ایران است.</span>
            </div>

            <div class="tx-td-bottom-end">
                <!-- مجوزهای رسمی: نسخه کوچک و جمع‌وجور -->
                <div class="tx-td-license-mini">
                    <a href="https://trustseal.enamad.ir/?id=446726&amp;Code=wM8fFIjlRjVLA4pJztmZoW6GeOe2iYsC" target="_blank" rel="noopener" class="tx-td-license-mini-item" title="نماد اعتماد الکترونیکی">
                        <img src="https://trustseal.enamad.ir/logo.aspx?id=446726&amp;Code=wM8fFIjlRjVLA4pJztmZoW6GeOe2iYsC" alt="نماد اعتماد الکترونیکی" loading="lazy" decoding="async" />
                    </a>
                    <a href="https://eanjoman.ir/member/9XwoamnQ1AEHBAOBdjwQvguPd" target="_blank" rel="noopener" class="tx-td-license-mini-item" title="عضو انجمن کسب‌وکار آنلاین">
                        <img src="https://eanjoman.ir/api/script?code=9XwoamnQ1AEHBAOBdjwQvguPd" alt="عضو انجمن کسب‌وکار آنلاین" loading="lazy" decoding="async" />
                    </a>
                </div>

                <span class="tx-td-bottom-sep" aria-hidden="true"></span>

                <div class="tx-td-bottom-links">
                    <a href="#">حریم خصوصی</a>
                    <a href="#">قوانین و مقررات</a>
                </div>
            </div>
        </div>

    </div>
</footer>

<style>
@property --idg-angle{
  syntax:'<angle>';
  inherits:false;
  initial-value:0deg;
}

.tx-td-footer{
  --idg-blue:#3d8bff;
  --idg-blue-soft:#5aa0ff;
  --idg-purple:#9b6bff;
  --idg-bg-1:#050810;
  --idg-text:#e7ebf5;
  --idg-text-muted:#8892a8;
  --idg-text-dim:#5c6478;
  --idg-border:rgba(255,255,255,0.08);
  --idg-border-strong:rgba(255,255,255,0.16);
  --idg-glass:rgba(255,255,255,0.035);
  --idg-angle:0deg;

  position:relative;
  isolation:isolate;
  overflow:hidden;
  background:radial-gradient(120% 100% at 50% 0%, #0a1024 0%, var(--idg-bg-1) 45%, #030509 100%);
  font-family:'Vazirmatn','Segoe UI',Tahoma,sans-serif;
  color:var(--idg-text);
  direction:rtl;
}
.tx-td-footer *{ box-sizing:border-box; }
.tx-td-footer svg{ display:block; flex-shrink:0; }

/* ---------- پس‌زمینه ---------- */
.tx-td-bg{ position:absolute; inset:0; z-index:0; pointer-events:none; overflow:hidden; }

.tx-td-grid{
  position:absolute; inset:-1px;
  background-image:
    linear-gradient(rgba(120,150,255,0.045) 1px, transparent 1px),
    linear-gradient(90deg, rgba(120,150,255,0.045) 1px, transparent 1px);
  background-size:42px 42px;
  -webkit-mask-image:radial-gradient(80% 70% at 50% 20%, #000 0%, transparent 78%);
  mask-image:radial-gradient(80% 70% at 50% 20%, #000 0%, transparent 78%);
}

.tx-td-circuit{ position:absolute; inset:0; width:100%; height:100%; opacity:0.9; }
.tx-td-trace{
  fill:none;
  stroke:url(#tx-td-line-grad);
  stroke-width:1.2;
  stroke-opacity:0.22;
}
.tx-td-trace--sub{ stroke-opacity:0.14; }
.tx-td-pulse{ fill:var(--idg-blue-soft); filter:drop-shadow(0 0 5px var(--idg-blue-soft)); }
.tx-td-pulse--1{ offset-path:path("M-20,90 L180,90 L220,50 L460,50 L500,90 L760,90 L800,50 L1080,50 L1120,90 L1300,90"); animation:tx-td-travel 7s linear infinite; }
.tx-td-pulse--2{ offset-path:path("M-20,230 L140,230 L140,190 L360,190 L400,230 L680,230 L720,190 L960,190 L1000,230 L1300,230"); animation:tx-td-travel 9s linear infinite; animation-delay:1.4s; fill:var(--idg-purple); filter:drop-shadow(0 0 5px var(--idg-purple)); }
.tx-td-pulse--3{ offset-path:path("M-20,340 L260,340 L300,380 L620,380 L660,340 L940,340 L980,380 L1300,380"); animation:tx-td-travel 11s linear infinite; animation-delay:3.2s; }
@keyframes tx-td-travel{
  0%{ offset-distance:0%; opacity:0; }
  6%{ opacity:1; }
  94%{ opacity:1; }
  100%{ offset-distance:100%; opacity:0; }
}

.tx-td-glow{ position:absolute; border-radius:50%; filter:blur(75px); opacity:0.32; animation:tx-td-pulse-glow 9s ease-in-out infinite; }
.tx-td-glow--top{ width:520px; height:220px; top:-150px; right:8%; background:radial-gradient(closest-side, var(--idg-blue), transparent 70%); }
.tx-td-glow--bottom{ width:460px; height:220px; bottom:-170px; left:6%; background:radial-gradient(closest-side, var(--idg-purple), transparent 70%); animation-delay:3s; }
@keyframes tx-td-pulse-glow{ 0%,100%{ opacity:0.26; transform:scale(1); } 50%{ opacity:0.4; transform:scale(1.07); } }

.tx-td-horizon{
  position:absolute; top:0; right:0; left:0; height:1px;
  background:linear-gradient(90deg, transparent 0%, var(--idg-purple) 20%, var(--idg-blue) 50%, var(--idg-purple) 80%, transparent 100%);
  opacity:0.55; box-shadow:0 0 16px 1px rgba(90,150,255,0.5);
}

/* ---------- کانتینر ---------- */
.tx-td-container{ position:relative; z-index:1; max-width:1240px; margin:0 auto; padding:28px 32px 24px; }

/* ---------- نوار تماس ---------- */
.tx-td-topbar{
  display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:14px;
  padding:14px 22px; margin-bottom:38px;
  background:var(--idg-glass); border:1px solid var(--idg-border); border-radius:14px;
  backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px);
}
.tx-td-topbar-item{
  display:flex; align-items:center; gap:9px; color:var(--idg-text-muted); text-decoration:none;
  font-size:13.5px; font-weight:500; padding:6px 14px; border-radius:999px; white-space:nowrap;
  transition:color .25s ease, background .25s ease;
}
.tx-td-topbar-item:not(.tx-td-topbar-item--static):hover{ color:var(--idg-text); background:rgba(255,255,255,0.045); }
.tx-td-topbar-item--static{ cursor:default; }
.tx-td-topbar .tx-td-ic{
  display:inline-flex; align-items:center; justify-content:center; width:26px; height:26px; border-radius:50%;
  background:linear-gradient(135deg, rgba(61,139,255,0.18), rgba(155,107,255,0.18)); color:var(--idg-blue-soft); font-size:11.5px; flex-shrink:0;
}

/* ---------- ستون‌ها ---------- */
.tx-td-main{ display:grid; grid-template-columns:1.5fr 1fr 1fr 1.2fr; gap:36px; padding-bottom:36px; position:relative; }
.tx-td-main > .tx-td-col:not(:last-child)::after{
  content:""; position:absolute; top:4px; bottom:4px; width:1px;
  background:linear-gradient(180deg, transparent, var(--idg-border) 20%, var(--idg-border) 80%, transparent);
}

.tx-td-status{
  display:inline-flex; align-items:center; gap:8px; font-size:12px; font-weight:600;
  color:var(--idg-text-dim); margin-bottom:14px;
}
.tx-td-status-dot{
  width:7px; height:7px; border-radius:50%; background:#4ade80;
  box-shadow:0 0 0 0 rgba(74,222,128,0.6);
  animation:tx-td-status-ping 2.2s ease-out infinite;
}
@keyframes tx-td-status-ping{
  0%{ box-shadow:0 0 0 0 rgba(74,222,128,0.55); }
  70%{ box-shadow:0 0 0 7px rgba(74,222,128,0); }
  100%{ box-shadow:0 0 0 0 rgba(74,222,128,0); }
}

.tx-td-brand-title{
  display:flex; align-items:baseline; gap:10px; font-size:22px; font-weight:800; margin:0 0 14px;
  background:linear-gradient(100deg, #fff 20%, var(--idg-blue-soft) 45%, #fff 60%, var(--idg-purple) 80%);
  background-size:250% auto;
  -webkit-background-clip:text; background-clip:text; color:transparent;
  animation:tx-td-shimmer 7s ease-in-out infinite;
}
@keyframes tx-td-shimmer{ 0%,100%{ background-position:0% 50%; } 50%{ background-position:100% 50%; } }
.tx-td-brand-en{ font-size:10.5px; font-weight:600; letter-spacing:2.5px; color:var(--idg-text-dim); -webkit-text-fill-color:var(--idg-text-dim); direction:ltr; }

.tx-td-text{ font-size:13.5px; line-height:2; color:var(--idg-text-muted); margin:0 0 20px; max-width:340px; }

.tx-td-socials{ display:flex; gap:10px; }
.tx-td-social-btn{
  display:flex; align-items:center; justify-content:center; width:38px; height:38px; border-radius:11px;
  background:var(--idg-glass); border:1px solid var(--idg-border); color:var(--idg-text-muted); font-size:14px;
  text-decoration:none; backdrop-filter:blur(8px);
  transition:transform .25s ease, color .25s ease, border-color .25s ease, box-shadow .25s ease;
}
.tx-td-social-btn:hover{ color:#fff; border-color:var(--idg-border-strong); transform:translateY(-2px); box-shadow:0 6px 18px -6px rgba(61,139,255,0.5); }

.tx-td-col-title{ font-size:14.5px; font-weight:700; color:var(--idg-text); margin:0 0 18px; position:relative; padding-bottom:10px; }
.tx-td-col-title::after{ content:""; position:absolute; right:0; bottom:0; width:26px; height:2px; border-radius:2px; background:linear-gradient(90deg, var(--idg-blue), var(--idg-purple)); }

.tx-td-links{ list-style:none; margin:0; padding:0; }
.tx-td-links li{ margin-bottom:11px; }
.tx-td-links a,
.tx-td-static-item{ display:flex; align-items:center; gap:7px; color:var(--idg-text-muted); text-decoration:none; font-size:13.3px; transition:color .2s ease, transform .2s ease; }
.tx-td-links a .tx-td-arrow{ color:var(--idg-blue-soft); opacity:0; transform:translateX(-4px); transition:opacity .2s ease, transform .2s ease; flex-shrink:0; }
.tx-td-links a:hover{ color:var(--idg-text); transform:translateX(-2px); }
.tx-td-links a:hover .tx-td-arrow{ opacity:1; transform:translateX(0); }

.tx-td-contact-list{ list-style:none; margin:0 0 20px; padding:0; }
.tx-td-contact-list li{ display:flex; align-items:center; gap:10px; margin-bottom:13px; }
.tx-td-contact-list a{ color:var(--idg-text-muted); text-decoration:none; font-size:13.3px; transition:color .2s ease; direction:ltr; unicode-bidi:plaintext; }
.tx-td-contact-list a:hover{ color:var(--idg-text); }
.tx-td-contact-list .tx-td-ic{
  display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; border-radius:9px;
  background:var(--idg-glass); border:1px solid var(--idg-border); color:var(--idg-blue-soft); font-size:12px; flex-shrink:0;
}

/* ---------- CTA با بوردر گرادیانی چرخان (سیگنیچر) ---------- */
.tx-td-cta{
  --idg-angle:0deg;
  display:block; width:100%; padding:2px; border-radius:13px; text-decoration:none;
  background:conic-gradient(from var(--idg-angle), var(--idg-blue), var(--idg-purple), var(--idg-blue-soft), var(--idg-purple), var(--idg-blue));
  animation:tx-td-rotate-border 4.5s linear infinite;
  box-shadow:0 10px 28px -10px rgba(61,139,255,0.5);
}
@keyframes tx-td-rotate-border{ to{ --idg-angle:360deg; } }
.tx-td-cta-inner{
  display:flex; align-items:center; justify-content:center; gap:9px;
  padding:12px 18px; border-radius:11px; background:#0a0f1e; color:#fff; font-size:13.8px; font-weight:700;
  transition:background .25s ease;
}
.tx-td-cta:hover .tx-td-cta-inner{ background:linear-gradient(90deg, rgba(61,139,255,0.28), rgba(155,107,255,0.28)); }
.tx-td-cta-inner svg{ flex-shrink:0; }

/* ---------- خبرنامه با گوشه‌های HUD ---------- */
.tx-td-newsletter{
  position:relative;
  display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:20px;
  padding:26px 30px; margin-bottom:30px; border-radius:18px;
  background:linear-gradient(135deg, rgba(61,139,255,0.06), rgba(155,107,255,0.05));
  border:1px solid var(--idg-border);
  backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px);
}
.tx-td-corner{ position:absolute; width:18px; height:18px; opacity:0.6; }
.tx-td-corner--tl{ top:10px; right:10px; border-top:1.5px solid var(--idg-blue-soft); border-right:1.5px solid var(--idg-blue-soft); border-radius:3px 0 0 0; }
.tx-td-corner--br{ bottom:10px; left:10px; border-bottom:1.5px solid var(--idg-purple); border-left:1.5px solid var(--idg-purple); border-radius:0 0 0 3px; }

.tx-td-newsletter-info h4{ font-size:16px; font-weight:700; margin:0 0 6px; color:var(--idg-text); }
.tx-td-newsletter-info p{ font-size:13px; color:var(--idg-text-muted); margin:0; }
.tx-td-newsletter-form{ display:flex; gap:10px; flex:1; max-width:420px; min-width:260px; }
.tx-td-newsletter-input{
  flex:1; padding:12px 16px; border-radius:10px; border:1px solid var(--idg-border-strong);
  background:rgba(255,255,255,0.04); color:var(--idg-text); font-family:inherit; font-size:13px; outline:none;
  transition:border-color .2s ease, background .2s ease;
}
.tx-td-newsletter-input::placeholder{ color:var(--idg-text-dim); }
.tx-td-newsletter-input:focus{ border-color:var(--idg-blue-soft); background:rgba(255,255,255,0.06); }
.tx-td-newsletter-btn{
  padding:12px 22px; border:none; border-radius:10px; background:linear-gradient(90deg, var(--idg-blue), var(--idg-purple));
  color:#fff; font-family:inherit; font-size:13px; font-weight:700; cursor:pointer; white-space:nowrap;
  transition:transform .2s ease, filter .2s ease;
}
.tx-td-newsletter-btn:hover{ transform:translateY(-2px); filter:brightness(1.08); }

/* ---------- اعتماد ---------- */
.tx-td-trust{ display:grid; grid-template-columns:repeat(4, 1fr); gap:14px; margin-bottom:24px; }
.tx-td-trust-item{
  display:flex; align-items:center; gap:11px; padding:14px 16px; border-radius:12px;
  background:var(--idg-glass); border:1px solid var(--idg-border); backdrop-filter:blur(10px);
  transition:transform .2s ease, border-color .2s ease, box-shadow .2s ease;
}
.tx-td-trust-item:hover{ transform:translateY(-2px); border-color:var(--idg-border-strong); box-shadow:0 8px 20px -10px rgba(61,139,255,0.4); }
.tx-td-trust-ic{
  display:flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:9px; flex-shrink:0;
  background:linear-gradient(135deg, rgba(61,139,255,0.16), rgba(155,107,255,0.16)); color:var(--idg-blue-soft); font-size:14px;
}
.tx-td-trust-item span:last-child{ font-size:12.5px; font-weight:600; color:var(--idg-text-muted); }

.tx-td-bottom-end{ display:flex; align-items:center; gap:16px; flex-wrap:wrap; }

.tx-td-license-mini{ display:flex; align-items:center; gap:8px; }
.tx-td-license-mini-item{
  display:flex; align-items:center; justify-content:center;
  width:34px; height:34px; border-radius:8px;
  background:var(--idg-glass); border:1px solid var(--idg-border);
  overflow:hidden; transition:border-color .2s ease, transform .2s ease;
}
.tx-td-license-mini-item:hover{ border-color:var(--idg-border-strong); transform:translateY(-1px); }
.tx-td-license-mini-item img{ width:100%; height:100%; object-fit:contain; padding:4px; opacity:.9; }
.tx-td-license-mini-item:hover img{ opacity:1; }

.tx-td-bottom-sep{ width:1px; height:20px; background:var(--idg-border-strong); }

/* ---------- جداکننده و پایین ---------- */
.tx-td-divider{ height:1px; background:linear-gradient(90deg, transparent, var(--idg-border-strong) 50%, transparent); margin-bottom:18px; }
.tx-td-bottom{ display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; padding-bottom:6px; }
.tx-td-copyright{ display:flex; flex-direction:column; gap:3px; }
.tx-td-copyright-en{ font-size:12px; letter-spacing:0.5px; color:var(--idg-text-dim); direction:ltr; text-align:right; }
.tx-td-copyright-fa{ font-size:12px; color:var(--idg-text-dim); }
.tx-td-bottom-links{ display:flex; gap:18px; }
.tx-td-bottom-links a{ font-size:12.5px; color:var(--idg-text-muted); text-decoration:none; transition:color .2s ease; }
.tx-td-bottom-links a:hover{ color:var(--idg-text); }

/* =========================================================
   ریسپانسیو
========================================================= */
@media (max-width:1024px){
  .tx-td-main{ grid-template-columns:1fr 1fr; row-gap:32px; }
  .tx-td-col--brand{ grid-column:1 / -1; }
  .tx-td-main > .tx-td-col:not(:last-child)::after{ display:none; }
  .tx-td-text{ max-width:520px; }
}

@media (max-width:640px){
  .tx-td-container{ padding:22px 16px 18px; }
  .tx-td-topbar{ flex-direction:column; align-items:stretch; gap:8px; padding:14px; }
  .tx-td-topbar-item{ justify-content:flex-start; background:rgba(255,255,255,0.03); border:1px solid var(--idg-border); border-radius:10px; padding:10px 12px; }
  .tx-td-main{ grid-template-columns:1fr; gap:28px; }
  .tx-td-newsletter{ flex-direction:column; align-items:stretch; padding:22px; }
  .tx-td-newsletter-form{ max-width:100%; }
  .tx-td-trust{ grid-template-columns:1fr 1fr; }
  .tx-td-bottom{ flex-direction:column; align-items:flex-start; }
  .tx-td-bottom-end{ width:100%; justify-content:space-between; }
}
@media (max-width:380px){
  .tx-td-trust{ grid-template-columns:1fr; }
  .tx-td-newsletter-form{ flex-direction:column; }
}
@media (prefers-reduced-motion:reduce){
  .tx-td-footer *{ animation-duration:0.001ms !important; animation-iteration-count:1 !important; }
}
</style>

<svg width="0" height="0" style="position:absolute">
    <defs>
        <linearGradient id="tx-td-line-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#3d8bff"/>
            <stop offset="50%" stop-color="#9b6bff"/>
            <stop offset="100%" stop-color="#3d8bff"/>
        </linearGradient>
    </defs>
</svg>
