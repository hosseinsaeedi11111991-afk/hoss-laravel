@extends('Shared::layouts.site.main')
@section('title', 'رزرو سفر')
@php
    use Modules\Cars\Models\Car;

@endphp

@section('css')
    <!-- Persian Datepicker CSS from CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css" />
    <!-- jQuery Timepicker CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css" />
    <!-- Font Awesome from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* همسان‌سازی با تمپلیت اصلی */
        .reservation-page {
            font-family: 'peyda', sans-serif;
            background: #f2f2f2;
            min-height: 100vh;
            padding: 20px 0;
        }
        .shadow-black{
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5) !important;
        }
        .month-grid-box .header{
            height: 1px!important;
        }
        #reservationDate, #reservationTime{
            border-radius: 30px!important;
        }
        .main-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            border: none;
            margin: 30px auto;
            max-width: 1200px;
        }

        .header-section {
            background: linear-gradient(135deg, #f5b754 0%, #e0a543 100%);
            color: #1b1b1b;
            padding: 40px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .header-section h1 {
            font-size: 35px;
            font-weight: 700;
            color: #1b1b1b;
            position: relative;
            z-index: 1;
            margin-bottom: 10px;
        }

        .header-section p {
            color: #1b1b1b;
            font-size: 14px;
            font-weight: 300;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }

        .trip-info {
            background: white;
            border: none;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
        }

        .trip-info .text-center {
            padding: 15px;
        }

        .trip-info .text-center i {
            color: #f5b754;
            margin-bottom: 10px;
        }

        .trip-info h6 {
            color: #1b1b1b;
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .trip-info .fw-bold {
            color: #555;
            font-weight: 300;
            font-size: 14px;
        }

        .car-card {
            border: 1px solid #f0f0f0;
            border-radius: 20px;
            padding: 0;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
            overflow: hidden;
            height: 100%;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            position: relative;
        }

        .car-card:hover {
            border-color: #f5b754;
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.2);
            transform: translateY(-5px);
        }

        .car-card.selected {
            border-color: #f5b754;
            background: rgba(245, 183, 84, 0.05);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.3);
        }

        .car-check-icon {
            position: absolute;
            top: 15px;
            left: 15px;
            background: #f5b754;
            color: #1b1b1b;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            z-index: 10;
            box-shadow: 0 4px 10px rgba(245, 183, 84, 0.4);
        }

        .car-card.selected .car-check-icon {
            display: flex;
        }

        .final-price-badge {
            display: inline-block;
            background: #f5b754;
            color: #1b1b1b;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 16px;
            margin-right: 15px;
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
        }

        .car-image {
            width: 100%;
            height: 160px;
            overflow: hidden;
            position: relative;
            background: #f2f2f2;
        }

        .car-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .car-card:hover .car-image img {
            transform: scale(1.1);
        }

        .car-info {
            padding: 20px;
        }

        .car-name {
            font-weight: 700;
            color: #1b1b1b;
            margin-bottom: 12px;
            font-size: 17px;
        }

        .car-specs {
            margin-bottom: 15px;
        }

        .spec {
            background: #f2f2f2;
            color: #555;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            margin: 3px;
            display: inline-block;
            font-weight: 300;
        }

        .spec i {
            padding: 0 0 0 8px;
            color: #f5b754;
        }

        .car-price {
            font-weight: 700;
            color: #999;
            font-size: 16px;
            text-align: left;
            padding: 8px 0;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }

        .car-card.selected .car-price {
            color: #dc3545;
        }

        .car-select-btn {
            width: 100%;
            background: #999;
            border: 1px solid #999;
            border-radius: 20px;
            padding: 12px;
            font-weight: 700;
            font-size: 14px;
            color: #fff;
            transition: all 0.3s ease;
            cursor: pointer;
            margin-top: 10px;
        }

        .car-select-btn:hover {
            background: #888;
            border-color: #888;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .car-card.selected .car-select-btn {
            background: #f5b754;
            border-color: #f5b754;
            color: #1b1b1b;
        }

        .car-card.selected .car-select-btn:hover {
            background: #e0a543;
            border-color: #e0a543;
        }

        .form-control, .form-select, textarea.form-control {

            border-radius: 30px;
            border: 1px solid #f0f0f0;
            padding: 18.5px 20px;
            transition: all 0.3s ease;
            background: white;
            font-size: 14px;
            font-weight: 300;
            color: #555;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5) !important;
            font-family: 'peyda', sans-serif;
        }

        textarea.form-control {
            border-radius: 20px;
            resize: vertical;
            min-height: 100px;
        }

        .form-control:focus, .form-select:focus, textarea.form-control:focus {
            border: 1px solid #f5b754;
            box-shadow: 0 4px 20px rgba(245, 183, 84, 0.2);
            background: white;
            outline: none;
        }

        .form-control::placeholder {
            color: #555;
            font-family: 'peyda', sans-serif;
            font-size: 14px;
            font-weight: 300;
        }

        .form-label {
            color: #1b1b1b;
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .btn-primary, .button-1 {
            background: #f5b754;
            border: 1px solid #f5b754;
            border-radius: 30px;
            padding: 14px 42px;
            font-weight: 300;
            font-size: 14px;
            color: #1b1b1b;
            transition: all 0.3s ease;
            font-family: 'peyda', sans-serif;
            text-transform: none;
        }

        .btn-primary:hover, .button-1:hover {
            background: #1b1b1b;
            border-color: #1b1b1b;
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(27, 27, 27, 0.3);
        }

        .btn-outline-info {
            border-radius: 30px;
            border: 1px solid #f5b754;
            color: #1b1b1b;
            background: #f5b754;
            font-weight: 300;
            padding: 14px 42px;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: 'peyda', sans-serif;
        }

        .btn-outline-info:hover {
            background: #1b1b1b;
            border-color: #1b1b1b;
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(27, 27, 27, 0.3);
        }

        .section-title {
            color: #1b1b1b;
            font-weight: 700;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f5b754;
            font-size: 21px;
        }

        .section-title i {
            color: #f5b754;
            margin-left: 10px;
        }

        .rules-section {
            background: white;
            border: none;
            border-radius: 20px;
            padding: 40px;
            margin-top: 30px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
        }

        .rules-section h6 {
            color: #1b1b1b;
            font-weight: 700;
            font-size: 17px;
            margin-bottom: 15px;
        }

        .rules-section h6 i {
            margin-left: 8px;
        }

        .rules-section ul {
            list-style: none;
            padding: 0;
        }

        .rules-section ul li {
            color: #555;
            font-size: 14px;
            font-weight: 300;
            line-height: 2em;
            padding-right: 20px;
            position: relative;
        }

        .rules-section ul li::before {
            content: '•';
            color: #f5b754;
            font-weight: bold;
            position: absolute;
            right: 0;
        }

        .form-check-input:checked {
            background-color: #f5b754;
            border-color: #f5b754;
        }

        .form-check-input {
            border: 1px solid #f0f0f0;
            border-radius: 4px;
        }

        .form-check-label {
            font-weight: 300;
            color: #555;
            font-size: 14px;
        }

        .final-price-display {
            background: #f5b754;
            color: #1b1b1b;
            padding: 20px;
            border-radius: 20px;
            text-align: center;
            margin-top: 15px;
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
        }

        .main-price {
            font-size: 21px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #1b1b1b;
        }

        .price-note {
            font-size: 12px;
            opacity: 0.8;
            font-weight: 300;
            color: #1b1b1b;
        }

        /* option buttons */
        .opt-btn {
            border-radius: 30px;
            padding: 12px 20px;
            transition: all 0.3s ease;
            font-family: 'peyda', sans-serif;
            font-size: 14px;
            font-weight: 300;
        }

        .btn-check:checked + .opt-btn {
            background: #f5b754;
            color: #1b1b1b;
            border-color: #f5b754;
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.3);
            transform: translateY(-2px);
        }

        .btn-check:not(:checked) + .opt-btn {
            background: #fff;
            color: #1b1b1b;
            border-color: #f5b754;
        }

        .btn-check:not(:checked) + .opt-btn:hover {
            background: rgba(245, 183, 84, 0.1);
        }

        .btn-check:focus + .opt-btn,
        .opt-btn:focus {
            box-shadow: 0 0 0 0.2rem rgba(245, 183, 84, 0.25);
        }

        /* Input group styling */
        .input-group {
            position: relative;
            display: flex;
            align-items: stretch;
        }

        .input-group .form-control {
            border-radius: 30px 0 0 30px;
            border-left: 1px solid #f0f0f0;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #f0f0f0;
            border-right: none;
        }

        .input-group .form-control:focus {
            border-left: 1px solid #f5b754;
            border-top: 1px solid #f5b754;
            border-bottom: 1px solid #f5b754;
            border-right: none;
        }

        .input-group-append {
            display: flex;
        }

        .input-group-text {
            background: #f5b754;
            border: 1px solid #f5b754;
            border-radius: 0 30px 30px 0;
            color: #1b1b1b;
            padding: 18.5px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .input-group-text:hover {
            background: #e0a543;
            border-color: #e0a543;
        }

        .input-group-text i {
            color: #1b1b1b;
            font-size: 16px;
        }

        .date-picker-icon {
            min-width: 50px;
        }

        /* Persian Date Picker Custom Styles */
        .pdp-container {
            font-family: 'peyda', sans-serif !important;
            border-radius: 20px !important;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15) !important;
            border: 1px solid #f0f0f0 !important;
        }

        .pdp-header {
            background: #f5b754 !important;
            border-radius: 20px 20px 0 0 !important;
            color: #1b1b1b !important;
        }

        .pdp-header .pdp-year,
        .pdp-header .pdp-month {
            color: #1b1b1b !important;
            font-weight: 700 !important;
        }

        .pdp-header .pdp-nav {
            color: #1b1b1b !important;
        }

        .pdp-header .pdp-nav:hover {
            background: rgba(27, 27, 27, 0.1) !important;
        }

        .pdp-day {
            color: #555 !important;
            font-weight: 300 !important;
        }

        .pdp-day.pdp-selected {
            background: #f5b754 !important;
            color: #1b1b1b !important;
            font-weight: 700 !important;
            border-radius: 10px !important;
        }

        .pdp-day:hover {
            background: rgba(245, 183, 84, 0.2) !important;
            border-radius: 10px !important;
        }

        .pdp-day.pdp-today {
            border: 2px solid #f5b754 !important;
            border-radius: 10px !important;
        }

        .pdp-time {
            border-top: 1px solid #f0f0f0 !important;
        }

        .pdp-time input {
            border: 1px solid #f0f0f0 !important;
            border-radius: 10px !important;
            padding: 8px 12px !important;
            font-family: 'peyda', sans-serif !important;
        }

        .pdp-time input:focus {
            border-color: #f5b754 !important;
            outline: none !important;
        }

        /* Additional styling improvements */
        .container {
            max-width: 1200px;
        }

        .mb-4 {
            margin-bottom: 30px !important;
        }

        .mt-4 {
            margin-top: 30px !important;
        }

        /* Icon colors in trip info */
        .trip-info .fa-route {
            color: #f5b754;
        }

        .trip-info .fa-map-marker-alt {
            color: #f5b754;
        }

        .trip-info .fa-clock {
            color: #f5b754;
        }

        .trip-info .fa-money-bill-wave {
            color: #f5b754;
        }

        /* Text color improvements */
        .text-danger {
            color: #f5b754 !important;
        }

        .text-success {
            color: #f5b754 !important;
        }

        .text-warning {
            color: #f5b754 !important;
        }

        /* Accordion Styling */
        .accordion {
            border-radius: 15px;
            overflow: hidden;
        }

        .accordion-item {
            border: none;
            border-bottom: 1px solid #f0f0f0;
            background: transparent;
        }

        .accordion-item:last-child {
            border-bottom: none;
        }

        .accordion-button {
            background: white;
            color: #1b1b1b;
            font-weight: 700;
            font-size: 14px;
            padding: 20px 25px;
            border: none;
            box-shadow: none;
            font-family: 'peyda', sans-serif;
            transition: all 0.3s ease;
        }

        .accordion-button:not(.collapsed) {
            background: rgba(245, 183, 84, 0.1);
            color: #1b1b1b;
            box-shadow: none;
        }

        .accordion-button:hover {
            background: rgba(245, 183, 84, 0.05);
        }

        .accordion-button::after {
            background-image: none;
            content: '\f078';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            color: #f5b754;
            transform: rotate(0deg);
            transition: transform 0.3s ease;
        }

        .accordion-button:not(.collapsed)::after {
            transform: rotate(180deg);
        }

        .accordion-button:focus {
            box-shadow: none;
            border: none;
        }

        .accordion-body {
            padding: 20px 25px;
            background: white;
            font-family: 'peyda', sans-serif;
        }

        .accordion-body ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .accordion-body ul li {
            color: #555;
            font-size: 14px;
            font-weight: 300;
            line-height: 2em;
            padding-right: 20px;
            position: relative;
        }

        .accordion-body ul li::before {
            content: '•';
            color: #f5b754;
            font-weight: bold;
            position: absolute;
            right: 0;
        }

        /* Discount Card Styles */
        #discountsSection .card {
            transition: all 0.3s ease;
        }

        #discountsSection .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(245, 183, 84, 0.3);
        }

        #discountMessage {
            min-height: 20px;
        }

        /* Responsive improvements */
        @media (max-width: 768px) {
            .main-container {
                margin: 15px;
                border-radius: 15px;
            }

            .header-section {
                padding: 30px 20px;
            }

            .header-section h1 {
                font-size: 28px;
            }

            .trip-info, .rules-section {
                padding: 20px;
            }

            .car-card {
                margin-bottom: 15px;
            }

            .accordion-button {
                padding: 15px 20px;
                font-size: 13px;
            }

            .accordion-body {
                padding: 15px 20px;
            }
        }

        /* Preloader Styles */
        .reservation-preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            backdrop-filter: blur(5px);
        }

        .reservation-preloader.show {
            display: flex;
        }

        .preloader-content {
            background: white;
            border-radius: 20px;
            padding: 40px 50px;
            text-align: center;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 90%;
        }

        .preloader-spinner {
            width: 60px;
            height: 60px;
            border: 5px solid #f0f0f0;
            border-top-color: #f5b754;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .preloader-text {
            color: #1b1b1b;
            font-size: 16px;
            font-weight: 700;
            margin-top: 15px;
            font-family: 'peyda', sans-serif;
        }

        .preloader-subtext {
            color: #555;
            font-size: 14px;
            font-weight: 300;
            margin-top: 10px;
            font-family: 'peyda', sans-serif;
        }

        /* ================================================================
           بازطراحی ظاهری کامل صفحه رزرو — فقط CSS، هیچ id/onclick/JS دست‌نخورده
           ================================================================ */

        .reservation-page{
            background:radial-gradient(120% 100% at 50% 0%, #14140f 0%, #0a0f1e 55%, #050810 100%) !important;
            position:relative;
        }
        .reservation-page::before{
            content:""; position:fixed; inset:0; z-index:0; pointer-events:none;
            background-image:linear-gradient(rgba(255,215,0,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,215,0,0.035) 1px, transparent 1px);
            background-size:44px 44px;
            -webkit-mask-image:radial-gradient(70% 60% at 50% 10%, #000 0%, transparent 78%);
            mask-image:radial-gradient(70% 60% at 50% 10%, #000 0%, transparent 78%);
        }

        .main-container{
            background:linear-gradient(180deg, rgba(255,255,255,0.035), rgba(255,255,255,0.015)) !important;
            border:1px solid rgba(255,215,0,0.14) !important;
            box-shadow:0 30px 70px -30px rgba(0,0,0,0.7) !important;
            position:relative; z-index:1;
            backdrop-filter:blur(6px);
        }

        /* ---------- هدر ---------- */
        .header-section{
            background:linear-gradient(135deg, #1a1400 0%, #0a0f1e 60%, #14140f 100%) !important;
            color:#fff !important;
            border-bottom:1px solid rgba(255,215,0,0.18);
        }
        .header-section::before{
            background:radial-gradient(circle, rgba(255,215,0,0.18) 0%, transparent 70%) !important;
        }
        .header-section h1{
            color:#fff !important;
            background:linear-gradient(90deg,#fff 30%, #FFD700 55%, #fff 75%);
            background-size:220% auto;
            -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;
            animation:resv-shimmer 6s ease-in-out infinite;
        }
        .header-section h1 i{ -webkit-text-fill-color:#FFD700; color:#FFD700; }
        .header-section p{ color:rgba(255,255,255,0.7) !important; }
        @keyframes resv-shimmer{ 0%,100%{ background-position:0% 50%; } 50%{ background-position:100% 50%; } }

        /* ---------- کارت‌های اطلاعاتی ---------- */
        .trip-info, .rules-section{
            background:rgba(255,255,255,0.03) !important;
            border:1px solid rgba(255,255,255,0.09) !important;
            box-shadow:none !important;
        }
        .trip-info .text-center i{ color:#FFD700 !important; }
        .trip-info h6{ color:#fff !important; }
        .trip-info .fw-bold{ color:#a3abc0 !important; }
        .section-title{ color:#fff !important; }
        .section-title i{ color:#FFD700 !important; }
        .price-note{ color:#8892a8 !important; }
        .main-price{ color:#FFD700 !important; }

        /* ---------- کارت‌های انتخاب خودرو ---------- */
        .car-card{
            background:rgba(255,255,255,0.03) !important;
            border:1px solid rgba(255,255,255,0.1) !important;
            transition:transform .25s ease, border-color .25s ease, box-shadow .25s ease, background .25s ease;
        }
        .car-card:hover{
            transform:translateY(-4px);
            border-color:rgba(255,215,0,0.3) !important;
            box-shadow:0 16px 34px -16px rgba(0,0,0,0.6) !important;
        }
        .car-card.selected{
            background:linear-gradient(160deg, rgba(255,215,0,0.1), rgba(255,255,255,0.02)) !important;
            border-color:#FFD700 !important;
            box-shadow:0 0 0 1px rgba(255,215,0,0.3), 0 16px 34px -16px rgba(0,0,0,0.6) !important;
        }
        .car-name{ color:#fff !important; }
        .car-card p{ color:#a3abc0 !important; }
        .car-price{ color:#e7ebf5 !important; }
        .car-card.selected .car-price{ color:#FFD700 !important; }
        .spec{ color:#8892a8 !important; }
        .car-check-icon{
            background:rgba(255,255,255,0.08) !important; color:#fff !important;
        }
        .car-card.selected .car-check-icon{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important; color:#1a1400 !important;
        }
        .car-select-btn{
            background:rgba(255,255,255,0.06) !important;
            border:1px solid rgba(255,255,255,0.16) !important;
            color:#e7ebf5 !important;
        }
        .car-card.selected .car-select-btn{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important;
            border-color:transparent !important;
            color:#1a1400 !important;
        }
        .car-card.selected .car-select-btn:hover{
            background:linear-gradient(135deg,#FFA500,#FFD700) !important;
        }

        /* ---------- فرم‌ها ---------- */
        .form-label{ color:#d7dbe4 !important; }
        .form-control, .form-select, textarea.form-control{
            background:rgba(255,255,255,0.04) !important;
            border:1px solid rgba(255,255,255,0.14) !important;
            color:#f2f4f8 !important;
            box-shadow:none !important;
        }
        .form-control::placeholder{ color:#6b7280 !important; }
        .form-control:focus, .form-select:focus{
            border-color:#FFD700 !important;
            box-shadow:0 0 0 3px rgba(255,215,0,0.15) !important;
            background:rgba(255,255,255,0.06) !important;
        }
        .form-select option{ background:#0a0f1e; color:#f2f4f8; }
        .input-group-text{
            background:rgba(255,255,255,0.06) !important;
            border:1px solid rgba(255,255,255,0.14) !important;
            color:#FFD700 !important;
        }
        .date-picker-icon{ color:#FFD700 !important; }
        .form-check-input{
            background:rgba(255,255,255,0.06) !important;
            border:1px solid rgba(255,255,255,0.22) !important;
        }
        .form-check-input:checked{
            background-color:#FFD700 !important;
            border-color:#FFD700 !important;
        }
        .form-check-label{ color:#d7dbe4 !important; }

        /* ---------- دکمه‌های گزینه‌های اضافی ---------- */
        .opt-btn{
            background:rgba(255,255,255,0.04) !important;
            border:1px solid rgba(255,255,255,0.14) !important;
            color:#e7ebf5 !important;
        }
        .btn-check:checked + .opt-btn{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important;
            border-color:transparent !important;
            color:#1a1400 !important;
        }
        .btn-check:not(:checked) + .opt-btn:hover{
            border-color:rgba(255,215,0,0.4) !important;
            background:rgba(255,255,255,0.07) !important;
        }

        /* ---------- تقویم شمسی (Persian Datepicker) ---------- */
        .pdp-container{
            background:#0d1220 !important;
            border:1px solid rgba(255,215,0,0.2) !important;
            box-shadow:0 20px 50px -18px rgba(0,0,0,0.7) !important;
        }
        .pdp-header{ background:#0a0f1e !important; }
        .pdp-header .pdp-year, .pdp-header .pdp-month{ color:#fff !important; }
        .pdp-header .pdp-nav{ color:#FFD700 !important; }
        .pdp-header .pdp-nav:hover{ background:rgba(255,215,0,0.12) !important; }
        .pdp-day{ color:#d7dbe4 !important; }
        .pdp-day:hover{ background:rgba(255,215,0,0.12) !important; }
        .pdp-day.pdp-today{ border:1px solid #FFD700 !important; color:#FFD700 !important; }
        .pdp-day.pdp-selected{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important;
            color:#1a1400 !important;
        }
        .pdp-time{ color:#d7dbe4 !important; }

        /* ---------- آکاردئون قوانین (Bootstrap استاندارد) ---------- */
        .accordion-item{
            background:rgba(255,255,255,0.03) !important;
            border:1px solid rgba(255,255,255,0.09) !important;
        }
        .accordion-button{
            background:transparent !important;
            color:#e7ebf5 !important;
        }
        .accordion-button:not(.collapsed){
            background:rgba(255,215,0,0.06) !important;
            color:#FFD700 !important;
            box-shadow:none !important;
        }
        .accordion-button::after{ filter:invert(1) brightness(1.6); }
        .accordion-body{
            background:rgba(255,255,255,0.015) !important;
            color:#a3abc0 !important;
        }
        .accordion-body .small{ color:#a3abc0 !important; }

        /* ---------- دکمه‌ها ---------- */
        .btn-primary, .button-1{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important;
            border:none !important;
            color:#1a1400 !important;
            box-shadow:0 10px 26px -8px rgba(255,183,3,0.5) !important;
        }
        .btn-primary:hover, .button-1:hover{
            background:linear-gradient(135deg,#FFA500,#FFD700) !important;
            border-color:transparent !important;
            color:#1a1400 !important;
            box-shadow:0 14px 32px -8px rgba(255,183,3,0.6) !important;
        }
        .btn-outline-info{
            background:linear-gradient(135deg,#FFD700,#FFA500) !important;
            border:none !important;
            color:#1a1400 !important;
        }
        .final-price-badge{
            background:rgba(255,215,0,0.1) !important;
            border:1px solid rgba(255,215,0,0.3) !important;
            color:#FFD700 !important;
        }

        /* ---------- پیش‌لودر ---------- */
        .reservation-preloader{
            background:rgba(5,8,16,0.92) !important;
        }
        .preloader-text{ color:#fff !important; }
        .preloader-subtext{ color:#a3abc0 !important; }

        /* ---------- پیام‌های هشدار (وقتی رزروی وجود ندارد یا خطا رخ داده) ---------- */
        .alert{
            border-radius:14px !important;
            border:1px solid transparent !important;
        }
        .alert-danger{
            background:rgba(255,107,107,0.12) !important;
            border-color:rgba(255,107,107,0.35) !important;
            color:#ffb3b3 !important;
        }
        .alert-info{
            background:rgba(255,215,0,0.08) !important;
            border-color:rgba(255,215,0,0.3) !important;
            color:#f2e6b3 !important;
        }
        .alert-link{
            color:#FFD700 !important;
            font-weight:700;
        }
        .alert-link:hover{ color:#FFA500 !important; }

        /* ---------- کارت‌های تخفیف (تولیدشده توسط جاوااسکریپت) ---------- */
        #availableDiscounts .card{
            background:rgba(255,255,255,0.04) !important;
            border-color:rgba(255,215,0,0.3) !important;
            color:#e7ebf5 !important;
        }
        #discountInfo{ color:#a3abc0; }

        /* ---------- جعبه‌ی هزینه‌ی نهایی (قبلاً پس‌زمینه‌ی زرد توپر داشت) ---------- */
        .final-price-display{
            background:linear-gradient(135deg, rgba(255,215,0,0.14), rgba(255,165,0,0.08)) !important;
            border:1px solid rgba(255,215,0,0.35) !important;
            color:#FFD700 !important;
            box-shadow:0 8px 20px -8px rgba(255,183,3,0.25) !important;
        }
        .main-price{ color:#FFD700 !important; }
        .car-image{ background:#0d1220 !important; }

        /* ================================================================
           پالایش خوانایی و زیبایی — رنگ‌بندی بهتر، کادرهای شیک‌تر
           ================================================================ */

        /* سلسله‌مراتب درست‌شده: مقدار مهم‌تر از برچسب دیده بشه */
        .trip-info h6{ color:#9aa3b8 !important; font-size:12.5px !important; font-weight:600 !important; }
        .trip-info .fw-bold{ color:#fff !important; font-weight:700 !important; font-size:15px !important; }

        /* روشن‌تر کردن متن‌های کم‌رنگ برای خوانایی بهتر */
        .car-card p{ color:#b4bcc9 !important; }
        .spec{ color:#9aa3b8 !important; }
        .accordion-body, .accordion-body .small{ color:#b4bcc9 !important; }
        .form-label{ color:#e2e6ee !important; font-weight:600 !important; font-size:13.5px !important; }
        .price-note{ color:#9aa3b8 !important; }
        .car-price small{ color:#c7cddb !important; }

        /* کادرهای شیک‌تر با لبه‌ی گرادیانی ظریف بالا */
        .trip-info, .car-card, .rules-section{
            position:relative; border-radius:18px !important;
        }
        .trip-info::before, .rules-section::before{
            content:""; position:absolute; top:0; right:16px; left:16px; height:2px; border-radius:2px;
            background:linear-gradient(90deg, transparent, rgba(255,215,0,0.5), transparent);
        }

        /* فرم شیک‌تر: فیلدها با عمق و درخشش ملایم روی فوکوس */
        .form-control, .form-select, textarea.form-control{
            background:rgba(255,255,255,0.045) !important;
            border:1px solid rgba(255,255,255,0.16) !important;
            box-shadow:inset 0 1px 3px rgba(0,0,0,0.3) !important;
            font-weight:500 !important;
        }
        .form-control:focus, .form-select:focus{
            background:rgba(255,255,255,0.07) !important;
            box-shadow:inset 0 1px 3px rgba(0,0,0,0.2), 0 0 0 3px rgba(255,215,0,0.18) !important;
        }

        /* چک‌باکس‌های سفارشی و شیک */
        .form-check-input{
            width:20px !important; height:20px !important;
            background:rgba(255,255,255,0.06) !important;
            border:1.5px solid rgba(255,255,255,0.3) !important;
            cursor:pointer;
        }
        .form-check-input:checked{
            background-color:#FFD700 !important;
            border-color:#FFD700 !important;
            box-shadow:0 0 0 3px rgba(255,215,0,0.15) !important;
        }
        .form-check-label{ cursor:pointer; padding-right:4px; }

        /* آیکون کنار عنوان بخش‌ها داخل یه نشان دایره‌ای طلایی */
        .section-title{ display:flex; align-items:center; gap:10px; }
        .section-title i, .section-title svg{
            display:inline-flex; align-items:center; justify-content:center;
            width:34px; height:34px; border-radius:50%; flex-shrink:0;
            background:rgba(255,215,0,0.1); color:#FFD700 !important;
            padding:8px; box-sizing:border-box;
        }

        /* عمق بیشتر برای main-container */
        .main-container{
            box-shadow:0 40px 90px -35px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,215,0,0.06) inset !important;
        }

        @media (prefers-reduced-motion:reduce){
            .header-section h1{ animation:none; }
        }

    </style>
@endsection
@section('main')
    @php
        use Modules\Cars\Models\CarCategory;
    @endphp
    <div class="container reservation-page">
        <div class="main-container">
            <!-- Header -->
            <div class="header-section">
                <h1><svg class="me-3" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11h1a1 1 0 011 1v5a1 1 0 01-1 1h-1v1a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1H7v1a1 1 0 01-1 1H5a1 1 0 01-1-1v-1H3a1 1 0 01-1-1v-5a1 1 0 011-1h1z"/></svg>رزرو سفر</h1>
                <p class="mb-0">سفری راحت و ایمن را تجربه کنید</p>
            </div>

            <div class="p-4">
                <!-- Trip Information (only when reservation exists) -->
                @if($reservation)
                <div class="trip-info">
                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1" stroke-linecap="round" stroke-linejoin="round"/></svg>اطلاعات سفر</h4>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="text-center">
                                <svg class="mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="26" height="26"><circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M6 17c0-6 12-2 12-8" stroke-linecap="round"/></svg>
                                <h6>فاصله</h6>
                                <span class="fw-bold">{{ $reservation->distance_km }} کیلومتر</span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center">
                                <svg class="mb-2" viewBox="0 0 24 24" fill="currentColor" width="26" height="26"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                                <h6>مسیر</h6>
                                <span class="fw-bold">{{ $reservation->origin_address }}</span>
                                <br>
                                <span class="fw-bold">{{ $reservation->destination_address }}</span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center">
                                <svg class="mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="26" height="26"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                <h6>زمان تقریبی</h6>
                                <span class="fw-bold">{{ $reservation->time }} ساعت</span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center">
                                <svg class="mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" width="26" height="26"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.4"/></svg>
                                <h6>هزینه نهایی</h6>
                                <div class="final-price-display">
                                    <div class="main-price" id="finalPrice" data-base-price="{{ $priceQuote['amount'] ?? 0 }}" data-trip-distance="{{ $reservation->distance_km ?? 0 }}" data-price-source="{{ $priceQuote['source'] ?? '' }}" data-is-city-to-city="{{ $priceQuote['meta']['is_city_to_city'] ?? false ? 'true' : 'false' }}" data-has-car-category="{{ $priceQuote['meta']['has_car_category'] ?? false ? 'true' : 'false' }}" data-pricing-car-category-id="{{ $priceQuote['meta']['car_category_id'] ?? '' }}">
                                        @if($priceQuote)
                                            {{ number_format($priceQuote['amount']) }} تومان
                                        @else
                                            در انتظار محاسبه
                                        @endif
                                    </div>
                                    <div id="discountInfo" style="display: none; margin-top: 10px;">
                                        <div style="font-size: 14px; color: #28a745; margin-bottom: 5px;">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            <span id="discountTitle"></span>
                                            <span id="discountAmount" style="font-weight: 700;"></span>
                                        </div>
                                        <div style="font-size: 12px; color: #999; text-decoration: line-through;">
                                            قیمت اصلی: <span id="originalPrice"></span> تومان
                                        </div>
                                    </div>
                                    <div class="price-note">
                                        @if($priceQuote && $priceQuote['source'])
                                            منبع قیمت: {{ $priceQuote['source'] === 'pricing_rule' ? 'قانون مسیر' : ($priceQuote['source'] === 'city_pricing' ? 'تعرفه شهری' : 'نرخ پیش‌فرض') }}
                                        @else
                                            شامل تمام هزینه‌ها
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @else
                @if(session('error'))
                <div class="trip-info mb-4">
                    <div class="alert alert-danger mb-0">
                        <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M12 3l9 16H3z" stroke-linejoin="round"/><path d="M12 9v4M12 16h.01" stroke-linecap="round"/></svg>
                        {{ session('error') }}
                        <a href="{{ route('home') }}" class="alert-link me-2">برو به صفحه اصلی</a>
                    </div>
                </div>
                @endif
                <div class="trip-info mb-4">
                    <div class="alert alert-info mb-0">
                        <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        برای ثبت رزرو: روی نقشه <strong>مبدا</strong> و <strong>مقصد</strong> را انتخاب کنید، دکمه «محاسبه مسیرها» را بزنید، شماره موبایل را وارد کنید و ادامه دهید. سپس به این صفحه منتقل می‌شوید و اطلاعات سفر و قیمت نمایش داده می‌شود.
                        <br>
                        <a href="{{ route('home') }}" class="alert-link mt-2 d-inline-block">برو به صفحه اصلی (نقشه)</a>
                    </div>
                </div>
                <div class="final-price-display mb-4" style="display: none;">
                    <div class="main-price" id="finalPrice" data-base-price="0" data-trip-distance="0" data-price-source="" data-is-city-to-city="false" data-has-car-category="false" data-pricing-car-category-id=""></div>
                </div>
                @endif

                <!-- Available Discounts Section -->
{{--                <div class="mb-4" id="discountsSection" style="">--}}
{{--                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M20.59 13.41L13.42 20.58a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" stroke-linejoin="round"/><circle cx="7" cy="7" r="1.3" fill="currentColor" stroke="none"/></svg>تخفیف‌های موجود</h4>--}}
{{--                    <div id="availableDiscounts" class="row g-3">--}}
{{--                        <!-- تخفیف‌ها از API لود می‌شوند -->--}}
{{--                    </div>--}}
{{--                </div>--}}

                <!-- Car Category Selection -->
                <div class="mb-4">
                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11h1a1 1 0 011 1v5a1 1 0 01-1 1h-1v1a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1H7v1a1 1 0 01-1 1H5a1 1 0 01-1-1v-1H3a1 1 0 01-1-1v-5a1 1 0 011-1h1z"/></svg>انتخاب دسته‌بندی خودرو</h4>

                    <div class="row g-3">

                        @foreach($carCategories as $category)
                                <?php
                                $isFixed = $category->price_type == \Modules\Cars\Models\CarCategory::PRICE_TYPE_FIXED;
                                $isPerKm = $category->price_type == \Modules\Cars\Models\CarCategory::PRICE_TYPE_PER_KM;
                                $isNegotiable = $category->price_type == \Modules\Cars\Models\CarCategory::PRICE_TYPE_NEGOTIABLE;

                                $fixedPrice = $isFixed ? (float)$category->fixed_price : 0;
                                $perKmPrice = $isPerKm ? (float)$category->price_per_km : 0;

                                // برای نمایش قیمت
                                if ($isNegotiable) {
                                    $displayPrice = 0;
                                    $pricing_type = 'قیمت توافقی';
                                } elseif ($isFixed) {
                                    $displayPrice = explode('.', $fixedPrice)[0];
                                    $pricing_type = 'قیمت ثابت';
                                } else {
                                    $displayPrice = explode('.', $perKmPrice)[0];
                                    $pricing_type = 'قیمت به ازای کیلومتر';
                                }

                                // تعداد خودروهای موجود در این دسته‌بندی
                                $availableCarsCount = $category->cars->where('status', 'available')->count();
                                ?>
                            <div class="col-md-4">
                                <div class="car-card {{ $loop->first ? 'selected' : '' }}"
                                     data-pricing-type="{{ $category->price_type }}"
                                     data-fixed-price="{{ $fixedPrice }}"
                                     data-per-km-price="{{ $perKmPrice }}"
                                     data-category-id="{{ $category->id }}"
                                     onclick="selectCarCategory(this, {{ $category->id }})">
                                    <div class="car-check-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" width="16" height="16"><path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                    </div>
                                    <div class="car-image">
                                        @if($category->logo)
                                            <img src="{{ asset('storage/'.$category->logo) }}" alt="{{ $category->title }}">
                                        @else
                                            <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #f5b754 0%, #e0a543 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">
                                                <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11h1a1 1 0 011 1v5a1 1 0 01-1 1h-1v1a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1H7v1a1 1 0 01-1 1H5a1 1 0 01-1-1v-1H3a1 1 0 01-1-1v-5a1 1 0 011-1h1z"/></svg>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="car-info">
                                        <h6 class="car-name">{{ $category->title }}</h6>
                                        @if($category->description)
                                            <p style="font-size: 12px; color: #555; margin-bottom: 10px; font-weight: 300;">{{ \Illuminate\Support\Str::limit($category->description, 60) }}</p>
                                        @endif
                                        <div class="car-price">
                                            @if($isNegotiable)
                                                <span style="color: #f5b754; font-weight: 700;">{{ $pricing_type }}</span>
                                                <small style="font-size: 12px; font-weight: 400; display: block; margin-top: 5px; color: #555;">تماس بگیرید</small>
                                            @else
                                                {{ number_format($displayPrice) }} تومان <small style="font-size: 12px; font-weight: 400;">{{ $pricing_type }}</small>
                                            @endif
                                        </div>
                                        <div class="car-specs">
                                            <span class="spec"><svg class="me-1" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11h1a1 1 0 011 1v5a1 1 0 01-1 1h-1v1a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1H7v1a1 1 0 01-1 1H5a1 1 0 01-1-1v-1H3a1 1 0 01-1-1v-5a1 1 0 011-1h1z"/></svg>{{ $availableCarsCount }} خودرو موجود</span>
                                            @if($category->type)
                                                <span class="spec"><svg class="me-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M20.59 13.41L13.42 20.58a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" stroke-linejoin="round"/><circle cx="7" cy="7" r="1.3" fill="currentColor" stroke="none"/></svg>{{ \Modules\Cars\Models\CarCategory::TYPES[$category->type] ?? $category->type }}</span>
                                            @endif
                                        </div>
                                        <button type="button" class="car-select-btn" onclick="event.stopPropagation(); selectCarCategory(this.closest('.car-card'), {{ $category->id }})">
                                            <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9" stroke-linecap="round" stroke-linejoin="round"/></svg>انتخاب
                                        </button>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- Personal Information -->
                <div class="mb-4">
                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><circle cx="12" cy="8" r="3.2"/><path d="M5 20c1-3.5 4-5.5 7-5.5s6 2 7 5.5" stroke-linecap="round"/></svg>اطلاعات شخصی</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">نام و نام خانوادگی</label>
                            <input type="text" id="passengerName" class="form-control" placeholder="نام کامل خود را وارد کنید">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">شماره تماس</label>
                            <input type="tel" id="passengerPhone" class="form-control" placeholder="۰۹۱۲۳۴۵۶۷۸۹" value="{{ $phoneFromSession ?? '' }}">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">تاریخ رزرو</label>
                            <input type="text" id="reservationDate" class="form-control" placeholder="انتخاب تاریخ" autocomplete="off" readonly>
                            <input type="hidden" id="reservationDateAlt">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">زمان رزرو</label>
                            <input type="text" id="reservationTime" class="form-control" placeholder="انتخاب زمان" autocomplete="off" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">تعداد نفرات</label>
                            <select class="form-select" id="passengerCount">
                                <option value="1">۱ نفر</option>
                                <option value="2">۲ نفر</option>
                                <option value="3">۳ نفر</option>
                                <option value="4">۴ نفر <small style="color: #f5b754;">(افزایش ۲۰٪ قیمت)</small></option>
                            </select>
                            <small id="passengerCountWarning" class="text-warning" style="display: none; font-size: 12px; margin-top: 5px;">
                                <svg class="me-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M12 3l9 16H3z" stroke-linejoin="round"/><path d="M12 9v4M12 16h.01" stroke-linecap="round"/></svg>توجه: انتخاب ۴ نفر باعث افزایش ۲۰٪ قیمت می‌شود
                            </small>
                        </div>
{{--                        <div class="col-md-6 mb-3">--}}
{{--                            <label class="form-label">کد تخفیف (اختیاری)</label>--}}
{{--                            <div class="input-group">--}}
{{--                                <input type="text" id="discountCode" class="form-control" placeholder="کد تخفیف خود را وارد کنید" onkeypress="if(event.key === 'Enter') applyDiscountCode()">--}}
{{--                                <button type="button" class="input-group-text" onclick="applyDiscountCode()">--}}
{{--                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" width="16" height="16"><path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round"/></svg> اعمال--}}
{{--                                </button>--}}
{{--                            </div>--}}
{{--                            <div id="discountMessage" class="mt-2" style="font-size: 12px;"></div>--}}
{{--                        </div>--}}
                        <div class="col-md-6 mb-3">
                            <label class="form-label">شماره دوم (اختیاری)</label>
                            <input type="tel" id="secondPhone" class="form-control" placeholder="۰۹۱۲۳۴۵۶۷۸۹">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label d-block">آیا نیاز به فاکتور دارید؟</label>
                            <div class="form-check form-check-inline mt-2">
                                <input class="form-check-input shadow-black" type="checkbox" id="needsInvoice" value="1">
                                <label class="form-check-label" for="needsInvoice">
                                    بله، نیاز به فاکتور دارم
                                </label>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">توضیحات اضافه (اختیاری)</label>
                            <textarea id="additionalDescription" class="form-control" rows="3" placeholder="هر توضیح اضافه‌ای که می‌خواهید اضافه کنید..."></textarea>
                        </div>
                        <input type="hidden" id="reservationId" value="{{ $reservation?->id }}">
                    </div>
                </div>

                <!-- Additional Options -->
                <div class="mb-4">
                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" stroke-linejoin="round"/><circle cx="12" cy="12" r="3"/></svg>گزینه‌های اضافی</h4>
                    <div class="row">

                        @foreach($options as $option)
                            <div class="col-md-3 mb-3">
                                <input type="checkbox"
                                       class="btn-check option-check"
                                       id="option_{{ $option->id }}"
                                       autocomplete="off"
                                       data-option-name="{{ $option->name }}"
                                       data-pricing-type="{{ $option->pricing_type }}"
                                       data-fixed-price="{{ $option->fixed_price }}"
                                       data-per-km-price="{{ $option->per_km_price }}"
                                       data-percentage-price="{{ $option->percentage_price }}">
                                <label class="btn w-100 opt-btn btn-outline-primary" for="option_{{ $option->id }}">
                                    {{ $option->name }}
                                </label>
                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- Rules and Information -->
                <div class="rules-section">
                    <h4 class="section-title"><svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1" stroke-linecap="round" stroke-linejoin="round"/></svg>قوانین و اطلاعات مهم</h4>

                    <div class="accordion" id="rulesAccordion">
                        <!-- قوانین استرداد وجه -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingRefund">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseRefund" aria-expanded="true" aria-controls="collapseRefund">
                                    <svg class="me-2 text-danger" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5" stroke-linecap="round" stroke-linejoin="round"/></svg>قوانین استرداد وجه
                                </button>
                            </h2>
                            <div id="collapseRefund" class="accordion-collapse collapse show" aria-labelledby="headingRefund" data-bs-parent="#rulesAccordion">
                                <div class="accordion-body">
                                    <ul class="small">
                                        <li>تا ۲۴ ساعت قبل: ۱۰۰٪ بازگشت</li>
                                        <li>تا ۱۲ ساعت قبل: ۵۰٪ بازگشت</li>
                                        <li>کمتر از ۱۲ ساعت: بدون بازگشت</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- جزئیات سفر -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTrip">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTrip" aria-expanded="false" aria-controls="collapseTrip">
                                    <svg class="me-2 text-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4M9 7l6-3" stroke-linecap="round" stroke-linejoin="round"/></svg>جزئیات سفر
                                </button>
                            </h2>
                            <div id="collapseTrip" class="accordion-collapse collapse" aria-labelledby="headingTrip" data-bs-parent="#rulesAccordion">
                                <div class="accordion-body">
                                    <ul class="small">
                                        <li>حرکت از ترمینال جنوب</li>
                                        <li>توقف ۱۵ دقیقه‌ای در نیمه راه</li>
                                        <li>رسیدن به ترمینال کاوه اصفهان</li>
                                        <li>راننده مجرب و حرفه‌ای</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- تعداد نفرات و چمدان -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingLuggage">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseLuggage" aria-expanded="false" aria-controls="collapseLuggage">
                                    <svg class="me-2 text-warning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><rect x="3" y="8" width="18" height="12" rx="2"/><path d="M8 8V6a2 2 0 012-2h4a2 2 0 012 2v2" stroke-linecap="round"/></svg>تعداد نفرات و چمدان
                                </button>
                            </h2>
                            <div id="collapseLuggage" class="accordion-collapse collapse" aria-labelledby="headingLuggage" data-bs-parent="#rulesAccordion">
                                <div class="accordion-body">
                                    <ul class="small">
                                        <li>حداکثر ظرفیت بر اساس خودرو</li>
                                        <li>چمدان اضافی: ۵۰,۰۰۰ تومان</li>
                                        <li>وزن هر چمدان حداکثر ۲۰ کیلو</li>
                                        <li>کیف دستی رایگان</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="text-center mt-4 mb-4">
                    <span class="final-price-badge" id="finalPriceBadge" style="display: none;">
                        <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" width="16" height="16"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.4"/></svg>
                        <span id="finalPriceText">0 تومان</span>
                    </span>
                    <button type="button" class="btn btn-outline-info button-1" id="sendSelectionButton">
                        <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M12 16V6M8 10l4-4 4 4" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 18h14" stroke-linecap="round"/></svg>ثبت درخواست تاکسی
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Preloader -->
    <div id="reservationPreloader" class="reservation-preloader">
        <div class="preloader-content">
            <div class="preloader-spinner"></div>
            <div class="preloader-text">در حال ثبت درخواست...</div>
            <div class="preloader-subtext">لطفاً صبر کنید</div>
        </div>
    </div>
@endsection

@section('script')
    <!-- Persian Date Library from CDN -->
    <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
    <!-- Persian Datepicker JS from CDN -->
    <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
    <!-- SweetAlert2 from CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jQuery Timepicker JS from CDN - باید بعد از jQuery لود شود -->
    <script>
        // اطمینان از لود شدن jQuery قبل از timepicker
        (function() {
            function loadTimepicker() {
                if (typeof jQuery !== 'undefined') {
                    var script = document.createElement('script');
                    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js';
                    script.onload = function() {
                        console.log('Timepicker library loaded successfully');
                    };
                    script.onerror = function() {
                        console.error('Failed to load Timepicker library');
                    };
                    document.head.appendChild(script);
                } else {
                    setTimeout(loadTimepicker, 100);
                }
            }
            loadTimepicker();
        })();
    </script>
    <script>
        // Initialize Persian Date Picker and Time Picker
        function initDateAndTimePickers() {
            // Check if jQuery is loaded
            if (typeof jQuery === 'undefined') {
                console.log('Waiting for jQuery...');
                setTimeout(initDateAndTimePickers, 200);
                return;
            }

            // Check if persianDatepicker is loaded
            if (typeof jQuery.fn.persianDatepicker === 'undefined') {
                console.log('Waiting for Persian Datepicker library...');
                setTimeout(initDateAndTimePickers, 200);
                return;
            }

            // Check if timepicker is loaded
            if (typeof jQuery.fn.timepicker === 'undefined') {
                console.log('Waiting for Timepicker library...');
                // اگر بعد از 10 ثانیه لود نشد، متوقف می‌شویم
                if (typeof initDateAndTimePickers.retryCount === 'undefined') {
                    initDateAndTimePickers.retryCount = 0;
                }
                initDateAndTimePickers.retryCount++;
                if (initDateAndTimePickers.retryCount > 50) {
                    console.error('Timepicker library failed to load after multiple attempts');
                    return;
                }
                setTimeout(initDateAndTimePickers, 200);
                return;
            }

            // Reset retry count on success
            if (typeof initDateAndTimePickers.retryCount !== 'undefined') {
                initDateAndTimePickers.retryCount = 0;
            }

            // Initialize Date Picker
            var $dateInput = jQuery("#reservationDate");
            if ($dateInput.length) {
                try {
                    // محاسبه تاریخ امروز به شمسی
                    var todayFormatted = null;
                    if (typeof persianDate !== 'undefined') {
                        var today = new persianDate();
                        todayFormatted = today.format('YYYY/MM/DD');
                    }

                    var datePickerOptions = {
                        altField: "#reservationDateAlt",
                        altFormat: "X",
                        format: "YYYY/MM/DD",
                        observer: true,
                        calendarType: 'persian',
                        initialValue: false,
                        autoClose: true,
                        onSelect: function(unixDate) {
                            console.log('Date selected:', unixDate);
                        }
                    };

                    // اگر persianDate در دسترس است، minDate را تنظیم می‌کنیم
                    if (todayFormatted) {
                        datePickerOptions.minDate = todayFormatted; // غیرفعال کردن تاریخ‌های قبل از امروز
                    }

                    $dateInput.persianDatepicker(datePickerOptions);
                    console.log('Persian Datepicker initialized successfully');
                } catch (error) {
                    console.error('Error initializing Persian Datepicker:', error);
                }
            }

            // Initialize Time Picker
            var $timeInput = jQuery("#reservationTime");
            if ($timeInput.length) {
                try {
                    $timeInput.timepicker({
                        timeFormat: 'HH:mm',
                        interval: 15,
                        minTime: '00:00',
                        maxTime: '23:59',
                        defaultTime: false,
                        startTime: '00:00',
                        dynamic: false,
                        dropdown: true,
                        scrollbar: true,
                        orientation: 'r' // RTL
                    });
                    console.log('Timepicker initialized successfully');
                } catch (error) {
                    console.error('Error initializing Timepicker:', error);
                }
            }
        }

        // Wait for all scripts to load before initializing
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                setTimeout(initDateAndTimePickers, 500);
            });
        } else {
            // DOM is already ready
            setTimeout(initDateAndTimePickers, 500);
        }

        // Also try on window load as backup
        window.addEventListener('load', function() {
            setTimeout(function() {
                if (typeof jQuery !== 'undefined' && typeof jQuery.fn.persianDatepicker !== 'undefined' && typeof jQuery.fn.timepicker !== 'undefined') {
                    var $dateInput = jQuery("#reservationDate");
                    var $timeInput = jQuery("#reservationTime");
                    if (($dateInput.length && !$dateInput.data('persianDatepicker')) || ($timeInput.length && !$timeInput.data('timepicker'))) {
                        console.log('Retrying date and time picker initialization on window load...');
                        initDateAndTimePickers();
                    }
                }
            }, 1000);
        });
    </script>
    <script>
        const priceElement = document.getElementById('finalPrice');
        let baseTripPrice = Number(priceElement.dataset.basePrice || 0);
        const baseTripDistance = Number(priceElement.dataset.tripDistance || 0);
        const priceSource = priceElement.dataset.priceSource || '';
        const reservationId = document.getElementById('reservationId')?.value || null;
        // تشخیص سفر شهر به شهر: بررسی می‌کنیم که آیا هم مبدا و هم مقصد در city_pricings هستند
        let isCityToCity = priceElement.dataset.isCityToCity === 'true'; // از data-is-city-to-city خوانده می‌شود
        // بررسی اینکه آیا pricing شامل قیمت دسته‌بندی است یا نه
        let hasCarCategoryInPricing = priceElement.dataset.hasCarCategory === 'true';
        let pricingCarCategoryId = priceElement.dataset.pricingCarCategoryId ? Number(priceElement.dataset.pricingCarCategoryId) : null;
        let selectedCategoryPricingType = 'fixed';
        let selectedCategoryFixedPrice = 0;
        let selectedCategoryPerKmPrice = 0;
        let selectedCategoryName = '';
        let selectedCategoryId = null;
        let selectedOptions = [];
        let lastCalculatedPrice = baseTripPrice;

        // متغیرهای مربوط به تخفیف
        let appliedDiscount = null;
        let appliedDiscountAmount = 0;
        let appliedDiscountCode = null;
        async function selectCarCategory(element, categoryId) {
            // Remove selected class from all categories
            document.querySelectorAll('.car-card').forEach(card => {
                card.classList.remove('selected');
            });

            // Add selected class to clicked category
            element.classList.add('selected');
            selectedCategoryPricingType = element.dataset.pricingType || 'fixed';
            selectedCategoryFixedPrice = Number(element.dataset.fixedPrice || 0);
            selectedCategoryPerKmPrice = Number(element.dataset.perKmPrice || 0);
            selectedCategoryName = element.querySelector('.car-name').textContent;
            selectedCategoryId = categoryId || element.dataset.categoryId || null;

            // اگر reservation_id موجود باشد، قیمت جدید را از سرور بگیریم
            if (reservationId && selectedCategoryId) {
                try {
                    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                    const response = await fetch("{{ route('site.reservation.price-quote') }}", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': csrfToken || '',
                        },
                        body: JSON.stringify({
                            reservation_id: Number(reservationId),
                            car_category_id: selectedCategoryId,
                        }),
                    });

                    const data = await response.json();
                    if (data.success && data.price_quote) {
                        const quote = data.price_quote;
                        baseTripPrice = Number(quote.amount || 0);
                        isCityToCity = quote.meta?.is_city_to_city === true;
                        hasCarCategoryInPricing = quote.meta?.has_car_category === true;
                        pricingCarCategoryId = quote.meta?.car_category_id ? Number(quote.meta.car_category_id) : null;
                    }
                } catch (error) {
                    console.error('Error fetching price quote:', error);
                }
            }

            updateFinalPrice();

            // بارگذاری مجدد تخفیف‌ها بعد از انتخاب دسته‌بندی
            if (reservationId) {
                setTimeout(() => {
                    loadAvailableDiscounts();
                }, 500);
            }
        }

        function updateFinalPrice() {
            const roundTrip = document.getElementById('roundTrip');
            const pet = document.getElementById('pet');
            const childSeat = document.getElementById('childSeat');

            // محاسبه قیمت دسته‌بندی بر اساس نوع قیمت‌گذاری
            let categoryPart = 0;
            const isNegotiable = selectedCategoryPricingType === 'negotiable';

            // بررسی اینکه آیا pricing شامل قیمت دسته‌بندی است یا نه
            // اگر pricing با car_category_id خاص پیدا شده باشد و با دسته‌بندی انتخاب شده match کند،
            // قیمت دسته‌بندی در pricing گنجانده شده است و نباید دوباره اضافه شود
            const hasCarCategoryMatch = hasCarCategoryInPricing &&
                pricingCarCategoryId !== null &&
                selectedCategoryId !== null &&
                pricingCarCategoryId === selectedCategoryId;

            // اگر سفر شهر به شهر است یا pricing شامل قیمت دسته‌بندی است، قیمت دسته‌بندی اضافه نمی‌شود
            if (!isNegotiable && !isCityToCity && !hasCarCategoryMatch) {
                if (selectedCategoryPricingType === 'per_km') {
                    // قیمت به ازای کیلومتر: در فاصله ضرب می‌شود
                    categoryPart = selectedCategoryPerKmPrice * baseTripDistance;
                } else if (selectedCategoryPricingType === 'fixed') {
                    // قیمت ثابت
                    categoryPart = selectedCategoryFixedPrice;
                }

                // اگر سفر رفت و برگشت باشد
                if (roundTrip && roundTrip.checked) {
                    if (selectedCategoryPricingType === 'per_km') {
                        categoryPart += selectedCategoryPerKmPrice * baseTripDistance;
                    } else if (selectedCategoryPricingType === 'fixed') {
                        categoryPart += selectedCategoryFixedPrice;
                    }
                }
            }

            // محاسبه قیمت پایه (قیمت اولیه + دسته‌بندی) برای محاسبه درصدی
            // در حالت توافقی، categoryPart = 0 است، پس basePrice = baseTripPrice
            const basePrice = baseTripPrice + categoryPart;

            // جدا کردن گزینه‌ها بر اساس نوع قیمت‌گذاری
            let fixedOptionPart = 0; // گزینه‌های ثابت
            let perKmOptionPart = 0; // گزینه‌های به ازای کیلومتر
            let percentageOptionPart = 0; // گزینه‌های درصدی

            selectedOptions.forEach(option => {
                if (option.pricingType === 'per_km') {
                    // قیمت به ازای کیلومتر: در کیلومتر ضرب می‌شود و با بقیه جمع می‌شود
                    perKmOptionPart += option.rate * baseTripDistance;
                } else if (option.pricingType === 'percentage') {
                    // قیمت درصدی: در کل قیمت (قیمت پایه + دسته‌بندی) ضرب می‌شود
                    // basePrice شامل قیمت اولیه + دسته‌بندی است
                    percentageOptionPart += (basePrice * option.rate) / 100;
                } else {
                    // قیمت ثابت: با بقیه جمع می‌شود
                    fixedOptionPart += option.rate;
                }
            });

            // گزینه‌های ساده (pet, childSeat) به عنوان ثابت محاسبه می‌شوند
            if (pet && pet.checked) {
                fixedOptionPart += 100000;
            }
            if (childSeat && childSeat.checked) {
                fixedOptionPart += 50000;
            }

            // محاسبه افزایش قیمت برای 4 نفر (20 درصد)
            const passengerCountInput = document.getElementById('passengerCount');
            const passengerCount = passengerCountInput ? parseInt(passengerCountInput.value) : 1;
            let passengerSurcharge = 0; // افزایش قیمت برای تعداد نفرات
            let passengerSurchargePercentage = 0; // درصد افزایش

            if (passengerCount === 4) {
                // اگر 4 نفر باشد، 20 درصد به قیمت پایه اضافه می‌شود
                passengerSurchargePercentage = 20;
            }

            // محاسبه قیمت نهایی
            let finalPrice = 0;
            let displayText = '';
            let actualPrice = 0; // قیمت واقعی برای ارسال به سرور

            if (isNegotiable) {
                // در حالت توافقی، محاسبه قیمت واقعی (قیمت پایه + گزینه‌ها بدون دسته‌بندی)
                const negotiableBasePrice = baseTripPrice; // فقط قیمت اولیه

                // محاسبه گزینه‌های درصدی برای حالت توافقی (بر اساس قیمت اولیه)
                let negotiablePercentagePart = 0;
                selectedOptions.forEach(option => {
                    if (option.pricingType === 'percentage') {
                        negotiablePercentagePart += (negotiableBasePrice * option.rate) / 100;
                    }
                });

                // محاسبه قیمت قبل از افزایش 4 نفره
                let priceBeforePassengerSurcharge = negotiableBasePrice + fixedOptionPart + perKmOptionPart + negotiablePercentagePart;

                // اعمال افزایش 20 درصدی برای 4 نفر
                if (passengerSurchargePercentage > 0) {
                    passengerSurcharge = (priceBeforePassengerSurcharge * passengerSurchargePercentage) / 100;
                }

                // قیمت واقعی برای ارسال (قیمت پایه + گزینه‌ها + افزایش 4 نفره)
                actualPrice = Math.max(0, Math.round(priceBeforePassengerSurcharge + passengerSurcharge));

                // برای نمایش: هیچ قیمتی نمایش داده نمی‌شود، فقط "توافقی"
                finalPrice = actualPrice; // قیمت واقعی برای ارسال
                displayText = 'توافقی';
            } else {
                // محاسبه قیمت قبل از افزایش 4 نفره
                let priceBeforePassengerSurcharge = basePrice + fixedOptionPart + perKmOptionPart + percentageOptionPart;

                // اعمال افزایش 20 درصدی برای 4 نفر
                if (passengerSurchargePercentage > 0) {
                    passengerSurcharge = (priceBeforePassengerSurcharge * passengerSurchargePercentage) / 100;
                }

                // حالت عادی: قیمت پایه + دسته‌بندی + گزینه‌ها + افزایش 4 نفره
                finalPrice = Math.max(0, Math.round(priceBeforePassengerSurcharge + passengerSurcharge));
                actualPrice = finalPrice;
                displayText = finalPrice.toLocaleString('fa-IR') + ' تومان';
            }

            lastCalculatedPrice = actualPrice; // استفاده از قیمت واقعی برای ارسال
            const finalPriceElement = document.getElementById('finalPrice');
            finalPriceElement.textContent = displayText;

            // نمایش/مخفی کردن هشدار برای 4 نفر
            const passengerCountWarning = document.getElementById('passengerCountWarning');
            if (passengerCountWarning) {
                if (passengerCount === 4) {
                    passengerCountWarning.style.display = 'block';
                } else {
                    passengerCountWarning.style.display = 'none';
                }
            }

            // اعمال تخفیف اگر وجود داشته باشد
            if (appliedDiscount && appliedDiscountAmount > 0) {
                finalPrice = Math.max(0, finalPrice - appliedDiscountAmount);
                actualPrice = finalPrice;
                displayText = finalPrice.toLocaleString('fa-IR') + ' تومان';

                // نمایش اطلاعات تخفیف
                const discountInfo = document.getElementById('discountInfo');
                const discountTitle = document.getElementById('discountTitle');
                const discountAmount = document.getElementById('discountAmount');
                const originalPrice = document.getElementById('originalPrice');

                if (discountInfo && discountTitle && discountAmount && originalPrice) {
                    discountTitle.textContent = appliedDiscount.title || 'تخفیف: ';
                    discountAmount.textContent = appliedDiscountAmount.toLocaleString('fa-IR') + ' تومان';
                    originalPrice.textContent = (finalPrice + appliedDiscountAmount).toLocaleString('fa-IR');
                    discountInfo.style.display = 'block';
                }
            } else {
                // مخفی کردن اطلاعات تخفیف
                const discountInfo = document.getElementById('discountInfo');
                if (discountInfo) {
                    discountInfo.style.display = 'none';
                }
            }

            // Update badge next to submit button
            const finalPriceBadge = document.getElementById('finalPriceBadge');
            const finalPriceText = document.getElementById('finalPriceText');
            if (finalPriceBadge && finalPriceText) {
                finalPriceText.textContent = displayText;
                finalPriceBadge.style.display = 'inline-block';
            }

            // بارگذاری مجدد تخفیف‌ها با قیمت جدید
            const currentReservationId = document.getElementById('reservationId')?.value || null;
            if (currentReservationId && !isNegotiable && actualPrice > 0) {
                // استفاده از setTimeout برای جلوگیری از درخواست‌های زیاد
                setTimeout(() => {
                    loadAvailableDiscounts();
                }, 300);
            }
        }

        // دریافت تخفیف‌های خودکار
        async function loadAvailableDiscounts() {
            // خواندن reservationId از input در هر بار فراخوانی
            const reservationIdInput = document.getElementById('reservationId');
            const currentReservationId = reservationIdInput ? reservationIdInput.value : null;

            console.log('loadAvailableDiscounts called', {
                reservationId: currentReservationId,
                selectedCategoryId,
                lastCalculatedPrice
            }); // دیباگ

            if (!currentReservationId) {
                console.warn('reservationId is not set, skipping loadAvailableDiscounts');
                return;
            }

            try {
                // دریافت قیمت فعلی از صفحه
                const priceElement = document.getElementById('finalPrice');
                let currentPrice = 0;

                if (priceElement) {
                    // اگر قیمت از lastCalculatedPrice موجود باشد، از آن استفاده می‌کنیم
                    if (typeof lastCalculatedPrice !== 'undefined' && lastCalculatedPrice > 0) {
                        currentPrice = lastCalculatedPrice;
                    } else {
                        // در غیر این صورت، از base-price استفاده می‌کنیم
                        currentPrice = Number(priceElement.dataset.basePrice || 0);
                    }
                }

                console.log('Loading discounts with:', { reservationId: currentReservationId, currentPrice, selectedCategoryId }); // دیباگ

                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                let url = "{{ route('api.discounts.available') }}?reservation_id=" + currentReservationId;

                if (currentPrice > 0) {
                    url += "&current_price=" + currentPrice;
                }

                // ارسال car_category_id اگر انتخاب شده باشد
                if (selectedCategoryId) {
                    url += "&car_category_id=" + selectedCategoryId;
                }

                console.log('Fetching discounts from:', url); // دیباگ

                const response = await fetch(url, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken || '',
                    },
                });

                if (!response.ok) {
                    console.error('API response not OK:', response.status, response.statusText);
                    const errorText = await response.text();
                    console.error('Error response:', errorText);
                    return;
                }

                const data = await response.json();
                console.log('Discounts API Response:', data); // برای دیباگ

                if (data.success && data.discounts && data.discounts.length > 0) {
                    console.log('Displaying discounts:', data.discounts.length, data.discounts); // برای دیباگ
                    displayAvailableDiscounts(data.discounts);
                } else {
                    console.log('No discounts to display', {
                        success: data.success,
                        discountsCount: data.discounts?.length || 0,
                        debug: data.debug
                    }); // برای دیباگ

                    // مخفی کردن بخش تخفیف‌ها
                    const discountsSection = document.getElementById('discountsSection');
                    if (discountsSection) {
                        discountsSection.style.display = 'none';
                    }
                }
            } catch (error) {
                console.error('Error loading available discounts:', error);
            }
        }

        // نمایش تخفیف‌های موجود
        function displayAvailableDiscounts(discounts) {
            console.log('displayAvailableDiscounts called with:', discounts); // دیباگ

            const discountsSection = document.getElementById('discountsSection');
            const availableDiscounts = document.getElementById('availableDiscounts');

            if (!discountsSection) {
                console.error('discountsSection element not found');
                return;
            }

            if (!availableDiscounts) {
                console.error('availableDiscounts element not found');
                return;
            }

            availableDiscounts.innerHTML = '';

            if (!discounts || discounts.length === 0) {
                console.warn('No discounts to display');
                discountsSection.style.display = 'none';
                return;
            }

            console.log('Displaying', discounts.length, 'discounts'); // دیباگ

            discounts.forEach(discount => {
                try {
                    const discountCard = document.createElement('div');
                    discountCard.className = 'col-md-4 mb-3';

                    // Escape کردن متن‌ها برای جلوگیری از مشکل در HTML
                    const title = (discount.title || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
                    const description = discount.description ? (discount.description.replace(/'/g, "\\'").replace(/"/g, '&quot;')) : '';
                    const calculatedAmount = Number(discount.calculated_amount || 0);

                    discountCard.innerHTML = `
                        <div class="card" style="border: 1px solid #f5b754; border-radius: 15px; cursor: pointer; transition: all 0.3s;" onclick="selectDiscount(${discount.id}, '${title}', ${calculatedAmount})">
                            <div class="card-body" style="padding: 15px;">
                                <h6 style="color: #f5b754; font-weight: 700; margin-bottom: 8px;">
                                    <svg class="me-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" width="16" height="16"><path d="M20.59 13.41L13.42 20.58a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" stroke-linejoin="round"/><circle cx="7" cy="7" r="1.3" fill="currentColor" stroke="none"/></svg>${title}
                                </h6>
                                ${description ? `<p style="font-size: 12px; color: #555; margin-bottom: 8px;">${description}</p>` : ''}
                                <div style="font-size: 16px; font-weight: 700; color: #28a745;">
                                    ${calculatedAmount.toLocaleString('fa-IR')} تومان تخفیف
                                </div>
                            </div>
                        </div>
                    `;
                    availableDiscounts.appendChild(discountCard);
                } catch (error) {
                    console.error('Error creating discount card:', error, discount);
                }
            });

            discountsSection.style.display = 'block';
            console.log('Discounts section displayed'); // دیباگ
        }

        // انتخاب تخفیف خودکار
        function selectDiscount(discountId, discountTitle, discountAmount) {
            appliedDiscount = {
                id: discountId,
                title: discountTitle
            };
            appliedDiscountAmount = discountAmount;
            appliedDiscountCode = null;

            // نمایش پیام موفقیت
            const discountMessage = document.getElementById('discountMessage');
            if (discountMessage) {
                discountMessage.innerHTML = '<span style="color: #28a745;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9" stroke-linecap="round" stroke-linejoin="round"/></svg> تخفیف اعمال شد</span>';
            }

            updateFinalPrice();
        }

        // اعمال کد تخفیف
        async function applyDiscountCode() {
            const discountCodeInput = document.getElementById('discountCode');
            const discountMessage = document.getElementById('discountMessage');

            if (!discountCodeInput || !reservationId) return;

            const code = discountCodeInput.value.trim();
            if (!code) {
                if (discountMessage) {
                    discountMessage.innerHTML = '<span style="color: #dc3545;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16h.01" stroke-linecap="round"/></svg> لطفاً کد تخفیف را وارد کنید</span>';
                }
                return;
            }

            try {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                const response = await fetch("{{ route('api.discounts.validate-code') }}", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken || '',
                    },
                    body: JSON.stringify({
                        code: code,
                        reservation_id: reservationId,
                    }),
                });

                const data = await response.json();

                if (data.success) {
                    appliedDiscount = {
                        id: null,
                        title: data.discount_title || 'تخفیف'
                    };
                    appliedDiscountAmount = data.discount_amount || 0;
                    appliedDiscountCode = code;

                    if (discountMessage) {
                        discountMessage.innerHTML = '<span style="color: #28a745;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9" stroke-linecap="round" stroke-linejoin="round"/></svg> ' + (data.message || 'تخفیف با موفقیت اعمال شد') + '</span>';
                    }

                    updateFinalPrice();
                } else {
                    appliedDiscount = null;
                    appliedDiscountAmount = 0;
                    appliedDiscountCode = null;

                    if (discountMessage) {
                        discountMessage.innerHTML = '<span style="color: #dc3545;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16h.01" stroke-linecap="round"/></svg> ' + (data.message || 'کد تخفیف معتبر نیست') + '</span>';
                    }

                    updateFinalPrice();
                }
            } catch (error) {
                console.error('Error applying discount code:', error);
                if (discountMessage) {
                    discountMessage.innerHTML = '<span style="color: #dc3545;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="16" height="16"><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16h.01" stroke-linecap="round"/></svg> خطا در اعمال کد تخفیف</span>';
                }
            }
        }

        function submitReservation() {
            console.log('submitReservation called');
        }

        // Add event listeners for checkboxes to update price in real-time
        document.addEventListener('DOMContentLoaded', function() {
            const categoryCards = document.querySelectorAll('.car-card');
            if (categoryCards.length > 0) {
                const initialCard = categoryCards[0];
                selectedCategoryPricingType = initialCard.dataset.pricingType || 'fixed';
                selectedCategoryFixedPrice = Number(initialCard.dataset.fixedPrice || 0);
                selectedCategoryPerKmPrice = Number(initialCard.dataset.perKmPrice || 0);
                selectedCategoryName = initialCard.querySelector('.car-name')?.textContent || '';
                selectedCategoryId = initialCard.dataset.categoryId || null;
                updateFinalPrice();
            }

            const optionCheckboxes = document.querySelectorAll('.option-check');
            optionCheckboxes.forEach(optionCheckbox => {
                optionCheckbox.addEventListener('change', function() {
                    const pricingType = this.dataset.pricingType || 'fixed';
                    const fixedPrice = Number(this.dataset.fixedPrice || 0);
                    const perKmPrice = Number(this.dataset.perKmPrice || 0);
                    const percentagePrice = Number(this.dataset.percentagePrice || 0);
                    const optionName = this.dataset.optionName || '';

                    if (this.checked) {
                        let rate = 0;
                        if (pricingType === 'per_km') {
                            rate = perKmPrice;
                        } else if (pricingType === 'percentage') {
                            rate = percentagePrice; // درصد (مثلاً 10 برای 10%)
                        } else {
                            rate = fixedPrice;
                        }

                        selectedOptions.push({
                            id: this.id,
                            name: optionName,
                            pricingType,
                            rate,
                        });
                    } else {
                        selectedOptions = selectedOptions.filter(option => option.id !== this.id);
                    }

                    updateFinalPrice();
                });
            });

            const simpleCheckboxes = ['roundTrip', 'pet', 'childSeat'];
            simpleCheckboxes.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    element.addEventListener('change', updateFinalPrice);
                }
            });

            // اضافه کردن event listener برای تعداد نفرات
            const passengerCountSelect = document.getElementById('passengerCount');
            if (passengerCountSelect) {
                passengerCountSelect.addEventListener('change', updateFinalPrice);
            }

            const sendSelectionButton = document.getElementById('sendSelectionButton');
            if (sendSelectionButton) {
                sendSelectionButton.addEventListener('click', sendSelectionData);
            }

            // بارگذاری تخفیف‌های خودکار
            loadAvailableDiscounts();
        });


        function collectSelectionPayload() {
            const roundTrip = document.getElementById('roundTrip');
            const pet = document.getElementById('pet');
            const childSeat = document.getElementById('childSeat');
            const dateInput = document.getElementById('reservationDate');
            const timeInput = document.getElementById('reservationTime');
            const altDateInput = document.getElementById('reservationDateAlt');
            const passengerNameInput = document.getElementById('passengerName');
            const passengerPhoneInput = document.getElementById('passengerPhone');
            const passengerCountInput = document.getElementById('passengerCount');
            const secondPhoneInput = document.getElementById('secondPhone');
            const needsInvoiceInput = document.getElementById('needsInvoice');
            const additionalDescriptionInput = document.getElementById('additionalDescription');
            const reservationIdInput = document.getElementById('reservationId');
            const reservationId = reservationIdInput && reservationIdInput.value !== ''
                ? Number(reservationIdInput.value)
                : null;

            // محاسبه قیمت پایه برای محاسبه درصدی در payload
            let categoryPriceForCalculation = 0;
            // بررسی اینکه آیا pricing شامل قیمت دسته‌بندی است یا نه
            const hasCarCategoryMatchForCalculation = hasCarCategoryInPricing &&
                pricingCarCategoryId !== null &&
                selectedCategoryId !== null &&
                pricingCarCategoryId === selectedCategoryId;
            // اگر سفر شهر به شهر است یا pricing شامل قیمت دسته‌بندی است، قیمت دسته‌بندی اضافه نمی‌شود
            if (!isCityToCity && selectedCategoryPricingType !== 'negotiable' && !hasCarCategoryMatchForCalculation) {
                if (selectedCategoryPricingType === 'per_km') {
                    categoryPriceForCalculation = selectedCategoryPerKmPrice * baseTripDistance;
                } else if (selectedCategoryPricingType === 'fixed') {
                    categoryPriceForCalculation = selectedCategoryFixedPrice;
                }
            }
            const basePriceForCalculation = baseTripPrice + categoryPriceForCalculation;

            const optionsPayload = selectedOptions.map(option => {
                let calculatedAmount = 0;
                if (option.pricingType === 'per_km') {
                    // قیمت به ازای کیلومتر: در کیلومتر ضرب می‌شود
                    calculatedAmount = option.rate * baseTripDistance;
                } else if (option.pricingType === 'percentage') {
                    // قیمت درصدی: در کل قیمت (قیمت پایه + دسته‌بندی) ضرب می‌شود
                    calculatedAmount = (basePriceForCalculation * option.rate) / 100;
                } else {
                    // قیمت ثابت: همان rate است
                    calculatedAmount = option.rate;
                }

                return {
                    id: parseInt(option.id.replace('option_', ''), 10) || option.id,
                    name: option.name,
                    pricing_type: option.pricingType,
                    rate: option.rate,
                    calculated_amount: calculatedAmount,
                    reservationIdInput: reservationIdInput,
                };
            });

            // محاسبه قیمت نهایی دسته‌بندی برای ارسال
            let categoryPriceForPayload = 0;
            // بررسی اینکه آیا pricing شامل قیمت دسته‌بندی است یا نه
            const hasCarCategoryMatchForPayload = hasCarCategoryInPricing &&
                pricingCarCategoryId !== null &&
                selectedCategoryId !== null &&
                pricingCarCategoryId === selectedCategoryId;
            // اگر سفر شهر به شهر است یا قیمت توافقی است یا pricing شامل قیمت دسته‌بندی است، قیمت دسته‌بندی 0 است
            if (!isCityToCity && selectedCategoryPricingType !== 'negotiable' && !hasCarCategoryMatchForPayload) {
                if (selectedCategoryPricingType === 'per_km') {
                    categoryPriceForPayload = selectedCategoryPerKmPrice * baseTripDistance;
                } else if (selectedCategoryPricingType === 'fixed') {
                    categoryPriceForPayload = selectedCategoryFixedPrice;
                }
            }

            // بررسی اینکه آیا قیمت توافقی است
            const isNegotiable = selectedCategoryPricingType === 'negotiable';

            return {
                base_trip_price: baseTripPrice,
                base_trip_distance: baseTripDistance,
                final_price: lastCalculatedPrice,
                is_negotiable: isNegotiable, // آیا قیمت توافقی است
                discount_code: appliedDiscountCode, // کد تخفیف اعمال شده
                selected_car_category: {
                    id: selectedCategoryId,
                    name: selectedCategoryName,
                    pricing_type: selectedCategoryPricingType,
                    fixed_price: selectedCategoryFixedPrice,
                    per_km_price: selectedCategoryPerKmPrice,
                    calculated_price: categoryPriceForPayload,
                },
                toggles: {
                    round_trip: !!(roundTrip && roundTrip.checked),
                    pet: !!(pet && pet.checked),
                    child_seat: !!(childSeat && childSeat.checked),
                },
                options: optionsPayload,
                selected_date: formatCombinedDateTime(dateInput ? dateInput.value : null, timeInput ? timeInput.value : null),
                selected_date_timestamp: altDateInput ? altDateInput.value : null,
                selected_time: timeInput ? timeInput.value : null,
                passenger: {
                    name: passengerNameInput ? passengerNameInput.value : null,
                    phone: passengerPhoneInput ? passengerPhoneInput.value : null,
                    passengers_count: passengerCountInput ? passengerCountInput.value : null,
                },
                second_phone: secondPhoneInput ? secondPhoneInput.value.trim() : null,
                needs_invoice: needsInvoiceInput ? needsInvoiceInput.checked : false,
                description: additionalDescriptionInput ? additionalDescriptionInput.value.trim() : null,
                reservation_id: reservationId,
                price_source: priceSource, // ارسال منبع قیمت برای تشخیص سفر شهر به شهر
            };
        }

        function isValidMobile(phone) {
            if (!phone) {
                return false;
            }

            const normalized = phone.replace(/\s+/g, '');
            const iranMobilePattern = /^09\d{9}$/;
            return iranMobilePattern.test(normalized);
        }

        function formatCombinedDateTime(dateValue, timeValue) {
            if (!dateValue) {
                return null;
            }

            if (!window.persianDate) {
                return dateValue + (timeValue ? ' ' + timeValue : '');
            }

            try {
                // ترکیب تاریخ و زمان
                let combinedValue = dateValue;
                if (timeValue) {
                    // تبدیل زمان به فرمت مناسب (HH:mm -> HH:mm:00)
                    const timeParts = timeValue.split(':');
                    if (timeParts.length >= 2) {
                        combinedValue += ' ' + timeValue + ':00';
                    } else {
                        combinedValue += ' ' + timeValue;
                    }
                } else {
                    combinedValue += ' 00:00:00';
                }

                const parsed = new persianDate().parse(combinedValue);
                return new persianDate(parsed).format('YYYY/MM/DD HH:mm:ss');
            } catch (error) {
                return dateValue + (timeValue ? ' ' + timeValue : '');
            }
        }

        // Functions for preloader
        function showPreloader() {
            const preloader = document.getElementById('reservationPreloader');
            if (preloader) {
                preloader.classList.add('show');
                // Disable submit button
                const submitButton = document.getElementById('sendSelectionButton');
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.style.opacity = '0.6';
                    submitButton.style.cursor = 'not-allowed';
                }
            }
        }

        function hidePreloader() {
            const preloader = document.getElementById('reservationPreloader');
            if (preloader) {
                preloader.classList.remove('show');
                // Enable submit button
                const submitButton = document.getElementById('sendSelectionButton');
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.style.opacity = '1';
                    submitButton.style.cursor = 'pointer';
                }
            }
        }

        async function sendSelectionData() {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
            const payload = collectSelectionPayload();

            if (!isValidMobile(payload.passenger.phone)) {
                Swal.fire({
                    icon: 'error',
                    title: 'خطا',
                    text: 'شماره موبایل وارد شده معتبر نیست (فرمت مجاز: 09xxxxxxxxx).',
                    confirmButtonText: 'باشه'
                });
                return;
            }

            // نمایش preloader
            showPreloader();

            try {
                const response = await fetch("{{ route('site.reservation.preview') }}", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken || '',
                    },
                    body: JSON.stringify(payload),
                });

                const text = await response.text();
                let data;

                try {
                    data = text ? JSON.parse(text) : {};
                } catch (parseError) {
                    data = {};
                    console.error('JSON parse error:', parseError, text);
                }

                // مخفی کردن preloader
                hidePreloader();

                if (!response.ok || !data.success) {
                    const message = (data && data.message) || 'خطایی رخ داد. لطفاً دوباره تلاش کنید.';
                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: message,
                        confirmButtonText: 'باشه'
                    });
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'موفقیت',
                    text: data.message || 'رزرو با موفقیت انجام شد همکاران ما در اسرع وقت با شما تماس خواهند گرفت.',
                    confirmButtonText: 'باشه'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '{{ url('/') }}';
                    }
                });
            } catch (error) {
                console.error('Error sending selection data:', error);
                // مخفی کردن preloader در صورت خطا
                hidePreloader();
                Swal.fire({
                    icon: 'error',
                    title: 'خطا',
                    text: 'خطا در برقراری ارتباط با سرور.',
                    confirmButtonText: 'باشه'
                });
            }
        }

    </script>


@endsection
