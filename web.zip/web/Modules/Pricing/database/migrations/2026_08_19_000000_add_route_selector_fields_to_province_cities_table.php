<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('province_cities', function (Blueprint $table) {
            if (! Schema::hasColumn('province_cities', 'latitude')) {
                $table->decimal('latitude', 10, 8)->nullable()->after('sort');
            }

            if (! Schema::hasColumn('province_cities', 'longitude')) {
                $table->decimal('longitude', 11, 8)->nullable()->after('latitude');
            }

            if (! Schema::hasColumn('province_cities', 'route_selector_enabled')) {
                $table->boolean('route_selector_enabled')->default(false)->after('longitude')->index();
            }

            if (! Schema::hasColumn('province_cities', 'route_selector_popular')) {
                $table->boolean('route_selector_popular')->default(false)->after('route_selector_enabled');
            }

            if (! Schema::hasColumn('province_cities', 'route_selector_sort')) {
                $table->unsignedSmallInteger('route_selector_sort')->nullable()->after('route_selector_popular')->index();
            }
        });
    }

    public function down(): void
    {
        Schema::table('province_cities', function (Blueprint $table) {
            if (Schema::hasColumn('province_cities', 'route_selector_enabled')) {
                $table->dropIndex(['route_selector_enabled']);
            }

            if (Schema::hasColumn('province_cities', 'route_selector_sort')) {
                $table->dropIndex(['route_selector_sort']);
            }

            foreach ([
                'latitude',
                'longitude',
                'route_selector_enabled',
                'route_selector_popular',
                'route_selector_sort',
            ] as $column) {
                if (Schema::hasColumn('province_cities', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
