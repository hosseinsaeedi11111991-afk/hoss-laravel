<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (
            ! Schema::hasTable('province_cities') ||
            ! Schema::hasColumn('province_cities', 'latitude') ||
            ! Schema::hasColumn('province_cities', 'longitude') ||
            ! Schema::hasColumn('province_cities', 'route_selector_enabled')
        ) {
            return;
        }

        $coordinates = $this->cityCoordinates();
        $sort = 1;

        DB::table('province_cities')
            ->where('parent', '!=', 0)
            ->whereNull('deleted_at')
            ->orderBy('id')
            ->get(['id', 'title'])
            ->each(function ($city) use ($coordinates, &$sort) {
                $key = $this->normalizeCityName($city->title);

                if (! isset($coordinates[$key])) {
                    return;
                }

                DB::table('province_cities')
                    ->where('id', $city->id)
                    ->update([
                        'latitude' => $coordinates[$key]['latitude'],
                        'longitude' => $coordinates[$key]['longitude'],
                        'route_selector_enabled' => true,
                        'route_selector_popular' => $coordinates[$key]['popular'],
                        'route_selector_sort' => $sort++,
                        'updated_at' => now(),
                    ]);
            });
    }

    public function down(): void
    {
        if (
            ! Schema::hasTable('province_cities') ||
            ! Schema::hasColumn('province_cities', 'route_selector_enabled')
        ) {
            return;
        }

        $keys = array_keys($this->cityCoordinates());

        DB::table('province_cities')
            ->where('parent', '!=', 0)
            ->whereNull('deleted_at')
            ->orderBy('id')
            ->get(['id', 'title'])
            ->each(function ($city) use ($keys) {
                if (! in_array($this->normalizeCityName($city->title), $keys, true)) {
                    return;
                }

                DB::table('province_cities')
                    ->where('id', $city->id)
                    ->update([
                        'route_selector_enabled' => false,
                        'route_selector_popular' => false,
                        'route_selector_sort' => null,
                        'updated_at' => now(),
                    ]);
            });
    }

    private function cityCoordinates(): array
    {
        return collect([
            ['تهران', 35.68919800, 51.38897400, true],
            ['اصفهان', 32.65389600, 51.66596600, true],
            ['مشهد', 36.29749400, 59.60592300, true],
            ['تبریز', 38.09623900, 46.27380100, true],
            ['شیراز', 29.59176800, 52.58369800, true],
            ['رشت', 37.28083400, 49.58305700, true],
            ['قم', 34.64157600, 50.87460400, true],
            ['کرج', 35.83266000, 50.99155000, true],
            ['یزد', 31.89742300, 54.35685600, false],
            ['کرمان', 30.28393700, 57.08336300, false],
            ['اهواز', 31.31832700, 48.67061900, false],
            ['قزوین', 36.26877300, 50.00410100, false],
            ['ساوه', 35.02130100, 50.35660200, false],
            ['کاشان', 33.98503500, 51.40996300, false],
            ['ساری', 36.56333300, 53.06008900, false],
            ['قائمشهر', 36.46305600, 52.86000000, false],
            ['بابل', 36.55132300, 52.67895100, false],
            ['آمل', 36.46961100, 52.35083300, false],
            ['نور', 36.57454600, 52.01530100, false],
            ['چالوس', 36.64591700, 51.40697900, false],
            ['نشتارود', 36.75034400, 51.03058400, false],
            ['رامسر', 36.90305600, 50.65833300, false],
            ['چابکسر', 36.97138900, 50.54916700, false],
            ['کلاچای', 37.07722200, 50.39722200, false],
            ['رودسر', 37.13784100, 50.28800000, false],
            ['بهشهر', 36.69234800, 53.55262000, false],
            ['گلوگاه', 36.72777800, 53.80888900, false],
            ['گنبدکاووس', 37.25000000, 55.16722200, false],
            ['فریدون‌کنار', 36.68638900, 52.52250000, false],
            ['فریدون کنار', 36.68638900, 52.52250000, false],
        ])->mapWithKeys(function (array $city) {
            return [
                $this->normalizeCityName($city[0]) => [
                    'latitude' => $city[1],
                    'longitude' => $city[2],
                    'popular' => $city[3],
                ],
            ];
        })->all();
    }

    private function normalizeCityName(?string $value): string
    {
        $value = trim((string) $value);
        $value = str_replace(['ي', 'ك', 'ة'], ['ی', 'ک', 'ه'], $value);
        $value = str_replace(["\u{200c}", ' ', '-'], '', $value);

        return mb_strtolower($value, 'UTF-8');
    }
};
