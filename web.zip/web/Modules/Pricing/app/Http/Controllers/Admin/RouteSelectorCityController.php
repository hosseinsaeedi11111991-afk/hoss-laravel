<?php

namespace Modules\Pricing\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Pricing\Models\City;
use Modules\Pricing\Models\Province;

class RouteSelectorCityController extends Controller
{
    public function index(Request $request)
    {
        $query = City::with('province')
            ->when($request->filled('province_id'), fn ($query) => $query->byProvince($request->integer('province_id')))
            ->when($request->filled('search'), fn ($query) => $query->where('title', 'like', '%' . $request->input('search') . '%'))
            ->when($request->filled('route_selector_enabled'), function ($query) use ($request) {
                $query->where('route_selector_enabled', $request->boolean('route_selector_enabled'));
            })
            ->orderByRaw('route_selector_sort IS NULL')
            ->orderBy('route_selector_sort')
            ->orderBy('sort')
            ->orderBy('title');

        $cities = $query->paginate(30)->withQueryString();
        $provinces = Province::ordered()->get(['id', 'title']);

        return view('pricing::admin.route_selector_cities.index', compact('cities', 'provinces'));
    }

    public function update(Request $request, City $city)
    {
        $data = $request->validate([
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'route_selector_sort' => ['nullable', 'integer', 'min:0', 'max:65535'],
            'route_selector_enabled' => ['nullable', 'boolean'],
            'route_selector_popular' => ['nullable', 'boolean'],
        ], [
            'latitude.between' => 'عرض جغرافیایی باید بین -90 و 90 باشد.',
            'longitude.between' => 'طول جغرافیایی باید بین -180 و 180 باشد.',
        ]);

        $city->update([
            'latitude' => $data['latitude'] ?? null,
            'longitude' => $data['longitude'] ?? null,
            'route_selector_sort' => $data['route_selector_sort'] ?? null,
            'route_selector_enabled' => $request->boolean('route_selector_enabled'),
            'route_selector_popular' => $request->boolean('route_selector_popular'),
        ]);

        return redirect()
            ->route('admin.route-selector-cities.index', $request->only(['province_id', 'search', 'route_selector_enabled', 'page']))
            ->with('success', 'تنظیمات شهر برای فرم انتخاب مسیر ذخیره شد.');
    }
}
