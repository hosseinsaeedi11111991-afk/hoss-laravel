<?php

namespace Modules\Pricing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\User\Models\User;

class City extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'province_cities';

    protected $fillable = [
        'user_id',
        'parent',
        'title',
        'sort',
        'latitude',
        'longitude',
        'route_selector_enabled',
        'route_selector_popular',
        'route_selector_sort',
    ];

    protected $casts = [
        'parent' => 'integer',
        'sort' => 'integer',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'route_selector_enabled' => 'boolean',
        'route_selector_popular' => 'boolean',
        'route_selector_sort' => 'integer',
    ];

    /**
     * The "booted" method of the model.
     */
    protected static function booted(): void
    {
        static::addGlobalScope('cities', function ($query) {
            $query->where('parent', '!=', 0);
        });
    }

    /* Relations */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function province()
    {
        return $this->belongsTo(Province::class, 'parent', 'id');
    }

    /* Scopes */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort');
    }

    public function scopeByProvince($query, $provinceId)
    {
        return $query->where('parent', $provinceId);
    }

    public function scopeRouteSelectable($query)
    {
        return $query
            ->where('route_selector_enabled', true)
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->orderByRaw('route_selector_sort IS NULL')
            ->orderBy('route_selector_sort')
            ->orderBy('sort')
            ->orderBy('title');
    }

    /* Helper methods */
    public function isCity(): bool
    {
        return $this->parent !== 0;
    }

    public function getProvinceName()
    {
        return $this->province ? $this->province->title : null;
    }

    /**
     * Get all cities without global scope
     */
    public static function allCities()
    {
        return static::withoutGlobalScope('cities')->where('parent', '!=', 0);
    }
}
