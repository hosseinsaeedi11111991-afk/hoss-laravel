@extends('Shared::layouts.admin.main')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.route-selector-cities.index') }}">شهرهای فرم مسیر/</a></span>
        مدیریت شهرها
    </h4>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">فیلتر شهرها</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="{{ route('admin.route-selector-cities.index') }}">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">جستجوی شهر</label>
                        <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="مثلا تهران">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">استان</label>
                        <select name="province_id" class="form-select">
                            <option value="">همه استان‌ها</option>
                            @foreach($provinces as $province)
                                <option value="{{ $province->id }}" @selected(request('province_id') == $province->id)>{{ $province->title }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نمایش در فرم صفحه اصلی</label>
                        <select name="route_selector_enabled" class="form-select">
                            <option value="">همه</option>
                            <option value="1" @selected(request('route_selector_enabled') === '1')>فعال</option>
                            <option value="0" @selected(request('route_selector_enabled') === '0')>غیرفعال</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="bx bx-search"></i> جستجو
                </button>
                <a href="{{ route('admin.route-selector-cities.index') }}" class="btn btn-secondary">پاک کردن</a>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">شهرهای قابل انتخاب برای محاسبه سریع مسیر</h5>
            <small class="text-muted">هر شهر فقط وقتی در صفحه اصلی نمایش داده می‌شود که فعال باشد و مختصات معتبر داشته باشد.</small>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped align-middle">
                <thead>
                <tr>
                    <th>#</th>
                    <th>شهر</th>
                    <th>استان</th>
                    <th>عرض جغرافیایی</th>
                    <th>طول جغرافیایی</th>
                    <th>ترتیب</th>
                    <th>فعال</th>
                    <th>پرطرفدار</th>
                    <th>ذخیره</th>
                </tr>
                </thead>
                <tbody>
                @forelse($cities as $key => $city)
                    <tr>
                        <td>
                            <form id="route-selector-city-{{ $city->id }}" method="POST" action="{{ route('admin.route-selector-cities.update', $city) }}">
                                @csrf
                                @method('PATCH')
                            </form>
                            {{ ($cities->currentPage() - 1) * $cities->perPage() + $key + 1 }}
                        </td>
                        <td><strong>{{ $city->title }}</strong></td>
                        <td>{{ $city->province?->title ?? '-' }}</td>
                        <td>
                            <input form="route-selector-city-{{ $city->id }}" type="number" step="0.00000001" min="-90" max="90" name="latitude" value="{{ old('latitude', $city->latitude) }}" class="form-control form-control-sm" placeholder="35.6892">
                        </td>
                        <td>
                            <input form="route-selector-city-{{ $city->id }}" type="number" step="0.00000001" min="-180" max="180" name="longitude" value="{{ old('longitude', $city->longitude) }}" class="form-control form-control-sm" placeholder="51.3890">
                        </td>
                        <td>
                            <input form="route-selector-city-{{ $city->id }}" type="number" min="0" max="65535" name="route_selector_sort" value="{{ old('route_selector_sort', $city->route_selector_sort) }}" class="form-control form-control-sm" style="width: 90px">
                        </td>
                        <td>
                            <div class="form-check form-switch">
                                <input form="route-selector-city-{{ $city->id }}" type="hidden" name="route_selector_enabled" value="0">
                                <input form="route-selector-city-{{ $city->id }}" class="form-check-input" type="checkbox" name="route_selector_enabled" value="1" @checked(old('route_selector_enabled', $city->route_selector_enabled))>
                            </div>
                        </td>
                        <td>
                            <div class="form-check form-switch">
                                <input form="route-selector-city-{{ $city->id }}" type="hidden" name="route_selector_popular" value="0">
                                <input form="route-selector-city-{{ $city->id }}" class="form-check-input" type="checkbox" name="route_selector_popular" value="1" @checked(old('route_selector_popular', $city->route_selector_popular))>
                            </div>
                        </td>
                        <td>
                            <button form="route-selector-city-{{ $city->id }}" type="submit" class="btn btn-sm btn-primary">
                                <i class="bx bx-save"></i>
                            </button>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">شهری پیدا نشد.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        {{ $cities->links('pagination::bootstrap-5') }}
    </div>
@endsection
