<?php

namespace Modules\User\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Modules\User\Models\User;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;


class UserDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $role = Role::firstOrCreate(
            ['name' => 'super_user'],
            ['guard_name' => 'web']
        );

        $permissions = Permission::all();
        if ($permissions->count()) {
            $role->syncPermissions($permissions);
        }

        $user = User::firstOrCreate(
            ['username' => 'SuperUser'],
            [
                'uuid'     => (string) Str::uuid(),
                'mobile'   => '09364307767',
                'national_code' => '0022586083',
                'first_name' => 'Mahdi',
                'last_name' => 'Mojtabavi',
                'email' => 'm.mojtabavi@outlook.com',
                'password' => Hash::make('#mAhdi7899'),
            ]
        );

        $user->assignRole($role);
        $this->command->info('Super User successfully created!');
    }
}
