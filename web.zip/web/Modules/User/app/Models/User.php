<?php

namespace Modules\User\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

/** @property mixed $id */
/** @property mixed $uuid */
/** @property mixed $username */
/** @property mixed $mobile */
/** @property mixed $national_code */
/** @property mixed $first_name */
/** @property mixed $last_name */
/** @property mixed $email */
/** @property mixed $password */
/** @property mixed $avatar */
/** @property mixed $status */
/** @property mixed $created_at */
/** @property mixed $updated_at */
class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'uuid',
        'username',
        'mobile',
        'national_code',
        'first_name',
        'last_name',
        'email',
        'password',
        'avatar',
        'status',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'uuid' => 'string',
            'password' => 'hashed',
        ];
    }

    public function getUsernameAttribute(?string $value): ?string
    {
        return $this->repairMojibake($value);
    }

    private function repairMojibake(?string $value): ?string
    {
        if ($value === null || $value === '') {
            return $value;
        }

        if (! preg_match('/[\x{00C2}\x{00C3}\x{00D8}\x{00D9}\x{00DA}\x{00DB}\x{00E2}]/u', $value)) {
            return $value;
        }

        $decoded = @mb_convert_encoding(
            mb_convert_encoding($value, 'Windows-1252', 'UTF-8'),
            'UTF-8',
            'UTF-8'
        );

        return $decoded ?: $value;
    }
}
