<x-text::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('text.name') !!}</p>
</x-text::layouts.master>
