<?php

namespace Modules\Text\Database\Seeders;

use Illuminate\Database\Seeder;

class TextDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
