<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('writtens', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['paragraph', 'heading', 'quote', 'list', 'html', 'code'])->default('paragraph');
            $table->string('title')->nullable();
            $table->string('subtitle')->nullable();
            $table->longText('content')->nullable();
            $table->string('btn_text')->nullable();
            $table->string('btn_url')->nullable();
            $table->enum('btn_target', ['_self', '_blank'])->nullable()->default('_self');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('written_meta', function (Blueprint $table) {
            $table->id();
            $table->foreignId('written_id')->constrained('writtens')->onDelete('cascade');
            $table->enum('type', ['style'])->default('style');
            $table->enum('belongs_to', ['content', 'cta'])->default('content');
            $table->string('attribute');
            $table->text('value');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('written_meta');
        Schema::dropIfExists('writtens');
    }
};
