<?php

return [
    'name' => 'Text',
];
