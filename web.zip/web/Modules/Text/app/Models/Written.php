<?php

namespace Modules\Text\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * @property mixed $id
 * @property mixed $type
 * @property mixed $title
 * @property mixed $subtitle
 * @property mixed $content
 * @property mixed $btn_text
 * @property mixed $btn_url
 * @property mixed $btn_target
 * @property mixed $is_active
 * @property mixed $created_at
 * @property mixed $updated_at
 */
class Written extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'type',
        'title',
        'subtitle',
        'content',
        'btn_text',
        'btn_url',
        'btn_target',
        'is_active',
    ];
}
