<?php

namespace Modules\Text\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * @property mixed $id
 * @property mixed $written_id
 * @property mixed $type
 * @property mixed $belongs_to
 * @property mixed $attribute
 * @property mixed $value
 * @property mixed $created_at
 * @property mixed $updated_at
 */
class WrittenMeta extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'written_id',
        'type',
        'belongs_to',
        'attribute',
        'value',
    ];
}
