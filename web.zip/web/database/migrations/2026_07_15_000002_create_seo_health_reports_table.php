<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('seo_health_reports', function (Blueprint $table) {
            $table->id();
            $table->string('status', 32)->default('running')->index();
            $table->unsignedInteger('scanned_urls')->default(0);
            $table->unsignedInteger('issue_count')->default(0);
            $table->json('summary')->nullable();
            $table->longText('issues')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('finished_at')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('seo_health_reports');
    }
};
