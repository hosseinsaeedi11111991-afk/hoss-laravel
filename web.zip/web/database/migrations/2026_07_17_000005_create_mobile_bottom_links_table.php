<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mobile_bottom_links', function (Blueprint $table) {
            $table->id();
            $table->string('title', 120);
            $table->string('link_type', 40)->default('custom')->index();
            $table->string('url', 255)->nullable();
            $table->string('icon_key', 40)->default('custom');
            $table->unsignedSmallInteger('sort_order')->default(0)->index();
            $table->boolean('is_active')->default(true)->index();
            $table->boolean('open_in_new_tab')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mobile_bottom_links');
    }
};
