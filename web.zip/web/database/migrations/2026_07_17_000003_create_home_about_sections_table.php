<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('home_about_sections', function (Blueprint $table) {
            $table->id();
            $table->string('subtitle', 120)->default('VIP Taxi Iran');
            $table->string('title', 160)->default('وی آی پی تاکسی');
            $table->string('highlight_title', 160)->default('تاکسی بین شهری');
            $table->text('body');
            $table->json('features')->nullable();
            $table->string('image_path')->nullable();
            $table->string('image_alt')->nullable();
            $table->string('video_url')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('home_about_sections');
    }
};
