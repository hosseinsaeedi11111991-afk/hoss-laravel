<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('sms_settings')) {
            Schema::create('sms_settings', function (Blueprint $table) {
                $table->id();
                $table->string('sender', 40)->nullable();
                $table->string('reservation_admin_recipient', 40)->nullable();
                $table->string('reservation_admin_pattern', 80)->nullable();
                $table->string('reservation_passenger_pattern', 80)->nullable();
                $table->boolean('require_phone_before_route_calculation')->default(false);
                $table->boolean('send_sms_after_early_phone_capture')->default(false);
                $table->timestamps();
            });

            return;
        }

        if (! Schema::hasColumn('sms_settings', 'require_phone_before_route_calculation')) {
            Schema::table('sms_settings', function (Blueprint $table) {
                $table->boolean('require_phone_before_route_calculation')->default(false)->after('reservation_passenger_pattern');
            });
        }

        if (! Schema::hasColumn('sms_settings', 'send_sms_after_early_phone_capture')) {
            Schema::table('sms_settings', function (Blueprint $table) {
                $table->boolean('send_sms_after_early_phone_capture')->default(false)->after('require_phone_before_route_calculation');
            });
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('sms_settings')) {
            return;
        }

        if (Schema::hasColumn('sms_settings', 'send_sms_after_early_phone_capture')) {
            Schema::table('sms_settings', function (Blueprint $table) {
                $table->dropColumn('send_sms_after_early_phone_capture');
            });
        }

        if (Schema::hasColumn('sms_settings', 'require_phone_before_route_calculation')) {
            Schema::table('sms_settings', function (Blueprint $table) {
                $table->dropColumn('require_phone_before_route_calculation');
            });
        }
    }
};
