<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('seo_index_rules', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('match_type', 32)->default('path');
            $table->string('pattern', 2048);
            $table->string('robots_directive', 64)->default('noindex, follow');
            $table->boolean('exclude_from_sitemap')->default(false)->index();
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedInteger('priority')->default(100)->index();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['match_type', 'is_active']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('seo_index_rules');
    }
};
