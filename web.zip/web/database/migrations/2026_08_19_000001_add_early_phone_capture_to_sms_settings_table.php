<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('sms_settings')) {
            return;
        }

        $needsRequirePhoneColumn = ! Schema::hasColumn('sms_settings', 'require_phone_before_route_calculation');
        $needsEarlySmsColumn = ! Schema::hasColumn('sms_settings', 'send_sms_after_early_phone_capture');

        Schema::table('sms_settings', function (Blueprint $table) use ($needsRequirePhoneColumn) {
            if ($needsRequirePhoneColumn) {
                $table->boolean('require_phone_before_route_calculation')->default(false)->after('reservation_passenger_pattern');
            }
        });

        Schema::table('sms_settings', function (Blueprint $table) use ($needsEarlySmsColumn) {
            if ($needsEarlySmsColumn) {
                $table->boolean('send_sms_after_early_phone_capture')->default(false)->after('require_phone_before_route_calculation');
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('sms_settings')) {
            return;
        }

        $hasEarlySmsColumn = Schema::hasColumn('sms_settings', 'send_sms_after_early_phone_capture');
        $hasRequirePhoneColumn = Schema::hasColumn('sms_settings', 'require_phone_before_route_calculation');

        Schema::table('sms_settings', function (Blueprint $table) use ($hasEarlySmsColumn) {
            if ($hasEarlySmsColumn) {
                $table->dropColumn('send_sms_after_early_phone_capture');
            }
        });

        Schema::table('sms_settings', function (Blueprint $table) use ($hasRequirePhoneColumn) {
            if ($hasRequirePhoneColumn) {
                $table->dropColumn('require_phone_before_route_calculation');
            }
        });
    }
};
