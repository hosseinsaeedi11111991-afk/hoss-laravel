<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            // اگر کلیدهای خارجی قبلاً تعریف نشده‌اند، فقط اضافه‌شان کن
            $table->foreign('car_id')
                ->references('id')
                ->on('cars')
                ->nullOnDelete();

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            $table->dropForeign(['car_id']);
            $table->dropForeign(['user_id']);
        });
    }
};
