<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('site_contact_settings', function (Blueprint $table) {
            $table->id();
            $table->string('phone_number', 40)->default('09120983462');
            $table->string('whatsapp_number', 40)->default('09120983462');
            $table->string('display_phone', 80)->default('+98 912 098 3462');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('site_contact_settings');
    }
};
