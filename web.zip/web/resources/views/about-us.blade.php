@extends('Shared::layouts.site.main')
@section('main')

    <section class="banner-header section-padding bg-img" data-background="{{ asset('site/img/slider/3.webp') }}" data-overlay-dark="4">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h6>VIP Taxi Iran</h6>
                        <h1>درباره<span>ما</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- About -->
    <section class="about section-padding">
        <div class="container">
            <div class="row justify-content-between" dir="rtl">
                <div class="col-lg-12 col-md-12 mb-30">
                    <div class="content" dir="rtl">
                        <div class="section-subtitle">VIP Taxi Iran</div>
                        <div class="section-title">درباره ما – VIPTaxiIran</div>

                        <div class="mb-40">
                            <p class="mb-30">در دنیایی که سرعت و کیفیت تعیین‌کننده تجربه‌های روزمره است، <strong>VIPTaxiIran</strong> فراتر از یک سرویس حمل‌ونقل عمل می‌کند؛ ما سفری را خلق می‌کنیم که از لحظه‌ی ورود تا مقصد، سرشار از آرامش، شکوه و اعتماد باشد.</p>

                            <p class="mb-30"><strong>VIPTaxiIran</strong> نه صرفاً یک سامانه حمل‌ونقل، بلکه تجسمی از مفهوم «سفر ممتاز» در ایران معاصر است. ما با تلفیق شکوه، دقت و نوآوری، تجربه‌ای را خلق می‌کنیم که فراتر از جابه‌جایی ساده بوده و به یک آیین لوکس بدل می‌گردد.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">🚖 تجربه‌ای متفاوت از جابه‌جایی</h4>
                            <p class="mb-30">هر خودرو در ناوگان ما نه‌تنها وسیله‌ای برای رسیدن به مقصد، بلکه بخشی از یک تجربه لوکس است. انتخاب دقیق خودروها، طراحی داخلی مدرن و رعایت استانداردهای بین‌المللی، تصویری از سفر بی‌نقص را برای شما ترسیم می‌کند.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">🌟 استانداردهای VIP واقعی</h4>
                            <p class="mb-30">ما به جزئیات اهمیت می‌دهیم؛ از نحوه‌ی خوشامدگویی رانندگان تا کیفیت موسیقی و رایحه داخل خودرو. هر جزئی کوچک، بخشی از فلسفه‌ی ماست: ارائه‌ی خدماتی که حس خاص بودن را در شما زنده کند.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">🤝 اعتماد، آرامش و امنیت</h4>
                            <p class="mb-30">VIPTaxiIran تنها یک نام نیست؛ یک تعهد است. تعهد به امنیت کامل، احترام به زمان شما و خلق لحظاتی که ارزشمندتر از یک سفر ساده‌اند. ما خود را متعهد می‌دانیم که سفری آرام، مطمئن و به‌موقع برای مشتریان فراهم آوریم. اعتماد شما سرمایه‌ی اصلی ماست و امنیت شما، نخستین اولویت ما.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">🌍 چهره‌ای مدرن از ایران لوکس</h4>
                            <p class="mb-30">ما نماینده‌ی تصویری نوین از حمل‌ونقل در ایران هستیم؛ تصویری که نشان می‌دهد سفر می‌تواند هم‌زمان راحت، باشکوه و به‌یادماندنی باشد. VIPTaxiIran با تلفیق سنت مهمان‌نوازی ایرانی و استانداردهای بین‌المللی، الگویی تازه از حمل‌ونقل ممتاز را به جهان معرفی می‌کند.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">رسالت و فلسفه وجودی</h4>
                            <p class="mb-30">فلسفه‌ی ما بر پایه‌ی ارتقای کیفیت زندگی روزمره بنا شده است؛ ما باور داریم که هر لحظه‌ی سفر می‌تواند به خاطره‌ای ارزشمند و ماندگار تبدیل شود. از این رو، VIPTaxiIran مأموریت خود را در ارائه‌ی خدماتی تعریف کرده است که هم‌زمان امنیت، آرامش و شأن اجتماعی را در بالاترین سطح تضمین نماید.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">ناوگان ممتاز و مدیریت هوشمند</h4>
                            <p class="mb-30">خودروهای منتخب ما با رعایت استانداردهای جهانی و بهره‌گیری از فناوری‌های نوین، نمادی از ظرافت و کارآمدی هستند. مدیریت دقیق ناوگان، کنترل مستمر کیفیت و توجه به جزئیات، ما را به الگویی متمایز در صنعت حمل‌ونقل لوکس بدل ساخته است.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">خدمات شخصی‌سازی‌شده و تجربه‌ی منحصر به‌فرد</h4>
                            <p class="mb-30">VIPTaxiIran به‌جای ارائه‌ی خدمات عمومی، بر طراحی تجربه‌ای اختصاصی برای هر مشتری تمرکز دارد. از نحوه‌ی خوشامدگویی رانندگان تا انتخاب موسیقی و فضای داخلی خودرو، هر جزئی با هدف ایجاد حس خاص بودن و القای شأن ممتاز طراحی شده است.</p>
                        </div>

                        <div class="mb-40">
                            <h4 class="mb-20">اعتماد، امنیت و اعتبار اجتماعی</h4>
                            <p class="mb-30">VIPTaxiIran با رعایت اصول حرفه‌ای و اخلاقی، جایگاهی معتبر و قابل اتکا در میان مخاطبان خود کسب کرده است.</p>
                        </div>

                        <div class="mb-40" style="border-top: 2px solid #e0e0e0; padding-top: 30px;">
                            <h4 class="mb-20">نتیجه‌گیری</h4>
                            <p class="mb-30">VIPTaxiIran انتخاب کسانی است که ارزش زمان، کیفیت و تجربه‌ای ممتاز را می‌دانند. ما باور داریم که هر سفر، فرصتی برای خلق یک خاطره‌ی ارزشمند و لوکس است؛ خاطره‌ای که نه‌تنها مقصد، بلکه مسیر را نیز به تجربه‌ای فاخر و بی‌بدیل بدل می‌سازد.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Video -->
    <section class="video-wrapper video section-padding bg-img bg-fixed" data-background="{{ asset('site/img/slider/1.webp') }}"
             data-overlay-dark="4">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-subtitle">وی آی پی تاکسی ایران</div>
                    <div class="section-title white">رزرو آنلاین<span>تاکسی بین شهری</span></div>
                </div>
            </div>
            <div class="row">
                <div class="text-center col-md-12">
                    <a class="vid" href="https://youtu.be/1LxcTt1adfY">
                        <div class="vid-butn"><span class="icon"><i class="ti-control-play"></i></span></div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonials -->
    <section class="testimonials section-padding mt-15">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">توصیفات</div>
                    <div class="section-title">نظر کاربران</div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>درود بر شما محمد نیکنام هستم مسافر تهران به تبریز تشکر از شما راننده و ماشین مرتب بودن.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="تاکسی بین شهری" src="{{ asset('site/img/team/1.webp') }}"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>محمد نیکنام</h6>
                                    <p>مسافر تهران به تبریز</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>سلام پرویز رضا پور هستم ماشین عالی راننده وقت شناس بود ممنونم از کلاردشت اومدم تهران.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="رزرو تاکسی بین شهری" src="{{ asset('site/img/team/4.webp') }}"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>پرویز رضا پور</h6>
                                    <p>مسافر کلاردشت به تهران</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="stars">
                                <span class="rate"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
                                <div class="shap-left-top">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                    </svg>
                                </div>
                            </div>
                            <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p>عرض ادب و احترام سا را مومنی مسافر تهران به رشت متشکرم از سفر خوبی که با گروه شما داشتم.</p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"><img alt="رزرو تاکسی دربستی" src="{{ asset('site/img/team/4.webp') }}"/></div>
                                    <div class="shap-left-top">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6>سا را مومنی</h6>
                                    <p>مسافر تهران به رشت</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Team -->
    <section class="team section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle">تیم دارای مجوز</div>
                    <div class="section-title">تیم کارشناسان ما</div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="item"><img alt="تاکسی دربستی بین شهری" class="img-fluid" src="{{ asset('site/img/team/1.webp') }}" />
                            <div class="bottom-fade"></div>
                            <div class="butn icon-bg"><a class="vid" href="#">
                                    <div class="icon"><i class="ti-info"></i></div>
                                </a>
                                <div class="br-left-top"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                              xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                                <div class="br-right-bottom"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                  xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                            </div>
                            <div class="title">
                                <h4>پوریا میرزایی</h4>
                                <h6>مشاور فروش</h6>
                            </div>
                        </div>
                        <div class="item"><img alt="تاکسی بین شهری آنلاین" class="img-fluid" src="{{ asset('site/img/team/4.webp') }}" />
                            <div class="bottom-fade"></div>
                            <div class="info">
                                <div class="butn icon-bg"><a class="vid" href="#">
                                        <div class="icon"><i class="ti-info"></i></div>
                                    </a>
                                    <div class="br-left-top"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                  xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg></div>
                                    <div class="br-right-bottom"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                      xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg></div>
                                </div>
                                <div class="title">
                                    <h4>فروغ فدایی</h4>
                                    <h6>مشاور فروش</h6>
                                </div>
                            </div>
                        </div>
                        <div class="item"><img alt="تاکسی آنلاین بین شهری" class="img-fluid" src="{{ asset('site/img/team/5.webp') }}" />
                            <div class="bottom-fade"></div>
                            <div class="info">
                                <div class="butn icon-bg"><a class="vid" href="#">
                                        <div class="icon"><i class="ti-info"></i></div>
                                    </a>
                                    <div class="br-left-top"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                  xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg></div>
                                    <div class="br-right-bottom"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                      xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                    fill="#ffffff"></path>
                                        </svg></div>
                                </div>
                                <div class="title">
                                    <h4>مرضیه مرتضوی</h4>
                                    <h6>مشاور فروش</h6>
                                </div>
                            </div>
                        </div>
                        <div class="item"><img alt="تاکسی برون شهری" class="img-fluid" src="{{ asset('site/img/team/2.webp') }}" />
                            <div class="bottom-fade"></div>
                            <div class="butn icon-bg"><a class="vid" href="#">
                                    <div class="icon"><i class="ti-info"></i></div>
                                </a>
                                <div class="br-left-top"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                              xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                                <div class="br-right-bottom"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                  xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                            </div>
                            <div class="title">
                                <h4>نسترن سلطانی</h4>
                                <h6>بخش فروش</h6>
                            </div>
                        </div>
                        <div class="item"><img alt="برون شهری تاکسی آنلاین" class="img-fluid" src="{{ asset('site/img/team/4.webp') }}" />
                            <div class="bottom-fade"></div>
                            <div class="butn icon-bg"><a class="vid" href="#">
                                    <div class="icon"><i class="ti-info"></i></div>
                                </a>
                                <div class="br-left-top"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                              xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                                <div class="br-right-bottom"><svg class="w-11 h-11" fill="none" viewbox="0 0 11 11"
                                                                  xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#ffffff"></path>
                                    </svg></div>
                            </div>
                            <div class="title">
                                <h4>مهسا بهرامی</h4>
                                <h6>بخش دارایی</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-background="{{ asset('site/img/slider/3.webp') }}" data-overlay-dark="5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>رزرو آنلاین تاکسی بین شهری</h6>
                    <h5>آماده سفر هستید؟</h5>
                    <p>برای رزرو تاکسی بین شهری با ما تماس بگیرید.</p>
                    <a class="button-2 mt-15 mb-15" data-bs-target="#exampleModal" data-bs-toggle="modal" data-bs-whatever="@mdo" href="#0">الان رزرو کن<span class="ti-arrow-top-right"></span></a><a class="button-1 mt-15 mb-15 me-2" href="https://wa.me/989120983462" target="_blank" dir="ltr"><i class="fa-brands fa-whatsapp"></i>واتس اپ</a>
                </div>
            </div>
        </div>
    </section>
    <!-- Clients -->
    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="clients-logo"><a href="#0"><img alt="تاکسی دربستی تهران به اصفهان" src="{{ asset('site/img/clients/1.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="تاکسی بین شهری تهران به مشهد" src="{{ asset('site/img/clients/2.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="درخواست تاکسی بین شهری" src="{{ asset('site/img/clients/3.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="تاکسی دربستی فرودگاه" src="{{ asset('site/img/clients/4.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="تاکسی دربستی تهران به رشت" src="{{ asset('site/img/clients/5.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="درخواست تاکسی دربستی" src="{{ asset('site/img/clients/6.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="تاکسی بین شهری" src="{{ asset('site/img/clients/7.webp') }}" /></a></div>
                        <div class="clients-logo"><a href="#0"><img alt="رزرو تاکسی بین شهری" src="{{ asset('site/img/clients/8.webp') }}" /></a></div>
                    </div>
                </div>
            </div>
        </div>
    </section>



@endsection
