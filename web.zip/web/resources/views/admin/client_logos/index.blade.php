@extends('Shared::layouts.admin.main')

@section('title', 'لوگوهای برند')

@section('css')
    <style>
        .client-logo-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 1rem;
        }
        .client-logo-card {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }
        .client-logo-preview {
            height: 140px;
            background: #f5f6fa;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .client-logo-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .client-logo-body {
            padding: .9rem;
        }
        @media (max-width: 1199px) {
            .client-logo-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 767px) {
            .client-logo-grid { grid-template-columns: 1fr; }
        }
    </style>
@endsection

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            لوگوهای برند
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($tableMissing)
        <div class="alert alert-warning">
            جدول لوگوهای برند هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و صفحه اصلی فعلاً از لوگوهای قبلی استفاده می‌کند.
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن لوگو</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.client-logos.store') }}" enctype="multipart/form-data" class="row g-3 align-items-end">
                @csrf
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="{{ old('title') }}" class="form-control" maxlength="120" required @disabled($tableMissing)>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">ALT تصویر</label>
                    <input type="text" name="alt" value="{{ old('alt') }}" class="form-control" maxlength="255" placeholder="اگر خالی باشد عنوان استفاده می‌شود" @disabled($tableMissing)>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="url" name="link_url" value="{{ old('link_url') }}" class="form-control" maxlength="255" dir="ltr" @disabled($tableMissing)>
                </div>
                <div class="col-lg-1 col-md-3">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" class="form-control" min="0" max="9999" @disabled($tableMissing)>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">تصویر</label>
                    <input type="file" name="image" class="form-control" accept="image/*" required @disabled($tableMissing)>
                </div>
                <div class="col-lg-1 col-md-3">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked @disabled($tableMissing)>
                        <label class="form-check-label">فعال</label>
                    </div>
                    <button class="btn btn-success w-100" type="submit" @disabled($tableMissing)>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(! $tableMissing)
        <div class="client-logo-grid">
            @forelse($logos as $logo)
                <div class="client-logo-card">
                    <div class="client-logo-preview">
                        <img src="{{ $logo->image_url }}" alt="{{ $logo->display_alt }}">
                    </div>
                    <div class="client-logo-body">
                        <form method="POST" action="{{ route('admin.client-logos.update', $logo) }}" enctype="multipart/form-data" class="row g-2">
                            @csrf
                            @method('PUT')
                            <div class="col-12">
                                <label class="form-label">عنوان</label>
                                <input type="text" name="title" value="{{ old('title', $logo->title) }}" class="form-control form-control-sm" maxlength="120" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">ALT تصویر</label>
                                <input type="text" name="alt" value="{{ old('alt', $logo->alt) }}" class="form-control form-control-sm" maxlength="255">
                            </div>
                            <div class="col-8">
                                <label class="form-label">لینک</label>
                                <input type="url" name="link_url" value="{{ old('link_url', $logo->link_url) }}" class="form-control form-control-sm" maxlength="255" dir="ltr">
                            </div>
                            <div class="col-4">
                                <label class="form-label">ترتیب</label>
                                <input type="number" name="sort_order" value="{{ old('sort_order', $logo->sort_order) }}" class="form-control form-control-sm" min="0" max="9999">
                            </div>
                            <div class="col-12">
                                <label class="form-label">تعویض تصویر</label>
                                <input type="file" name="image" class="form-control form-control-sm" accept="image/*">
                            </div>
                            <div class="col-6">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="is_active" value="1" class="form-check-input" @checked($logo->is_active)>
                                    <label class="form-check-label">فعال</label>
                                </div>
                            </div>
                            <div class="col-6 text-end">
                                <button class="btn btn-sm btn-primary" type="submit">
                                    <i class="bx bx-save"></i>
                                    ذخیره
                                </button>
                            </div>
                        </form>
                        <form method="POST" action="{{ route('admin.client-logos.destroy', $logo) }}" class="mt-2" onsubmit="return confirm('این لوگو حذف شود؟')">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger w-100" type="submit">
                                <i class="bx bx-trash"></i>
                                حذف
                            </button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="alert alert-info mb-0">
                    هنوز لوگویی ثبت نشده است. تا زمان ثبت لوگو، صفحه اصلی از لوگوهای قبلی فایل‌سیستمی استفاده می‌کند.
                </div>
            @endforelse
        </div>

        <div class="mt-3">
            {{ $logos->links() }}
        </div>
    @endif
@endsection
