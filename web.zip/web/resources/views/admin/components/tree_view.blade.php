@props(['content', 'selected' => null, 'level' => 0, 'name' => 'parent_id', 'label' => 'name'])
@once
    @push('styles')
        <style>
            ul, #item-tree {
                list-style-type: none;
            }

            #item-tree {
                margin: 20px 0;
                padding: 0;
                border-right: 2px solid #5a8dee;
            }

            .caret {
                cursor: pointer;
                user-select: none;
                color: #5a8dee;
                font-weight: 600;
                transition: color 0.3s ease;
            }

            .caret:hover {
                color: #39da8a;
            }

            .caret::before {
                display: inline-block;
                margin-left: 6px;
                transition: transform 0.3s ease;
            }

            .caret-down::before {
                transform: rotate(-90deg);
            }

            .nested {
                display: none;
                margin-right: 15px;
                border-right: 1px dashed #dbe9ff;
                padding-right: 15px;
            }

            .active {
                display: block;
            }

            .tree-view-form-check {
                margin: 5px 0 !important;
                padding: 5px 10px !important;
                background: #f4f8ff;
                border-radius: 6px;
                border: 1px solid #e1e9ff;
            }

            .tree-view-form-check:hover {
                background-color: #e8f6f2;
            }

            .tree-view-form-check-input {
                margin-right: 10px !important;
                float: right !important;
                accent-color: #39da8a;
            }

            .form-label span {
                font-weight: bold;
                color: #5a8dee;
            }

            .bx-minus, .bxs-chevron-left {
                color: #39da8a;
                font-size: 16px;
                margin-right: 6px;
            }

            label > span {
                color: #222;
            }
        </style>
    @endpush

@endonce

@if($level == 0)
    <ul id="item-tree" class="px-4">
        <label class="form-label">
            <span>لطفا انتخاب کنید</span>
            <i class="bx bx-health font-size-1 text-danger mx-2"></i>
        </label>

        @if($name == 'parent_id')
            <li class="tree-view-form-check">
                <label>
                    <i class="bx bx-minus"></i>
                    <span>(هیچکدام)</span>
                    <input type="radio" name="{{ $name }}" class="tree-view-form-check-input" value="">
                </label>
            </li>
        @endif
@endif

@foreach ($content as $item)
    @php $hasChildren = $item->children && $item->children->count(); @endphp
    <li class="tree-view-form-check">
        <label>
            @if ($hasChildren) <i class="bx bxs-chevron-left caret"></i> @else <i class="bx bx-minus"></i> @endif   
            <span>{{ $item->$label }}</span>
            <input type="radio" class="tree-view-form-check-input" name="{{ $name }}" value="{{ $item->id }}" @checked($selected == $item->id)>
        </label>
        @if ($hasChildren)
            <ul class="nested">
                @include('page::admin.components.tree_view', [
                    'content' => $item->children,
                    'selected' => $selected,
                    'level' => $level + 1
                ])
            </ul>
        @endif
    </li>
@endforeach

@if($level == 0)
    </ul>
@endif

@once
    @push('scripts')
        <script>
            let toggleList = document.getElementsByClassName("caret");
            for (let i = 0; i < toggleList.length; i++) {
                toggleList[i].addEventListener("click", function() {
                    this.parentElement.querySelector(".nested").classList.toggle("active");
                    this.classList.toggle("caret-down");
                });
            }
        </script>
    @endpush
@endonce
