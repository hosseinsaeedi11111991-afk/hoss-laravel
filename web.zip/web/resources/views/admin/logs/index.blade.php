@extends('Shared::layouts.admin.main')

@section('title', 'لاگ سیستم')

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            لاگ سیستم
        </h4>
    </div>

    <div class="alert alert-info">
        این صفحه فقط برای مشاهده لاگ‌هاست. مقدارهای حساس مثل API key، token و password قبل از نمایش ماسک می‌شوند.
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">فیلتر لاگ‌ها</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="{{ route('admin.logs.index') }}" class="row g-3">
                <div class="col-lg-3 col-md-6">
                    <label class="form-label" for="file">فایل لاگ</label>
                    <select id="file" name="file" class="form-select">
                        @forelse($files as $file)
                            <option value="{{ $file['name'] }}" @selected($selectedFile === $file['name'])>
                                {{ $file['name'] }}
                            </option>
                        @empty
                            <option value="">فایلی وجود ندارد</option>
                        @endforelse
                    </select>
                </div>

                <div class="col-lg-2 col-md-6">
                    <label class="form-label" for="level">سطح</label>
                    <select id="level" name="level" class="form-select">
                        <option value="">همه</option>
                        @foreach($levels as $level)
                            <option value="{{ $level }}" @selected($selectedLevel === $level)>{{ strtoupper($level) }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-lg-2 col-md-6">
                    <label class="form-label" for="lines">تعداد خطوط</label>
                    <select id="lines" name="lines" class="form-select">
                        @foreach([100, 300, 500, 1000, 2000] as $option)
                            <option value="{{ $option }}" @selected($lines === $option)>{{ $option }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-lg-3 col-md-6">
                    <label class="form-label" for="q">جستجو</label>
                    <input
                        id="q"
                        name="q"
                        type="search"
                        value="{{ $query }}"
                        class="form-control"
                        placeholder="مثلاً SMS یا Faraz"
                    >
                </div>

                <div class="col-lg-2 col-md-12 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bx bx-search"></i>
                        نمایش
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between gap-3 flex-wrap">
            <h5 class="mb-0">نتیجه لاگ</h5>
            @if($selectedFile)
                <span class="badge bg-label-secondary" dir="ltr">{{ $selectedFile }}</span>
            @endif
        </div>
        <div class="card-body">
            @if($files->isEmpty())
                <div class="alert alert-warning mb-0">هیچ فایل لاگی در مسیر storage/logs پیدا نشد.</div>
            @elseif(empty($logLines))
                <div class="alert alert-warning mb-0">برای فیلتر انتخاب‌شده خطی پیدا نشد.</div>
            @else
                <div class="log-viewer" dir="ltr">
                    @foreach($logLines as $line)
                        <pre class="mb-1 p-2 rounded bg-light text-dark border" style="white-space: pre-wrap; word-break: break-word; font-size: 12px;">{{ $line }}</pre>
                    @endforeach
                </div>
            @endif
        </div>
    </div>
@endsection
