@extends('Shared::layouts.admin.main')

@section('title', 'سلامت سئو')

@php
    $typeLabels = [
        'title' => 'Title',
        'description' => 'Meta Description',
        'canonical' => 'Canonical',
        'heading' => 'Heading',
        'schema' => 'Schema',
        'image_alt' => 'تصاویر بدون ALT',
        'image_size' => 'تصاویر سنگین',
        'internal_links' => 'لینک داخلی',
        'broken_link' => 'لینک شکسته',
        'orphan_page' => 'صفحات یتیم',
        'outgoing_internal_links' => 'بدون لینک داخلی خروجی',
        'redirected_link' => 'لینک داخلی ریدایرکت‌شده',
        'sitemap' => 'Sitemap',
        'redirect' => 'Redirect',
        'page' => 'صفحه',
        'site' => 'سایت',
    ];
@endphp

@section('css')
    <style>
        .seo-health-summary {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .75rem;
        }

        .seo-health-card {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            padding: .9rem;
        }

        .seo-health-card span {
            display: block;
            color: #7f8ea3;
            font-size: .76rem;
            margin-bottom: .35rem;
        }

        .seo-health-card strong {
            color: #4f6074;
            font-size: 1.15rem;
        }

        .seo-health-table {
            table-layout: fixed;
            font-size: .84rem;
        }

        .seo-health-table th,
        .seo-health-table td {
            vertical-align: middle;
            white-space: normal;
            overflow-wrap: anywhere;
        }

        .seo-health-table .col-severity { width: 95px; }
        .seo-health-table .col-type { width: 145px; }

        @media (max-width: 991px) {
            .seo-health-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
    </style>
@endsection

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            <span>سئو/</span>
            سلامت سئو
        </h4>

        <form method="POST" action="{{ route('admin.seo.health.crawl') }}" class="mb-0">
            @csrf
            <button class="btn btn-primary" type="submit" @disabled($migrationMissing)>
                <i class="bx bx-search-alt"></i>
                شروع کرال دستی
            </button>
        </form>
    </div>

    @if($migrationMissing)
        <div class="alert alert-warning">
            جدول گزارش سلامت سئو هنوز ساخته نشده است. بعد از اجرای migration، کرال دستی فعال می‌شود.
        </div>
    @endif

    @if($report)
        <div class="alert alert-info">
            آخرین کرال:
            {{ $report->finished_at ? verta($report->finished_at)->format('Y/m/d H:i') : 'در حال اجرا یا بدون زمان پایان' }}
            @if($report->status === \App\Models\SeoHealthReport::STATUS_FAILED)
                <span class="text-danger d-block mt-1">{{ $report->error_message }}</span>
            @endif
        </div>
    @else
        <div class="alert alert-secondary">
            هنوز گزارشی ثبت نشده است. برای ساخت اولین گزارش، دکمه «شروع کرال دستی» را بزنید.
        </div>
    @endif

    <div class="seo-health-summary mb-4">
        <div class="seo-health-card"><span>صفحات بررسی‌شده</span><strong>{{ $summary['pages'] ?? 0 }}</strong></div>
        <div class="seo-health-card"><span>کل ایرادها</span><strong>{{ $summary['issues'] ?? 0 }}</strong></div>
        <div class="seo-health-card"><span>خطاها</span><strong>{{ $summary['errors'] ?? 0 }}</strong></div>
        <div class="seo-health-card"><span>هشدارها</span><strong>{{ $summary['warnings'] ?? 0 }}</strong></div>
    </div>

    @if(! empty($summary['by_type']))
        <div class="card mb-4">
            <div class="card-header">خلاصه بر اساس نوع ایراد</div>
            <div class="card-body d-flex flex-wrap gap-2">
                @foreach($summary['by_type'] as $type => $count)
                    <span class="badge bg-label-primary">
                        {{ $typeLabels[$type] ?? $type }}: {{ $count }}
                    </span>
                @endforeach
            </div>
        </div>
    @endif

    <div class="card">
        <div class="table-responsive">
            <table class="table table-striped seo-health-table mb-0">
                <thead>
                <tr>
                    <th class="col-severity">شدت</th>
                    <th class="col-type">نوع</th>
                    <th>آدرس</th>
                    <th>پیام</th>
                    <th>جزئیات</th>
                </tr>
                </thead>
                <tbody>
                @forelse($issues as $issue)
                    <tr>
                        <td>
                            @if(($issue['severity'] ?? '') === 'error')
                                <span class="badge bg-danger">خطا</span>
                            @else
                                <span class="badge bg-warning text-dark">هشدار</span>
                            @endif
                        </td>
                        <td>{{ $typeLabels[$issue['type'] ?? ''] ?? ($issue['type'] ?? '-') }}</td>
                        <td dir="ltr">{{ $issue['url'] ?? '-' }}</td>
                        <td>{{ $issue['message'] ?? '-' }}</td>
                        <td>{{ $issue['detail'] ?? '-' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-5">ایرادی در آخرین گزارش ثبت نشده است.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection
