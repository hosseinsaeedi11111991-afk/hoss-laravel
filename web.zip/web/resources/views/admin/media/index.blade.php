@extends('Shared::layouts.admin.main')

@section('title', 'رسانه')

@php
    use Illuminate\Support\Facades\Storage;
    use Modules\Attachment\Models\Attachment;

    $typeLabels = [
        Attachment::FILE_TYPE_IMAGE => 'تصویر',
        Attachment::FILE_TYPE_VIDEO => 'ویدئو',
        Attachment::FILE_TYPE_AUDIO => 'صدا',
        Attachment::FILE_TYPE_DOCUMENT => 'سند',
        Attachment::FILE_TYPE_OTHER => 'سایر',
    ];

    $humanSize = function ($bytes) {
        $bytes = (float) $bytes;
        return $bytes >= 1048576
            ? number_format($bytes / 1048576, 2) . ' MB'
            : number_format($bytes / 1024, 1) . ' KB';
    };
@endphp

@section('css')
    <style>
        .media-summary {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: .75rem;
        }
        .media-summary-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            padding: .85rem;
            background: #fff;
        }
        .media-summary-item span {
            display: block;
            color: #7f8ea3;
            font-size: .76rem;
            margin-bottom: .35rem;
        }
        .media-summary-item strong {
            color: #4f6074;
            font-size: 1.15rem;
        }
        .media-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 1rem;
        }
        .media-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }
        .media-preview {
            aspect-ratio: 4 / 3;
            background: #f5f6fa;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .media-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .media-preview i {
            font-size: 2.2rem;
            color: #8b9ab0;
        }
        .media-body {
            padding: .85rem;
        }
        .media-name {
            font-size: .84rem;
            font-weight: 600;
            color: #4f6074;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .media-meta {
            color: #7f8ea3;
            font-size: .76rem;
            line-height: 1.6;
        }
        .media-actions {
            display: flex;
            gap: .35rem;
            flex-wrap: wrap;
        }
        @media (max-width: 1199px) {
            .media-summary,
            .media-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        }
        @media (max-width: 767px) {
            .media-summary,
            .media-grid { grid-template-columns: 1fr; }
        }
    </style>
@endsection

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            رسانه
        </h4>
    </div>

    @if($tableMissing)
        <div class="alert alert-warning">
            جدول‌های رسانه هنوز در دیتابیس ساخته نشده‌اند. بعد از اجرای migrationهای Attachment، این بخش فعال می‌شود.
        </div>
    @endif

    <div class="media-summary mb-4">
        <div class="media-summary-item"><span>کل فایل‌ها</span><strong>{{ $summary['total'] }}</strong></div>
        <div class="media-summary-item"><span>تصاویر</span><strong>{{ $summary['images'] }}</strong></div>
        <div class="media-summary-item"><span>تصاویر فایل‌سیستم</span><strong>{{ $summary['public_images'] }}</strong></div>
        <div class="media-summary-item"><span>بدون اتصال</span><strong>{{ $summary['unused'] }}</strong></div>
        <div class="media-summary-item"><span>تصویر بدون ALT</span><strong>{{ $summary['without_alt'] }}</strong></div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('admin.media.store') }}" enctype="multipart/form-data" class="row g-3 align-items-end">
                @csrf
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">افزودن فایل</label>
                    <input type="file" name="file" class="form-control" @disabled($tableMissing)>
                </div>
                <div class="col-lg-5 col-md-6">
                    <label class="form-label">ALT تصویر</label>
                    <input type="text" name="image_alt" class="form-control" maxlength="255" placeholder="متن جایگزین تصویر" @disabled($tableMissing)>
                </div>
                <div class="col-lg-3">
                    <button class="btn btn-success" type="submit" @disabled($tableMissing)>
                        <i class="bx bx-upload"></i>
                        آپلود
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.media.index') }}" class="row g-3 align-items-end">
                <div class="col-lg-5 col-md-6">
                    <label class="form-label">جستجو</label>
                    <input type="text" name="q" value="{{ request('q') }}" class="form-control" placeholder="نام فایل، مسیر یا نوع">
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نوع فایل</label>
                    <select name="type" class="form-select">
                        <option value="">همه</option>
                        @foreach($typeLabels as $type => $label)
                            <option value="{{ $type }}" @selected(request('type') === $type)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-4 d-flex gap-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bx bx-search"></i>
                        جستجو
                    </button>
                    <a href="{{ route('admin.media.index') }}" class="btn btn-outline-secondary">پاک کردن</a>
                </div>
            </form>
        </div>
    </div>

    <form method="POST" action="{{ route('admin.media.bulkDestroy') }}" id="bulkDeleteMediaForm" class="d-none">
        @csrf
        @method('DELETE')
    </form>

    <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap mb-3">
        <div class="text-muted">{{ $attachments->total() }} فایل ثبت‌شده در دیتابیس</div>
        <button class="btn btn-outline-danger" type="submit" form="bulkDeleteMediaForm" id="bulkDeleteMediaButton" disabled>
            <i class="bx bx-trash"></i>
            حذف انتخاب‌شده‌ها
        </button>
    </div>

    <div class="media-grid">
        @forelse($attachments as $attachment)
            @php
                $url = Storage::disk($attachment->disk)->url($attachment->path);
                $alt = $attachment->display_alt ?? $attachment->meta->firstWhere('attribute', 'image_alt')?->value;
                $isImage = $attachment->file_type === Attachment::FILE_TYPE_IMAGE;
                $isUsed = $attachment->attachables->isNotEmpty();
            @endphp
            <div class="media-item">
                <div class="media-preview">
                    @if($isImage)
                        <a href="{{ $url }}" target="_blank" rel="noopener">
                            <img src="{{ $url }}" alt="{{ $alt ?: $attachment->file_name }}">
                        </a>
                    @else
                        <i class="bx bx-file"></i>
                    @endif
                </div>
                <div class="media-body">
                    <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                        <div class="media-name" title="{{ $attachment->file_name }}">{{ $attachment->file_name }}</div>
                        @if(! $isUsed)
                            <input class="form-check-input media-checkbox" type="checkbox" name="attachment_ids[]" value="{{ $attachment->id }}" form="bulkDeleteMediaForm" aria-label="انتخاب {{ $attachment->file_name }}">
                        @else
                            <span class="badge bg-label-secondary">در حال استفاده</span>
                        @endif
                    </div>

                    <div class="media-meta mb-2">
                        <div>{{ $typeLabels[$attachment->file_type] ?? $attachment->file_type }} | {{ $humanSize($attachment->file_size) }}</div>
                        <div dir="ltr">{{ $attachment->path }}</div>
                        <div>{{ $attachment->mime_type }}</div>
                    </div>

                    @if($isImage)
                        <form method="POST" action="{{ route('admin.media.update', $attachment) }}" class="mb-2">
                            @csrf
                            @method('PUT')
                            <label class="form-label mb-1">ALT</label>
                            @if(($attachment->alt_source ?? 'saved') === 'suggested')
                                <span class="badge bg-label-info mb-1">پیشنهادی</span>
                            @endif
                            <div class="input-group input-group-sm">
                                <input type="text" name="image_alt" class="form-control" value="{{ $alt }}" maxlength="255" placeholder="ALT تصویر">
                                <button class="btn btn-outline-primary" type="submit">
                                    <i class="bx bx-save"></i>
                                </button>
                            </div>
                        </form>
                    @endif

                    <div class="media-actions">
                        <a href="{{ $url }}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-info">
                            <i class="bx bx-show"></i>
                            مشاهده
                        </a>
                        @if(! $isUsed)
                            <form method="POST" action="{{ route('admin.media.destroy', $attachment) }}" class="d-inline single-delete-media-form">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                    <i class="bx bx-trash"></i>
                                    حذف
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="card">
                <div class="card-body text-center text-muted py-5">فایلی یافت نشد.</div>
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $attachments->links('pagination::bootstrap-5') }}
    </div>

    <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap mt-5 mb-3">
        <h5 class="mb-0">تصاویر موجود روی فایل‌سیستم</h5>
        <span class="text-muted">{{ $publicImages->total() }} تصویر فایل‌سیستم</span>
    </div>

    <div class="alert alert-info">
        این بخش عکس‌هایی را نشان می‌دهد که واقعاً داخل فایل‌سیستم سایت وجود دارند. حذف فایل‌ها برای جلوگیری از خطای Production فقط از بخش فایل‌های ثبت‌شده در دیتابیس انجام می‌شود، اما متن جایگزین این تصاویر از همین‌جا قابل ویرایش است.
    </div>

    <div class="media-grid">
        @forelse($publicImages as $image)
            <div class="media-item">
                <div class="media-preview">
                    <a href="{{ $image['url'] }}" target="_blank" rel="noopener">
                        <img src="{{ $image['url'] }}" alt="{{ $image['alt'] ?: $image['name'] }}">
                    </a>
                </div>
                <div class="media-body">
                    <div class="media-name" title="{{ $image['name'] }}">{{ $image['name'] }}</div>
                    <div class="media-meta mb-2">
                        <div>{{ strtoupper($image['extension']) }} | {{ $humanSize($image['size']) }}</div>
                        <div dir="ltr">{{ $image['relative'] }}</div>
                        <div>آخرین تغییر: {{ $image['modified_at'] }}</div>
                    </div>
                    <form method="POST" action="{{ route('admin.media.filesystemAlt') }}" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="image_path" value="{{ $image['relative'] }}">
                        <label class="form-label mb-1">متن جایگزین تصویر</label>
                        @if(($image['alt_source'] ?? 'saved') === 'suggested')
                            <span class="badge bg-label-info mb-1">پیشنهادی</span>
                        @endif
                        <div class="input-group input-group-sm">
                            <input type="text" name="image_alt" class="form-control" value="{{ $image['alt'] }}" maxlength="255" placeholder="متن جایگزین تصویر">
                            <button class="btn btn-outline-primary" type="submit">
                                <i class="bx bx-save"></i>
                            </button>
                        </div>
                    </form>
                    <div class="media-actions">
                        <a href="{{ $image['url'] }}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-info">
                            <i class="bx bx-show"></i>
                            مشاهده
                        </a>
                        <span class="badge bg-label-secondary align-self-center">فایل‌سیستم</span>
                    </div>
                </div>
            </div>
        @empty
            <div class="card">
                <div class="card-body text-center text-muted py-5">تصویری روی فایل‌سیستم یافت نشد.</div>
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $publicImages->links('pagination::bootstrap-5') }}
    </div>

    @push('scripts')
        <script>
            const mediaCheckboxes = document.querySelectorAll('.media-checkbox');
            const bulkDeleteMediaButton = document.getElementById('bulkDeleteMediaButton');
            const bulkDeleteMediaForm = document.getElementById('bulkDeleteMediaForm');

            function updateMediaBulkState() {
                const selected = document.querySelectorAll('.media-checkbox:checked').length;
                bulkDeleteMediaButton.disabled = selected === 0;
                bulkDeleteMediaButton.innerHTML = '<i class="bx bx-trash"></i> حذف انتخاب‌شده‌ها' + (selected ? ' (' + selected + ')' : '');
            }

            mediaCheckboxes.forEach((checkbox) => checkbox.addEventListener('change', updateMediaBulkState));

            if (bulkDeleteMediaForm) {
                bulkDeleteMediaForm.addEventListener('submit', function (event) {
                    const selected = document.querySelectorAll('.media-checkbox:checked').length;
                    if (!selected || !confirm(selected + ' فایل بدون اتصال حذف می‌شود. ادامه می‌دهید؟')) {
                        event.preventDefault();
                    }
                });
            }

            document.querySelectorAll('.single-delete-media-form').forEach((form) => {
                form.addEventListener('submit', function (event) {
                    if (!confirm('این فایل بدون اتصال حذف می‌شود. ادامه می‌دهید؟')) {
                        event.preventDefault();
                    }
                });
            });
        </script>
    @endpush
@endsection
