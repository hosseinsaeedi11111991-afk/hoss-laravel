@extends('Shared::layouts.admin.main')

@section('title', 'رضایت مشتریان')

@section('css')
    <style>
        .testimonial-admin-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1rem;
        }
        .testimonial-admin-card {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            background: #fff;
            padding: 1rem;
        }
        .testimonial-admin-preview {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            object-fit: cover;
            background: #f5f6fa;
        }
        @media (max-width: 991px) {
            .testimonial-admin-grid { grid-template-columns: 1fr; }
        }
    </style>
@endsection

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            رضایت مشتریان
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($tableMissing)
        <div class="alert alert-warning">
            جدول رضایت مشتریان هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و صفحه اصلی فعلاً از نظرات قبلی استفاده می‌کند.
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن نظر مشتری</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.testimonials.store') }}" enctype="multipart/form-data" class="row g-3">
                @csrf
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نام مشتری</label>
                    <input type="text" name="name" value="{{ old('name') }}" class="form-control" maxlength="120" required @disabled($tableMissing)>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">عنوان/نقش</label>
                    <input type="text" name="role" value="{{ old('role', 'مشتری') }}" class="form-control" maxlength="160" @disabled($tableMissing)>
                </div>
                <div class="col-lg-2 col-md-4">
                    <label class="form-label">امتیاز</label>
                    <select name="rating" class="form-select" required @disabled($tableMissing)>
                        @for($rate = 5; $rate >= 1; $rate--)
                            <option value="{{ $rate }}" @selected((int) old('rating', 5) === $rate)>{{ $rate }}</option>
                        @endfor
                    </select>
                </div>
                <div class="col-lg-2 col-md-4">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" class="form-control" min="0" max="9999" @disabled($tableMissing)>
                </div>
                <div class="col-lg-2 col-md-4">
                    <label class="form-label">عکس</label>
                    <input type="file" name="image" class="form-control" accept="image/*" @disabled($tableMissing)>
                </div>
                <div class="col-md-6">
                    <label class="form-label">ALT عکس</label>
                    <input type="text" name="image_alt" value="{{ old('image_alt') }}" class="form-control" maxlength="255" placeholder="اگر خالی باشد نام مشتری استفاده می‌شود" @disabled($tableMissing)>
                </div>
                <div class="col-md-6">
                    <div class="form-check mt-4">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked @disabled($tableMissing)>
                        <label class="form-check-label">فعال باشد</label>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label">متن نظر</label>
                    <textarea name="body" rows="4" class="form-control" maxlength="1200" required @disabled($tableMissing)>{{ old('body') }}</textarea>
                </div>
                <div class="col-12 text-end">
                    <button class="btn btn-success" type="submit" @disabled($tableMissing)>
                        <i class="bx bx-plus"></i>
                        افزودن
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if(! $tableMissing)
        <div class="testimonial-admin-grid">
            @forelse($testimonials as $testimonial)
                <div class="testimonial-admin-card">
                    <form method="POST" action="{{ route('admin.testimonials.update', $testimonial) }}" enctype="multipart/form-data" class="row g-3">
                        @csrf
                        @method('PUT')
                        <div class="col-12 d-flex align-items-center gap-3">
                            <img class="testimonial-admin-preview" src="{{ $testimonial->image_url }}" alt="{{ $testimonial->display_alt }}">
                            <div class="flex-grow-1">
                                <label class="form-label">تعویض عکس</label>
                                <input type="file" name="image" class="form-control form-control-sm" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">نام مشتری</label>
                            <input type="text" name="name" value="{{ old('name', $testimonial->name) }}" class="form-control form-control-sm" maxlength="120" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">عنوان/نقش</label>
                            <input type="text" name="role" value="{{ old('role', $testimonial->role) }}" class="form-control form-control-sm" maxlength="160">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">ALT عکس</label>
                            <input type="text" name="image_alt" value="{{ old('image_alt', $testimonial->image_alt) }}" class="form-control form-control-sm" maxlength="255">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">امتیاز</label>
                            <select name="rating" class="form-select form-select-sm" required>
                                @for($rate = 5; $rate >= 1; $rate--)
                                    <option value="{{ $rate }}" @selected((int) old('rating', $testimonial->rating) === $rate)>{{ $rate }}</option>
                                @endfor
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">ترتیب</label>
                            <input type="number" name="sort_order" value="{{ old('sort_order', $testimonial->sort_order) }}" class="form-control form-control-sm" min="0" max="9999">
                        </div>
                        <div class="col-12">
                            <label class="form-label">متن نظر</label>
                            <textarea name="body" rows="4" class="form-control form-control-sm" maxlength="1200" required>{{ old('body', $testimonial->body) }}</textarea>
                        </div>
                        <div class="col-6">
                            <div class="form-check mt-1">
                                <input type="checkbox" name="is_active" value="1" class="form-check-input" @checked($testimonial->is_active)>
                                <label class="form-check-label">فعال</label>
                            </div>
                        </div>
                        <div class="col-6 text-end">
                            <button class="btn btn-sm btn-primary" type="submit">
                                <i class="bx bx-save"></i>
                                ذخیره
                            </button>
                        </div>
                    </form>
                    <form method="POST" action="{{ route('admin.testimonials.destroy', $testimonial) }}" class="mt-2" onsubmit="return confirm('این نظر حذف شود؟')">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-sm btn-outline-danger w-100" type="submit">
                            <i class="bx bx-trash"></i>
                            حذف
                        </button>
                    </form>
                </div>
            @empty
                <div class="alert alert-info mb-0">
                    هنوز نظری ثبت نشده است. تا زمان ثبت نظر، صفحه اصلی از نظرات قبلی استفاده می‌کند.
                </div>
            @endforelse
        </div>

        <div class="mt-3">
            {{ $testimonials->links() }}
        </div>
    @endif
@endsection
