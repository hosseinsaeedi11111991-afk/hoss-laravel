@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش ریدایرکت')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.seo.redirects.index') }}">ریدایرکت‌ها/</a></span>
        ویرایش ریدایرکت
    </h4>

    @include('admin.seo_redirects.partials.form')
@endsection
