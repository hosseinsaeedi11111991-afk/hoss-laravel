<form method="POST" action="{{ $redirect->exists ? route('admin.seo.redirects.update', $redirect) : route('admin.seo.redirects.store') }}">
    @csrf
    @if($redirect->exists)
        @method('PUT')
    @endif

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6 mb-3">
                    <label class="form-label" for="source_path">آدرس مبدا</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="bx bx-link"></i></span>
                        <input id="source_path" dir="ltr" type="text" name="source_path" class="form-control" value="{{ old('source_path', $redirect->source_path) }}" placeholder="/old-url">
                    </div>
                    <small class="text-muted">فقط مسیر را وارد کنید. مثال: /old-page</small>
                    @error('source_path')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="col-lg-6 mb-3">
                    <label class="form-label" for="target_url">آدرس مقصد</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="bx bx-link-external"></i></span>
                        <input id="target_url" dir="ltr" type="text" name="target_url" class="form-control" value="{{ old('target_url', $redirect->target_url) }}" placeholder="/new-url یا https://example.com/new-url">
                    </div>
                    <small class="text-muted">برای 410 می‌توانید مقصد را خالی بگذارید.</small>
                    @error('target_url')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="col-md-4 mb-3">
                    <label class="form-label" for="status_code">نوع ریدایرکت</label>
                    <select id="status_code" name="status_code" class="form-select">
                        @foreach(\App\Models\SeoRedirect::statuses() as $code => $label)
                            <option value="{{ $code }}" @selected((int) old('status_code', $redirect->status_code) === (int) $code)>{{ $label }}</option>
                        @endforeach
                    </select>
                    @error('status_code')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="col-md-4 mb-3 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input type="hidden" name="is_active" value="0">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" @checked(old('is_active', $redirect->is_active ?? true))>
                        <label class="form-check-label" for="is_active">فعال باشد</label>
                    </div>
                </div>

                <div class="col-12 mb-3">
                    <label class="form-label" for="notes">یادداشت</label>
                    <textarea id="notes" name="notes" class="form-control" rows="3">{{ old('notes', $redirect->notes) }}</textarea>
                    @error('notes')<div class="text-danger">{{ $message }}</div>@enderror
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bx bx-save"></i>
                    ذخیره
                </button>
                <a href="{{ route('admin.seo.redirects.index') }}" class="btn btn-outline-secondary">بازگشت</a>
            </div>
        </div>
    </div>
</form>
