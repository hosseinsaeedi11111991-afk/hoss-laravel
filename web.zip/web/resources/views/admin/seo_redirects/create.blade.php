@extends('Shared::layouts.admin.main')

@section('title', 'افزودن ریدایرکت')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.seo.redirects.index') }}">ریدایرکت‌ها/</a></span>
        افزودن ریدایرکت
    </h4>

    @include('admin.seo_redirects.partials.form')
@endsection
