@extends('Shared::layouts.admin.main')

@section('title', 'خدمات فوتر')

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            خدمات فوتر
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($tableMissing)
        <div class="alert alert-warning">
            جدول لینک‌های خدمات فوتر هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و سایت فعلاً از آیتم‌های قبلی فوتر استفاده می‌کند.
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن لینک خدمات</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.footer-service-links.store') }}" class="row g-3 align-items-end">
                @csrf
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="{{ old('title') }}" class="form-control" maxlength="160" required @disabled($tableMissing)>
                </div>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="text" name="url" value="{{ old('url') }}" class="form-control" maxlength="255" dir="ltr" placeholder="/reservation یا https://..." @disabled($tableMissing)>
                </div>
                <div class="col-lg-2 col-md-4">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" class="form-control" min="0" max="9999" @disabled($tableMissing)>
                </div>
                <div class="col-lg-1 col-md-4">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked @disabled($tableMissing)>
                        <label class="form-check-label">فعال</label>
                    </div>
                </div>
                <div class="col-lg-1 col-md-4">
                    <button class="btn btn-success w-100" type="submit" @disabled($tableMissing)>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if(! $tableMissing)
        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>لینک</th>
                        <th>ترتیب</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($links as $link)
                        <tr>
                            <td colspan="5">
                                <form method="POST" action="{{ route('admin.footer-service-links.update', $link) }}" class="row g-2 align-items-center">
                                    @csrf
                                    @method('PUT')
                                    <div class="col-lg-3 col-md-6">
                                        <input type="text" name="title" value="{{ old('title', $link->title) }}" class="form-control form-control-sm" maxlength="160" required>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <input type="text" name="url" value="{{ old('url', $link->url) }}" class="form-control form-control-sm" maxlength="255" dir="ltr">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <input type="number" name="sort_order" value="{{ old('sort_order', $link->sort_order) }}" class="form-control form-control-sm" min="0" max="9999">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="is_active" value="1" class="form-check-input" @checked($link->is_active)>
                                            <label class="form-check-label">فعال</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-6 d-flex gap-2">
                                        <button class="btn btn-sm btn-primary" type="submit">
                                            <i class="bx bx-save"></i>
                                            ذخیره
                                        </button>
                                    </div>
                                </form>
                                <form method="POST" action="{{ route('admin.footer-service-links.destroy', $link) }}" class="mt-2" onsubmit="return confirm('این لینک حذف شود؟')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger" type="submit">
                                        <i class="bx bx-trash"></i>
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                هنوز لینکی ثبت نشده است. تا زمان ثبت لینک، سایت از آیتم‌های قبلی فوتر استفاده می‌کند.
                            </td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3">
            {{ $links->links() }}
        </div>
    @endif
@endsection
