@extends('Shared::layouts.admin.main')

@section('title', 'معرفی صفحه اصلی')

@section('main')
    @php
        $source = $section ?: (object) $data;
        $features = old('features', implode(PHP_EOL, $section?->features ?: ($data['features'] ?? [])));
    @endphp

    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            معرفی صفحه اصلی
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($tableMissing)
        <div class="alert alert-warning">
            جدول بخش معرفی صفحه اصلی هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود و صفحه اصلی فعلاً از محتوای قبلی استفاده می‌کند.
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">ویرایش سکشن معرفی</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.home-about.update') }}" enctype="multipart/form-data" class="row g-3">
                @csrf
                @method('PUT')

                <div class="col-md-4">
                    <label class="form-label">زیرعنوان</label>
                    <input type="text" name="subtitle" value="{{ old('subtitle', $source->subtitle ?? '') }}" class="form-control" maxlength="120" required @disabled($tableMissing)>
                </div>
                <div class="col-md-4">
                    <label class="form-label">عنوان اصلی</label>
                    <input type="text" name="title" value="{{ old('title', $source->title ?? '') }}" class="form-control" maxlength="160" required @disabled($tableMissing)>
                </div>
                <div class="col-md-4">
                    <label class="form-label">عنوان طلایی/تکمیلی</label>
                    <input type="text" name="highlight_title" value="{{ old('highlight_title', $source->highlight_title ?? '') }}" class="form-control" maxlength="160" @disabled($tableMissing)>
                </div>
                <div class="col-12">
                    <label class="form-label">متن</label>
                    <textarea name="body" rows="6" class="form-control" maxlength="2500" required @disabled($tableMissing)>{{ old('body', $source->body ?? '') }}</textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">آیتم‌های تیک‌دار</label>
                    <textarea name="features" rows="4" class="form-control" maxlength="1000" placeholder="هر آیتم در یک خط" @disabled($tableMissing)>{{ $features }}</textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">لینک ویدئو</label>
                    <input type="text" name="video_url" value="{{ old('video_url', $source->video_url ?? '') }}" class="form-control" maxlength="255" dir="ltr" @disabled($tableMissing)>

                    <label class="form-label mt-3">ALT عکس</label>
                    <input type="text" name="image_alt" value="{{ old('image_alt', $source->image_alt ?? ($source->image_alt ?? '')) }}" class="form-control" maxlength="255" @disabled($tableMissing)>
                </div>
                <div class="col-md-6">
                    <label class="form-label">عکس جدید</label>
                    <input type="file" name="image" class="form-control" accept="image/*" @disabled($tableMissing)>
                    <div class="form-check mt-2">
                        <input type="checkbox" name="remove_image" value="1" class="form-check-input" @disabled($tableMissing || ! $section?->image_path)>
                        <label class="form-check-label">حذف عکس اختصاصی و استفاده از عکس پیش‌فرض</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">پیش‌نمایش عکس فعلی</label>
                    <div>
                        <img src="{{ $section?->image_url ?? ($data['image_url'] ?? asset('site/img/about.webp')) }}" alt="{{ $section?->display_alt ?? ($data['image_alt'] ?? 'تاکسی بین شهری') }}" style="max-width: 260px; border-radius: 8px;">
                    </div>
                </div>
                <div class="col-12 text-end">
                    <button class="btn btn-primary" type="submit" @disabled($tableMissing)>
                        <i class="bx bx-save"></i>
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
