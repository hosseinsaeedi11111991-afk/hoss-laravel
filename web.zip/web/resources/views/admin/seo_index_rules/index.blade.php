@extends('Shared::layouts.admin.main')

@section('title', 'تنظیمات ایندکس سئو')

@section('css')
    <style>
        .seo-index-summary {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .75rem;
        }

        .seo-index-summary-item {
            border: 1px solid rgba(67, 89, 113, .12);
            border-radius: 8px;
            padding: .85rem;
            background: #fff;
        }

        .seo-index-summary-item span {
            display: block;
            color: #7f8ea3;
            font-size: .75rem;
            margin-bottom: .35rem;
        }

        .seo-index-summary-item strong {
            color: #4f6074;
            font-size: 1.1rem;
        }

        .seo-index-table {
            table-layout: fixed;
            font-size: .84rem;
        }

        .seo-index-table th,
        .seo-index-table td {
            vertical-align: middle;
            white-space: normal;
            overflow-wrap: anywhere;
        }

        .seo-index-table .col-actions { width: 120px; }
        .seo-index-table .col-status { width: 92px; }
        .seo-index-table .col-priority { width: 84px; }

        @media (max-width: 991px) {
            .seo-index-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
    </style>
@endsection

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            <span>سئو/</span>
            تنظیمات ایندکس
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($migrationMissing)
        <div class="alert alert-warning">
            جدول تنظیمات ایندکس هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت noindex فعال می‌شود و سایت بدون خطا با رفتار قبلی ادامه می‌دهد.
        </div>
    @endif

    <div class="seo-index-summary mb-4">
        <div class="seo-index-summary-item"><span>کل قوانین</span><strong>{{ $summary['total'] }}</strong></div>
        <div class="seo-index-summary-item"><span>فعال</span><strong>{{ $summary['active'] }}</strong></div>
        <div class="seo-index-summary-item"><span>noindex</span><strong>{{ $summary['noindex'] }}</strong></div>
        <div class="seo-index-summary-item"><span>حذف از sitemap</span><strong>{{ $summary['sitemap_excluded'] }}</strong></div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن قانون جدید</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.seo.index-rules.store') }}" class="row g-3">
                @csrf
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نام</label>
                    <input type="text" name="name" class="form-control" value="{{ old('name') }}" placeholder="مثلاً فیلتر جستجو" @disabled($migrationMissing)>
                    @error('name')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">نوع تطبیق</label>
                    <select name="match_type" class="form-select" @disabled($migrationMissing)>
                        @foreach(\App\Models\SeoIndexRule::matchTypes() as $value => $label)
                            <option value="{{ $value }}" @selected(old('match_type', 'query_key') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                    @error('match_type')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">الگو</label>
                    <input type="text" name="pattern" class="form-control" value="{{ old('pattern') }}" dir="ltr" placeholder="s یا filter_* یا /search*" @disabled($migrationMissing)>
                    @error('pattern')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">Robots</label>
                    <select name="robots_directive" class="form-select" @disabled($migrationMissing)>
                        @foreach(\App\Models\SeoIndexRule::robotsDirectives() as $value => $label)
                            <option value="{{ $value }}" @selected(old('robots_directive', \App\Models\SeoIndexRule::ROBOTS_NOINDEX_FOLLOW) === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                    @error('robots_directive')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">اولویت</label>
                    <input type="number" name="priority" class="form-control" value="{{ old('priority', 100) }}" min="1" @disabled($migrationMissing)>
                    @error('priority')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label">یادداشت</label>
                    <input type="text" name="notes" class="form-control" value="{{ old('notes') }}" @disabled($migrationMissing)>
                    @error('notes')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-lg-4 col-md-6 d-flex align-items-end gap-4">
                    <div class="form-check">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" id="new-rule-active" @checked(old('is_active', true)) @disabled($migrationMissing)>
                        <label class="form-check-label" for="new-rule-active">فعال</label>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="exclude_from_sitemap" value="1" class="form-check-input" id="new-rule-sitemap" @checked(old('exclude_from_sitemap')) @disabled($migrationMissing)>
                        <label class="form-check-label" for="new-rule-sitemap">حذف از sitemap</label>
                    </div>
                </div>
                <div class="col-lg-4 d-flex align-items-end justify-content-lg-end">
                    <button class="btn btn-success" type="submit" @disabled($migrationMissing)>
                        <i class="bx bx-plus"></i>
                        ثبت قانون
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-striped seo-index-table mb-0">
                <thead>
                <tr>
                    <th>نام</th>
                    <th>نوع</th>
                    <th>الگو</th>
                    <th>Robots</th>
                    <th class="col-priority">اولویت</th>
                    <th class="col-status">وضعیت</th>
                    <th>یادداشت</th>
                    <th class="col-actions">عملیات</th>
                </tr>
                </thead>
                <tbody>
                @forelse($rules as $rule)
                    <tr>
                        <td>
                            <form id="rule-update-{{ $rule->id }}" method="POST" action="{{ route('admin.seo.index-rules.update', $rule) }}">
                                @csrf
                                @method('PUT')
                                <input type="text" name="name" class="form-control form-control-sm" value="{{ $rule->name }}">
                            </form>
                        </td>
                        <td>
                            <select name="match_type" form="rule-update-{{ $rule->id }}" class="form-select form-select-sm">
                                @foreach(\App\Models\SeoIndexRule::matchTypes() as $value => $label)
                                    <option value="{{ $value }}" @selected($rule->match_type === $value)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </td>
                        <td><input type="text" name="pattern" form="rule-update-{{ $rule->id }}" class="form-control form-control-sm" value="{{ $rule->pattern }}" dir="ltr"></td>
                        <td>
                            <select name="robots_directive" form="rule-update-{{ $rule->id }}" class="form-select form-select-sm">
                                @foreach(\App\Models\SeoIndexRule::robotsDirectives() as $value => $label)
                                    <option value="{{ $value }}" @selected($rule->robots_directive === $value)>{{ $label }}</option>
                                @endforeach
                            </select>
                            @if($rule->exclude_from_sitemap)
                                <span class="badge bg-label-warning mt-1">حذف از sitemap</span>
                            @endif
                        </td>
                        <td><input type="number" name="priority" form="rule-update-{{ $rule->id }}" class="form-control form-control-sm" value="{{ $rule->priority }}" min="1"></td>
                        <td>
                            <div class="form-check mb-2">
                                <input type="checkbox" name="is_active" form="rule-update-{{ $rule->id }}" value="1" class="form-check-input" id="rule-active-{{ $rule->id }}" @checked($rule->is_active)>
                                <label class="form-check-label" for="rule-active-{{ $rule->id }}">فعال</label>
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="exclude_from_sitemap" form="rule-update-{{ $rule->id }}" value="1" class="form-check-input" id="rule-sitemap-{{ $rule->id }}" @checked($rule->exclude_from_sitemap)>
                                <label class="form-check-label" for="rule-sitemap-{{ $rule->id }}">sitemap</label>
                            </div>
                        </td>
                        <td><input type="text" name="notes" form="rule-update-{{ $rule->id }}" class="form-control form-control-sm" value="{{ $rule->notes }}"></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-warning" title="ذخیره" form="rule-update-{{ $rule->id }}">
                                    <i class="bx bx-save"></i>
                                </button>
                                <form method="POST" action="{{ route('admin.seo.index-rules.destroy', $rule) }}" class="delete-form">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-danger" title="حذف">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center text-muted py-5">هنوز قانونی برای noindex یا مدیریت crawl ثبت نشده است.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        {{ $rules->links('pagination::bootstrap-5') }}
    </div>
@endsection
