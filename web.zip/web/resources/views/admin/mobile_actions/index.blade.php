@extends('Shared::layouts.admin.main')

@section('title', 'اکشن‌های موبایل')

@section('main')
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
        <h4 class="breadcrumb-wrapper mb-0">
            <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
            اکشن‌های موبایل
        </h4>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if($contactsTableMissing || $linksTableMissing)
        <div class="alert alert-warning">
            جدول تنظیمات تماس یا لینک‌های موبایل هنوز در دیتابیس ساخته نشده است. بعد از اجرای migration، مدیریت کامل فعال می‌شود و سایت تا آن زمان از دکمه‌های قبلی استفاده می‌کند.
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">تنظیم شماره تماس و واتساپ</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.mobile-actions.contact.update') }}" class="row g-3 align-items-end">
                @csrf
                @method('PUT')
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">شماره تماس</label>
                    <input type="text" name="phone_number" value="{{ old('phone_number', $contact->phone_number ?? '09120983462') }}" class="form-control" maxlength="40" dir="ltr" required @disabled($contactsTableMissing)>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">شماره واتساپ</label>
                    <input type="text" name="whatsapp_number" value="{{ old('whatsapp_number', $contact->whatsapp_number ?? '09120983462') }}" class="form-control" maxlength="40" dir="ltr" required @disabled($contactsTableMissing)>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">نمایش شماره</label>
                    <input type="text" name="display_phone" value="{{ old('display_phone', $contact->display_phone ?? '+98 912 098 3462') }}" class="form-control" maxlength="80" dir="ltr" required @disabled($contactsTableMissing)>
                </div>
                <div class="col-lg-2 col-md-6">
                    <button class="btn btn-primary w-100" type="submit" @disabled($contactsTableMissing)>
                        <i class="bx bx-save"></i>
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">افزودن آیتم نوار پایین موبایل</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.mobile-actions.store') }}" class="row g-3 align-items-end">
                @csrf
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">عنوان</label>
                    <input type="text" name="title" value="{{ old('title') }}" class="form-control" maxlength="120" required @disabled($linksTableMissing)>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">نوع لینک</label>
                    <select name="link_type" class="form-select" required @disabled($linksTableMissing)>
                        @foreach($linkTypes as $value => $label)
                            <option value="{{ $value }}" @selected(old('link_type', 'custom') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-2 col-md-6">
                    <label class="form-label">آیکون</label>
                    <select name="icon_key" class="form-select" required @disabled($linksTableMissing)>
                        @foreach($iconKeys as $value => $label)
                            <option value="{{ $value }}" @selected(old('icon_key', 'custom') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label class="form-label">لینک اختیاری</label>
                    <input type="text" name="url" value="{{ old('url') }}" class="form-control" maxlength="255" dir="ltr" placeholder="خالی بماند تا از نوع لینک ساخته شود" @disabled($linksTableMissing)>
                </div>
                <div class="col-lg-1 col-md-4">
                    <label class="form-label">ترتیب</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" class="form-control" min="0" max="9999" @disabled($linksTableMissing)>
                </div>
                <div class="col-lg-1 col-md-4">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" checked @disabled($linksTableMissing)>
                        <label class="form-check-label">فعال</label>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="open_in_new_tab" value="1" class="form-check-input" @disabled($linksTableMissing)>
                        <label class="form-check-label">تب جدید</label>
                    </div>
                </div>
                <div class="col-lg-1 col-md-4">
                    <button class="btn btn-success w-100" type="submit" @disabled($linksTableMissing)>
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if(! $linksTableMissing)
        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>نوع/آیکون</th>
                        <th>لینک دستی</th>
                        <th>ترتیب</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($links as $link)
                        <tr>
                            <td colspan="6">
                                <form method="POST" action="{{ route('admin.mobile-actions.update', $link) }}" class="row g-2 align-items-center">
                                    @csrf
                                    @method('PUT')
                                    <div class="col-lg-2 col-md-6">
                                        <input type="text" name="title" value="{{ old('title', $link->title) }}" class="form-control form-control-sm" maxlength="120" required>
                                    </div>
                                    <div class="col-lg-2 col-md-6">
                                        <select name="link_type" class="form-select form-select-sm" required>
                                            @foreach($linkTypes as $value => $label)
                                                <option value="{{ $value }}" @selected(old('link_type', $link->link_type) === $value)>{{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-6">
                                        <select name="icon_key" class="form-select form-select-sm" required>
                                            @foreach($iconKeys as $value => $label)
                                                <option value="{{ $value }}" @selected(old('icon_key', $link->icon_key) === $value)>{{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <input type="text" name="url" value="{{ old('url', $link->url) }}" class="form-control form-control-sm" maxlength="255" dir="ltr">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <input type="number" name="sort_order" value="{{ old('sort_order', $link->sort_order) }}" class="form-control form-control-sm" min="0" max="9999">
                                    </div>
                                    <div class="col-lg-1 col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="is_active" value="1" class="form-check-input" @checked($link->is_active)>
                                            <label class="form-check-label">فعال</label>
                                        </div>
                                        <div class="form-check">
                                            <input type="checkbox" name="open_in_new_tab" value="1" class="form-check-input" @checked($link->open_in_new_tab)>
                                            <label class="form-check-label">تب جدید</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-6">
                                        <button class="btn btn-sm btn-primary w-100" type="submit">
                                            <i class="bx bx-save"></i>
                                        </button>
                                    </div>
                                </form>
                                <form method="POST" action="{{ route('admin.mobile-actions.destroy', $link) }}" class="mt-2" onsubmit="return confirm('این آیتم حذف شود؟')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger" type="submit">
                                        <i class="bx bx-trash"></i>
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                هنوز آیتمی ثبت نشده است. تا زمان ثبت آیتم، سایت از دکمه‌های قبلی استفاده می‌کند.
                            </td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3">
            {{ $links->links() }}
        </div>
    @endif

    <div class="card mt-4">
        <div class="card-header">
            <h5 class="mb-0">دکمه‌های پیش‌فرض فعلی</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>لینک</th>
                        <th>آیکون</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($legacyLinks as $legacyLink)
                        <tr>
                            <td>{{ $legacyLink['title'] }}</td>
                            <td dir="ltr">{{ $legacyLink['url'] }}</td>
                            <td>{{ $legacyLink['icon_key'] }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
