<div class="item">
    <div class="stars">
        <span class="rate">
            @for($star = 1; $star <= (int) ($testimonial['rating'] ?? 5); $star++)
                <i class="fa-solid fa-star"></i>
            @endfor
        </span>
        <div class="shap-left-top">
            <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
            </svg>
        </div>
        <div class="shap-right-bottom">
            <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
            </svg>
        </div>
    </div>
    <i class="fa-solid fa-quote-left"></i>
    <div class="text">
        <p>{{ $testimonial['body'] }}</p>
    </div>
    <div class="info mt-30">
        <div class="img-curv">
            <div class="img"><img alt="{{ $testimonial['image_alt'] }}" src="{{ $testimonial['image_url'] }}"/></div>
            <div class="shap-left-top">
                <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                </svg>
            </div>
            <div class="shap-right-bottom">
                <svg class="w-11 h-11" fill="none" viewbox="0 0 11 11" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#ffffff"></path>
                </svg>
            </div>
        </div>
        <div class="ml-30">
            <h6>{{ $testimonial['name'] }}</h6>
            <p>{{ $testimonial['role'] }}</p>
        </div>
    </div>
</div>
