<?php

namespace App\Traits;

trait StringHelpers
{
    /**
     * Convert Persian/Arabic digits in the given string to English digits.
     *
     * @param string|null $input
     * @return string|null
     */
    public function convertToEnglishDigits(?string $input): ?string
    {
        if ($input === null) {
            return null;
        }

        $persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabicDigits  = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        $converted = str_replace($persianDigits, $englishDigits, $input);
        $converted = str_replace($arabicDigits, $englishDigits, $converted);

        return $converted;
    }

    /**
     * Generate a URL friendly "slug" from a given string.
     *
     * @param string $string
     * @param string $separator
     * @return string
     */
    public function slugify(string $string, string $separator = '-'): string
    {
        // Normalize characters and remove special characters
        $slug = preg_replace('/[^\p{L}\p{N}\s]+/u', '', $string);
        // Replace whitespace with separator
        $slug = preg_replace('/[\s]+/u', $separator, $slug);
        // Lowercase the slug
        $slug = mb_strtolower($slug);

        return trim($slug, $separator);
    }
}
