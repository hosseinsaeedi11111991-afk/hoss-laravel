<?php

namespace App\Http\Controllers;

use App\Models\ClientLogo;
use App\Models\Testimonial;
use App\Services\HomeFaqService;
use App\Services\HomeAboutSectionService;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Modules\Cars\Models\Car;
use Modules\Cars\Models\CarCategory;
use Modules\Blog\Models\BlogPost;
use Modules\Reservation\Models\PopularRoute;

class WelcomeController extends Controller
{
    public function index(HomeFaqService $homeFaqService, HomeAboutSectionService $homeAboutSectionService)
    {
        $cars = Car::with('category')->where('status','available')->limit(4)->get();
        $carCategories = CarCategory::all();
        $blogPosts = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->with(['category', 'user', 'comments'])
            ->orderBy('published_at', 'desc')
            ->limit(6)
            ->get();
        $popularRoutes = PopularRoute::active()->get();
        $clientLogos = $this->clientLogos();
        $homeAboutSection = $homeAboutSectionService->data();
        $testimonials = $this->testimonials();
        $homeFaqs = $homeFaqService->items();
        $homeFaqSchema = $homeFaqService->schema($homeFaqs);

        return view('map', compact('cars', 'carCategories', 'blogPosts', 'popularRoutes', 'clientLogos', 'homeAboutSection', 'testimonials', 'homeFaqs', 'homeFaqSchema'));
    }
    public function aboutUs()
    {
        return view('about-us');
    }
    public function contactUS()
    {
        return view('contact-us');
    }



    private function clientLogos(): Collection
    {
        if (Schema::hasTable('client_logos')) {
            $logos = ClientLogo::query()
                ->active()
                ->orderBy('sort_order')
                ->orderByDesc('id')
                ->get()
                ->map(fn (ClientLogo $logo) => [
                    'image_url' => $logo->image_url,
                    'alt' => $logo->display_alt,
                    'link_url' => $logo->link_url,
                ]);

            if ($logos->isNotEmpty()) {
                return $logos;
            }
        }

        return $this->legacyClientLogos();
    }

    private function legacyClientLogos(): Collection
    {
        $paths = [
            public_path('site/img/logo'),
            dirname(base_path()).'/public_html/site/img/logo',
        ];

        foreach ($paths as $path) {
            $files = glob($path.'/*.webp') ?: [];

            if ($files !== []) {
                return collect($files)
                    ->sort()
                    ->values()
                    ->map(function (string $file) {
                        $name = basename($file);

                        return [
                            'image_url' => asset('site/img/logo/'.$name),
                            'alt' => pathinfo($name, PATHINFO_FILENAME),
                            'link_url' => null,
                        ];
                    });
            }
        }

        return collect();
    }

    private function testimonials(): Collection
    {
        if (Schema::hasTable('testimonials')) {
            $testimonials = Testimonial::query()
                ->active()
                ->orderBy('sort_order')
                ->orderByDesc('id')
                ->get()
                ->map(fn (Testimonial $testimonial) => [
                    'name' => $testimonial->name,
                    'role' => $testimonial->role ?: 'مشتری',
                    'body' => $testimonial->body,
                    'image_url' => $testimonial->image_url,
                    'image_alt' => $testimonial->display_alt,
                    'rating' => max(1, min(5, (int) $testimonial->rating)),
                ]);

            if ($testimonials->isNotEmpty()) {
                return $testimonials;
            }
        }

        return $this->legacyTestimonials();
    }

    private function legacyTestimonials(): Collection
    {
        return collect([
            [
                'name' => 'پوریا میرزایی',
                'role' => 'مشتری',
                'body' => 'خدمات فوق‌العاده و رانندگان خوش برخورد. سفر من از تهران به اصفهان با VIP Taxi Iran تجربه‌ای بسیار راحت و لذت‌بخش بود. تاکسی تمیز و راحت بود و قیمت‌ها هم کاملاً منصفانه بود. حتماً دوباره استفاده می‌کنم و به دوستانم هم معرفی می‌کنم.',
                'image_url' => asset('site/img/team/1.webp'),
                'image_alt' => 'تاکسی برون شهری',
                'rating' => 5,
            ],
            [
                'name' => 'نسترن سلطانی',
                'role' => 'مشتری',
                'body' => 'برای سفرم به شمال از خدمات ترانسفر فرودگاهی VIP Taxi Iran استفاده کردم. راننده بسیار وقت‌شناس بود و در زمان مقرر در فرودگاه حاضر شد. تاکسی تمیز و مجهز بود و سفر خیلی راحتی داشتم. قیمت‌ها هم نسبت به کیفیت خدماتی که دریافت کردم بسیار مناسب بود.',
                'image_url' => asset('site/img/team/4.webp'),
                'image_alt' => 'رزرو تاکسی بین شهری',
                'rating' => 5,
            ],
            [
                'name' => 'فروغ فدایی',
                'role' => 'مشتری',
                'body' => 'ما برای مراسم عروسی از خدمات VIP Taxi Iran استفاده کردیم. تاکسی‌های لوکس و رانندگان خوش پوش و مودب بودند. خدمات بسیار حرفه‌ای و به موقع بود. مهمان‌های ما از کیفیت خدمات خیلی راضی بودند. واقعاً بهترین انتخاب بود.',
                'image_url' => asset('site/img/team/6.webp'),
                'image_alt' => 'نظر مشتری تاکسی بین شهری',
                'rating' => 5,
            ],
        ]);
    }
}
