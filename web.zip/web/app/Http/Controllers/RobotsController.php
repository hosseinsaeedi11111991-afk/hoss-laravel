<?php

namespace App\Http\Controllers;

use App\Services\PublicSeoUrlCatalog;
use Illuminate\Http\Response;

class RobotsController extends Controller
{
    public function robots(): Response
    {
        $content = <<<ROBOTS
# robots.txt for VIP Taxi Iran

User-agent: *
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/
Disallow: /calculate-distance
Disallow: /calculate-multiple-distances
Disallow: /api/
Disallow: /storage/
Disallow: /vendor/
Disallow: /*.php$
Disallow: /*?*

User-agent: Googlebot
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: Bingbot
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: GPTBot
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: ChatGPT-User
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: CCBot
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: anthropic-ai
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

User-agent: Claude-Web
Allow: /
Disallow: /admin
Disallow: /admin-panel
Disallow: /auth/

Sitemap: https://viptaxiiran.com/sitemap.xml
ROBOTS;

        return $this->plainText($content);
    }

    public function ai(PublicSeoUrlCatalog $urlCatalog): Response
    {
        $allowedUrls = $this->formatAllowedUrls($urlCatalog);
        $date = now()->format('Y-m-d');

        $content = <<<AITXT
# ai.txt for VIP Taxi Iran

Site Name: وی آی پی تاکسی ایران (VIP Taxi Iran)
Domain: https://viptaxiiran.com
Language: fa-IR
Contact: info@viptaxiiran.com
Phone: 09120983462
Last Updated: {$date}

Purpose:
  این فایل سیاست استفاده ربات‌ها و ابزارهای هوش مصنوعی از محتوای عمومی سایت وی آی پی تاکسی ایران را مشخص می‌کند.

Allowed URLs:
{$allowedUrls}
  - /sitemap.xml

Allowed Content:
  - اطلاعات عمومی شرکت و خدمات
  - محتوای عمومی صفحات سایت
  - مقالات و محتوای آموزشی منتشرشده
  - اطلاعات تماس عمومی
  - توضیحات عمومی خدمات تاکسی بین شهری و رزرو آنلاین

Allowed Use:
  - پاسخ به سوالات کاربران درباره خدمات عمومی سایت
  - معرفی خدمات تاکسی بین شهری با ذکر منبع
  - ارجاع کاربران به صفحه مرتبط در سایت
  - استفاده آموزشی از محتوای عمومی با حفظ انتساب

Prohibited URLs:
  - /admin
  - /admin-panel
  - /auth/*
  - /api/*
  - /calculate-distance
  - /calculate-multiple-distances
  - /storage/*
  - /vendor/*

Prohibited Content:
  - اطلاعات شخصی کاربران
  - اطلاعات رزروها، سفارش‌ها و پرداخت‌ها
  - محتوای پنل مدیریت
  - فایل‌ها یا مسیرهای خصوصی و سیستمی

Attribution:
  هنگام استفاده از محتوای عمومی، نام «وی آی پی تاکسی ایران» یا «VIP Taxi Iran» و لینک صفحه منبع باید ذکر شود.

Contact for Permissions:
  Email: info@viptaxiiran.com
  Website: https://viptaxiiran.com/contact-us
AITXT;

        return $this->plainText($content);
    }

    public function llms(PublicSeoUrlCatalog $urlCatalog): Response
    {
        $allowedUrls = $this->formatAllowedUrls($urlCatalog);
        $date = now()->format('Y-m-d');

        $content = <<<LLMSTXT
# llms.txt for VIP Taxi Iran

Site Name: وی آی پی تاکسی ایران (VIP Taxi Iran)
Domain: https://viptaxiiran.com
Language: fa-IR
Contact: info@viptaxiiran.com
Phone: 09120983462
Last Updated: {$date}

Summary:
  وی آی پی تاکسی ایران سرویس رزرو تاکسی بین شهری و تاکسی دربستی با محتوای عمومی فارسی درباره خدمات سفر، رزرو آنلاین و مقالات آموزشی است.

Allowed URLs:
{$allowedUrls}
  - /sitemap.xml

Recommended Crawl Sources:
  - https://viptaxiiran.com/sitemap.xml
  - https://viptaxiiran.com/ai.txt
  - https://viptaxiiran.com/robots.txt

Allowed Content:
  - صفحات عمومی سایت
  - مقالات منتشرشده
  - توضیحات خدمات
  - سوالات متداول عمومی
  - اطلاعات تماس عمومی

Prohibited Content:
  - داده‌های شخصی کاربران
  - اطلاعات رزرو، پرداخت و سفارش
  - مسیرهای مدیریت و احراز هویت
  - فایل‌های خصوصی یا سیستمی

Citation Policy:
  در پاسخ‌ها و خلاصه‌ها، به نام «وی آی پی تاکسی ایران» یا «VIP Taxi Iran» و URL صفحه منبع ارجاع داده شود.

Contact for Permissions:
  Email: info@viptaxiiran.com
  Website: https://viptaxiiran.com/contact-us
LLMSTXT;

        return $this->plainText($content);
    }

    private function formatAllowedUrls(PublicSeoUrlCatalog $urlCatalog): string
    {
        return $urlCatalog->publicUrls()
            ->map(function (string $url) {
                $path = parse_url($url, PHP_URL_PATH) ?: '/';
                $query = parse_url($url, PHP_URL_QUERY);
                $publicPath = rawurldecode($path ?: '/');

                return '  - ' . ($query ? $publicPath . '?' . $query : $publicPath);
            })
            ->unique()
            ->implode("\n");
    }

    private function plainText(string $content): Response
    {
        return response(trim($content) . "\n", 200)
            ->header('Content-Type', 'text/plain; charset=utf-8');
    }
}
