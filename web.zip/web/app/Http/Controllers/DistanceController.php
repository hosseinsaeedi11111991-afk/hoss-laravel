<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Modules\Reservation\Models\Reservation;
use Carbon\Carbon;
use App\Services\SmsSettingsService;
use Modules\Neshan\Services\NeshanService;
use Modules\Notification\Services\SmsService;
use Illuminate\Support\Facades\DB;

class DistanceController extends Controller
{
    private $apiKey = 'service.983e1c873c3d4de1b3d989b52355bec9';
    private $neshanService;

    public function __construct(NeshanService $neshanService)
    {
        $this->neshanService = $neshanService;
    }

    public function calculate(Request $request)
    {
        $request->validate([
            'origin_lat' => 'required|numeric',
            'origin_lng' => 'required|numeric',
            'destination_lat' => 'required|numeric',
            'destination_lng' => 'required|numeric',
        ]);

        $origin = $request->origin_lat . ',' . $request->origin_lng;
        $destination = $request->destination_lat . ',' . $request->destination_lng;

        try {
            // گرفتن مسیر از API نشان
            $url = "https://api.neshan.org/v4/direction/no-traffic";
            $response = Http::withHeaders([
                'Api-Key' => $this->apiKey
            ])->get($url, [
                'type' => 'car',
                'origin' => $origin,
                'destination' => $destination
            ]);

            if ($response->failed()) {
                return response()->json([
                    'error' => 'خطا در دریافت اطلاعات از API نشان',
                    'details' => $response->body()
                ], 500);
            }

            $result = $response->json();

            $distanceMeters = $result['routes'][0]['legs'][0]['distance']['value'] ?? null;
            $distanceKm = $distanceMeters ? $distanceMeters / 1000 : null;

            $durationSeconds = $result['routes'][0]['legs'][0]['duration']['value'] ?? null;
            $durationMin = $durationSeconds ? $durationSeconds / 60 : null;

            $encodedPolyline = $result['routes'][0]['overview_polyline']['points'] ?? null;
            $routePath = $this->decodePolyline($encodedPolyline);

            // محاسبه فاصله بر اساس استان
            $provinceDistances = $this->calculateDistanceByProvince($routePath);

            return response()->json([
                'success' => true,
                'distanceKm' => $distanceKm,
                'durationMin' => $durationMin,
                'provinceDistances' => $provinceDistances,
                'routePath' => $routePath
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'خطا در محاسبه مسیر',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function calculateMultipleDistances(Request $request)
    {
        $smsSettings = app(SmsSettingsService::class);
        $requireEarlyPhone = $smsSettings->requirePhoneBeforeRouteCalculation();
        $sendEarlySms = $smsSettings->sendSmsAfterEarlyPhoneCapture();

        // Allow JSON string payload from HTML form
        if (is_string($request->input('routes'))) {
            $decoded = json_decode($request->input('routes'), true);
            if (json_last_error() === JSON_ERROR_NONE) {
                if (isset($decoded['routes'])) {
                    $request->merge(['routes' => $decoded['routes']]);
                } else {
                    $request->merge(['routes' => $decoded]);
                }
            }
        }

        $phoneRule = $requireEarlyPhone
            ? 'required|string|regex:/^09\d{9}$/'
            : 'nullable|string|regex:/^09\d{9}$/';

        $request->validate([
            'routes' => 'required|array|min:1',
            'routes.*.origin_lat' => 'required|numeric',
            'routes.*.origin_lng' => 'required|numeric',
            'routes.*.destination_lat' => 'required|numeric',
            'routes.*.destination_lng' => 'required|numeric',
            'routes.*.origin_index' => 'required|integer',
            'routes.*.destination_index' => 'required|integer',
            'phone' => $phoneRule,
        ], [
            'phone.required' => 'شماره موبایل الزامی است',
            'phone.regex' => 'شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود',
        ]);

        $routes = $request->routes;
        $phone = $request->filled('phone') ? trim((string) $request->input('phone')) : null;
        $sendEarlyCalculationSms = $requireEarlyPhone && $sendEarlySms;

        $results = [];
        $longestRoute = null;
        $maxDistance = 0;

// --- درخواست‌های همزمان به API ---
        $responses = Http::pool(function ($pool) use ($routes) {
            foreach ($routes as $index => $route) {
                $origin = $route['origin_lat'] . ',' . $route['origin_lng'];
                $destination = $route['destination_lat'] . ',' . $route['destination_lng'];

                $pool->as((string)$index)
                    ->withHeaders([
                        'Api-Key' => $this->apiKey
                    ])
                    ->get('https://api.neshan.org/v4/direction/no-traffic', [
                        'type' => 'car',
                        'origin' => $origin,
                        'destination' => $destination
                    ]);
            }
        });

// --- پردازش نتایج ---
        foreach ($routes as $index => $route) {
            try {
                $response = $responses[(string)$index];

                if ($response->failed()) {
                    $results[] = [
                        'error' => 'خطا در دریافت اطلاعات از API نشان',
                        'route_index' => $index,
                        'origin_index' => $route['origin_index'],
                        'destination_index' => $route['destination_index']
                    ];
                    continue;
                }

                $result = $response->json();



                $distanceMeters = $result['routes'][0]['legs'][0]['distance']['value'] ?? null;
                $distanceKm = $distanceMeters ? $distanceMeters / 1000 : null;

                $durationSeconds = $result['routes'][0]['legs'][0]['duration']['value'] ?? null;
                $durationMin = $durationSeconds ? $durationSeconds / 60 : null;

                $encodedPolyline = $result['routes'][0]['overview_polyline']['points'] ?? null;
                $routePath = $this->decodePolyline($encodedPolyline);

                $provinceDistances = $this->calculateDistanceByProvince($routePath);

                $routeResult = [
                    'success' => true,
                    'distanceKm' => $distanceKm,
                    'durationMin' => $durationMin,
                    'provinceDistances' => $provinceDistances,
                    'routePath' => $routePath,
                    'route_index' => $index,
                    'origin_index' => $route['origin_index'],
                    'destination_index' => $route['destination_index'],
                    'origin_lat' => $route['origin_lat'],
                    'origin_lng' => $route['origin_lng'],
                    'destination_lat' => $route['destination_lat'],
                    'destination_lng' => $route['destination_lng'],
                ];

                $results[] = $routeResult;

                if ($distanceKm > $maxDistance) {
                    $maxDistance = $distanceKm;
                    $longestRoute = $routeResult;
                }

            } catch (\Exception $e) {
                $results[] = [
                    'error' => 'خطا در محاسبه مسیر',
                    'message' => $e->getMessage(),
                    'route_index' => $index,
                    'origin_index' => $route['origin_index'],
                    'destination_index' => $route['destination_index']
                ];
            }
        }


        // ذخیره مسیر طولانی‌ترین در دیتابیس
        $reservation = null;
        if ($longestRoute) {
            try {
                $reservation = $this->saveLongestRouteToReservation($longestRoute, $results, $phone, $sendEarlyCalculationSms);
            } catch (\Exception $e) {
                \Log::error('خطا در ذخیره رزرو: ' . $e->getMessage());
            }
        }

        // If this is an API/AJAX request, return JSON; otherwise redirect to reservation page
        if ($request->expectsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'routes' => $results,
                'longestRoute' => $longestRoute,
                'totalRoutes' => count($routes),
                'longestDistance' => $maxDistance,
                'reservation_id' => $reservation ? $reservation->id : null,
                'reservation_created' => $reservation ? true : false
            ]);
        }

        if ($reservation) {
            return redirect()->route('site.reservation.index', ['reservation' => $reservation->id]);
        }

        // محاسبه یا ذخیره رزرو انجام نشد — پیام برای کاربر
        if (!$longestRoute) {
            return redirect()->route('site.reservation.index')->with('error', 'محاسبه مسیر انجام نشد. لطفاً مبدا و مقصد را روی نقشه انتخاب کنید و دوباره تلاش کنید.');
        }

        return redirect()->route('site.reservation.index')->with('error', 'ذخیره رزرو با خطا مواجه شد. لطفاً دوباره از صفحه اصلی مبدا و مقصد را انتخاب کنید.');
    }

    private function saveLongestRouteToReservation($longestRoute, $allRoutes, ?string $phone = null, bool $sendEarlyCalculationSms = false)
    {
    
        DB::beginTransaction();

        try {
            // دریافت آدرس‌های دقیق از API نشان
            $originAddress = $this->getAddressFromCoordinates($longestRoute['origin_lat'], $longestRoute['origin_lng']);
            $destinationAddress = $this->getAddressFromCoordinates($longestRoute['destination_lat'], $longestRoute['destination_lng']);

            // بررسی وجود کاربر
            $userId = auth()->id();

            // اگر کاربر لاگین نباشد و شماره تلفن ارسال شده باشد، کاربر را جستجو می‌کنیم
            if (!$userId && $phone) {
                $user = \Modules\User\Models\User::where('mobile', $phone)->first();
                if ($user) {
                    $userId = $user->id;
                    \Log::info('User found by phone number', [
                        'phone' => $phone,
                        'user_id' => $userId,
                    ]);
                } else {
                    \Log::info('No user found with phone number', [
                        'phone' => $phone,
                    ]);
                }
            }

            \Log::info('Setting user_id for reservation', [
                'user_id' => $userId,
                'phone' => $phone,
                'auth_user_id' => auth()->id(),
            ]);


            $durationMin = $longestRoute['durationMin'];

            $hours = floor($durationMin / 60);
            $minutes = round($durationMin % 60);

            $time = sprintf('%02d:%02d', $hours, $minutes);

            // ایجاد رزرو جدید
            $reservation = Reservation::withoutEvents(fn () => Reservation::create([
                'user_id' => $userId,
                'date' => null,
                'phone' => $phone,
                'distance_km' => $longestRoute['distanceKm'],
                'status' => Reservation::STATUS_PENDING,
                'origin_address' => $originAddress,
                'destination_address' => $destinationAddress,
                'origin' => $longestRoute['origin_lat'] . ',' . $longestRoute['origin_lng'],
                'destination' => $longestRoute['destination_lat'] . ',' . $longestRoute['destination_lng'],
                'time' => null,
            ]));
            // ذخیره تمام نقاط در ماژول Neshan
            $this->neshanService->saveLocationsForReservation($reservation, $allRoutes);

            // ذخیره مسافت استان‌ها در جدول neshan_location_cities
            if (!empty($longestRoute['provinceDistances']) && is_array($longestRoute['provinceDistances'])) {
                $this->neshanService->syncProvinceDistances($reservation, $longestRoute['provinceDistances']);
            }

            // ذخیره اطلاعات اضافی در جدول مربوطه (اگر نیاز باشد)
            $this->saveRouteDetails($reservation, $longestRoute, $allRoutes);

            // ذخیره شماره در session برای استفاده در صفحه رزرو
            if ($phone) {
                session(['reservation_phone' => $phone]);
            }

            // تایید تراکنش
            DB::commit();

            \Log::info('رزرو با موفقیت ایجاد شد', [
                'reservation_id' => $reservation->id,
                'distance' => $longestRoute['distanceKm'],
                'origin' => $originAddress,
                'destination' => $destinationAddress,
                'user_id' => $userId,
                'phone' => $phone,
            ]);

            if ($sendEarlyCalculationSms && $phone) {
                $this->notifyAdminAboutPriceCalculation($reservation, $phone);
            }

            return $reservation;

        } catch (\Exception $e) {
            // بازگشت تراکنش در صورت خطا
            DB::rollBack();

            \Log::error('خطا در ایجاد رزرو', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'longest_route' => $longestRoute
            ]);

            throw $e;
        }
    }



    protected function notifyAdminAboutPriceCalculation(Reservation $reservation, string $phone): void
    {
        try {
            $smsSettings = app(SmsSettingsService::class);
            $recipient = $smsSettings->adminRecipient();

            if (!$recipient) {
                \Log::warning('Admin price calculation SMS skipped because recipient is not configured.', [
                    'reservation_id' => $reservation->id,
                    'phone' => $phone,
                ]);

                return;
            }

            $origin = $this->compactSmsText((string) $reservation->origin_address);
            $destination = $this->compactSmsText((string) $reservation->destination_address);

            $message = implode("\n", [
                'درخواست محاسبه قیمت تاکسی',
                "موبایل: {$phone}",
                "کد رزرو اولیه: {$reservation->id}",
                "مبدا: {$origin}",
                "مقصد: {$destination}",
            ]);

            $sent = app(SmsService::class)->send($recipient, $message);

            \Log::log($sent ? 'info' : 'warning', 'Admin price calculation SMS processed.', [
                'reservation_id' => $reservation->id,
                'phone' => $phone,
                'recipient' => $recipient,
                'sent' => $sent,
            ]);
        } catch (\Throwable $e) {
            \Log::warning('Admin price calculation SMS failed without blocking reservation.', [
                'reservation_id' => $reservation->id,
                'phone' => $phone,
                'error' => $e->getMessage(),
            ]);
        }
    }

    protected function notifyAdminAboutPriceCalculationPhoneCaptured(string $phone, array $routes): void
    {
        try {
            $smsSettings = app(SmsSettingsService::class);
            $recipient = $smsSettings->adminRecipient();

            if (!$recipient) {
                \Log::warning('Admin price calculation lead SMS skipped because recipient is not configured.', [
                    'phone' => $phone,
                    'routes_count' => count($routes),
                ]);

                return;
            }

            $firstRoute = $routes[0] ?? [];
            $origin = $this->formatCoordinatePair($firstRoute['origin_lat'] ?? null, $firstRoute['origin_lng'] ?? null);
            $destination = $this->formatCoordinatePair($firstRoute['destination_lat'] ?? null, $firstRoute['destination_lng'] ?? null);

            $message = implode("\n", [
                'درخواست محاسبه قیمت تاکسی',
                "موبایل: {$phone}",
                'مرحله: ورود شماره بعد از دکمه ادامه',
                'تعداد مسیرها: ' . count($routes),
                "مبدا: {$origin}",
                "مقصد: {$destination}",
            ]);

            $sent = app(SmsService::class)->send($recipient, $message);

            \Log::log($sent ? 'info' : 'warning', 'Admin price calculation lead SMS processed.', [
                'phone' => $phone,
                'recipient' => $recipient,
                'routes_count' => count($routes),
                'sent' => $sent,
            ]);
        } catch (\Throwable $e) {
            \Log::warning('Admin price calculation lead SMS failed without blocking route calculation.', [
                'phone' => $phone,
                'routes_count' => count($routes),
                'error' => $e->getMessage(),
            ]);
        }
    }

    private function formatCoordinatePair($lat, $lng): string
    {
        if ($lat === null || $lng === null) {
            return 'نامشخص';
        }

        return trim((string) $lat) . ',' . trim((string) $lng);
    }

    private function compactSmsText(string $value, int $limit = 70): string
    {
        $value = trim((string) preg_replace('/\s+/u', ' ', $value));

        if ($value === '') {
            return 'نامشخص';
        }

        if (mb_strlen($value, 'UTF-8') <= $limit) {
            return $value;
        }

        return mb_substr($value, 0, max(0, $limit - 3), 'UTF-8') . '...';
    }

    private function getAddressFromCoordinates($lat, $lng)
    {
        try {
            $url = "https://api.neshan.org/v5/reverse";
            $response = Http::timeout(15)->withHeaders([
                'Api-Key' => $this->apiKey
            ])->get($url, [
                'lat' => $lat,
                'lng' => $lng
            ]);

            if ($response->successful()) {
                $data = $response->json();

                // ساخت آدرس کامل از اطلاعات API
                $addressParts = [];

                // نام محله یا منطقه
                if (isset($data['neighbourhood'])) {
                    $addressParts[] = $data['neighbourhood'];
                }

                // نام خیابان
                if (isset($data['street'])) {
                    $addressParts[] = $data['street'];
                }

                // نام شهر
                if (isset($data['city'])) {
                    $addressParts[] = $data['city'];
                }

                // نام استان
                if (isset($data['state'])) {
                    $addressParts[] = $data['state'];
                }

                // اگر آدرس کامل موجود است، از آن استفاده کن
                if (isset($data['formatted_address']) && !empty($data['formatted_address'])) {
                    return $data['formatted_address'];
                }

                // در غیر این صورت، از قطعات ساخته شده استفاده کن
                if (!empty($addressParts)) {
                    return implode('، ', $addressParts);
                }

                // اگر هیچ اطلاعاتی موجود نیست، از آدرس ساده استفاده کن
                return "مختصات: {$lat}, {$lng}";
            }
        } catch (\Exception $e) {
            \Log::warning("خطا در دریافت آدرس برای نقطه: {$lat}, {$lng}", ['error' => $e->getMessage()]);
        }

        return "مختصات: {$lat}, {$lng}";
    }

    private function saveRouteDetails($reservation, $longestRoute, $allRoutes)
    {
        // اینجا می‌توانید اطلاعات اضافی را ذخیره کنید
        // مثلاً در جدول جداگانه یا به صورت JSON در فیلد options
        $routeDetails = [
            'longest_route' => [
                'origin_coordinates' => [
                    'lat' => $longestRoute['origin_lat'],
                    'lng' => $longestRoute['origin_lng']
                ],
                'destination_coordinates' => [
                    'lat' => $longestRoute['destination_lat'],
                    'lng' => $longestRoute['destination_lng']
                ],
                'distance_km' => $longestRoute['distanceKm'],
                'duration_minutes' => $longestRoute['durationMin'],
                'province_distances' => $longestRoute['provinceDistances']
            ],
            'all_routes_count' => count($allRoutes),
            'calculated_at' => Carbon::now()->toISOString()
        ];

        // ذخیره در فیلد options یا جدول جداگانه
        // $reservation->update(['options' => json_encode($routeDetails)]);
    }

    private function decodePolyline($encoded)
    {
        $points = [];
        $index = $lat = $lng = 0;

        while ($index < strlen($encoded)) {
            $result = 1;
            $shift = 0;
            do {
                $b = ord($encoded[$index++]) - 63 - 1;
                $result += $b << $shift;
                $shift += 5;
            } while ($b >= 0x1f);
            $lat += ($result & 1) ? ~($result >> 1) : ($result >> 1);

            $result = 1;
            $shift = 0;
            do {
                $b = ord($encoded[$index++]) - 63 - 1;
                $result += $b << $shift;
                $shift += 5;
            } while ($b >= 0x1f);
            $lng += ($result & 1) ? ~($result >> 1) : ($result >> 1);

            $points[] = [$lat / 1E5, $lng / 1E5];
        }

        return $points;
    }

    private function getProvinceForPoint($lat, $lng)
    {
        try {
            $url = "https://api.neshan.org/v5/reverse";
            $response = Http::withHeaders([
                'Api-Key' => $this->apiKey
            ])->get($url, [
                'lat' => $lat,
                'lng' => $lng
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return $data['state'] ?? null;
            }
        } catch (\Exception $e) {
            // Log error but don't fail the entire calculation
            \Log::warning("Failed to get province for point: {$lat}, {$lng}", ['error' => $e->getMessage()]);
        }

        return null;
    }

    private function calculateDistanceByProvince($points)
    {
        $provinceDistances = [];

        // نمونه‌برداری: هر 10 نقطه برای کاهش تعداد درخواست‌ها
        $sampledPoints = array_filter($points, function ($index) {
            return $index % 10 === 0;
        }, ARRAY_FILTER_USE_KEY);

        // ایجاد pool برای درخواست‌های همزمان
        $responses = Http::pool(function ($pool) use ($sampledPoints) {
            foreach ($sampledPoints as $i => [$lat, $lng]) {
                $pool->as($i)->withHeaders(['Api-Key' => $this->apiKey])
                    ->get('https://api.neshan.org/v5/reverse', ['lat' => $lat, 'lng' => $lng]);
            }
        });

        // ثبت استان‌ها برای نقاط نمونه
        $provinces = [];
        foreach ($responses as $i => $response) {
            if ($response->successful()) {
                $provinces[$i] = $response->json()['state'] ?? null;
            }
        }

        // محاسبه فاصله‌ها
        $prevProvince = null;
        $prevPoint = null;
        foreach ($points as $i => [$lat, $lng]) {
            $currentProvince = $provinces[$i] ?? $prevProvince;

            if ($prevPoint && $currentProvince) {
                [$lat1, $lng1] = $prevPoint;
                $segmentDistance = $this->haversineDistance($lat1, $lng1, $lat, $lng);

                if (!isset($provinceDistances[$currentProvince])) {
                    $provinceDistances[$currentProvince] = 0;
                }

                $provinceDistances[$currentProvince] += $segmentDistance;
            }

            $prevProvince = $currentProvince;
            $prevPoint = [$lat, $lng];
        }

        return $provinceDistances;
    }

    private function haversineDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // کیلومتر

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $lat1 = deg2rad($lat1);
        $lat2 = deg2rad($lat2);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            sin($dLon / 2) * sin($dLon / 2) * cos($lat1) * cos($lat2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }
}
