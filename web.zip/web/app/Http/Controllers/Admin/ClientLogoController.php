<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClientLogo;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ClientLogoController extends Controller
{
    public function index(): View
    {
        return view('admin.client_logos.index', [
            'logos' => Schema::hasTable('client_logos')
                ? ClientLogo::query()->orderBy('sort_order')->orderByDesc('id')->paginate(24)
                : collect(),
            'tableMissing' => ! Schema::hasTable('client_logos'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Schema::hasTable('client_logos')) {
            return redirect()->route('admin.client-logos.index')->with('error', 'جدول لوگوهای برند هنوز ساخته نشده است. بعد از اجرای migration این بخش فعال می‌شود.');
        }

        $data = $this->validateLogo($request);
        $data['image_path'] = $request->file('image')->store('client-logos', 'public');
        $data['is_active'] = $request->boolean('is_active', true);

        ClientLogo::create($data);

        return redirect()->route('admin.client-logos.index')->with('success', 'لوگو اضافه شد.');
    }

    public function update(Request $request, ClientLogo $clientLogo): RedirectResponse
    {
        $data = $this->validateLogo($request, false);
        $data['is_active'] = $request->boolean('is_active');

        if ($request->hasFile('image')) {
            $oldPath = $clientLogo->image_path;
            $data['image_path'] = $request->file('image')->store('client-logos', 'public');

            if ($oldPath && str_starts_with($oldPath, 'client-logos/')) {
                Storage::disk('public')->delete($oldPath);
            }
        }

        $clientLogo->update($data);

        return redirect()->route('admin.client-logos.index')->with('success', 'لوگو بروزرسانی شد.');
    }

    public function destroy(ClientLogo $clientLogo): RedirectResponse
    {
        $imagePath = $clientLogo->image_path;
        $clientLogo->delete();

        if ($imagePath && str_starts_with($imagePath, 'client-logos/')) {
            Storage::disk('public')->delete($imagePath);
        }

        return redirect()->route('admin.client-logos.index')->with('success', 'لوگو حذف شد.');
    }

    private function validateLogo(Request $request, bool $imageRequired = true): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'alt' => ['nullable', 'string', 'max:255'],
            'link_url' => ['nullable', 'url', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'image' => [$imageRequired ? 'required' : 'nullable', 'image', 'mimes:jpg,jpeg,png,webp,svg', 'max:2048'],
        ]);
    }
}
