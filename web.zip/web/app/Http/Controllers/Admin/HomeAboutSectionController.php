<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HomeAboutSection;
use App\Services\HomeAboutSectionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class HomeAboutSectionController extends Controller
{
    public function edit(HomeAboutSectionService $service): View
    {
        $tableMissing = ! Schema::hasTable('home_about_sections');
        $section = $tableMissing ? null : HomeAboutSection::query()->latest('id')->first();

        return view('admin.home_about.edit', [
            'section' => $section,
            'data' => $section ? null : $service->legacyData(),
            'tableMissing' => $tableMissing,
        ]);
    }

    public function update(Request $request, HomeAboutSectionService $service): RedirectResponse
    {
        if (! Schema::hasTable('home_about_sections')) {
            return redirect()->route('admin.home-about.edit')
                ->with('error', 'جدول بخش معرفی صفحه اصلی هنوز ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود.');
        }

        $data = $request->validate([
            'subtitle' => ['required', 'string', 'max:120'],
            'title' => ['required', 'string', 'max:160'],
            'highlight_title' => ['nullable', 'string', 'max:160'],
            'body' => ['required', 'string', 'max:2500'],
            'features' => ['nullable', 'string', 'max:1000'],
            'image_alt' => ['nullable', 'string', 'max:255'],
            'video_url' => ['nullable', 'string', 'max:255'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $section = HomeAboutSection::query()->latest('id')->first() ?: new HomeAboutSection();
        $oldImage = $section->image_path;

        $data['features'] = $service->cleanFeatures(preg_split('/\r\n|\r|\n/', (string) ($data['features'] ?? '')) ?: []);
        $data['is_active'] = true;

        if ($request->boolean('remove_image') && $oldImage && str_starts_with($oldImage, 'home-about/')) {
            Storage::disk('public')->delete($oldImage);
            $data['image_path'] = null;
        }

        if ($request->hasFile('image')) {
            $data['image_path'] = $request->file('image')->store('home-about', 'public');

            if ($oldImage && str_starts_with($oldImage, 'home-about/')) {
                Storage::disk('public')->delete($oldImage);
            }
        }

        $section->fill($data)->save();

        return redirect()->route('admin.home-about.edit')->with('success', 'بخش معرفی صفحه اصلی بروزرسانی شد.');
    }
}
