<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SmsSetting;
use App\Services\SmsSettingsService;
use Illuminate\Http\Request;
use Modules\Notification\Services\SmsService;

class SmsSettingsController extends Controller
{
    public function index(Request $request, SmsService $smsService, SmsSettingsService $settingsService)
    {
        $apiKey = (string) config('notification.sms.farazsms.api_key', '');
        $check = $request->query('check');
        $settings = $settingsService->values();
        $earlyPhoneSettingsMissing = ! $settings['early_phone_capture_columns_exist'];

        $balance = null;
        $profile = null;
        $remoteError = null;

        if ($check === 'balance') {
            $balance = $smsService->getBalance();
            $remoteError = $balance === null ? 'دریافت موجودی از سرویس پیامک ناموفق بود.' : null;
        } elseif ($check === 'profile') {
            $profile = $smsService->getProfile();
            $remoteError = $profile === null ? 'دریافت پروفایل از سرویس پیامک ناموفق بود.' : null;
        }

        return view('admin.sms_settings.index', [
            'configured' => $smsService->isConfigured(),
            'settings' => [
                'provider' => $settings['provider'],
                'base_url' => $settings['base_url'],
                'sender' => $settings['sender'],
                'api_key_masked' => $this->maskSecret($apiKey),
                'api_key_present' => $apiKey !== '',
                'admin_recipient' => $settings['admin_recipient'],
                'admin_pattern' => $settings['admin_pattern'],
                'passenger_pattern' => $settings['passenger_pattern'],
                'require_phone_before_route_calculation' => $settings['require_phone_before_route_calculation'],
                'send_sms_after_early_phone_capture' => $settings['send_sms_after_early_phone_capture'],
                'timeout' => $settings['timeout'],
            ],
            'settingsTableMissing' => ! $settings['table_exists'],
            'earlyPhoneSettingsMissing' => $earlyPhoneSettingsMissing,
            'balance' => $balance,
            'profile' => $profile,
            'remoteError' => $remoteError,
        ]);
    }

    public function update(Request $request, SmsSettingsService $settingsService)
    {
        if (! $settingsService->tableExists()) {
            return back()->with('error', 'جدول تنظیمات پیامک هنوز ساخته نشده است. بعد از اجرای migration امکان ویرایش فعال می‌شود.');
        }

        $data = $request->validate([
            'sender' => ['nullable', 'string', 'max:40', 'regex:/^[0-9+]+$/'],
            'reservation_admin_recipient' => ['nullable', 'string', 'max:40', 'regex:/^[0-9+]+$/'],
            'reservation_admin_pattern' => ['nullable', 'string', 'max:80', 'regex:/^[A-Za-z0-9_-]+$/'],
            'reservation_passenger_pattern' => ['nullable', 'string', 'max:80', 'regex:/^[A-Za-z0-9_-]+$/'],
            'require_phone_before_route_calculation' => ['nullable', 'boolean'],
            'send_sms_after_early_phone_capture' => ['nullable', 'boolean'],
        ], [
            'sender.regex' => 'شماره فرستنده فقط می‌تواند شامل عدد و علامت + باشد.',
            'reservation_admin_recipient.regex' => 'شماره مدیر فقط می‌تواند شامل عدد و علامت + باشد.',
            'reservation_admin_pattern.regex' => 'کد پترن مدیر فقط می‌تواند شامل حروف انگلیسی، عدد، خط تیره و آندرلاین باشد.',
            'reservation_passenger_pattern.regex' => 'کد پترن مسافر فقط می‌تواند شامل حروف انگلیسی، عدد، خط تیره و آندرلاین باشد.',
        ]);

        $earlyPhoneSettingsReady = $settingsService->earlyPhoneCaptureColumnsExist();

        $settings = SmsSetting::query()->first() ?? new SmsSetting();
        $fillable = [
            'sender' => $data['sender'] !== null ? trim((string) $data['sender']) : null,
            'reservation_admin_recipient' => $data['reservation_admin_recipient'] !== null ? trim((string) $data['reservation_admin_recipient']) : null,
            'reservation_admin_pattern' => $data['reservation_admin_pattern'] !== null ? trim((string) $data['reservation_admin_pattern']) : null,
            'reservation_passenger_pattern' => $data['reservation_passenger_pattern'] !== null ? trim((string) $data['reservation_passenger_pattern']) : null,
        ];

        if ($earlyPhoneSettingsReady) {
            $fillable['require_phone_before_route_calculation'] = $request->boolean('require_phone_before_route_calculation');
            $fillable['send_sms_after_early_phone_capture'] = $request->boolean('send_sms_after_early_phone_capture');
        }

        $settings->fill($fillable);
        $settings->save();

        return redirect()
            ->route('admin.sms-settings.index')
            ->with('success', 'تنظیمات پیامک با موفقیت ذخیره شد.');
    }

    private function maskSecret(string $value): string
    {
        if ($value === '') {
            return 'تنظیم نشده';
        }

        $length = mb_strlen($value, 'UTF-8');

        if ($length <= 8) {
            return str_repeat('*', $length);
        }

        return mb_substr($value, 0, 4, 'UTF-8') . str_repeat('*', max(6, $length - 8)) . mb_substr($value, -4, null, 'UTF-8');
    }
}
