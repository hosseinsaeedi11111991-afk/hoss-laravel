<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SeoIndexRule;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class SeoIndexRuleController extends Controller
{
    public function index(Request $request): View
    {
        if (! Schema::hasTable('seo_index_rules')) {
            return view('admin.seo_index_rules.index', [
                'rules' => $this->emptyPaginator($request),
                'summary' => $this->emptySummary(),
                'migrationMissing' => true,
            ]);
        }

        $rules = SeoIndexRule::query()
            ->orderBy('priority')
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        $summary = [
            'total' => SeoIndexRule::query()->count(),
            'active' => SeoIndexRule::query()->where('is_active', true)->count(),
            'noindex' => SeoIndexRule::query()->where('robots_directive', 'like', 'noindex%')->count(),
            'sitemap_excluded' => SeoIndexRule::query()->where('exclude_from_sitemap', true)->count(),
        ];

        return view('admin.seo_index_rules.index', compact('rules', 'summary') + [
            'migrationMissing' => false,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Schema::hasTable('seo_index_rules')) {
            return redirect()
                ->route('admin.seo.index-rules.index')
                ->with('error', 'جدول تنظیمات ایندکس هنوز ساخته نشده است. ابتدا migration را اجرا کنید.');
        }

        SeoIndexRule::create($this->validatedData($request));

        return redirect()
            ->route('admin.seo.index-rules.index')
            ->with('success', 'قانون ایندکس با موفقیت ثبت شد.');
    }

    public function update(Request $request, SeoIndexRule $indexRule): RedirectResponse
    {
        $indexRule->update($this->validatedData($request));

        return redirect()
            ->route('admin.seo.index-rules.index')
            ->with('success', 'قانون ایندکس به‌روزرسانی شد.');
    }

    public function destroy(SeoIndexRule $indexRule): RedirectResponse
    {
        $indexRule->delete();

        return redirect()
            ->route('admin.seo.index-rules.index')
            ->with('success', 'قانون ایندکس حذف شد.');
    }

    private function validatedData(Request $request): array
    {
        $request->merge([
            'is_active' => $request->boolean('is_active'),
            'exclude_from_sitemap' => $request->boolean('exclude_from_sitemap'),
            'priority' => max(1, (int) $request->input('priority', 100)),
        ]);

        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'match_type' => ['required', Rule::in(array_keys(SeoIndexRule::matchTypes()))],
            'pattern' => ['required', 'string', 'max:2048'],
            'robots_directive' => ['required', Rule::in(array_keys(SeoIndexRule::robotsDirectives()))],
            'exclude_from_sitemap' => ['boolean'],
            'is_active' => ['boolean'],
            'priority' => ['required', 'integer', 'min:1', 'max:999999'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);
    }

    private function emptyPaginator(Request $request): LengthAwarePaginator
    {
        return new LengthAwarePaginator([], 0, 20, max(1, (int) $request->input('page', 1)), [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);
    }

    private function emptySummary(): array
    {
        return [
            'total' => 0,
            'active' => 0,
            'noindex' => 0,
            'sitemap_excluded' => 0,
        ];
    }
}
