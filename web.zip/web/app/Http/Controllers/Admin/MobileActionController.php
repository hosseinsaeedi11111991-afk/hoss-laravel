<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MobileBottomLink;
use App\Models\SiteContactSetting;
use App\Services\SiteContactService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class MobileActionController extends Controller
{
    public function index(SiteContactService $service): View
    {
        $contactsTableMissing = ! Schema::hasTable('site_contact_settings');
        $linksTableMissing = ! Schema::hasTable('mobile_bottom_links');
        $contact = $contactsTableMissing
            ? (object) $service->contact()
            : (SiteContactSetting::query()->latest('id')->first() ?: (object) $service->contact());

        return view('admin.mobile_actions.index', [
            'contact' => $contact,
            'links' => $linksTableMissing
                ? collect()
                : MobileBottomLink::query()->orderBy('sort_order')->orderBy('id')->paginate(30),
            'legacyLinks' => $service->legacyMobileBottomLinks(),
            'contactsTableMissing' => $contactsTableMissing,
            'linksTableMissing' => $linksTableMissing,
            'linkTypes' => $this->linkTypes(),
            'iconKeys' => $this->iconKeys(),
        ]);
    }

    public function updateContact(Request $request, SiteContactService $service): RedirectResponse
    {
        if (! Schema::hasTable('site_contact_settings')) {
            return redirect()->route('admin.mobile-actions.index')
                ->with('error', 'جدول تنظیمات تماس هنوز ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود.');
        }

        $data = $request->validate([
            'phone_number' => ['required', 'string', 'max:40'],
            'whatsapp_number' => ['required', 'string', 'max:40'],
            'display_phone' => ['required', 'string', 'max:80'],
        ]);

        $data['phone_number'] = $service->normalizeDigits($data['phone_number']);
        $data['whatsapp_number'] = $service->normalizeDigits($data['whatsapp_number']);

        $setting = SiteContactSetting::query()->latest('id')->first() ?: new SiteContactSetting();
        $setting->fill($data)->save();

        return redirect()->route('admin.mobile-actions.index')->with('success', 'تنظیمات تماس بروزرسانی شد.');
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Schema::hasTable('mobile_bottom_links')) {
            return redirect()->route('admin.mobile-actions.index')
                ->with('error', 'جدول لینک‌های نوار پایین موبایل هنوز ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود.');
        }

        $data = $this->validatedLinkData($request);
        $data['is_active'] = $request->boolean('is_active', true);
        $data['open_in_new_tab'] = $request->boolean('open_in_new_tab');

        MobileBottomLink::create($data);

        return redirect()->route('admin.mobile-actions.index')->with('success', 'لینک نوار پایین موبایل اضافه شد.');
    }

    public function update(Request $request, MobileBottomLink $mobileBottomLink): RedirectResponse
    {
        $data = $this->validatedLinkData($request);
        $data['is_active'] = $request->boolean('is_active');
        $data['open_in_new_tab'] = $request->boolean('open_in_new_tab');

        $mobileBottomLink->update($data);

        return redirect()->route('admin.mobile-actions.index')->with('success', 'لینک نوار پایین موبایل بروزرسانی شد.');
    }

    public function destroy(MobileBottomLink $mobileBottomLink): RedirectResponse
    {
        $mobileBottomLink->delete();

        return redirect()->route('admin.mobile-actions.index')->with('success', 'لینک نوار پایین موبایل حذف شد.');
    }

    private function validatedLinkData(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'link_type' => ['required', 'string', 'in:phone,whatsapp,home,support,custom'],
            'url' => ['nullable', 'string', 'max:255'],
            'icon_key' => ['required', 'string', 'in:phone,whatsapp,home,support,custom'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ]);
    }

    private function linkTypes(): array
    {
        return [
            'phone' => 'تماس',
            'whatsapp' => 'واتساپ',
            'home' => 'صفحه نخست',
            'support' => 'پشتیبانی',
            'custom' => 'لینک دستی',
        ];
    }

    private function iconKeys(): array
    {
        return [
            'phone' => 'تلفن',
            'whatsapp' => 'واتساپ',
            'home' => 'خانه',
            'support' => 'پشتیبانی',
            'custom' => 'دایره ساده',
        ];
    }
}
