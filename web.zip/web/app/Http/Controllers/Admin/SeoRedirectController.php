<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SeoRedirect;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class SeoRedirectController extends Controller
{
    public function index(Request $request): View
    {
        if (! $this->redirectTableExists()) {
            return view('admin.seo_redirects.index', [
                'redirects' => $this->emptyRedirectPaginator($request),
                'diagnostics' => [],
                'summary' => $this->emptySummary(),
                'migrationMissing' => true,
            ]);
        }

        $query = SeoRedirect::query()->latest();

        if ($request->filled('status_code')) {
            $query->where('status_code', (int) $request->input('status_code'));
        }

        if ($request->filled('is_active')) {
            $query->where('is_active', $request->input('is_active') === '1');
        }

        if ($request->filled('q')) {
            $search = trim((string) $request->input('q'));
            $query->where(function ($builder) use ($search) {
                $builder->where('source_path', 'like', "%{$search}%")
                    ->orWhere('target_url', 'like', "%{$search}%");
            });
        }

        $redirects = $query->paginate(20)->withQueryString();
        $diagnostics = $this->diagnostics(SeoRedirect::query()->get());
        $summary = [
            'total' => SeoRedirect::query()->count(),
            'active' => SeoRedirect::query()->where('is_active', true)->count(),
            'permanent' => SeoRedirect::query()->where('status_code', SeoRedirect::STATUS_301)->count(),
            'temporary' => SeoRedirect::query()->where('status_code', SeoRedirect::STATUS_302)->count(),
            'gone' => SeoRedirect::query()->where('status_code', SeoRedirect::STATUS_410)->count(),
            'issues' => count(array_filter($diagnostics)),
        ];

        return view('admin.seo_redirects.index', compact('redirects', 'diagnostics', 'summary') + [
            'migrationMissing' => false,
        ]);
    }

    public function create(): View
    {
        return view('admin.seo_redirects.create', [
            'redirect' => new SeoRedirect(['status_code' => SeoRedirect::STATUS_301, 'is_active' => true]),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! $this->redirectTableExists()) {
            return redirect()
                ->route('admin.seo.redirects.index')
                ->with('error', 'جدول ریدایرکت‌ها هنوز ساخته نشده است. ابتدا migration را اجرا کنید.');
        }

        $data = $this->validatedData($request);
        SeoRedirect::create($data);
        SeoRedirect::flushRedirectCache();

        return redirect()->route('admin.seo.redirects.index')->with('success', 'ریدایرکت با موفقیت ثبت شد.');
    }

    public function edit(SeoRedirect $redirect): View
    {
        return view('admin.seo_redirects.edit', compact('redirect'));
    }

    public function update(Request $request, SeoRedirect $redirect): RedirectResponse
    {
        $data = $this->validatedData($request, $redirect);
        $redirect->update($data);
        SeoRedirect::flushRedirectCache();

        return redirect()->route('admin.seo.redirects.index')->with('success', 'ریدایرکت با موفقیت بروزرسانی شد.');
    }

    public function destroy(SeoRedirect $redirect): RedirectResponse
    {
        $redirect->delete();
        SeoRedirect::flushRedirectCache();

        return redirect()->route('admin.seo.redirects.index')->with('success', 'ریدایرکت حذف شد.');
    }

    private function validatedData(Request $request, ?SeoRedirect $redirect = null): array
    {
        $request->merge([
            'source_path' => SeoRedirect::normalizeSourcePath($request->input('source_path')),
            'source_hash' => SeoRedirect::sourceHash($request->input('source_path')),
            'target_url' => trim((string) $request->input('target_url')),
            'is_active' => $request->boolean('is_active'),
        ]);

        $data = $request->validate([
            'source_path' => [
                'required',
                'string',
                'max:2048',
                function ($attribute, $value, $fail) {
                    $reserved = ['/admin-panel', '/robots.txt', '/sitemap.xml', '/ai.txt', '/llms.txt'];

                    if (in_array($value, $reserved, true) || str_starts_with($value, '/admin-panel/')) {
                        $fail('این مسیر برای ریدایرکت دستی مجاز نیست.');
                    }
                },
            ],
            'source_hash' => [
                'required',
                Rule::unique('seo_redirects', 'source_hash')->ignore($redirect?->id),
            ],
            'target_url' => [
                Rule::requiredIf((int) $request->input('status_code') !== SeoRedirect::STATUS_410),
                'nullable',
                'string',
                'max:2048',
                function ($attribute, $value, $fail) {
                    $value = trim((string) $value);
                    if ($value === '') {
                        return;
                    }

                    if (! str_starts_with($value, '/') && ! filter_var($value, FILTER_VALIDATE_URL)) {
                        $fail('مقصد باید مسیر داخلی با / یا آدرس کامل معتبر باشد.');
                    }
                },
            ],
            'status_code' => ['required', 'integer', Rule::in(array_keys(SeoRedirect::statuses()))],
            'is_active' => ['boolean'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);

        $data['target_url'] = (string) ($data['target_url'] ?? '');

        if ((int) $data['status_code'] !== SeoRedirect::STATUS_410 && SeoRedirect::targetPath($data['target_url']) === $data['source_path']) {
            validator([], [])->after(fn ($validator) => $validator->errors()->add('target_url', 'مبدا و مقصد نباید یکسان باشند.'))->validate();
        }

        return $data;
    }

    private function diagnostics($redirects): array
    {
        $active = $redirects->where('is_active', true)->keyBy('source_path');
        $diagnostics = [];

        foreach ($redirects as $redirect) {
            $issues = [];
            $targetPath = SeoRedirect::targetPath($redirect->target_url);

            if ((int) $redirect->status_code !== SeoRedirect::STATUS_410 && ! str_starts_with($redirect->target_url, '/') && ! filter_var($redirect->target_url, FILTER_VALIDATE_URL)) {
                $issues[] = 'مقصد نامعتبر';
            }

            if ((int) $redirect->status_code !== SeoRedirect::STATUS_410 && $targetPath && $targetPath === $redirect->source_path) {
                $issues[] = 'حلقه مستقیم';
            }

            if ((int) $redirect->status_code !== SeoRedirect::STATUS_410 && $redirect->is_active && $targetPath && $active->has($targetPath)) {
                $issues[] = 'زنجیره ریدایرکت';
            }

            if ((int) $redirect->status_code !== SeoRedirect::STATUS_410 && $redirect->is_active && $this->hasLoop($redirect, $active)) {
                $issues[] = 'حلقه زنجیره‌ای';
            }

            $diagnostics[$redirect->id] = $issues;
        }

        return $diagnostics;
    }

    private function hasLoop(SeoRedirect $redirect, $active): bool
    {
        $seen = [$redirect->source_path => true];
        $current = SeoRedirect::targetPath($redirect->target_url);

        for ($depth = 0; $depth < 20; $depth++) {
            if (! $current || ! $active->has($current)) {
                return false;
            }

            if (isset($seen[$current])) {
                return true;
            }

            $seen[$current] = true;
            $current = SeoRedirect::targetPath($active[$current]->target_url);
        }

        return true;
    }

    private function redirectTableExists(): bool
    {
        return Schema::hasTable('seo_redirects');
    }

    private function emptyRedirectPaginator(Request $request): LengthAwarePaginator
    {
        return new LengthAwarePaginator([], 0, 20, max(1, (int) $request->input('page', 1)), [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);
    }

    private function emptySummary(): array
    {
        return [
            'total' => 0,
            'active' => 0,
            'permanent' => 0,
            'temporary' => 0,
            'gone' => 0,
            'issues' => 0,
        ];
    }
}
