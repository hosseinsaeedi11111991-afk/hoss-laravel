<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use RuntimeException;
use Throwable;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;
use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Services\AttachmentService;

class MediaController extends Controller
{
    private const FALLBACK_IMAGE_ALTS = [
        'تاکسی بین شهری',
        'رزرو تاکسی بین شهری',
        'رزرو تاکسی دربستی',
        'تاکسی دربستی بین شهری',
        'تاکسی بین شهری آنلاین',
        'تاکسی آنلاین بین شهری',
        'تاکسی برون شهری',
        'برون شهری تاکسی آنلاین',
        'تاکسی دربستی تهران به اصفهان',
        'تاکسی بین شهری تهران به مشهد',
        'درخواست تاکسی بین شهری',
        'تاکسی دربستی فرودگاه',
        'تاکسی دربستی تهران به رشت',
        'درخواست تاکسی دربستی',
    ];

    public function index(Request $request): View
    {
        if (! $this->tablesExist()) {
            return view('admin.media.index', [
                'attachments' => $this->emptyPaginator($request),
                'publicImages' => $this->publicImagesPaginator($request),
                'summary' => $this->emptySummary(),
                'tableMissing' => true,
            ]);
        }

        $query = Attachment::query()
            ->with(['meta', 'attachables'])
            ->latest();

        if ($request->filled('type')) {
            $query->where('file_type', $request->input('type'));
        }

        if ($request->filled('q')) {
            $search = trim((string) $request->input('q'));
            $query->where(function ($builder) use ($search) {
                $builder->where('file_name', 'like', "%{$search}%")
                    ->orWhere('path', 'like', "%{$search}%")
                    ->orWhere('mime_type', 'like', "%{$search}%");
            });
        }

        $attachments = $query->paginate(24)->withQueryString();
        $attachments->getCollection()->transform(function (Attachment $attachment) {
            $alt = trim((string) ($attachment->meta->firstWhere('attribute', 'image_alt')?->value ?? ''));
            $attachment->display_alt = $alt !== '' ? $alt : $this->suggestedImageAlt($attachment->path ?: $attachment->file_name);
            $attachment->alt_source = $alt !== '' ? 'saved' : 'suggested';

            return $attachment;
        });
        $publicImages = $this->publicImagesPaginator($request);
        $summary = [
            'total' => Attachment::query()->count(),
            'images' => Attachment::query()->where('file_type', Attachment::FILE_TYPE_IMAGE)->count(),
            'public_images' => $publicImages->total(),
            'unused' => Attachment::query()->doesntHave('attachables')->count(),
            'without_alt' => Attachment::query()
                ->where('file_type', Attachment::FILE_TYPE_IMAGE)
                ->whereDoesntHave('meta', fn ($query) => $query->where('attribute', 'image_alt')->whereNotNull('value')->where('value', '!=', ''))
                ->count(),
        ];

        return view('admin.media.index', [
            'attachments' => $attachments,
            'publicImages' => $publicImages,
            'summary' => $summary,
            'tableMissing' => false,
        ]);
    }

    public function store(Request $request, AttachmentService $attachmentService): RedirectResponse
    {
        if (! $this->tablesExist()) {
            return redirect()->route('admin.media.index')->with('error', 'جدول رسانه هنوز ساخته نشده است. ابتدا migration را اجرا کنید.');
        }

        $data = $request->validate([
            'file' => ['required', 'file', 'mimes:jpeg,png,jpg,gif,webp,svg,mp4,mov,webm,pdf,txt,doc,docx', 'max:5120'],
            'image_alt' => ['nullable', 'string', 'max:255'],
        ]);

        $attachment = $attachmentService->uploadFile($data['file'], 'public', 'media');

        if ($attachment->file_type === Attachment::FILE_TYPE_IMAGE) {
            $attachmentService->upsertMeta($attachment, 'image_alt', $data['image_alt'] ?? '');
        }

        return redirect()->route('admin.media.index')->with('success', 'فایل با موفقیت اضافه شد.');
    }

    public function update(Request $request, Attachment $attachment, AttachmentService $attachmentService): RedirectResponse
    {
        $data = $request->validate([
            'image_alt' => ['nullable', 'string', 'max:255'],
        ]);

        $attachmentService->upsertMeta($attachment, 'image_alt', $data['image_alt'] ?? '');

        return redirect()->route('admin.media.index')->with('success', 'ALT تصویر بروزرسانی شد.');
    }

    public function updateFilesystemAlt(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'image_path' => ['required', 'string', 'max:512'],
            'image_alt' => ['nullable', 'string', 'max:255'],
        ]);

        $imagePath = str_replace('\\', '/', trim($data['image_path'], '/'));
        $image = collect($this->publicImages())->firstWhere('relative', $imagePath);

        if (! $image) {
            return redirect()->route('admin.media.index')->with('error', 'تصویر انتخاب‌شده روی فایل‌سیستم یافت نشد.');
        }

        $altMap = $this->savedPublicImageAltMap();
        $alt = trim((string) ($data['image_alt'] ?? ''));

        $altMap[$imagePath] = $alt;

        $this->savePublicImageAltMap($altMap);

        return redirect()->route('admin.media.index')->with('success', 'ALT تصویر فایل‌سیستم بروزرسانی شد.');
    }

    public function destroy(Attachment $attachment, AttachmentService $attachmentService): RedirectResponse
    {
        if (! $this->canDelete($attachment)) {
            return redirect()->route('admin.media.index')->with('error', 'این فایل در حال استفاده است و حذف نشد.');
        }

        $attachmentService->deleteWithThumbnails($attachment);

        return redirect()->route('admin.media.index')->with('success', 'فایل حذف شد.');
    }

    public function bulkDestroy(Request $request, AttachmentService $attachmentService): RedirectResponse
    {
        $data = $request->validate([
            'attachment_ids' => ['required', 'array', 'min:1'],
            'attachment_ids.*' => ['integer', Rule::exists('attachments', 'id')],
        ]);

        $deleted = 0;
        $skipped = 0;

        Attachment::query()
            ->whereIn('id', $data['attachment_ids'])
            ->with('attachables')
            ->get()
            ->each(function (Attachment $attachment) use ($attachmentService, &$deleted, &$skipped) {
                if (! $this->canDelete($attachment)) {
                    $skipped++;
                    return;
                }

                $attachmentService->deleteWithThumbnails($attachment);
                $deleted++;
            });

        return redirect()
            ->route('admin.media.index')
            ->with('success', "{$deleted} فایل حذف شد و {$skipped} فایل به دلیل استفاده شدن حذف نشد.");
    }

    private function canDelete(Attachment $attachment): bool
    {
        $attachment->loadMissing('attachables');

        return $attachment->attachables->isEmpty();
    }

    private function tablesExist(): bool
    {
        return Schema::hasTable('attachments') &&
            Schema::hasTable('attachment_meta') &&
            Schema::hasTable('attachables');
    }

    private function emptyPaginator(Request $request): LengthAwarePaginator
    {
        return new LengthAwarePaginator([], 0, 24, max(1, (int) $request->input('page', 1)), [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);
    }

    private function emptySummary(): array
    {
        return [
            'total' => 0,
            'images' => 0,
            'public_images' => 0,
            'unused' => 0,
            'without_alt' => 0,
        ];
    }

    private function publicImagesPaginator(Request $request): LengthAwarePaginator
    {
        if ($request->filled('type') && $request->input('type') !== Attachment::FILE_TYPE_IMAGE) {
            return $this->emptyPublicImagesPaginator($request);
        }

        $search = trim((string) $request->input('q', ''));
        $images = $this->publicImages($search);
        $page = max(1, (int) $request->input('public_page', 1));
        $perPage = 24;

        return new LengthAwarePaginator(
            array_slice($images, ($page - 1) * $perPage, $perPage),
            count($images),
            $perPage,
            $page,
            [
                'path' => $request->url(),
                'query' => $request->query(),
                'pageName' => 'public_page',
            ]
        );
    }

    private function emptyPublicImagesPaginator(Request $request): LengthAwarePaginator
    {
        return new LengthAwarePaginator([], 0, 24, 1, [
            'path' => $request->url(),
            'query' => $request->query(),
            'pageName' => 'public_page',
        ]);
    }

    private function publicImages(string $search = ''): array
    {
        $items = [];
        $seen = [];
        $altMap = $this->publicImageAltMap();

        $this->collectImages(public_path(), '', $search, $items, $seen, $altMap, 'storage');
        $this->collectImages(storage_path('app/public'), 'storage', $search, $items, $seen, $altMap);

        usort($items, fn ($a, $b) => strcmp($a['relative'], $b['relative']));

        return $items;
    }

    private function collectImages(
        string $root,
        string $urlPrefix,
        string $search,
        array &$items,
        array &$seen,
        array $altMap,
        ?string $skipTopLevelDirectory = null
    ): void {
        if (! is_dir($root)) {
            return;
        }

        $extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'ico'];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (! $file instanceof SplFileInfo || ! $file->isFile()) {
                continue;
            }

            $extension = strtolower($file->getExtension());
            if (! in_array($extension, $extensions, true)) {
                continue;
            }

            $relative = str_replace('\\', '/', ltrim(str_replace($root, '', $file->getPathname()), DIRECTORY_SEPARATOR));
            $publicRelative = trim($urlPrefix.'/'.$relative, '/');

            if ($skipTopLevelDirectory !== null && str_starts_with($relative, $skipTopLevelDirectory.'/')) {
                continue;
            }

            if ($search !== '' && stripos($publicRelative, $search) === false) {
                continue;
            }

            if (isset($seen[$publicRelative])) {
                continue;
            }

            $seen[$publicRelative] = true;
            $items[] = [
                'name' => $file->getFilename(),
                'relative' => $publicRelative,
                'url' => asset($publicRelative),
                'alt' => trim((string) ($altMap[$publicRelative] ?? '')) ?: $this->suggestedImageAlt($publicRelative),
                'alt_source' => trim((string) ($altMap[$publicRelative] ?? '')) !== '' ? 'saved' : 'suggested',
                'size' => $file->getSize(),
                'modified_at' => date('Y/m/d H:i', $file->getMTime()),
                'extension' => $extension,
            ];
        }
    }

    private function publicImageAltMap(): array
    {
        return array_replace(
            $this->discoveredPublicImageAltMap(),
            $this->databasePublicImageAltMap(),
            $this->savedPublicImageAltMap()
        );
    }

    private function savedPublicImageAltMap(): array
    {
        $path = $this->publicImageAltMapPath();

        if (! is_file($path)) {
            return [];
        }

        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : [];
    }

    private function discoveredPublicImageAltMap(): array
    {
        $items = [];
        $roots = [
            resource_path('views'),
            base_path('Modules'),
        ];

        foreach ($roots as $root) {
            $this->collectDiscoveredAltFromViews($root, $items);
        }

        return $items;
    }

    private function collectDiscoveredAltFromViews(string $root, array &$items): void
    {
        if (! is_dir($root)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (! $file instanceof SplFileInfo || ! $file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            $content = (string) file_get_contents($file->getPathname());

            $this->collectAltFromHtml($content, $items);
        }
    }

    private function databasePublicImageAltMap(): array
    {
        $items = [];

        $this->collectAttachmentMetaAlt($items);
        $this->collectBlogPostAlt($items);

        return $items;
    }

    private function collectAttachmentMetaAlt(array &$items): void
    {
        if (! Schema::hasTable('attachments') || ! Schema::hasTable('attachment_meta')) {
            return;
        }

        try {
            DB::table('attachments')
                ->join('attachment_meta', 'attachments.id', '=', 'attachment_meta.attachment_id')
                ->where('attachments.file_type', Attachment::FILE_TYPE_IMAGE)
                ->where('attachment_meta.attribute', 'image_alt')
                ->whereNotNull('attachment_meta.value')
                ->where('attachment_meta.value', '!=', '')
                ->select('attachments.path', 'attachment_meta.value')
                ->orderBy('attachments.id')
                ->chunk(200, function ($rows) use (&$items) {
                    foreach ($rows as $row) {
                        $relative = $this->storageRelativePath((string) $row->path);

                        if ($relative !== null && ! isset($items[$relative])) {
                            $items[$relative] = (string) $row->value;
                        }
                    }
                });
        } catch (Throwable) {
            return;
        }
    }

    private function collectBlogPostAlt(array &$items): void
    {
        if (! Schema::hasTable('blog_posts')) {
            return;
        }

        try {
            DB::table('blog_posts')
                ->select('thumbnail', 'thumbnail_tag', 'image', 'image_tag', 'body')
                ->orderBy('id')
                ->chunk(100, function ($posts) use (&$items) {
                    foreach ($posts as $post) {
                        $this->addPathAlt($items, $post->thumbnail ?? null, $post->thumbnail_tag ?? null);
                        $this->addPathAlt($items, $post->image ?? null, $post->image_tag ?? null);
                        $this->collectAltFromHtml((string) ($post->body ?? ''), $items);
                    }
                });
        } catch (Throwable) {
            return;
        }
    }

    private function addPathAlt(array &$items, ?string $path, ?string $alt): void
    {
        $alt = trim((string) $alt);

        if ($path === null || $alt === '') {
            return;
        }

        $relative = $this->storageRelativePath($path);

        if ($relative !== null && ! isset($items[$relative])) {
            $items[$relative] = $alt;
        }
    }

    private function collectAltFromHtml(string $html, array &$items): void
    {
        if (! preg_match_all('/<img\b[^>]*>/iu', $html, $matches)) {
            return;
        }

        foreach ($matches[0] as $imgTag) {
            $source = $this->attributeFromTag($imgTag, 'src');
            $alt = $this->attributeFromTag($imgTag, 'alt');

            if ($source === null || $alt === null || trim($alt) === '') {
                continue;
            }

            $relative = $this->publicRelativePathFromSource($source);

            if ($relative === null || isset($items[$relative])) {
                continue;
            }

            $items[$relative] = html_entity_decode(trim($alt), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    }

    private function attributeFromTag(string $tag, string $attribute): ?string
    {
        if (! preg_match('/\s'.preg_quote($attribute, '/').'\s*=\s*(["\'])(.*?)\1/isu', $tag, $match)) {
            return null;
        }

        return $match[2];
    }

    private function publicRelativePathFromSource(string $source): ?string
    {
        $source = $this->withoutUrlQuery(trim($source));

        if (preg_match('/asset\s*\(\s*([\'"])(.*?)\1\s*\)/u', $source, $match)) {
            return trim(str_replace('\\', '/', $match[2]), '/');
        }

        if (preg_match('/^(?:https?:)?\/\/[^\/]+\/(.+)$/u', $source, $match)) {
            return trim($match[1], '/');
        }

        if (str_starts_with($source, '/')) {
            return trim($source, '/');
        }

        return null;
    }

    private function storageRelativePath(string $path): ?string
    {
        $path = $this->withoutUrlQuery(trim(str_replace('\\', '/', $path)));

        if ($path === '') {
            return null;
        }

        return str_starts_with($path, 'storage/')
            ? trim($path, '/')
            : 'storage/'.trim($path, '/');
    }

    private function withoutUrlQuery(string $path): string
    {
        return preg_replace('/[?#].*$/', '', $path) ?? $path;
    }

    private function suggestedImageAlt(string $path): string
    {
        $index = abs((int) crc32($path)) % count(self::FALLBACK_IMAGE_ALTS);

        return self::FALLBACK_IMAGE_ALTS[$index];
    }

    private function savePublicImageAltMap(array $altMap): void
    {
        $path = $this->publicImageAltMapPath();
        $directory = dirname($path);

        if (! is_dir($directory) && ! mkdir($directory, 0755, true) && ! is_dir($directory)) {
            throw new RuntimeException('Unable to create media alt metadata directory.');
        }

        ksort($altMap);

        file_put_contents($path, json_encode($altMap, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    private function publicImageAltMapPath(): string
    {
        return storage_path('app/media-alt.json');
    }
}
