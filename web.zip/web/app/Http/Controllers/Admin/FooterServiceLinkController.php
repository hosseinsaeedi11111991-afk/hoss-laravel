<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FooterServiceLink;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class FooterServiceLinkController extends Controller
{
    public function index(): View
    {
        return view('admin.footer_service_links.index', [
            'links' => Schema::hasTable('footer_service_links')
                ? FooterServiceLink::query()->orderBy('sort_order')->orderByDesc('id')->paginate(30)
                : collect(),
            'tableMissing' => ! Schema::hasTable('footer_service_links'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Schema::hasTable('footer_service_links')) {
            return redirect()->route('admin.footer-service-links.index')
                ->with('error', 'جدول لینک‌های خدمات فوتر هنوز ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود.');
        }

        $data = $this->validatedData($request);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['is_active'] = $request->boolean('is_active', true);

        FooterServiceLink::create($data);

        return redirect()->route('admin.footer-service-links.index')->with('success', 'لینک خدمات اضافه شد.');
    }

    public function update(Request $request, FooterServiceLink $footerServiceLink): RedirectResponse
    {
        $data = $this->validatedData($request);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['is_active'] = $request->boolean('is_active');

        $footerServiceLink->update($data);

        return redirect()->route('admin.footer-service-links.index')->with('success', 'لینک خدمات بروزرسانی شد.');
    }

    public function destroy(FooterServiceLink $footerServiceLink): RedirectResponse
    {
        $footerServiceLink->delete();

        return redirect()->route('admin.footer-service-links.index')->with('success', 'لینک خدمات حذف شد.');
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:160'],
            'url' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ]);
    }
}
