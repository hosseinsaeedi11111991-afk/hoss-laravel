<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Testimonial;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class TestimonialController extends Controller
{
    public function index(): View
    {
        return view('admin.testimonials.index', [
            'testimonials' => Schema::hasTable('testimonials')
                ? Testimonial::query()->orderBy('sort_order')->orderByDesc('id')->paginate(20)
                : collect(),
            'tableMissing' => ! Schema::hasTable('testimonials'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Schema::hasTable('testimonials')) {
            return redirect()->route('admin.testimonials.index')
                ->with('error', 'جدول رضایت مشتریان هنوز ساخته نشده است. بعد از اجرای migration، مدیریت این بخش فعال می‌شود.');
        }

        $data = $this->validatedData($request);
        $data['is_active'] = $request->boolean('is_active', true);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        if ($request->hasFile('image')) {
            $data['image_path'] = $request->file('image')->store('testimonials', 'public');
        }

        Testimonial::create($data);

        return redirect()->route('admin.testimonials.index')->with('success', 'نظر مشتری اضافه شد.');
    }

    public function update(Request $request, Testimonial $testimonial): RedirectResponse
    {
        $data = $this->validatedData($request);
        $data['is_active'] = $request->boolean('is_active');
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        if ($request->hasFile('image')) {
            $oldPath = $testimonial->image_path;
            $data['image_path'] = $request->file('image')->store('testimonials', 'public');

            if ($oldPath && str_starts_with($oldPath, 'testimonials/')) {
                Storage::disk('public')->delete($oldPath);
            }
        }

        $testimonial->update($data);

        return redirect()->route('admin.testimonials.index')->with('success', 'نظر مشتری بروزرسانی شد.');
    }

    public function destroy(Testimonial $testimonial): RedirectResponse
    {
        $imagePath = $testimonial->image_path;
        $testimonial->delete();

        if ($imagePath && str_starts_with($imagePath, 'testimonials/')) {
            Storage::disk('public')->delete($imagePath);
        }

        return redirect()->route('admin.testimonials.index')->with('success', 'نظر مشتری حذف شد.');
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'role' => ['nullable', 'string', 'max:160'],
            'body' => ['required', 'string', 'max:1200'],
            'image_alt' => ['nullable', 'string', 'max:255'],
            'rating' => ['required', 'integer', Rule::in([1, 2, 3, 4, 5])],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);
    }
}
