<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use SplFileObject;

class LogViewerController extends Controller
{
    private const DEFAULT_LINES = 300;
    private const MAX_LINES = 2000;

    public function index(Request $request)
    {
        $files = $this->logFiles();
        $selectedFile = $this->selectedFile($request, $files);
        $lines = min(max((int) $request->integer('lines', self::DEFAULT_LINES), 50), self::MAX_LINES);
        $level = strtolower((string) $request->query('level', ''));
        $query = trim((string) $request->query('q', ''));
        $logLines = [];

        if ($selectedFile !== null) {
            $path = storage_path('logs' . DIRECTORY_SEPARATOR . $selectedFile);
            $logLines = $this->filterLines($this->tailFile($path, $lines), $level, $query);
        }

        return view('admin.logs.index', [
            'files' => $files,
            'selectedFile' => $selectedFile,
            'logLines' => $logLines,
            'levels' => ['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug'],
            'selectedLevel' => $level,
            'query' => $query,
            'lines' => $lines,
        ]);
    }

    private function logFiles(): Collection
    {
        $directory = storage_path('logs');

        if (! File::isDirectory($directory)) {
            return collect();
        }

        return collect(File::files($directory))
            ->filter(fn ($file) => $file->isFile() && strtolower($file->getExtension()) === 'log')
            ->map(fn ($file) => [
                'name' => $file->getFilename(),
                'size' => $file->getSize(),
                'modified_at' => $file->getMTime(),
            ])
            ->sortByDesc('modified_at')
            ->values();
    }

    private function selectedFile(Request $request, Collection $files): ?string
    {
        if ($files->isEmpty()) {
            return null;
        }

        $available = $files->pluck('name');
        $requested = basename((string) $request->query('file', ''));

        if ($requested !== '' && $available->contains($requested)) {
            return $requested;
        }

        return $available->contains('laravel.log') ? 'laravel.log' : $available->first();
    }

    private function tailFile(string $path, int $lines): array
    {
        if (! File::isFile($path) || ! is_readable($path)) {
            return [];
        }

        $file = new SplFileObject($path, 'r');
        $file->seek(PHP_INT_MAX);
        $lastLine = $file->key();
        $startLine = max(0, $lastLine - $lines);
        $rows = [];

        $file->seek($startLine);

        while (! $file->eof()) {
            $line = rtrim((string) $file->fgets(), "\r\n");

            if ($line !== '') {
                $rows[] = $this->maskSensitive($line);
            }
        }

        return $rows;
    }

    private function filterLines(array $lines, string $level, string $query): array
    {
        return array_values(array_filter($lines, function (string $line) use ($level, $query) {
            if ($level !== '' && ! str_contains(strtolower($line), '.' . $level . ':')) {
                return false;
            }

            return $query === '' || mb_stripos($line, $query, 0, 'UTF-8') !== false;
        }));
    }

    private function maskSensitive(string $line): string
    {
        $line = preg_replace(
            '/((?:api[_-]?key|apikey|authorization|bearer|token|password|passwd|secret)\s*["\']?\s*[:=]\s*["\']?)([^"\'\s,}]+)/i',
            '$1[masked]',
            $line
        ) ?? $line;

        return preg_replace(
            '/((?:Authorization|Bearer)\s+)[A-Za-z0-9._\-]{16,}/i',
            '$1[masked]',
            $line
        ) ?? $line;
    }
}
