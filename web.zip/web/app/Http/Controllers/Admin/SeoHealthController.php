<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SeoHealthReport;
use App\Services\SeoHealthCrawler;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;
use Throwable;

class SeoHealthController extends Controller
{
    public function index(): View
    {
        if (! Schema::hasTable('seo_health_reports')) {
            return view('admin.seo_health.index', [
                'report' => null,
                'summary' => $this->emptySummary(),
                'issues' => [],
                'migrationMissing' => true,
            ]);
        }

        $report = SeoHealthReport::query()->latest()->first();

        return view('admin.seo_health.index', [
            'report' => $report,
            'summary' => $report?->summary ?: $this->emptySummary(),
            'issues' => $report?->issues ?: [],
            'migrationMissing' => false,
        ]);
    }

    public function crawl(SeoHealthCrawler $crawler): RedirectResponse
    {
        if (! Schema::hasTable('seo_health_reports')) {
            return redirect()
                ->route('admin.seo.health.index')
                ->with('error', 'جدول گزارش سلامت سئو هنوز ساخته نشده است. ابتدا migration را اجرا کنید.');
        }

        $report = SeoHealthReport::create([
            'status' => SeoHealthReport::STATUS_RUNNING,
            'started_at' => now(),
        ]);

        try {
            $result = $crawler->crawl(100);

            $report->update([
                'status' => SeoHealthReport::STATUS_COMPLETED,
                'scanned_urls' => $result['scanned_urls'],
                'issue_count' => $result['issue_count'],
                'summary' => $result['summary'],
                'issues' => $result['issues'],
                'finished_at' => now(),
            ]);

            return redirect()
                ->route('admin.seo.health.index')
                ->with('success', 'کرال دستی سلامت سئو با موفقیت انجام شد.');
        } catch (Throwable $exception) {
            $report->update([
                'status' => SeoHealthReport::STATUS_FAILED,
                'error_message' => $exception->getMessage(),
                'finished_at' => now(),
            ]);

            return redirect()
                ->route('admin.seo.health.index')
                ->with('error', 'کرال دستی با خطا متوقف شد.');
        }
    }

    private function emptySummary(): array
    {
        return [
            'pages' => 0,
            'issues' => 0,
            'errors' => 0,
            'warnings' => 0,
            'by_type' => [],
        ];
    }
}
