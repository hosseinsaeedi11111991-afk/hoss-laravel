<?php

namespace App\Http\Middleware;

use App\Models\SeoRedirect;
use Closure;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

class SeoRedirectMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->isMethod('GET') && ! $request->isMethod('HEAD')) {
            return $next($request);
        }

        if ($this->shouldSkip($request)) {
            return $next($request);
        }

        $path = SeoRedirect::normalizeSourcePath('/' . ltrim($request->path(), '/'));

        try {
            $redirect = $this->activeRedirects()[$path] ?? null;
        } catch (QueryException) {
            return $next($request);
        }

        if (! $redirect) {
            return $next($request);
        }

        $targetPath = SeoRedirect::targetPath($redirect['target_url']);
        if ($targetPath && $targetPath === $path) {
            return $next($request);
        }

        SeoRedirect::query()
            ->whereKey($redirect['id'])
            ->update([
                'hits' => ((int) $redirect['hits']) + 1,
                'last_hit_at' => now(),
            ]);

        SeoRedirect::flushRedirectCache();

        if ((int) $redirect['status_code'] === SeoRedirect::STATUS_410) {
            return response('', SeoRedirect::STATUS_410);
        }

        return redirect()->to($redirect['target_url'], (int) $redirect['status_code']);
    }

    private function shouldSkip(Request $request): bool
    {
        return $request->is('admin-panel') ||
            $request->is('admin-panel/*') ||
            $request->is('storage/*') ||
            $request->is('build/*') ||
            $request->is('vendor/*') ||
            $request->is('admin/assets/*') ||
            $request->is('robots.txt') ||
            $request->is('sitemap.xml') ||
            $request->is('ai.txt') ||
            $request->is('llms.txt');
    }

    private function activeRedirects(): array
    {
        return Cache::rememberForever(SeoRedirect::CACHE_KEY, function () {
            return SeoRedirect::query()
                ->where('is_active', true)
                ->get(['id', 'source_path', 'target_url', 'status_code', 'hits'])
                ->keyBy('source_path')
                ->map(fn (SeoRedirect $redirect) => [
                    'id' => $redirect->id,
                    'target_url' => $redirect->target_url,
                    'status_code' => $redirect->status_code,
                    'hits' => $redirect->hits,
                ])
                ->all();
        });
    }
}
