<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware
{
    protected function redirectTo($request): ?string
    {
        if ($request->expectsJson()) {
            return null;
        }
        if ($request->is('admin-panel') || $request->is('admin-panel/*')) {
            return route('admin.auth.pass.login.form');
        }

        return route('auth.login.form');
    }
}
