<?php

namespace App\Services;

use App\Models\SeoIndexRule;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

class SeoIndexRuleService
{
    public function robotsForRequest(Request $request): ?string
    {
        $rule = $this->matchingRuleForRequest($request);

        return $rule?->robots_directive;
    }

    public function shouldExcludeFromSitemap(string $url): bool
    {
        $rule = $this->matchingRuleForUrl($url);

        return (bool) ($rule?->exclude_from_sitemap);
    }

    public function matchingRuleForRequest(Request $request): ?SeoIndexRule
    {
        return $this->activeRules()->first(fn (SeoIndexRule $rule) => $this->matchesRequest($rule, $request));
    }

    public function matchingRuleForUrl(string $url): ?SeoIndexRule
    {
        $request = Request::create($url);

        return $this->matchingRuleForRequest($request);
    }

    private function activeRules(): Collection
    {
        if (! Schema::hasTable('seo_index_rules')) {
            return collect();
        }

        return Cache::remember(SeoIndexRule::CACHE_KEY, now()->addMinutes(10), function () {
            return SeoIndexRule::query()
                ->where('is_active', true)
                ->orderBy('priority')
                ->orderBy('id')
                ->get();
        });
    }

    private function matchesRequest(SeoIndexRule $rule, Request $request): bool
    {
        return match ($rule->match_type) {
            SeoIndexRule::MATCH_QUERY_KEY => $this->queryKeyMatches($rule->pattern, $request),
            SeoIndexRule::MATCH_QUERY_VALUE => $this->queryValueMatches($rule->pattern, $request),
            SeoIndexRule::MATCH_FULL_URL => $this->globMatches($rule->pattern, $request->fullUrl()),
            default => $this->pathMatches($rule->pattern, $request),
        };
    }

    private function pathMatches(string $pattern, Request $request): bool
    {
        $path = '/' . ltrim($request->path(), '/');
        $path = $path === '/.' ? '/' : (rtrim($path, '/') ?: '/');

        return $this->globMatches($pattern, $path) || $this->globMatches($pattern, ltrim($path, '/'));
    }

    private function queryKeyMatches(string $pattern, Request $request): bool
    {
        foreach (array_keys($request->query()) as $key) {
            if ($this->globMatches($pattern, (string) $key)) {
                return true;
            }
        }

        return false;
    }

    private function queryValueMatches(string $pattern, Request $request): bool
    {
        [$keyPattern, $valuePattern] = array_pad(explode('=', $pattern, 2), 2, '*');

        foreach ($request->query() as $key => $value) {
            if (! $this->globMatches($keyPattern, (string) $key)) {
                continue;
            }

            $values = is_array($value) ? $value : [$value];
            foreach ($values as $item) {
                if ($this->globMatches($valuePattern, (string) $item)) {
                    return true;
                }
            }
        }

        return false;
    }

    private function globMatches(string $pattern, string $value): bool
    {
        $pattern = trim($pattern);
        $value = trim($value);

        if ($pattern === '') {
            return false;
        }

        $regex = '#^' . str_replace('\*', '.*', preg_quote($pattern, '#')) . '$#iu';

        return (bool) preg_match($regex, $value);
    }
}
