<?php

namespace App\Services;

use App\Models\HomeAboutSection;
use Illuminate\Support\Facades\Schema;

class HomeAboutSectionService
{
    public function data(): array
    {
        if (Schema::hasTable('home_about_sections')) {
            $section = HomeAboutSection::query()
                ->where('is_active', true)
                ->latest('id')
                ->first();

            if ($section) {
                return [
                    'subtitle' => $section->subtitle,
                    'title' => $section->title,
                    'highlight_title' => $section->highlight_title,
                    'body' => $section->body,
                    'features' => $this->cleanFeatures($section->features ?: []),
                    'image_url' => $section->image_url,
                    'image_alt' => $section->display_alt,
                    'video_url' => $section->video_url ?: 'https://youtu.be/1LxcTt1adfY',
                ];
            }
        }

        return $this->legacyData();
    }

    public function legacyData(): array
    {
        return [
            'subtitle' => 'VIP Taxi Iran',
            'title' => 'وی آی پی تاکسی',
            'highlight_title' => 'تاکسی بین شهری',
            'body' => 'ما (وی آی پی تاکسی ایران) بیش از ۱۰ سال است که در صنعت تاکسیرانی خدمات ارائه می دهیم و شهروندان عزیز می توانند برای تمامی سفرهای بین شهری خود از خدمات و سرویس های تخصصی ما استفاده کنند. ما با توجه به دانش و تجربه ای که در این حوزه داریم خدمات جامع و با کیفیتی را ارائه می دهیم. همچنین در مجموعه خود رانندگانی بسیار مجرب داریم و مشتریان ما می توانند برای سفرهای خود علاوه بر خدمات معمولی از خدمات ویژه و خودروهای مدل بالا نیز بهره ببرند.',
            'features' => [
                'تاکسی‌های VIP و لوکس',
                'تاکسی‌های معمولی و اقتصادی',
            ],
            'image_url' => asset('site/img/about.webp'),
            'image_alt' => 'تاکسی بین شهری',
            'video_url' => 'https://youtu.be/1LxcTt1adfY',
        ];
    }

    public function cleanFeatures(array $features): array
    {
        return collect($features)
            ->map(fn ($feature) => trim((string) $feature))
            ->filter()
            ->values()
            ->all();
    }
}
