<?php

namespace App\Services;

use App\Models\SmsSetting;
use Illuminate\Support\Facades\Schema;

class SmsSettingsService
{
    public function values(): array
    {
        $row = $this->storedSettings();

        return [
            'provider' => 'FarazSMS / IPPanel',
            'base_url' => config('notification.sms.farazsms.base_url'),
            'sender' => $this->value($row?->sender, 'notification.sms.farazsms.sender'),
            'admin_recipient' => $this->value($row?->reservation_admin_recipient, 'notification.sms.reservation_admin_recipient'),
            'admin_pattern' => $this->value($row?->reservation_admin_pattern, 'notification.sms.reservation_admin_pattern'),
            'passenger_pattern' => $this->value($row?->reservation_passenger_pattern, 'notification.sms.reservation_passenger_pattern'),
            'require_phone_before_route_calculation' => $this->booleanValue($row, 'require_phone_before_route_calculation'),
            'send_sms_after_early_phone_capture' => $this->booleanValue($row, 'send_sms_after_early_phone_capture'),
            'early_phone_capture_columns_exist' => $this->earlyPhoneCaptureColumnsExist(),
            'timeout' => config('notification.sms.farazsms.timeout'),
            'table_exists' => $this->tableExists(),
        ];
    }

    public function sender(): ?string
    {
        return $this->values()['sender'];
    }

    public function adminRecipient(): ?string
    {
        return $this->values()['admin_recipient'];
    }

    public function adminPattern(): ?string
    {
        return $this->values()['admin_pattern'];
    }

    public function passengerPattern(): ?string
    {
        return $this->values()['passenger_pattern'];
    }

    public function requirePhoneBeforeRouteCalculation(): bool
    {
        return (bool) $this->values()['require_phone_before_route_calculation'];
    }

    public function sendSmsAfterEarlyPhoneCapture(): bool
    {
        return (bool) $this->values()['send_sms_after_early_phone_capture'];
    }

    public function earlyPhoneCaptureColumnsExist(): bool
    {
        return $this->tableHasColumn('require_phone_before_route_calculation')
            && $this->tableHasColumn('send_sms_after_early_phone_capture');
    }

    public function tableExists(): bool
    {
        try {
            return Schema::hasTable('sms_settings');
        } catch (\Throwable) {
            return false;
        }
    }

    private function storedSettings(): ?SmsSetting
    {
        if (! $this->tableExists()) {
            return null;
        }

        return SmsSetting::query()->first();
    }

    private function value(?string $storedValue, string $configKey): ?string
    {
        $storedValue = trim((string) $storedValue);

        if ($storedValue !== '') {
            return $storedValue;
        }

        $configValue = config($configKey);

        return $configValue !== null && trim((string) $configValue) !== ''
            ? trim((string) $configValue)
            : null;
    }

    private function booleanValue(?SmsSetting $row, string $key): bool
    {
        if (! $row || ! $this->tableHasColumn($key)) {
            return false;
        }

        return (bool) $row->{$key};
    }

    private function tableHasColumn(string $column): bool
    {
        if (! $this->tableExists()) {
            return false;
        }

        try {
            return Schema::hasColumn('sms_settings', $column);
        } catch (\Throwable) {
            return false;
        }
    }
}
