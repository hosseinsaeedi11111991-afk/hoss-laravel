<?php

namespace App\Services;

use App\Models\MobileBottomLink;
use App\Models\SiteContactSetting;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class SiteContactService
{
    public function contact(): array
    {
        $settings = Schema::hasTable('site_contact_settings')
            ? SiteContactSetting::query()->latest('id')->first()
            : null;

        $phone = $settings?->phone_number ?: '09120983462';
        $whatsapp = $settings?->whatsapp_number ?: $phone;
        $displayPhone = $settings?->display_phone ?: '+98 912 098 3462';

        return [
            'phone_number' => $phone,
            'tel_phone' => $this->toTelPhone($phone),
            'display_phone' => $displayPhone,
            'whatsapp_number' => $this->toWhatsappNumber($whatsapp),
            'whatsapp_url' => 'https://wa.me/' . $this->toWhatsappNumber($whatsapp),
        ];
    }

    public function mobileBottomLinks(): Collection
    {
        $contact = $this->contact();

        if (Schema::hasTable('mobile_bottom_links')) {
            $query = MobileBottomLink::query();

            if ($query->exists()) {
                return MobileBottomLink::query()
                    ->active()
                    ->orderBy('sort_order')
                    ->orderBy('id')
                    ->get()
                    ->map(fn (MobileBottomLink $link) => $this->mapMobileLink($link, $contact));
            }

            $links = MobileBottomLink::query()
                ->active()
                ->orderBy('sort_order')
                ->orderBy('id')
                ->get()
                ->map(fn (MobileBottomLink $link) => $this->mapMobileLink($link, $contact));

            if ($links->isNotEmpty()) {
                return $links;
            }
        }

        return $this->legacyMobileBottomLinks($contact);
    }

    public function legacyMobileBottomLinks(?array $contact = null): Collection
    {
        $contact ??= $this->contact();

        return collect([
            [
                'title' => 'تماس',
                'url' => 'tel:' . $contact['tel_phone'],
                'icon_key' => 'phone',
                'open_in_new_tab' => false,
            ],
            [
                'title' => 'واتساپ',
                'url' => $contact['whatsapp_url'],
                'icon_key' => 'whatsapp',
                'open_in_new_tab' => true,
            ],
            [
                'title' => 'صفحه نخست',
                'url' => 'https://viptaxiiran.com/',
                'icon_key' => 'home',
                'open_in_new_tab' => false,
            ],
            [
                'title' => 'پشتیبانی',
                'url' => 'tel:' . $contact['tel_phone'],
                'icon_key' => 'support',
                'open_in_new_tab' => false,
            ],
        ]);
    }

    public function normalizeDigits(string $value): string
    {
        return strtr($value, [
            '۰' => '0',
            '۱' => '1',
            '۲' => '2',
            '۳' => '3',
            '۴' => '4',
            '۵' => '5',
            '۶' => '6',
            '۷' => '7',
            '۸' => '8',
            '۹' => '9',
            '٠' => '0',
            '١' => '1',
            '٢' => '2',
            '٣' => '3',
            '٤' => '4',
            '٥' => '5',
            '٦' => '6',
            '٧' => '7',
            '٨' => '8',
            '٩' => '9',
        ]);
    }

    private function mapMobileLink(MobileBottomLink $link, array $contact): array
    {
        return [
            'title' => $link->title,
            'url' => $this->resolveMobileUrl($link, $contact),
            'icon_key' => $link->icon_key ?: 'custom',
            'open_in_new_tab' => (bool) $link->open_in_new_tab,
        ];
    }

    private function resolveMobileUrl(MobileBottomLink $link, array $contact): string
    {
        if ($link->url) {
            return $link->url;
        }

        return match ($link->link_type) {
            'phone', 'support' => 'tel:' . $contact['tel_phone'],
            'whatsapp' => $contact['whatsapp_url'],
            'home' => 'https://viptaxiiran.com/',
            default => '#',
        };
    }

    private function toTelPhone(string $phone): string
    {
        $digits = $this->onlyDigits($phone);

        if (str_starts_with($digits, '00')) {
            $digits = substr($digits, 2);
        }

        if (str_starts_with($digits, '0')) {
            return '+98' . substr($digits, 1);
        }

        if (str_starts_with($digits, '98')) {
            return '+' . $digits;
        }

        if (str_starts_with($digits, '9')) {
            return '+98' . $digits;
        }

        return '+' . $digits;
    }

    private function toWhatsappNumber(string $phone): string
    {
        return ltrim($this->toTelPhone($phone), '+');
    }

    private function onlyDigits(string $phone): string
    {
        return preg_replace('/\D+/', '', $this->normalizeDigits($phone)) ?: '';
    }
}
