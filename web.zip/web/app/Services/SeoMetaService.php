<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Pagination\AbstractPaginator;
use Illuminate\Support\Collection;
use Modules\Blog\Models\BlogPost;

class SeoMetaService
{
    private const CANONICAL_HOST = 'https://viptaxiiran.com';
    private const SITE_NAME = 'وی آی پی تاکسی ایران';
    private const DEFAULT_IMAGE = '/site/img/gold_logo.webp';

    public function generic(string $title = '', string $description = '', ?Request $request = null): array
    {
        $title = $this->cleanText($title) ?: self::SITE_NAME;
        $description = $this->metaDescription($description, $title, '');
        $canonical = $this->canonical($request);
        $image = $this->absoluteUrl(self::DEFAULT_IMAGE);

        return $this->withSocial([
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'image' => $image,
            'schema' => [
                $this->webPageSchema($title, $description, $canonical, $image),
            ],
        ]);
    }

    public function home(string $title, string $description, ?Request $request = null): array
    {
        $meta = $this->generic($title, $description, $request);
        $meta['schema'] = [
            [
                '@context' => 'https://schema.org',
                '@type' => 'WebSite',
                '@id' => self::CANONICAL_HOST . '/#website',
                'url' => self::CANONICAL_HOST . '/',
                'name' => self::SITE_NAME,
                'inLanguage' => 'fa-IR',
            ],
            [
                '@context' => 'https://schema.org',
                '@type' => 'Organization',
                '@id' => self::CANONICAL_HOST . '/#organization',
                'name' => self::SITE_NAME,
                'url' => self::CANONICAL_HOST . '/',
                'logo' => $this->absoluteUrl(self::DEFAULT_IMAGE),
            ],
        ];

        return $meta;
    }

    public function blogCollection(string $baseTitle, string $baseDescription, AbstractPaginator $posts, ?Request $request = null): array
    {
        $page = max(1, (int) $posts->currentPage());
        $title = $this->paginatedTitle($baseTitle, $page);
        $description = $this->paginatedDescription($baseDescription, $title, $page);
        $canonical = $this->canonical($request, $page);
        $image = $this->absoluteUrl('/site/img/slider/10.jpg');

        return $this->withSocial([
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'image' => $image,
            'schema' => [
                $this->collectionSchema($title, $description, $canonical, $posts->getCollection()),
            ],
            'page' => $page,
        ]);
    }

    public function blogPost(BlogPost $post, ?Request $request = null): array
    {
        $manualTitle = $post->seo?->title;
        $manualDescription = $post->seo?->description;
        $title = $this->cleanText($manualTitle ?: ($post->title ?: 'مقاله'));
        $description = $this->metaDescription($manualDescription, $title, $post->summary ?: $post->body ?: '');
        $summary = $this->summary($post->summary ?: '', $post->body ?: '');
        $canonical = $this->canonical($request);
        $image = $this->postImage($post);
        $author = $this->cleanText($post->seo?->author_name ?: ($post->user?->name ?: ($post->author ?: self::SITE_NAME)));

        return $this->withSocial([
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'image' => $image,
            'summary' => $summary,
            'article' => [
                'published_time' => optional($post->published_at ?: $post->created_at)->toIso8601String(),
                'modified_time' => optional($post->updated_at)->toIso8601String(),
                'author' => $author,
            ],
            'schema' => [
                $this->articleSchema($post, $title, $description, $canonical, $image, $author),
                $this->breadcrumbSchema($post, $canonical),
            ],
        ], 'article');
    }

    public function canonical(?Request $request = null, ?int $page = null): string
    {
        $request = $request ?: request();
        $path = '/' . ltrim($request->path(), '/');
        $path = $path === '/.' ? '/' : $path;
        $path = $path === '//' ? '/' : $path;

        $query = $request->query();
        foreach (array_keys($query) as $key) {
            if ($this->isTrackingParameter((string) $key)) {
                unset($query[$key]);
            }
        }

        $page = $page ?: (int) ($query['page'] ?? 1);
        if ($page <= 1) {
            unset($query['page']);
        } else {
            $query['page'] = $page;
        }

        ksort($query);
        $queryString = http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        return rtrim(self::CANONICAL_HOST, '/') . ($path === '/' ? '/' : $path) . ($queryString ? '?' . $queryString : '');
    }

    public function paginatedTitle(string $baseTitle, int $page): string
    {
        $baseTitle = $this->cleanText($baseTitle) ?: self::SITE_NAME;

        return $page > 1 ? "{$baseTitle} | صفحه {$page}" : $baseTitle;
    }

    public function metaDescription(?string $manual, string $title, string $content): string
    {
        $text = $this->cleanText($manual ?: trim($title . ' ' . $this->cleanText($content)));

        return $this->limitCompleteWords($text, 165);
    }

    public function paginatedDescription(string $baseDescription, string $title, int $page): string
    {
        $description = $this->metaDescription($baseDescription, $title, '');
        if ($page > 1) {
            $description = $this->limitCompleteWords($description . " صفحه {$page}.", 165);
        }

        return $description;
    }

    public function summary(?string $manual, ?string $content): string
    {
        $text = $this->cleanText($manual ?: $content ?: '');
        if ($text === '') {
            return '';
        }

        $words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($words) <= 300) {
            return $text;
        }

        return implode(' ', array_slice($words, 0, 300));
    }

    public function cleanText(?string $value): string
    {
        $value = html_entity_decode((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/<script\b[^>]*>.*?<\/script>/is', ' ', $value) ?? $value;
        $value = preg_replace('/<style\b[^>]*>.*?<\/style>/is', ' ', $value) ?? $value;
        $value = strip_tags($value);
        $value = preg_replace('/\[[^\]]+\]/u', ' ', $value) ?? $value;
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;

        return trim($value);
    }

    private function limitCompleteWords(string $text, int $limit): string
    {
        $text = $this->cleanText($text);
        if (mb_strlen($text) <= $limit) {
            return $text;
        }

        $slice = mb_substr($text, 0, $limit + 1);
        $cut = max(
            mb_strrpos($slice, ' ') ?: 0,
            mb_strrpos($slice, '،') ?: 0,
            mb_strrpos($slice, '.') ?: 0,
            mb_strrpos($slice, '؛') ?: 0
        );

        if ($cut < 80) {
            $cut = $limit;
        }

        return rtrim(mb_substr($text, 0, $cut), " \t\n\r\0\x0B،.;؛");
    }

    private function withSocial(array $meta, string $type = 'website'): array
    {
        $meta['og'] = [
            'type' => $type,
            'title' => $meta['title'],
            'description' => $meta['description'],
            'url' => $meta['canonical'],
            'image' => $meta['image'],
            'site_name' => self::SITE_NAME,
            'locale' => 'fa_IR',
        ];
        $meta['twitter'] = [
            'card' => 'summary_large_image',
            'title' => $meta['title'],
            'description' => $meta['description'],
            'image' => $meta['image'],
        ];

        return $meta;
    }

    private function webPageSchema(string $title, string $description, string $canonical, string $image): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $title,
            'description' => $description,
            'image' => $image,
            'inLanguage' => 'fa-IR',
        ];
    }

    private function articleSchema(BlogPost $post, string $title, string $description, string $canonical, string $image, string $author): array
    {
        return array_filter([
            '@context' => 'https://schema.org',
            '@type' => 'BlogPosting',
            '@id' => $canonical . '#article',
            'mainEntityOfPage' => $canonical,
            'url' => $canonical,
            'headline' => $title,
            'description' => $description,
            'image' => $image,
            'author' => [
                '@type' => 'Person',
                'name' => $author,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name' => self::SITE_NAME,
                'logo' => [
                    '@type' => 'ImageObject',
                    'url' => $this->absoluteUrl(self::DEFAULT_IMAGE),
                ],
            ],
            'datePublished' => optional($post->published_at ?: $post->created_at)->toIso8601String(),
            'dateModified' => optional($post->updated_at)->toIso8601String(),
            'inLanguage' => 'fa-IR',
        ]);
    }

    private function collectionSchema(string $title, string $description, string $canonical, Collection $posts): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'CollectionPage',
            '@id' => $canonical . '#collection',
            'url' => $canonical,
            'name' => $title,
            'description' => $description,
            'mainEntity' => [
                '@type' => 'ItemList',
                'itemListElement' => $posts->values()->map(function ($post, int $index) {
                    return [
                        '@type' => 'ListItem',
                        'position' => $index + 1,
                        'url' => route('blog.show', $post->en_slug),
                        'name' => $this->cleanText($post->title),
                    ];
                })->all(),
            ],
            'inLanguage' => 'fa-IR',
        ];
    }

    private function breadcrumbSchema(BlogPost $post, string $canonical): array
    {
        $items = [
            [
                '@type' => 'ListItem',
                'position' => 1,
                'name' => 'خانه',
                'item' => self::CANONICAL_HOST . '/',
            ],
        ];

        if ($post->category) {
            $items[] = [
                '@type' => 'ListItem',
                'position' => 2,
                'name' => $this->cleanText($post->category->name),
                'item' => route('blog.category'),
            ];
        }

        $items[] = [
            '@type' => 'ListItem',
            'position' => count($items) + 1,
            'name' => $this->cleanText($post->title),
            'item' => $canonical,
        ];

        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items,
        ];
    }

    private function postImage(BlogPost $post): string
    {
        $image = $post->thumbnail ?: $post->image;
        if ($image) {
            return $this->absoluteUrl('/storage/' . ltrim($image, '/'));
        }

        return $this->absoluteUrl(self::DEFAULT_IMAGE);
    }

    private function absoluteUrl(string $path): string
    {
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            return preg_replace('#^http://viptaxiiran\.com#i', self::CANONICAL_HOST, $path) ?? $path;
        }

        return rtrim(self::CANONICAL_HOST, '/') . '/' . ltrim($path, '/');
    }

    private function isTrackingParameter(string $key): bool
    {
        $key = mb_strtolower($key);

        return str_starts_with($key, 'utm_') || in_array($key, ['fbclid', 'gclid', 'msclkid', 'ref'], true);
    }
}
