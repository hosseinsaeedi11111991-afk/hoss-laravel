<?php

namespace App\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Modules\Faq\Models\Faq;
use Modules\Faq\Models\FaqContent;

class HomeFaqService
{
    public function items(int $limit = 8): Collection
    {
        if (! $this->tablesExist()) {
            return collect();
        }

        return FaqContent::query()
            ->where('status', FaqContent::STATUS_ACTIVE)
            ->whereHas('faq', fn ($query) => $query->where('status', Faq::STATUS_ACTIVE))
            ->orderBy('sort_order')
            ->orderBy('id')
            ->limit($limit)
            ->get()
            ->map(fn (FaqContent $item) => [
                'question' => $this->cleanText($item->question),
                'answer' => $this->cleanText($item->answer),
            ])
            ->filter(fn (array $item) => $item['question'] !== '' && $item['answer'] !== '')
            ->values();
    }

    public function schema(Collection $items): ?array
    {
        if ($items->isEmpty()) {
            return null;
        }

        return [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            '@id' => url('/').'#faq',
            'mainEntity' => $items->map(fn (array $item) => [
                '@type' => 'Question',
                'name' => $item['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $item['answer'],
                ],
            ])->all(),
        ];
    }

    private function tablesExist(): bool
    {
        return Schema::hasTable('faq') && Schema::hasTable('faq_content');
    }

    private function cleanText(?string $value): string
    {
        $value = html_entity_decode((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = strip_tags($value);
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;

        return trim($value);
    }
}
