<?php

namespace App\Services;

use App\Models\FooterServiceLink;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class FooterServiceLinkService
{
    public function items(): Collection
    {
        if (Schema::hasTable('footer_service_links')) {
            $items = FooterServiceLink::query()
                ->active()
                ->orderBy('sort_order')
                ->orderByDesc('id')
                ->get()
                ->map(fn (FooterServiceLink $link) => [
                    'title' => $link->title,
                    'url' => $link->url,
                ]);

            if ($items->isNotEmpty()) {
                return $items;
            }
        }

        return $this->legacyItems();
    }

    private function legacyItems(): Collection
    {
        return collect([
            ['title' => 'تاکسی دربستی بین شهری', 'url' => null],
            ['title' => 'تاکسی فرودگاه امام', 'url' => null],
            ['title' => 'تاکسی فرودگاه مهرآباد', 'url' => null],
            ['title' => 'تاکسی در اختیار بین شهری', 'url' => null],
        ]);
    }
}
