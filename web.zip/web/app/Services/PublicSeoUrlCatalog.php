<?php

namespace App\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Modules\Blog\Models\BlogPost;
use Spatie\Sitemap\Tags\Url;

class PublicSeoUrlCatalog
{
    private const CANONICAL_BASE_URL = 'https://viptaxiiran.com';

    public function sitemapEntries(): Collection
    {
        $entries = collect();

        $this->addRoute($entries, 'home', 1.0, Url::CHANGE_FREQUENCY_WEEKLY);
        $this->addRoute($entries, 'about-us', 0.8, Url::CHANGE_FREQUENCY_MONTHLY);
        $this->addRoute($entries, 'contact-us', 0.8, Url::CHANGE_FREQUENCY_MONTHLY);
        $this->addRoute($entries, 'site.reservation.index', 0.9, Url::CHANGE_FREQUENCY_WEEKLY);
        $this->addRoute($entries, 'blog.category', 0.9, Url::CHANGE_FREQUENCY_WEEKLY);
        $this->addRoute($entries, 'blog.index', 0.6, Url::CHANGE_FREQUENCY_WEEKLY);

        $this->addBlogPosts($entries);
        $this->addPages($entries);
        $this->addFaqIndex($entries);

        return $entries->values();
    }

    public function publicUrls(): Collection
    {
        return $this->sitemapEntries()
            ->pluck('url')
            ->unique()
            ->values();
    }

    private function addRoute(Collection $entries, string $routeName, float $priority, string $frequency): void
    {
        if (! Route::has($routeName)) {
            return;
        }

        $this->add($entries, route($routeName), $priority, $frequency);
    }

    private function addBlogPosts(Collection $entries): void
    {
        if (! class_exists(BlogPost::class) || ! Schema::hasTable('blog_posts')) {
            return;
        }

        BlogPost::query()
            ->where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->whereNotNull('published_at')
            ->where('published_at', '<=', now())
            ->whereNotNull('en_slug')
            ->where('en_slug', '!=', '')
            ->orderByDesc('updated_at')
            ->cursor()
            ->each(function (BlogPost $post) use ($entries) {
                $this->add(
                    $entries,
                    url('/'.trim($post->en_slug, '/')),
                    0.8,
                    Url::CHANGE_FREQUENCY_WEEKLY,
                    $post->updated_at ?? $post->created_at
                );
            });
    }

    private function addPages(Collection $entries): void
    {
        if (! class_exists(\Modules\Page\Models\Page::class) || ! Schema::hasTable('pages')) {
            return;
        }

        \Modules\Page\Models\Page::query()
            ->whereIn('status', [
                \Modules\Page\Models\Page::STATUS_PUBLISHED,
                \Modules\Page\Models\Page::STATUS_ACTIVE,
            ])
            ->cursor()
            ->each(function ($page) use ($entries) {
                $this->add(
                    $entries,
                    url($page->getFullPath()),
                    0.7,
                    Url::CHANGE_FREQUENCY_MONTHLY,
                    $page->updated_at ?? $page->created_at
                );
            });
    }

    private function addFaqIndex(Collection $entries): void
    {
        if (Route::has('faq.index')) {
            $this->addRoute($entries, 'faq.index', 0.6, Url::CHANGE_FREQUENCY_MONTHLY);
        }
    }

    private function add(Collection $entries, string $url, float $priority, string $frequency, mixed $lastModified = null): void
    {
        $url = $this->normalizeUrl($url);

        if ($url === '' || $entries->has($url)) {
            return;
        }

        if (app(SeoIndexRuleService::class)->shouldExcludeFromSitemap($url)) {
            return;
        }

        $entries->put($url, [
            'url' => $url,
            'priority' => $priority,
            'frequency' => $frequency,
            'last_modified' => $lastModified,
        ]);
    }

    private function normalizeUrl(string $url): string
    {
        $url = trim($url);

        if ($url === '') {
            return self::CANONICAL_BASE_URL;
        }

        if (str_starts_with($url, '/')) {
            $url = self::CANONICAL_BASE_URL . $url;
        }

        $parts = parse_url($url);

        if (! $parts || empty($parts['host'])) {
            return rtrim(self::CANONICAL_BASE_URL . '/' . ltrim($url, '/'), '/');
        }

        $path = preg_replace('#/+#', '/', $parts['path'] ?? '/');
        $path = $path ?: '/';
        $query = empty($parts['query']) ? '' : '?' . $parts['query'];

        return rtrim(self::CANONICAL_BASE_URL . ($path === '/' ? '' : $path) . $query, '/') ?: self::CANONICAL_BASE_URL;
    }
}
