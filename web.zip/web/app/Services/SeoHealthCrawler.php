<?php

namespace App\Services;

use App\Models\SeoRedirect;
use DOMDocument;
use DOMXPath;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Throwable;

class SeoHealthCrawler
{
    private const MAX_INTERNAL_LINK_CHECKS = 120;
    private const MAX_IMAGE_SIZE_CHECKS = 80;
    private const LARGE_IMAGE_BYTES = 524288;

    private string $baseUrl;
    private string $baseHost;
    private string $baseScheme;
    private array $issues = [];
    private array $pages = [];
    private array $inbound = [];
    private array $internalLinks = [];
    private array $imageUrls = [];
    private array $sitemapUrls = [];

    public function crawl(int $maxPages = 100): array
    {
        $this->baseUrl = rtrim((string) config('app.url'), '/');
        $this->baseHost = (string) parse_url($this->baseUrl, PHP_URL_HOST);
        $this->baseScheme = (string) (parse_url($this->baseUrl, PHP_URL_SCHEME) ?: 'https');

        if ($this->baseUrl === '' || $this->baseHost === '') {
            $this->addIssue('site', 'error', '/', 'آدرس APP_URL معتبر نیست.');

            return $this->result();
        }

        $queue = $this->seedUrls();
        $visited = [];

        while ($queue && count($visited) < $maxPages) {
            $url = array_shift($queue);
            $url = $this->normalizeUrl($url);

            if (! $url || isset($visited[$url]) || ! $this->isInternalUrl($url) || $this->shouldSkipUrl($url)) {
                continue;
            }

            $visited[$url] = true;
            $newLinks = $this->crawlPage($url);

            foreach ($newLinks as $link) {
                if (! isset($visited[$link]) && count($visited) + count($queue) < ($maxPages * 2)) {
                    $queue[] = $link;
                }
            }
        }

        $this->checkDuplicates();
        $this->checkOrphanPages();
        $this->checkPagesWithoutOutgoingInternalLinks();
        $this->checkSitemapCoverage();
        $this->checkBrokenInternalLinks();
        $this->checkRedirectedInternalLinks();
        $this->checkLargeImages();
        $this->checkRedirectIssues();

        return $this->result();
    }

    private function seedUrls(): array
    {
        $urls = [$this->baseUrl . '/'];
        $this->sitemapUrls = $this->fetchSitemapUrls();

        return array_values(array_unique(array_merge($urls, array_slice($this->sitemapUrls, 0, 100))));
    }

    private function fetchSitemapUrls(): array
    {
        try {
            $response = Http::timeout(8)->get($this->baseUrl . '/sitemap.xml');
        } catch (Throwable) {
            $this->addIssue('sitemap', 'warning', $this->baseUrl . '/sitemap.xml', 'sitemap قابل خواندن نیست.');

            return [];
        }

        if (! $response->successful()) {
            $this->addIssue('sitemap', 'warning', $this->baseUrl . '/sitemap.xml', 'sitemap پاسخ موفق برنگرداند.', 'HTTP ' . $response->status());

            return [];
        }

        preg_match_all('/<loc>\s*([^<]+)\s*<\/loc>/i', $response->body(), $matches);

        return array_values(array_filter(array_map(fn ($url) => $this->normalizeUrl(html_entity_decode($url)), $matches[1] ?? [])));
    }

    private function crawlPage(string $url): array
    {
        try {
            $response = Http::timeout(8)->withHeaders([
                'User-Agent' => 'VipTaxiIran SEO Health Crawler',
            ])->get($url);
        } catch (Throwable $exception) {
            $this->addIssue('page', 'error', $url, 'صفحه قابل دریافت نیست.', $exception->getMessage());

            return [];
        }

        $status = $response->status();
        if ($status >= 400) {
            $this->addIssue('page', 'error', $url, 'صفحه خطای HTTP دارد.', 'HTTP ' . $status);
        }

        $contentType = strtolower($response->header('Content-Type', ''));
        if ($status >= 400 || ($contentType && ! str_contains($contentType, 'html'))) {
            return [];
        }

        $html = $response->body();
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
        $xpath = new DOMXPath($dom);

        $title = trim((string) optional($xpath->query('//title')->item(0))->textContent);
        $description = trim((string) optional($xpath->query("//meta[translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='description']/@content")->item(0))->textContent);
        $canonicalNode = $xpath->query("//link[translate(@rel,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='canonical']/@href")->item(0);
        $canonical = $canonicalNode ? trim((string) $canonicalNode->textContent) : '';
        $h1Count = $xpath->query('//h1')->length;
        $schemaNodes = $xpath->query("//script[translate(@type,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='application/ld+json']");

        $this->pages[$url] = [
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'h1_count' => $h1Count,
        ];

        $this->checkPageMeta($url, $title, $description, $canonical, $h1Count);
        $this->checkSchema($url, $schemaNodes);

        $links = $this->extractLinks($url, $xpath);
        $this->checkImages($url, $xpath);

        return $links;
    }

    private function checkPageMeta(string $url, string $title, string $description, string $canonical, int $h1Count): void
    {
        if ($title === '') {
            $this->addIssue('title', 'error', $url, 'صفحه title ندارد.');
        } elseif (mb_strlen($title) < 20 || mb_strlen($title) > 65) {
            $this->addIssue('title', 'warning', $url, 'طول title مناسب نیست.', $title);
        }

        if ($description === '') {
            $this->addIssue('description', 'error', $url, 'صفحه meta description ندارد.');
        } elseif (mb_strlen($description) < 70 || mb_strlen($description) > 170) {
            $this->addIssue('description', 'warning', $url, 'طول meta description مناسب نیست.', $description);
        }

        if ($canonical === '') {
            $this->addIssue('canonical', 'warning', $url, 'صفحه canonical ندارد.');
        } elseif ($this->normalizeUrl($canonical) !== $url) {
            $this->addIssue('canonical', 'warning', $url, 'canonical با آدرس صفحه متفاوت است.', $canonical);
        }

        if ($h1Count === 0) {
            $this->addIssue('heading', 'error', $url, 'صفحه H1 ندارد.');
        } elseif ($h1Count > 1) {
            $this->addIssue('heading', 'warning', $url, 'صفحه چند H1 دارد.', (string) $h1Count);
        }
    }

    private function checkSchema(string $url, $schemaNodes): void
    {
        if ($schemaNodes->length === 0) {
            $this->addIssue('schema', 'warning', $url, 'صفحه schema ندارد.');

            return;
        }

        foreach ($schemaNodes as $node) {
            $json = trim($node->textContent);
            $decoded = json_decode($json, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->addIssue('schema', 'error', $url, 'JSON-LD نامعتبر است.', json_last_error_msg());
                continue;
            }

            if (! $this->schemaHasType($decoded)) {
                $this->addIssue('schema', 'warning', $url, 'schema ناقص است و @type ندارد.');
            }
        }
    }

    private function schemaHasType(array $schema): bool
    {
        if (isset($schema['@type'])) {
            return true;
        }

        foreach (($schema['@graph'] ?? []) as $item) {
            if (is_array($item) && isset($item['@type'])) {
                return true;
            }
        }

        return false;
    }

    private function extractLinks(string $pageUrl, DOMXPath $xpath): array
    {
        $links = [];

        foreach ($xpath->query('//a[@href]') as $node) {
            $url = $this->normalizeUrl($node->getAttribute('href'), $pageUrl);

            if (! $url || ! $this->isInternalUrl($url) || $this->shouldSkipUrl($url)) {
                continue;
            }

            $links[] = $url;
            $this->internalLinks[$pageUrl][$url] = true;
            $this->inbound[$url][$pageUrl] = true;
        }

        return array_values(array_unique($links));
    }

    private function checkImages(string $pageUrl, DOMXPath $xpath): void
    {
        foreach ($xpath->query('//img') as $node) {
            $src = $this->normalizeUrl($node->getAttribute('src'), $pageUrl);
            $alt = trim((string) $node->getAttribute('alt'));

            if ($src && $this->isInternalUrl($src)) {
                $this->imageUrls[$src][$pageUrl] = true;
            }

            if ($alt === '') {
                $this->addIssue('image_alt', 'warning', $pageUrl, 'تصویر بدون ALT پیدا شد.', $src ?: 'src خالی');
            }
        }
    }

    private function checkDuplicates(): void
    {
        foreach (['title' => 'title تکراری', 'description' => 'meta description تکراری'] as $field => $message) {
            $groups = [];
            foreach ($this->pages as $url => $page) {
                $value = trim((string) $page[$field]);
                if ($value !== '') {
                    $groups[$value][] = $url;
                }
            }

            foreach ($groups as $value => $urls) {
                if (count($urls) > 1 && count($this->uniqueReportUrls($urls)) > 1) {
                    foreach ($urls as $url) {
                        $this->addIssue($field, 'warning', $url, $message, $value);
                    }
                }
            }
        }
    }

    private function uniqueReportUrls(array $urls): array
    {
        $unique = [];

        foreach ($urls as $url) {
            $key = $this->reportUrlKey($url);
            $unique[$key] = true;
        }

        return array_keys($unique);
    }

    private function reportUrlKey(string $url): string
    {
        $parts = parse_url($url);

        if (! $parts || empty($parts['host'])) {
            return $url;
        }

        $path = preg_replace('#/+#', '/', $parts['path'] ?? '/');
        $path = $path ?: '/';
        $query = $parts['query'] ?? '';

        parse_str($query, $params);
        unset($params['utm_source'], $params['utm_medium'], $params['utm_campaign'], $params['utm_term'], $params['utm_content']);
        ksort($params);

        $normalizedQuery = http_build_query($params);

        return strtolower($parts['host']).rtrim($path, '/').($normalizedQuery ? '?'.$normalizedQuery : '');
    }

    private function checkOrphanPages(): void
    {
        $urls = array_values(array_unique(array_merge(array_keys($this->pages), $this->sitemapUrls)));

        foreach ($urls as $url) {
            if ($url !== $this->baseUrl . '/' && empty($this->inbound[$url])) {
                $this->addIssue('orphan_page', 'warning', $url, 'صفحه هیچ لینک داخلی ورودی ندارد.');
            }
        }
    }

    private function checkPagesWithoutOutgoingInternalLinks(): void
    {
        foreach (array_keys($this->pages) as $url) {
            $outgoingLinks = array_filter(
                array_keys($this->internalLinks[$url] ?? []),
                fn ($link) => $link !== $url
            );

            if ($url !== $this->baseUrl . '/' && empty($outgoingLinks)) {
                $this->addIssue('outgoing_internal_links', 'warning', $url, 'صفحه هیچ لینک داخلی خروجی به صفحه دیگری ندارد.');
            }
        }
    }

    private function checkSitemapCoverage(): void
    {
        if (! $this->sitemapUrls) {
            return;
        }

        $sitemap = array_fill_keys($this->sitemapUrls, true);

        foreach (array_keys($this->pages) as $url) {
            if ($url !== $this->baseUrl . '/' && ! isset($sitemap[$url])) {
                $this->addIssue('sitemap', 'warning', $url, 'صفحه در sitemap نیست.');
            }
        }
    }

    private function checkBrokenInternalLinks(): void
    {
        $links = array_slice(array_keys(array_merge(...array_values($this->internalLinks ?: [[]]))), 0, self::MAX_INTERNAL_LINK_CHECKS);

        foreach ($links as $url) {
            try {
                $response = Http::timeout(5)->withoutRedirecting()->head($url);
                if ($response->status() === 405) {
                    $response = Http::timeout(5)->withoutRedirecting()->get($url);
                }
            } catch (Throwable) {
                $this->addIssue('broken_link', 'error', $url, 'لینک داخلی قابل بررسی نیست.', $this->internalLinkSourceDetail($url));
                continue;
            }

            if ($response->status() >= 400) {
                $detail = trim('HTTP ' . $response->status() . ' ' . $this->internalLinkSourceDetail($url));
                $this->addIssue('broken_link', 'error', $url, 'لینک داخلی شکسته است.', $detail);
            }
        }
    }

    private function checkRedirectedInternalLinks(): void
    {
        $links = array_slice(array_keys(array_merge(...array_values($this->internalLinks ?: [[]]))), 0, self::MAX_INTERNAL_LINK_CHECKS);

        foreach ($links as $url) {
            try {
                $response = Http::timeout(5)->withoutRedirecting()->head($url);
                if ($response->status() === 405) {
                    $response = Http::timeout(5)->withoutRedirecting()->get($url);
                }
            } catch (Throwable) {
                continue;
            }

            if ($response->redirect()) {
                $location = $this->normalizeUrl($response->header('Location'), $url) ?: (string) $response->header('Location');
                $detail = trim('HTTP ' . $response->status() . ' -> ' . $location . ' ' . $this->internalLinkSourceDetail($url));

                $this->addIssue('redirected_link', 'warning', $url, 'لینک داخلی به آدرسی اشاره می‌کند که ریدایرکت می‌شود.', $detail);
            }
        }
    }

    private function checkLargeImages(): void
    {
        foreach (array_slice(array_keys($this->imageUrls), 0, self::MAX_IMAGE_SIZE_CHECKS) as $url) {
            try {
                $response = Http::timeout(5)->head($url);
            } catch (Throwable) {
                continue;
            }

            $bytes = (int) $response->header('Content-Length', 0);
            if ($bytes > self::LARGE_IMAGE_BYTES) {
                $this->addIssue('image_size', 'warning', $url, 'حجم تصویر بالا است.', number_format($bytes / 1024, 0) . ' KB');
            }
        }
    }

    private function checkRedirectIssues(): void
    {
        if (! Schema::hasTable('seo_redirects')) {
            return;
        }

        $redirects = SeoRedirect::query()->where('is_active', true)->get()->keyBy('source_path');

        foreach ($redirects as $redirect) {
            $targetPath = SeoRedirect::targetPath($redirect->target_url);

            if ($targetPath && $targetPath === $redirect->source_path) {
                $this->addIssue('redirect', 'error', $redirect->source_path, 'ریدایرکت loop مستقیم دارد.');
            } elseif ($targetPath && $redirects->has($targetPath)) {
                $this->addIssue('redirect', 'warning', $redirect->source_path, 'ریدایرکت زنجیره‌ای است.', $redirect->target_url);
            }
        }
    }

    private function normalizeUrl(?string $url, ?string $currentUrl = null): ?string
    {
        $url = trim((string) $url);

        if ($url === '' || str_starts_with($url, '#') || preg_match('/^(mailto|tel|javascript):/i', $url)) {
            return null;
        }

        $url = preg_replace('/#.*$/', '', $url);

        if (str_starts_with($url, '//')) {
            $scheme = parse_url($this->baseUrl, PHP_URL_SCHEME) ?: 'https';
            $url = $scheme . ':' . $url;
        } elseif (str_starts_with($url, '/')) {
            $url = $this->baseUrl . $url;
        } elseif (! preg_match('#^https?://#i', $url) && $currentUrl) {
            $url = rtrim(dirname($currentUrl), '/') . '/' . ltrim($url, '/');
        }

        $parts = parse_url($url);
        if (! $parts || empty($parts['scheme']) || empty($parts['host'])) {
            return null;
        }

        $path = preg_replace('#/+#', '/', $parts['path'] ?? '/');
        $path = $path ?: '/';
        $host = strtolower($parts['host']);
        $scheme = strcasecmp($host, $this->baseHost) === 0
            ? strtolower($this->baseScheme)
            : strtolower($parts['scheme']);
        $normalized = $scheme . '://' . $host . $path;

        if (! empty($parts['query'])) {
            $normalized .= '?' . $parts['query'];
        }

        return $path === '/' && empty($parts['query']) ? $normalized : rtrim($normalized, '/');
    }

    private function isInternalUrl(string $url): bool
    {
        return strcasecmp((string) parse_url($url, PHP_URL_HOST), $this->baseHost) === 0;
    }

    private function shouldSkipUrl(string $url): bool
    {
        $path = parse_url($url, PHP_URL_PATH) ?: '/';

        return str_starts_with($path, '/admin-panel') ||
            str_starts_with($path, '/storage') ||
            str_starts_with($path, '/vendor') ||
            str_starts_with($path, '/build') ||
            str_starts_with($path, '/admin/assets') ||
            preg_match('/\.(pdf|zip|rar|mp4|mov|avi|webm|mp3|css|js|woff2?|ttf|eot)$/i', $path);
    }

    private function internalLinkSourceDetail(string $url): string
    {
        $sources = array_keys($this->inbound[$url] ?? []);

        if (! $sources) {
            return '';
        }

        $limitedSources = array_slice($sources, 0, 3);
        $suffix = count($sources) > 3 ? ' و ' . (count($sources) - 3) . ' صفحه دیگر' : '';

        return 'از: ' . implode('، ', $limitedSources) . $suffix;
    }

    private function addIssue(string $type, string $severity, string $url, string $message, ?string $detail = null): void
    {
        $this->issues[] = compact('type', 'severity', 'url', 'message', 'detail');
    }

    private function result(): array
    {
        $summary = [
            'pages' => count($this->pages),
            'issues' => count($this->issues),
            'errors' => count(array_filter($this->issues, fn ($issue) => $issue['severity'] === 'error')),
            'warnings' => count(array_filter($this->issues, fn ($issue) => $issue['severity'] === 'warning')),
            'by_type' => array_count_values(array_map(fn ($issue) => $issue['type'], $this->issues)),
        ];

        return [
            'scanned_urls' => count($this->pages),
            'issue_count' => count($this->issues),
            'summary' => $summary,
            'issues' => $this->issues,
        ];
    }
}
