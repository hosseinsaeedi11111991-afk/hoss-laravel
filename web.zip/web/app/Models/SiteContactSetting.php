<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteContactSetting extends Model
{
    protected $fillable = [
        'phone_number',
        'whatsapp_number',
        'display_phone',
    ];
}
