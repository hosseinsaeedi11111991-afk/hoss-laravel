<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class SeoIndexRule extends Model
{
    public const CACHE_KEY = 'seo_index_rules.active';

    public const MATCH_PATH = 'path';
    public const MATCH_QUERY_KEY = 'query_key';
    public const MATCH_QUERY_VALUE = 'query_value';
    public const MATCH_FULL_URL = 'full_url';

    public const ROBOTS_INDEX_FOLLOW = 'index, follow';
    public const ROBOTS_NOINDEX_FOLLOW = 'noindex, follow';
    public const ROBOTS_NOINDEX_NOFOLLOW = 'noindex, nofollow';

    protected $fillable = [
        'name',
        'match_type',
        'pattern',
        'robots_directive',
        'exclude_from_sitemap',
        'is_active',
        'priority',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'exclude_from_sitemap' => 'boolean',
            'is_active' => 'boolean',
            'priority' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (SeoIndexRule $rule) {
            $rule->pattern = trim((string) $rule->pattern);
            $rule->priority = max(1, (int) $rule->priority);
        });

        static::saved(fn () => self::flushCache());
        static::deleted(fn () => self::flushCache());
    }

    public static function matchTypes(): array
    {
        return [
            self::MATCH_PATH => 'مسیر صفحه',
            self::MATCH_QUERY_KEY => 'وجود پارامتر',
            self::MATCH_QUERY_VALUE => 'مقدار پارامتر',
            self::MATCH_FULL_URL => 'آدرس کامل',
        ];
    }

    public static function robotsDirectives(): array
    {
        return [
            self::ROBOTS_INDEX_FOLLOW => 'index, follow',
            self::ROBOTS_NOINDEX_FOLLOW => 'noindex, follow',
            self::ROBOTS_NOINDEX_NOFOLLOW => 'noindex, nofollow',
        ];
    }

    public static function flushCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }
}
