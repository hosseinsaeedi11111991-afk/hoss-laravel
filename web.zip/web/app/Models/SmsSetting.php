<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmsSetting extends Model
{
    protected $fillable = [
        'sender',
        'reservation_admin_recipient',
        'reservation_admin_pattern',
        'reservation_passenger_pattern',
        'require_phone_before_route_calculation',
        'send_sms_after_early_phone_capture',
    ];

    protected $casts = [
        'require_phone_before_route_calculation' => 'boolean',
        'send_sms_after_early_phone_capture' => 'boolean',
    ];
}
