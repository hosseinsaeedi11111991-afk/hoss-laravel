<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Testimonial extends Model
{
    protected $fillable = [
        'name',
        'role',
        'body',
        'image_path',
        'image_alt',
        'rating',
        'sort_order',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'rating' => 'integer',
        'sort_order' => 'integer',
    ];

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function getImageUrlAttribute(): string
    {
        if ($this->image_path && str_starts_with($this->image_path, 'testimonials/')) {
            return Storage::disk('public')->url($this->image_path);
        }

        return $this->image_path ?: asset('site/img/team/1.webp');
    }

    public function getDisplayAltAttribute(): string
    {
        return trim((string) $this->image_alt) !== '' ? $this->image_alt : $this->name;
    }
}
