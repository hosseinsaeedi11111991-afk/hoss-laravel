<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SeoHealthReport extends Model
{
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_FAILED = 'failed';
    public const STATUS_RUNNING = 'running';

    protected $fillable = [
        'status',
        'scanned_urls',
        'issue_count',
        'summary',
        'issues',
        'started_at',
        'finished_at',
        'error_message',
    ];

    protected function casts(): array
    {
        return [
            'summary' => 'array',
            'issues' => 'array',
            'started_at' => 'datetime',
            'finished_at' => 'datetime',
        ];
    }
}
