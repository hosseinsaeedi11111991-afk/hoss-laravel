<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class HomeAboutSection extends Model
{
    protected $fillable = [
        'subtitle',
        'title',
        'highlight_title',
        'body',
        'features',
        'image_path',
        'image_alt',
        'video_url',
        'is_active',
    ];

    protected $casts = [
        'features' => 'array',
        'is_active' => 'boolean',
    ];

    public function getImageUrlAttribute(): string
    {
        if ($this->image_path && str_starts_with($this->image_path, 'home-about/')) {
            return Storage::disk('public')->url($this->image_path);
        }

        return $this->image_path ?: asset('site/img/about.webp');
    }

    public function getDisplayAltAttribute(): string
    {
        return trim((string) $this->image_alt) !== '' ? $this->image_alt : 'تاکسی بین شهری';
    }
}
