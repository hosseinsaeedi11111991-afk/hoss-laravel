<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class SeoRedirect extends Model
{
    public const STATUS_301 = 301;
    public const STATUS_302 = 302;
    public const STATUS_410 = 410;

    public const CACHE_KEY = 'seo_redirects.active_map';

    protected $fillable = [
        'source_path',
        'source_hash',
        'target_url',
        'status_code',
        'is_active',
        'hits',
        'last_hit_at',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'status_code' => 'integer',
            'is_active' => 'boolean',
            'hits' => 'integer',
            'last_hit_at' => 'datetime',
        ];
    }

    public static function statuses(): array
    {
        return [
            self::STATUS_301 => '301 - دائمی',
            self::STATUS_302 => '302 - موقت',
            self::STATUS_410 => '410 - Gone',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (SeoRedirect $redirect) {
            $redirect->source_path = self::normalizeSourcePath($redirect->source_path);
            $redirect->source_hash = self::sourceHash($redirect->source_path);
        });

        static::saved(fn () => self::flushRedirectCache());
        static::deleted(fn () => self::flushRedirectCache());
    }

    public static function sourceHash(string $sourcePath): string
    {
        return hash('sha256', self::normalizeSourcePath($sourcePath));
    }

    public static function flushRedirectCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }

    public static function normalizeSourcePath(?string $value): string
    {
        $value = trim((string) $value);

        if ($value === '') {
            return '/';
        }

        if (filter_var($value, FILTER_VALIDATE_URL)) {
            $parts = parse_url($value);
            $value = $parts['path'] ?? '/';
        }

        $value = '/' . ltrim($value, '/');
        $value = preg_replace('#/+#', '/', $value) ?: '/';

        return rtrim($value, '/') ?: '/';
    }

    public static function targetPath(?string $targetUrl): ?string
    {
        $targetUrl = trim((string) $targetUrl);

        if ($targetUrl === '') {
            return null;
        }

        if (str_starts_with($targetUrl, '/')) {
            return self::normalizeSourcePath($targetUrl);
        }

        if (! filter_var($targetUrl, FILTER_VALIDATE_URL)) {
            return null;
        }

        $appHost = parse_url((string) config('app.url'), PHP_URL_HOST);
        $targetHost = parse_url($targetUrl, PHP_URL_HOST);

        if ($appHost && $targetHost && strcasecmp($appHost, $targetHost) === 0) {
            return self::normalizeSourcePath(parse_url($targetUrl, PHP_URL_PATH) ?: '/');
        }

        return null;
    }
}
