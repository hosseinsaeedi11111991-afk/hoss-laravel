<?php

return [
    'thumbnail_path'    => 'thumbnails',
    'poster_path'       => 'posters',
    'thumbnail_quality' => 90,
    'thumbnail_sizes'   => [
        'small'  => 150,
        'medium' => 300,
        'large'  => 600,
        'xlarge' => 1200,
    ],
    'default_disk' => 'public',
    'chunk_size'   => 8388608, // 8MB
];
