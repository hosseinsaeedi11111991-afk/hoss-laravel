#!/bin/bash

echo "========== Laravel Deploy =========="

echo "Pulling latest code..."
git pull --ff-only origin main || exit 1

echo "Clearing caches..."
php artisan optimize:clear || exit 1

echo "Caching config..."
php artisan config:cache || exit 1

echo "Caching routes..."
php artisan route:cache || exit 1

echo "Caching views..."
php artisan view:cache || exit 1

echo ""
echo "✅ Deployment completed successfully."