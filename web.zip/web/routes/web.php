<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\DistanceController;
use App\Http\Controllers\Admin\SeoHealthController;
use App\Http\Controllers\Admin\SeoIndexRuleController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Admin\SeoRedirectController;
use App\Http\Controllers\Admin\ClientLogoController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\Admin\FooterServiceLinkController;
use App\Http\Controllers\Admin\HomeAboutSectionController;
use App\Http\Controllers\Admin\MobileActionController;
use App\Http\Controllers\Admin\SmsSettingsController;
use App\Http\Controllers\Admin\LogViewerController;
use Modules\Sitemap\Http\Controllers\SitemapController;
use App\Http\Controllers\RobotsController;
use Modules\Reservation\Http\Controllers\site\PopularRouteSiteController;
use Modules\Reservation\Http\Controllers\site\ReservationSiteController;

// Public robots.txt, ai.txt and llms.txt routes - Must be before catch-all routes
Route::get('/robots.txt', [RobotsController::class, 'robots'])->name('robots');
Route::get('/ai.txt', [RobotsController::class, 'ai'])->name('ai');
Route::get('/llms.txt', [RobotsController::class, 'llms'])->name('llms');

// Public sitemap route - Must be before catch-all routes
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');

Route::get('/', [WelcomeController::class, 'index'])->name('home');

// Reservation page (site) - ensure it is loaded with main routes
Route::get('/reservation/{reservation?}', [ReservationSiteController::class, 'index'])->name('site.reservation.index');
Route::post('/popular-route/{popularRoute}/start', [PopularRouteSiteController::class, 'start'])->name('site.popular-route.start');

Route::post('/calculate-distance', [DistanceController::class, 'calculate']);
Route::post('/calculate-multiple-distances', [DistanceController::class, 'calculateMultipleDistances']);

// Route to view Neshan locations for a reservation
Route::get('/admin/reservations/{reservation}/neshan', function ($reservation) {
    $locations = \Modules\Neshan\Models\NeshanLocation::where('reservation_id', $reservation)
        ->orderBy('type')
        ->orderByDesc('is_primary')
        ->get();

    return view('neshan-locations', compact('reservation', 'locations'));
})->name('reservation.neshan');




// Map routes
Route::get('/route', [WelcomeController::class, 'index']);
Route::get('/route2', [WelcomeController::class, 'index']);
Route::get('/route-view', [WelcomeController::class, 'routeView']);
Route::get('/route-w', [WelcomeController::class, 'testPolygon']);

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->get('/admin-panel', function () {
        $stats = ['today' => 0, 'pending' => 0, 'completed' => 0, 'revenue' => 0];
        try {
            $stats['today']     = \Modules\Reservation\Models\Reservation::whereDate('created_at', today())->count();
            $stats['pending']   = \Modules\Reservation\Models\Reservation::where('status', 'pending')->count();
            $stats['completed'] = \Modules\Reservation\Models\Reservation::where('status', 'completed')->count();
            $stats['revenue']   = (float) \Modules\Reservation\Models\Reservation::where('status', 'completed')
                ->whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)
                ->sum('total_price');
        } catch (\Throwable $e) {
            // اگر جدول رزرو در دسترس نبود، آمار صفر می‌ماند و داشبورد سالم رندر می‌شود
        }

        return view('admin.dashboard', compact('stats'));
    })->name('admin.home');

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/seo')
    ->name('admin.seo.')
    ->group(function () {
        Route::get('health', [SeoHealthController::class, 'index'])->name('health.index');
        Route::post('health/crawl', [SeoHealthController::class, 'crawl'])->name('health.crawl');
        Route::resource('index-rules', SeoIndexRuleController::class)
            ->parameters(['index-rules' => 'indexRule'])
            ->except(['show', 'create', 'edit']);
        Route::resource('redirects', SeoRedirectController::class)->except(['show']);
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/media')
    ->name('admin.media.')
    ->group(function () {
        Route::get('/', [MediaController::class, 'index'])->name('index');
        Route::post('/', [MediaController::class, 'store'])->name('store');
        Route::put('/filesystem-alt', [MediaController::class, 'updateFilesystemAlt'])->name('filesystemAlt');
        Route::put('/{attachment}', [MediaController::class, 'update'])->name('update');
        Route::delete('/bulk-delete', [MediaController::class, 'bulkDestroy'])->name('bulkDestroy');
        Route::delete('/{attachment}', [MediaController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/client-logos')
    ->name('admin.client-logos.')
    ->group(function () {
        Route::get('/', [ClientLogoController::class, 'index'])->name('index');
        Route::post('/', [ClientLogoController::class, 'store'])->name('store');
        Route::put('/{clientLogo}', [ClientLogoController::class, 'update'])->name('update');
        Route::delete('/{clientLogo}', [ClientLogoController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/testimonials')
    ->name('admin.testimonials.')
    ->group(function () {
        Route::get('/', [TestimonialController::class, 'index'])->name('index');
        Route::post('/', [TestimonialController::class, 'store'])->name('store');
        Route::put('/{testimonial}', [TestimonialController::class, 'update'])->name('update');
        Route::delete('/{testimonial}', [TestimonialController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/footer-service-links')
    ->name('admin.footer-service-links.')
    ->group(function () {
        Route::get('/', [FooterServiceLinkController::class, 'index'])->name('index');
        Route::post('/', [FooterServiceLinkController::class, 'store'])->name('store');
        Route::put('/{footerServiceLink}', [FooterServiceLinkController::class, 'update'])->name('update');
        Route::delete('/{footerServiceLink}', [FooterServiceLinkController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/home-about')
    ->name('admin.home-about.')
    ->group(function () {
        Route::get('/', [HomeAboutSectionController::class, 'edit'])->name('edit');
        Route::put('/', [HomeAboutSectionController::class, 'update'])->name('update');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/mobile-actions')
    ->name('admin.mobile-actions.')
    ->group(function () {
        Route::get('/', [MobileActionController::class, 'index'])->name('index');
        Route::put('/contact', [MobileActionController::class, 'updateContact'])->name('contact.update');
        Route::post('/', [MobileActionController::class, 'store'])->name('store');
        Route::put('/{mobileBottomLink}', [MobileActionController::class, 'update'])->name('update');
        Route::delete('/{mobileBottomLink}', [MobileActionController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/sms-settings')
    ->name('admin.sms-settings.')
    ->group(function () {
        Route::get('/', [SmsSettingsController::class, 'index'])->name('index');
        Route::put('/', [SmsSettingsController::class, 'update'])->name('update');
    });

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel/logs')
    ->name('admin.logs.')
    ->group(function () {
        Route::get('/', [LogViewerController::class, 'index'])->name('index');
    });

Route::get('/about-us', [WelcomeController::class, 'aboutUs'])->name('about-us');
Route::get('/contact-us', [WelcomeController::class, 'contactUS'])->name('contact-us');

if (! Route::has('site.popular-route.start')) {
    Route::post('/popular-route/{popularRoute}/start', [PopularRouteSiteController::class, 'start'])->name('site.popular-route.start');
}

Route::name('site.reservation.')->group(function () {
    if (! Route::has('site.reservation.index')) {
        Route::get('/reservation/{reservation?}', [ReservationSiteController::class, 'index'])->name('index');
    }

    if (! Route::has('site.reservation.store')) {
        Route::post('/reservation', [ReservationSiteController::class, 'store'])->name('store');
    }

    if (! Route::has('site.reservation.prepare')) {
        Route::post('/reservation/prepare', [ReservationSiteController::class, 'prepare'])->name('prepare');
    }

    if (! Route::has('site.reservation.preview')) {
        Route::post('/reservation/preview', [ReservationSiteController::class, 'previewSelection'])->name('preview');
    }

    if (! Route::has('site.reservation.price-quote')) {
        Route::post('/reservation/price-quote', [ReservationSiteController::class, 'getPriceQuote'])->name('price-quote');
    }
});

if (! Route::has('admin.auth.pass.login.form')) {
    Route::middleware(['web'])
        ->prefix('admin-panel/auth')
        ->name('admin.auth.')
        ->group(function () {
            Route::middleware('guest')
                ->controller(\Modules\Auth\Http\Controllers\Admin\AuthController::class)
                ->group(function () {
                    Route::get('/login/password', 'loginByPassForm')->name('pass.login.form');
                    Route::post('/login/password', 'loginByPass')->name('pass.login.submit');
                });

            Route::middleware('auth')
                ->controller(\Modules\Auth\Http\Controllers\Admin\AuthController::class)
                ->group(function () {
                    Route::get('/logout', 'logout')->name('logout');
                });
        });
}

if (! Route::has('admin.reservations.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
        ->prefix('admin-panel/reservations')
        ->controller(\Modules\Reservation\Http\Controllers\Admin\ReservationController::class)
        ->group(function () {
            Route::get('/', 'index')->name('admin.reservations.index');
            Route::get('create', 'create')->name('admin.reservations.create');
            Route::get('export', 'export')->name('admin.reservations.export');
            Route::delete('bulk-delete', 'bulkDestroy')->name('admin.reservations.bulkDestroy');
            Route::post('/', 'store')->name('admin.reservations.store');
            Route::get('{reservation}', 'show')->name('admin.reservations.show');
            Route::get('{reservation}/edit', 'edit')->name('admin.reservations.edit');
            Route::put('{reservation}', 'update')->name('admin.reservations.update');
            Route::delete('{reservation}', 'destroy')->name('admin.reservations.destroy');
            Route::patch('{reservation}/status', 'updateStatus')->name('admin.reservations.updateStatus');
            Route::get('{reservation}/neshan', 'neshan')->name('admin.reservations.neshan');
        });
}

if (! Route::has('admin.pricing_rules.index')) {
    Route::prefix('admin')
        ->middleware(['auth', 'role:super_user|admin'])
        ->group(function () {
            Route::get('pricing_rules/cities/{provinceId}', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'getCities'])->name('admin.pricing_rules.cities');
            Route::get('pricing_rules/bulk/create', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkCreate'])->name('admin.pricing_rules.bulk.create');
            Route::post('pricing_rules/bulk/store', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkStore'])->name('admin.pricing_rules.bulk.store');
            Route::get('pricing_rules/bulk/edit', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkEdit'])->name('admin.pricing_rules.bulk.edit');
            Route::post('pricing_rules/bulk/update', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkUpdate'])->name('admin.pricing_rules.bulk.update');
            Route::get('pricing_rules/bulk/delete', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkDelete'])->name('admin.pricing_rules.bulk.delete');
            Route::delete('pricing_rules/bulk/destroy', [\Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class, 'bulkDestroy'])->name('admin.pricing_rules.bulk.destroy');
            Route::resource('pricing_rules', \Modules\Pricing\Http\Controllers\Admin\PricingRuleController::class)->names('admin.pricing_rules');
            Route::resource('city_pricings', \Modules\Pricing\Http\Controllers\Admin\CityPricingController::class)->names('admin.city_pricings');
            Route::resource('default_pricings', \Modules\Pricing\Http\Controllers\Admin\DefaultPricingController::class)->names('admin.default_pricings');
            Route::get('pricing-rules/run-seeder', [\Modules\Pricing\Http\Controllers\Admin\PricingSeederController::class, 'runSeeder'])->name('admin.pricing_rules.run_seeder');
        });
}

if (! Route::has('admin.discounts.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin'])
        ->prefix('admin-panel')
        ->group(function () {
            Route::controller(\Modules\Discount\Http\Controllers\Admin\DiscountController::class)
                ->prefix('discounts')
                ->group(function () {
                    Route::get('/', 'index')->name('admin.discounts.index');
                    Route::get('create', 'create')->name('admin.discounts.create');
                    Route::post('/', 'store')->name('admin.discounts.store');
                    Route::get('{discount}', 'show')->name('admin.discounts.show');
                    Route::get('{discount}/edit', 'edit')->name('admin.discounts.edit');
                    Route::put('{discount}', 'update')->name('admin.discounts.update');
                    Route::delete('{discount}', 'destroy')->name('admin.discounts.destroy');
                });

            Route::controller(\Modules\Discount\Http\Controllers\Admin\DiscountUsageController::class)
                ->prefix('discount-usages')
                ->group(function () {
                    Route::get('/', 'index')->name('admin.discount-usages.index');
                    Route::get('{discountUsage}', 'show')->name('admin.discount-usages.show');
                });
        });
}

if (! Route::has('admin.neshan-locations.index')) {
    Route::middleware(['web'])
        ->prefix('admin-panel')
        ->name('admin.neshan-locations.')
        ->group(function () {
            Route::resource('neshan-locations', \Modules\Neshan\Http\Controllers\Admin\NeshanLocationController::class)
                ->parameters(['neshan-locations' => 'neshan_location'])
                ->names([
                    'index' => 'index',
                    'create' => 'create',
                    'store' => 'store',
                    'show' => 'show',
                    'edit' => 'edit',
                    'update' => 'update',
                    'destroy' => 'destroy',
                ]);

            Route::resource('neshan-location-cities', \Modules\Neshan\Http\Controllers\Admin\NeshanLocationCityController::class)
                ->parameters(['neshan-location-cities' => 'neshan_location_city'])
                ->names([
                    'index' => 'city.index',
                    'create' => 'city.create',
                    'store' => 'city.store',
                    'show' => 'city.show',
                    'edit' => 'city.edit',
                    'update' => 'city.update',
                    'destroy' => 'city.destroy',
                ]);
        });
}

if (! Route::has('admin.menu.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
        ->prefix('admin-panel')
        ->name('admin.')
        ->group(function () {
            Route::controller(\Modules\Menu\Http\Controllers\Admin\MenuController::class)
                ->prefix('menu')
                ->name('menu.')
                ->group(function () {
                    Route::get('{position}/', 'index')->name('index');
                    Route::get('{position}/create', 'create')->name('create');
                    Route::post('store', 'store')->name('store');
                    Route::get('{menu}/show', 'show')->name('show');
                    Route::get('{menu}/edit', 'edit')->name('edit');
                    Route::put('{menu}/update', 'update')->name('update');
                    Route::put('{menu}/toggle-status', 'toggleStatus')->name('toggle_status');
                    Route::delete('{menu}/destroy', 'destroy')->name('destroy');
                });

            Route::controller(\Modules\Menu\Http\Controllers\Admin\MenuItemController::class)
                ->prefix('menu/{menu}/item')
                ->name('menu_item.')
                ->group(function () {
                    Route::get('/', 'index')->name('index');
                    Route::get('create', 'create')->name('create');
                    Route::post('store', 'store')->name('store');
                    Route::get('{menu_item}/show', 'show')->name('show');
                    Route::get('{menu_item}/edit', 'edit')->name('edit');
                    Route::put('{menu_item}/update', 'update')->name('update');
                    Route::put('{menu_item}/toggle-status', 'toggleStatus')->name('toggle_status');
                    Route::delete('{menu_item}/destroy', 'destroy')->name('destroy');
                });
        });
}

if (! Route::has('admin.faq.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
        ->prefix('admin-panel')
        ->name('admin.')
        ->group(function () {
            Route::controller(\Modules\Faq\Http\Controllers\Admin\FaqController::class)
                ->prefix('faq')
                ->name('faq.')
                ->group(function () {
                    Route::get('/', 'index')->name('index');
                    Route::get('/create', 'create')->name('create');
                    Route::get('{faq}/show', 'show')->name('show');
                    Route::get('{faq}/edit', 'edit')->name('edit');
                    Route::put('{faq}/update', 'update')->name('update');
                    Route::put('{faq}/toggle-status', 'toggleStatus')->name('toggle_status');
                    Route::delete('{faq}/destroy', 'destroy')->name('destroy');
                });

            Route::controller(\Modules\Faq\Http\Controllers\Admin\FaqContentController::class)
                ->prefix('faq/{faq}/content')
                ->name('faq_content.')
                ->group(function () {
                    Route::get('/', 'index')->name('index');
                    Route::get('/create', 'create')->name('create');
                    Route::post('/store', 'store')->name('store');
                    Route::get('{faq_content}/show', 'show')->name('show');
                    Route::get('{faq_content}/edit', 'edit')->name('edit');
                    Route::put('{faq_content}/update', 'update')->name('update');
                    Route::put('{faq_content}/toggle-status', 'toggleStatus')->name('toggle_status');
                    Route::delete('{faq_content}/destroy', 'destroy')->name('destroy');
                });
        });
}

if (! Route::has('admin.page.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
        ->prefix('admin-panel')
        ->name('admin.')
        ->group(function () {
            Route::controller(\Modules\Page\Http\Controllers\Admin\PageController::class)
                ->prefix('page')
                ->name('page.')
                ->group(function () {
                    Route::get('/', 'index')->name('index');
                    Route::get('/create', 'create')->name('create');
                    Route::post('/store', 'store')->name('store');
                    Route::get('{page}/show', 'show')->name('show');
                    Route::get('{page}/edit', 'edit')->name('edit');
                    Route::put('{page}/update', 'update')->name('update');
                    Route::put('{page}/toggle-status', 'toggleStatus')->name('toggle_status');
                    Route::delete('{page}/destroy', 'destroy')->name('destroy');
                });
        });
}

if (! Route::has('admin.role.index')) {
    Route::middleware(['web'])
        ->prefix('admin-panel')
        ->name('admin.')
        ->group(function () {
            Route::controller(\Modules\Permission\Http\Controllers\Admin\RoleController::class)
                ->middleware(['auth', 'role:super_user|admin'])
                ->prefix('role')
                ->name('role.')
                ->group(function () {
                    Route::get('', 'index')->name('index');
                    Route::get('create', 'create')->name('create');
                    Route::post('store', 'store')->name('store');
                    Route::get('{role}/edit', 'edit')->name('edit');
                    Route::put('{role}/update', 'update')->name('update');
                    Route::delete('{role}/destroy', 'destroy')->name('destroy');
                });

            Route::controller(\Modules\Permission\Http\Controllers\Admin\PermissionController::class)
                ->middleware(['auth', 'role:super_user|admin'])
                ->prefix('permission')
                ->name('permission.')
                ->group(function () {
                    Route::get('', 'index')->name('index');
                    Route::get('create', 'create')->name('create');
                    Route::post('store', 'store')->name('store');
                    Route::get('{permission}/edit', 'edit')->name('edit');
                    Route::put('{permission}/update', 'update')->name('update');
                    Route::delete('{permission}/destroy', 'destroy')->name('destroy');
                });
        });
}

if (! Route::has('admin.blog-post.index')) {
    Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
        ->prefix('admin-panel')
        ->get('blog-posts', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'index'])
        ->name('admin.blog-post.index');
}

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')
    ->group(function () {
        if (! Route::has('admin.blog-post.import')) {
            Route::get('blog-posts/import', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'importForm'])
                ->name('admin.blog-post.import');
        }

        if (! Route::has('admin.blog-post.test-connection')) {
            Route::post('blog-posts/test-connection', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'testWordPressConnection'])
                ->name('admin.blog-post.test-connection');
        }

        if (! Route::has('admin.blog-post.fetch-posts')) {
            Route::post('blog-posts/fetch-posts', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'fetchWordPressPosts'])
                ->name('admin.blog-post.fetch-posts');
        }

        if (! Route::has('admin.blog-post.import-posts')) {
            Route::post('blog-posts/import-posts', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'importWordPressPosts'])
                ->name('admin.blog-post.import-posts');
        }

        if (! Route::has('admin.blog-post.create')) {
            Route::get('blog-posts/create', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'create'])
                ->name('admin.blog-post.create');
        }

        if (! Route::has('admin.blog-post.store')) {
            Route::post('blog-posts', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'store'])
                ->name('admin.blog-post.store');
        }

        if (! Route::has('admin.blog-post.show')) {
            Route::get('blog-posts/{blog_post}', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'show'])
                ->name('admin.blog-post.show');
        }

        if (! Route::has('admin.blog-post.edit')) {
            Route::get('blog-posts/{blog_post}/edit', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'edit'])
                ->name('admin.blog-post.edit');
        }

        if (! Route::has('admin.blog-post.update')) {
            Route::match(['put', 'patch'], 'blog-posts/{blog_post}', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'update'])
                ->name('admin.blog-post.update');
        }

        if (! Route::has('admin.blog-post.destroy')) {
            Route::delete('blog-posts/{blog_post}', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'destroy'])
                ->name('admin.blog-post.destroy');
        }

        if (! Route::has('admin.blog-post.toggle.status')) {
            Route::post('blog_posts/toggle-status', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'toggleStatus'])
                ->name('admin.blog-post.toggle.status');
        }

        if (! Route::has('admin.blog-post.uploadImageArticle')) {
            Route::post('blog_posts/upload-image-article', [\Modules\Blog\Http\Controllers\admin\BlogPostController::class, 'uploadImageArticle'])
                ->name('admin.blog-post.uploadImageArticle');
        }
    });

Route::name('blog.')->group(function () {
    if (! Route::has('blog.index')) {
        Route::get('/blog-category', [\Modules\Blog\Http\Controllers\site\BlogController::class, 'index'])->name('index');
    }

    if (! Route::has('blog.comment.store')) {
        Route::post('/comment', [\Modules\Blog\Http\Controllers\site\BlogController::class, 'storeComment'])->name('comment.store');
    }

    if (! Route::has('blog.tag')) {
        Route::get('/tag/{slug}', [\Modules\Blog\Http\Controllers\site\BlogController::class, 'tag'])->name('tag');
    }

    if (! Route::has('blog.category')) {
        Route::get('/مقالات', [\Modules\Blog\Http\Controllers\site\BlogController::class, 'category'])->name('category');
    }
});

if (! Route::has('blog.show')) {
    Route::get('/{slug}', [\Modules\Blog\Http\Controllers\site\BlogController::class, 'show'])->name('blog.show');
}
