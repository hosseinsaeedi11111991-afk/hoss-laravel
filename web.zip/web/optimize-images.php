<?php
/**
 * Script to optimize logo images by reducing quality and dimensions
 * 
 * Usage: php optimize-images.php
 * 
 * This script will:
 * 1. Find all logo images in public/site/img/logo directory
 * 2. Optimize them by reducing quality and resizing if needed
 * 3. Create optimized versions
 */

// Configuration
$logoDir = __DIR__ . '/public/site/img/logo';
$maxWidth = 300; // Maximum width for logos
$maxHeight = 300; // Maximum height for logos
$quality = 75; // WebP quality (0-100)

// Check if GD extension is available
if (!function_exists('imagewebp')) {
    die("Error: GD extension with WebP support is required!\n");
}

// Check if Imagick is available (alternative)
$useImagick = extension_loaded('imagick');

/**
 * Optimize image with GD
 */
function optimizeWithGD($source, $destination, $maxWidth, $maxHeight, $quality) {
    $image = null;
    $info = getimagesize($source);
    if ($info === false) {
        return false;
    }

    $mime = $info['mime'];
    $width = $info[0];
    $height = $info[1];

    // Create image from source
    if ($mime == 'image/jpeg') {
        $image = imagecreatefromjpeg($source);
    } elseif ($mime == 'image/png') {
        $image = imagecreatefrompng($source);
        imagealphablending($image, false);
        imagesavealpha($image, true);
    } elseif ($mime == 'image/webp') {
        $image = imagecreatefromwebp($source);
    } else {
        return false;
    }

    if ($image === false) {
        return false;
    }

    // Calculate new dimensions
    $ratio = min($maxWidth / $width, $maxHeight / $height);
    if ($ratio < 1) {
        $newWidth = (int)($width * $ratio);
        $newHeight = (int)($height * $ratio);
        
        // Create resized image
        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        if ($mime == 'image/png' || $mime == 'image/webp') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
        }
        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        imagedestroy($image);
        $image = $newImage;
    }

    // Save as WebP
    $result = imagewebp($image, $destination, $quality);
    imagedestroy($image);
    return $result;
}

// Main execution
echo "=== Logo Image Optimizer ===\n\n";

if (!is_dir($logoDir)) {
    die("Error: Logo directory not found: $logoDir\n");
}

$logoFiles = glob($logoDir . '/*.{webp,jpg,jpeg,png}', GLOB_BRACE);

if (empty($logoFiles)) {
    echo "No logo images found to optimize.\n";
    exit(0);
}

echo "Found " . count($logoFiles) . " logo images to process.\n\n";

foreach ($logoFiles as $sourceFile) {
    $pathInfo = pathinfo($sourceFile);
    $filename = $pathInfo['filename'];
    $extension = strtolower($pathInfo['extension']);
    
    // Skip if already optimized
    if (strpos($filename, '_optimized') !== false) {
        echo "Skipping (already optimized): " . basename($sourceFile) . "\n";
        continue;
    }
    
    // Create optimized filename
    $optimizedFile = $pathInfo['dirname'] . '/' . $filename . '_optimized.webp';
    
    // Check original file size
    $originalSize = filesize($sourceFile);
    
    echo "Optimizing: " . basename($sourceFile) . " -> " . basename($optimizedFile) . "... ";
    
    $success = optimizeWithGD($sourceFile, $optimizedFile, $maxWidth, $maxHeight, $quality);
    
    if ($success && file_exists($optimizedFile)) {
        $optimizedSize = filesize($optimizedFile);
        $savings = $originalSize - $optimizedSize;
        $percentage = round(($savings / $originalSize) * 100, 2);
        
        echo "DONE\n";
        echo "  Original: " . number_format($originalSize) . " bytes\n";
        echo "  Optimized: " . number_format($optimizedSize) . " bytes\n";
        echo "  Savings: " . number_format($savings) . " bytes ($percentage%)\n\n";
    } else {
        echo "FAILED\n\n";
    }
}

echo "Optimization process completed.\n";
echo "\nNote: Review optimized images and update Blade templates to use _optimized versions if satisfied.\n";

