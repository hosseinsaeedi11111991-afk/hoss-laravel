<?php
/**
 * Script to minify CSS and JavaScript files
 * 
 * Usage: php minify-assets.php
 * 
 * This script will:
 * 1. Minify CSS files (style.css)
 * 2. Minify JavaScript files (select2.js, datepicker.js, magnific-popup.js)
 * 3. Create .min versions of files
 */

// Configuration
$cssFiles = [
    'public/site/css/style.css' => 'public/site/css/style.min.css'
];

$jsFiles = [
    'public/site/js/select2.js' => 'public/site/js/select2.min.js',
    'public/site/js/datepicker.js' => 'public/site/js/datepicker.min.js',
    'public/site/js/jquery.magnific-popup.js' => 'public/site/js/jquery.magnific-popup.min.js'
];

/**
 * Minify CSS
 */
function minifyCSS($css) {
    // Remove comments
    $css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
    
    // Remove whitespace
    $css = str_replace(["\r\n", "\r", "\n", "\t", '  ', '    ', '    '], '', $css);
    
    // Remove spaces around colons, semicolons, braces, etc.
    $css = preg_replace('/\s*:\s*/', ':', $css);
    $css = preg_replace('/\s*;\s*/', ';', $css);
    $css = preg_replace('/\s*{\s*/', '{', $css);
    $css = preg_replace('/\s*}\s*/', '}', $css);
    $css = preg_replace('/\s*,\s*/', ',', $css);
    $css = preg_replace('/\s*>\s*/', '>', $css);
    $css = preg_replace('/\s*\+\s*/', '+', $css);
    $css = preg_replace('/\s*~\s*/', '~', $css);
    
    // Remove spaces around parentheses
    $css = preg_replace('/\s*\(\s*/', '(', $css);
    $css = preg_replace('/\s*\)\s*/', ')', $css);
    
    // Remove leading and trailing spaces
    $css = trim($css);
    
    return $css;
}

/**
 * Minify JavaScript (basic)
 */
function minifyJS($js) {
    // Remove single-line comments (but not URLs)
    $js = preg_replace('/(?<!:)\/\/.*$/m', '', $js);
    
    // Remove multi-line comments
    $js = preg_replace('/\/\*[\s\S]*?\*\//', '', $js);
    
    // Remove whitespace around operators (but keep in strings)
    $js = preg_replace('/\s*([=+\-*\/%<>!&|?:;,{}()\[\]])\s*/', '$1', $js);
    
    // Remove multiple spaces
    $js = preg_replace('/\s+/', ' ', $js);
    
    // Remove spaces around semicolons
    $js = preg_replace('/\s*;\s*/', ';', $js);
    
    // Remove leading and trailing spaces
    $js = trim($js);
    
    return $js;
}

// Main execution
echo "=== Asset Minifier ===\n\n";

// Minify CSS files
echo "Minifying CSS files...\n";
foreach ($cssFiles as $source => $destination) {
    if (!file_exists($source)) {
        echo "Warning: Source file not found: $source\n";
        continue;
    }
    
    echo "Processing: $source -> $destination\n";
    
    $content = file_get_contents($source);
    $minified = minifyCSS($content);
    
    // Create directory if it doesn't exist
    $dir = dirname($destination);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    file_put_contents($destination, $minified);
    
    $originalSize = strlen($content);
    $minifiedSize = strlen($minified);
    $savings = $originalSize - $minifiedSize;
    $percentage = round(($savings / $originalSize) * 100, 2);
    
    echo "  Original: " . number_format($originalSize) . " bytes\n";
    echo "  Minified: " . number_format($minifiedSize) . " bytes\n";
    echo "  Savings: " . number_format($savings) . " bytes ($percentage%)\n\n";
}

// Minify JavaScript files
echo "Minifying JavaScript files...\n";
foreach ($jsFiles as $source => $destination) {
    if (!file_exists($source)) {
        echo "Warning: Source file not found: $source\n";
        continue;
    }
    
    echo "Processing: $source -> $destination\n";
    
    $content = file_get_contents($source);
    $minified = minifyJS($content);
    
    // Create directory if it doesn't exist
    $dir = dirname($destination);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    file_put_contents($destination, $minified);
    
    $originalSize = strlen($content);
    $minifiedSize = strlen($minified);
    $savings = $originalSize - $minifiedSize;
    $percentage = round(($savings / $originalSize) * 100, 2);
    
    echo "  Original: " . number_format($originalSize) . " bytes\n";
    echo "  Minified: " . number_format($minifiedSize) . " bytes\n";
    echo "  Savings: " . number_format($savings) . " bytes ($percentage%)\n\n";
}

echo "Minification completed!\n";
echo "\nNote: Update your Blade templates to use .min versions of files.\n";

