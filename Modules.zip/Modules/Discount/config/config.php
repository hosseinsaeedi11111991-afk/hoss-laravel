<?php

return [
    'name' => 'Discount',
    'description' => 'Discount module for taxi reservation system',
];

