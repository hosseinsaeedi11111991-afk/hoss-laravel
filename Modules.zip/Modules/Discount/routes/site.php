<?php

use Illuminate\Support\Facades\Route;
use Modules\Discount\Http\Controllers\site\DiscountSiteController;

Route::middleware(['web'])->group(function () {
    // Routes for site if needed
});

