<?php

use Illuminate\Support\Facades\Route;
use Modules\Discount\Http\Controllers\site\DiscountSiteController;

Route::middleware(['api'])->group(function () {
    Route::prefix('discounts')->group(function () {
        Route::post('validate-code', [DiscountSiteController::class, 'validateCode'])->name('api.discounts.validate-code');
        Route::get('available', [DiscountSiteController::class, 'getAvailableDiscounts'])->name('api.discounts.available');
    });
});

