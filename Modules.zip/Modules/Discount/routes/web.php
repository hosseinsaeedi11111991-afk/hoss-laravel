<?php

use Illuminate\Support\Facades\Route;

// Include admin and site routes
include_once 'admin.php';
include_once 'site.php';

