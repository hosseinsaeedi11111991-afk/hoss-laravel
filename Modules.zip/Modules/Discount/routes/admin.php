<?php

use Illuminate\Support\Facades\Route;
use Modules\Discount\Http\Controllers\Admin\DiscountController;
use Modules\Discount\Http\Controllers\Admin\DiscountUsageController;

Route::middleware(['web', 'auth', 'role:super_user|admin'])
    ->prefix('admin-panel')
    ->group(function () {

        // ------------------ Discounts ------------------
        Route::controller(DiscountController::class)->prefix('discounts')->group(function () {
            Route::get('/', 'index')->name('admin.discounts.index');
            Route::get('create', 'create')->name('admin.discounts.create');
            Route::post('/', 'store')->name('admin.discounts.store');
            Route::get('{discount}', 'show')->name('admin.discounts.show');
            Route::get('{discount}/edit', 'edit')->name('admin.discounts.edit');
            Route::put('{discount}', 'update')->name('admin.discounts.update');
            Route::delete('{discount}', 'destroy')->name('admin.discounts.destroy');
        });

        // ------------------ Discount Usages ------------------
        Route::controller(DiscountUsageController::class)->prefix('discount-usages')->group(function () {
            Route::get('/', 'index')->name('admin.discount-usages.index');
            Route::get('{discountUsage}', 'show')->name('admin.discount-usages.show');
        });

    });
