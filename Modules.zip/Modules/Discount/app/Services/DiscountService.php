<?php

namespace Modules\Discount\Services;

use Modules\Discount\Models\Discount;
use Modules\Discount\Models\DiscountUsage;
use Modules\Reservation\Models\Reservation;
use Modules\Neshan\Models\NeshanLocationCity;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DiscountService
{
    /**
     * پیدا کردن تخفیف‌های خودکار قابل اعمال برای یک رزرو
     */
    public function findApplicableAutomaticDiscounts(Reservation $reservation, ?float $currentPrice = null): Collection
    {
        $allDiscounts = Discount::active()
            ->automatic()
            ->get();

        \Log::info('Finding applicable discounts', [
            'reservation_id' => $reservation->id,
            'car_category_id' => $reservation->car_category_id,
            'total_price' => $reservation->total_price,
            'current_price' => $currentPrice,
            'all_discounts_count' => $allDiscounts->count(),
            'all_discount_ids' => $allDiscounts->pluck('id')->toArray(),
        ]);

        return $allDiscounts
            ->filter(function ($discount) use ($reservation, $currentPrice) {
                $matches = $this->matchesAllConditions($discount, $reservation, $currentPrice);

                if (!$matches) {
                    \Log::debug('Discount filtered out', [
                        'discount_id' => $discount->id,
                        'discount_title' => $discount->title,
                        'applicable_to' => $discount->applicable_to,
                        'car_category_id' => $discount->car_category_id,
                        'reservation_car_category_id' => $reservation->car_category_id,
                    ]);
                }

                return $matches;
            })
            ->sortByDesc(function ($discount) {
                return $this->getPriorityValue($discount->priority);
            });
    }

    /**
     * بررسی اعتبار کد تخفیف برای یک رزرو
     */
    public function validateCode(string $code, Reservation $reservation, ?float $currentPrice = null): ?Discount
    {
        $discount = Discount::active()
            ->byCode($code)
            ->first();

        if (!$discount) {
            return null;
        }

        if (!$this->matchesAllConditions($discount, $reservation, $currentPrice)) {
            return null;
        }

        // checkUsageLimits در matchesAllConditions بررسی می‌شود

        return $discount;
    }

    /**
     * بررسی تطابق همه شرایط تخفیف با رزرو
     */
    public function matchesAllConditions(Discount $discount, Reservation $reservation, ?float $currentPrice = null): bool
    {
        // بررسی مسیر
        if (!$this->matchesRoute($discount, $reservation)) {
            return false;
        }

        // بررسی دسته‌بندی
        if (!$this->matchesCarCategory($discount, $reservation)) {
            return false;
        }

        // بررسی مسافت
        if (!$this->matchesDistance($discount, $reservation)) {
            return false;
        }

        // بررسی مبلغ (استفاده از currentPrice اگر موجود باشد)
        if (!$this->matchesOrderAmount($discount, $reservation, $currentPrice)) {
            return false;
        }

        // بررسی تعداد مسافر
        if (!$this->matchesPassengers($discount, $reservation)) {
            return false;
        }

        // بررسی زمان
        if (!$this->matchesTime($discount, $reservation)) {
            return false;
        }

        // بررسی شرایط کاربر
        if (!$this->matchesUserConditions($discount, $reservation)) {
            return false;
        }

        // بررسی محدودیت‌های استفاده
        if (!$this->checkUsageLimits($discount, $reservation->user_id)) {
            \Log::debug("Discount {$discount->id} ({$discount->title}) failed usage limits check", [
                'reservation_id' => $reservation->id,
                'user_id' => $reservation->user_id,
            ]);
            return false;
        }

        return true;
    }

    /**
     * بررسی تطابق مسیر
     */
    protected function matchesRoute(Discount $discount, Reservation $reservation): bool
    {
        if ($discount->applicable_to === Discount::APPLICABLE_TO_ALL) {
            return true;
        }

        $originCity = $this->extractCityName($reservation, 'origin');
        $destinationCity = $this->extractCityName($reservation, 'destination');

        if ($discount->applicable_to === Discount::APPLICABLE_TO_SPECIFIC_ROUTE) {
            $originMatch = $this->cityMatches($originCity, $discount->origin_city);
            $destinationMatch = $this->cityMatches($destinationCity, $discount->destination_city);
            return $originMatch && $destinationMatch;
        }

        if ($discount->applicable_to === Discount::APPLICABLE_TO_SPECIFIC_CITY) {
            return $this->cityMatches($originCity, $discount->origin_city) ||
                $this->cityMatches($destinationCity, $discount->destination_city);
        }

        if ($discount->applicable_to === Discount::APPLICABLE_TO_ROUTE_AND_CATEGORY) {
            $originMatch = $this->cityMatches($originCity, $discount->origin_city);
            $destinationMatch = $this->cityMatches($destinationCity, $discount->destination_city);
            return $originMatch && $destinationMatch;
        }

        return true;
    }

    /**
     * بررسی تطابق دسته‌بندی
     */
    protected function matchesCarCategory(Discount $discount, Reservation $reservation): bool
    {
        // اگر تخفیف برای همه یا مسیر خاص یا شهر خاص باشد، نیازی به بررسی دسته‌بندی نیست
        if (in_array($discount->applicable_to, [
            Discount::APPLICABLE_TO_ALL,
            Discount::APPLICABLE_TO_SPECIFIC_ROUTE,
            Discount::APPLICABLE_TO_SPECIFIC_CITY
        ])) {
            return true;
        }

        // اگر تخفیف برای دسته‌بندی خاص یا مسیر + دسته‌بندی باشد
        if (in_array($discount->applicable_to, [
            Discount::APPLICABLE_TO_SPECIFIC_CAR_CATEGORY,
            Discount::APPLICABLE_TO_ROUTE_AND_CATEGORY
        ])) {
            // اگر car_category_id در تخفیف تنظیم نشده باشد، این تخفیف معتبر نیست
            if ($discount->car_category_id === null) {
                return false;
            }

            // بررسی تطابق دسته‌بندی
            return $reservation->car_category_id === $discount->car_category_id;
        }

        return true;
    }

    /**
     * بررسی تطابق مسافت
     */
    protected function matchesDistance(Discount $discount, Reservation $reservation): bool
    {
        if ($discount->min_distance_km !== null &&
            $reservation->distance_km < $discount->min_distance_km) {
            return false;
        }

        if ($discount->max_distance_km !== null &&
            $reservation->distance_km > $discount->max_distance_km) {
            return false;
        }

        return true;
    }

    /**
     * بررسی تطابق مبلغ
     */
    protected function matchesOrderAmount(Discount $discount, Reservation $reservation, ?float $currentPrice = null): bool
    {
        // استفاده از currentPrice اگر موجود باشد، در غیر این صورت از total_price
        $price = $currentPrice !== null ? $currentPrice : (float) $reservation->total_price;

        if ($discount->min_order_amount !== null &&
            $price < $discount->min_order_amount) {
            return false;
        }

        if ($discount->max_order_amount !== null &&
            $price > $discount->max_order_amount) {
            return false;
        }

        return true;
    }

    /**
     * بررسی تطابق تعداد مسافر
     */
    protected function matchesPassengers(Discount $discount, Reservation $reservation): bool
    {
        if ($discount->min_passengers_count !== null &&
            $reservation->passengers_count < $discount->min_passengers_count) {
            return false;
        }

        if ($discount->max_passengers_count !== null &&
            $reservation->passengers_count > $discount->max_passengers_count) {
            return false;
        }

        return true;
    }

    /**
     * بررسی تطابق زمان
     */
    protected function matchesTime(Discount $discount, Reservation $reservation): bool
    {
        // بررسی روز هفته
        if ($discount->day_of_week !== null && !empty($discount->day_of_week)) {
            // اگر تاریخ رزرو موجود نباشد، این شرط را رد نمی‌کنیم (برای تخفیف‌های خودکار)
            if (!$reservation->date) {
                return true; // اگر تاریخ تنظیم نشده باشد، این شرط را رد نمی‌کنیم
            }

            try {
                $reservationDate = Carbon::parse($reservation->date);
                $reservationDay = $reservationDate->dayOfWeek; // 0=یکشنبه, 6=شنبه

                // تبدیل به فرمت Laravel (1=دوشنبه, 7=یکشنبه)
                $dayOfWeek = $reservationDay === 0 ? 7 : $reservationDay;

                if (!in_array($dayOfWeek, $discount->day_of_week)) {
                    return false;
                }
            } catch (\Exception $e) {
                // اگر تاریخ معتبر نباشد، این شرط را رد نمی‌کنیم
                return true;
            }
        }

        // بررسی ساعت
        if ($discount->time_from !== null && $discount->time_until !== null) {
            // اگر زمان رزرو موجود نباشد، این شرط را رد نمی‌کنیم (برای تخفیف‌های خودکار)
            if (!$reservation->time && !$reservation->date) {
                return true; // اگر زمان تنظیم نشده باشد، این شرط را رد نمی‌کنیم
            }

            try {
                $reservationTime = $reservation->time ? Carbon::parse($reservation->time)->format('H:i') : null;

                // اگر time موجود نباشد اما date موجود باشد، از date استفاده می‌کنیم
                if (!$reservationTime && $reservation->date) {
                    $reservationTime = Carbon::parse($reservation->date)->format('H:i');
                }

                if ($reservationTime) {
                    $timeFrom = $discount->time_from;
                    $timeUntil = $discount->time_until;

                    // اگر بازه زمانی از نیمه شب عبور می‌کند (مثلاً 22:00 تا 06:00)
                    if ($timeFrom > $timeUntil) {
                        // بازه شبانه
                        if (!($reservationTime >= $timeFrom || $reservationTime <= $timeUntil)) {
                            return false;
                        }
                    } else {
                        // بازه عادی
                        if (!($reservationTime >= $timeFrom && $reservationTime <= $timeUntil)) {
                            return false;
                        }
                    }
                }
            } catch (\Exception $e) {
                // اگر زمان معتبر نباشد، این شرط را رد نمی‌کنیم
                return true;
            }
        }

        return true;
    }

    /**
     * بررسی شرایط کاربر
     */
    protected function matchesUserConditions(Discount $discount, Reservation $reservation): bool
    {
        if (!$reservation->user_id) {
            return true; // اگر کاربر لاگین نباشد، این شرط‌ها بررسی نمی‌شوند
        }

        // کاربر خاص
        if ($discount->user_id !== null && $discount->user_id !== $reservation->user_id) {
            return false;
        }

        // فقط اولین رزرو
        if ($discount->first_time_only) {
            $userReservationsCount = Reservation::where('user_id', $reservation->user_id)
                ->where('id', '!=', $reservation->id)
                ->count();
            if ($userReservationsCount > 0) {
                return false;
            }
        }

        // حداقل تعداد رزروهای قبلی
        if ($discount->min_user_reservations !== null) {
            $userReservationsCount = Reservation::where('user_id', $reservation->user_id)
                ->where('id', '!=', $reservation->id)
                ->where('status', '!=', Reservation::STATUS_CANCELED)
                ->count();
            if ($userReservationsCount < $discount->min_user_reservations) {
                return false;
            }
        }

        return true;
    }

    /**
     * بررسی محدودیت‌های استفاده
     */
    protected function checkUsageLimits(Discount $discount, ?int $userId): bool
    {
        // محدودیت کل
        if ($discount->usage_limit !== null) {
            if ($discount->current_usage_count >= $discount->usage_limit) {
                \Log::debug("Discount {$discount->id} ({$discount->title}) failed: total usage limit reached", [
                    'current_usage' => $discount->current_usage_count,
                    'usage_limit' => $discount->usage_limit,
                ]);
                return false;
            }
        }

        // محدودیت برای کاربر
        if ($discount->usage_limit_per_user !== null) {
            if (!$userId) {
                // اگر کاربری وجود نداشته باشد و محدودیت استفاده برای هر کاربر تنظیم شده باشد،
                // نمی‌توانیم بررسی کنیم که آیا قبلاً استفاده کرده است یا نه
                // در این حالت، تخفیف را نمایش نمی‌دهیم
                \Log::debug("Discount {$discount->id} ({$discount->title}) failed: user_id is null but usage_limit_per_user is set", [
                    'usage_limit_per_user' => $discount->usage_limit_per_user,
                ]);
                return false;
            }

            $userUsageCount = $discount->usages()
                ->where('user_id', $userId)
                ->count();

            \Log::debug("Checking user usage limit for discount {$discount->id}", [
                'user_id' => $userId,
                'user_usage_count' => $userUsageCount,
                'usage_limit_per_user' => $discount->usage_limit_per_user,
            ]);

            if ($userUsageCount >= $discount->usage_limit_per_user) {
                \Log::debug("Discount {$discount->id} ({$discount->title}) failed: user usage limit reached", [
                    'user_id' => $userId,
                    'user_usage_count' => $userUsageCount,
                    'usage_limit_per_user' => $discount->usage_limit_per_user,
                ]);
                return false;
            }
        }

        return true;
    }

    /**
     * اعمال تخفیف به رزرو
     */
    public function applyToReservation(
        Discount $discount,
        Reservation $reservation,
        float $discountAmount
    ): void {
        DB::transaction(function () use ($discount, $reservation, $discountAmount) {
            $originalPrice = $reservation->total_price;
            $finalPrice = $originalPrice - $discountAmount;

            // ذخیره در pivot table
            $reservation->discounts()->attach($discount->id, [
                'discount_amount' => $discountAmount,
                'original_price' => $originalPrice,
                'final_price' => $finalPrice,
            ]);

            // ثبت در تاریخچه
            DiscountUsage::create([
                'discount_id' => $discount->id,
                'user_id' => $reservation->user_id,
                'reservation_id' => $reservation->id,
                'discount_amount' => $discountAmount,
                'original_price' => $originalPrice,
                'final_price' => $finalPrice,
                'applied_via' => $discount->isAutomatic() ? 'automatic' : 'code',
                'code_used' => $discount->code,
                'used_at' => now(),
            ]);

            // به‌روزرسانی تعداد استفاده
            $discount->increment('current_usage_count');

            // به‌روزرسانی قیمت رزرو
            $reservation->update(['total_price' => $finalPrice]);
        });
    }

    /**
     * استخراج نام شهر از رزرو
     */
    protected function extractCityName(Reservation $reservation, string $type = 'origin'): ?string
    {
        if ($type === 'origin') {
            // استفاده از primaryOriginLocation
            if (!$reservation->relationLoaded('primaryOriginLocation')) {
                $reservation->load('primaryOriginLocation');
            }

            $primaryLocation = $reservation->primaryOriginLocation;
            if ($primaryLocation) {
                // استفاده از cities مربوط به این location
                $city = $reservation->cities()
                    ->where('neshan_location_id', $primaryLocation->id)
                    ->first();

                if ($city && $city->city_name) {
                    return $city->city_name;
                }
            }

            // Fallback به origin_address
            return $reservation->origin_address;
        } else {
            // استفاده از primaryDestinationLocation
            if (!$reservation->relationLoaded('primaryDestinationLocation')) {
                $reservation->load('primaryDestinationLocation');
            }

            $primaryLocation = $reservation->primaryDestinationLocation;
            if ($primaryLocation) {
                // استفاده از cities مربوط به این location
                $city = $reservation->cities()
                    ->where('neshan_location_id', $primaryLocation->id)
                    ->first();

                if ($city && $city->city_name) {
                    return $city->city_name;
                }
            }

            // Fallback به destination_address
            return $reservation->destination_address;
        }
    }

    /**
     * تطابق شهر (مشابه PricingCalculatorService)
     */
    protected function cityMatches(?string $city1, ?string $city2): bool
    {
        if (!$city1 || !$city2) {
            return false;
        }

        $normalized1 = $this->normalizeForComparison($city1);
        $normalized2 = $this->normalizeForComparison($city2);

        return mb_stripos($normalized1, $normalized2) !== false ||
            mb_stripos($normalized2, $normalized1) !== false;
    }

    /**
     * نرمال‌سازی برای مقایسه (مشابه PricingCalculatorService)
     */
    protected function normalizeForComparison(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        $value = str_replace(['ي', 'ك', 'ة'], ['ی', 'ک', 'ه'], $value);
        $value = str_replace(['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $value);
        $value = preg_replace('/\s+/u', ' ', $value);

        return mb_strtolower($value, 'UTF-8');
    }

    /**
     * دریافت مقدار عددی اولویت
     */
    protected function getPriorityValue(string $priority): int
    {
        return match($priority) {
            'high' => 3,
            'medium' => 2,
            'low' => 1,
            default => 2
        };
    }
}

