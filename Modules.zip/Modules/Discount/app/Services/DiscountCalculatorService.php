<?php

namespace Modules\Discount\Services;

use Modules\Discount\Models\Discount;
use Illuminate\Support\Collection;

class DiscountCalculatorService
{
    /**
     * محاسبه مبلغ تخفیف
     */
    public function calculate(Discount $discount, float $originalPrice): float
    {
        if ($discount->isPercentage()) {
            $amount = ($originalPrice * $discount->discount_value) / 100;
            
            // محدودیت حداکثر مبلغ
            if ($discount->max_discount_amount !== null) {
                $amount = min($amount, $discount->max_discount_amount);
            }
            
            return round($amount, 2);
        }
        
        if ($discount->isFixedAmount()) {
            return min($discount->discount_value, $originalPrice);
        }
        
        // free_delivery - در اینجا می‌توانید منطق خاص خود را پیاده کنید
        // برای مثال، می‌توانید یک مبلغ ثابت برای ارسال در نظر بگیرید
        // یا از فیلد discount_value استفاده کنید
        if ($discount->isFreeDelivery()) {
            // اگر discount_value برای free_delivery تنظیم شده باشد، از آن استفاده می‌کنیم
            // در غیر این صورت، می‌توانید منطق خاص خود را پیاده کنید
            return $discount->discount_value > 0 ? min($discount->discount_value, $originalPrice) : 0;
        }
        
        return 0;
    }
    
    /**
     * انتخاب بهترین تخفیف از لیست
     */
    public function selectBestDiscount(Collection $discounts, float $originalPrice): ?Discount
    {
        if ($discounts->isEmpty()) {
            return null;
        }
        
        $bestDiscount = null;
        $maxDiscountAmount = 0;
        
        foreach ($discounts as $discount) {
            $amount = $this->calculate($discount, $originalPrice);
            if ($amount > $maxDiscountAmount) {
                $maxDiscountAmount = $amount;
                $bestDiscount = $discount;
            }
        }
        
        return $bestDiscount;
    }
    
    /**
     * محاسبه تخفیف‌های ترکیبی (اگر stackable باشند)
     */
    public function calculateStackedDiscounts(Collection $discounts, float $originalPrice): float
    {
        $totalDiscount = 0;
        $remainingPrice = $originalPrice;
        
        foreach ($discounts->sortByDesc(function ($discount) {
            return $this->getPriorityValue($discount->priority);
        }) as $discount) {
            if (!$discount->canStack()) {
                continue;
            }
            
            $discountAmount = $this->calculate($discount, $remainingPrice);
            $totalDiscount += $discountAmount;
            $remainingPrice -= $discountAmount;
            
            if ($remainingPrice <= 0) {
                break;
            }
        }
        
        return round($totalDiscount, 2);
    }
    
    /**
     * دریافت مقدار عددی اولویت
     */
    protected function getPriorityValue(string $priority): int
    {
        return match($priority) {
            'high' => 3,
            'medium' => 2,
            'low' => 1,
            default => 2
        };
    }
}

