<?php

namespace Modules\Discount\Http\Controllers\site;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Discount\Models\Discount;
use Modules\Discount\Services\DiscountService;
use Modules\Discount\Services\DiscountCalculatorService;
use Modules\Reservation\Models\Reservation;
use Modules\Pricing\Services\PricingCalculatorService;

class DiscountSiteController extends Controller
{
    public function __construct(
        private DiscountService $discountService,
        private DiscountCalculatorService $discountCalculator,
        private PricingCalculatorService $pricingCalculator
    ) {
    }

    /**
     * بررسی اعتبار کد تخفیف
     */
    public function validateCode(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'reservation_id' => 'nullable|exists:reservations,id',
        ]);

        $code = $request->input('code');
        $reservationId = $request->input('reservation_id');

        if ($reservationId) {
            $reservation = Reservation::with('user')->findOrFail($reservationId);

            \Log::debug('Validating discount code', [
                'reservation_id' => $reservation->id,
                'user_id' => $reservation->user_id,
                'user_mobile' => $reservation->user ? $reservation->user->mobile : null,
                'code' => $code,
            ]);
        } else {
            // اگر reservation_id ارسال نشده باشد، یک reservation موقت ایجاد می‌کنیم
            // یا می‌توانید منطق دیگری پیاده کنید
            return response()->json([
                'success' => false,
                'message' => 'شناسه رزرو الزامی است'
            ], 400);
        }

        // محاسبه قیمت در صورت نیاز
        $totalPrice = (float) $reservation->total_price;

        if ($totalPrice <= 0) {
            $reservation->loadMissing([
                'primaryOriginLocation',
                'primaryDestinationLocation',
                'cities',
            ]);

            $distanceKm = (float) ($reservation->distance_km ?? 0);
            if ($distanceKm <= 0) {
                $distanceKm = (float) $reservation->cities->sum('distance_km');
            }

            $originTexts = $this->collectLocationTexts(
                $reservation->primaryOriginLocation,
                $reservation->origin_address
            );

            $destinationTexts = $this->collectLocationTexts(
                $reservation->primaryDestinationLocation,
                $reservation->destination_address
            );

            $routeCities = $reservation->cities->map(function ($city) {
                return [
                    'name' => $city->city_name,
                    'distance_km' => (float) $city->distance_km,
                ];
            })->filter(function ($city) {
                return !empty($city['name']);
            })->values()->all();

            $priceQuote = $this->pricingCalculator->calculateInitialPrice($distanceKm, [
                'origin_texts' => $originTexts,
                'destination_texts' => $destinationTexts,
                'route_cities' => $routeCities,
                'car_category_id' => $reservation->car_category_id,
            ]);

            $totalPrice = (float) ($priceQuote['amount'] ?? 0.0);
        }

        $discount = $this->discountService->validateCode($code, $reservation, $totalPrice);

        if (!$discount) {
            return response()->json([
                'success' => false,
                'message' => 'کد تخفیف معتبر نیست یا شرایط اعمال را ندارد'
            ], 400);
        }

        $discountAmount = $this->discountCalculator->calculate($discount, $totalPrice);

        return response()->json([
            'success' => true,
            'discount_amount' => $discountAmount,
            'discount_title' => $discount->title,
            'message' => 'کد تخفیف با موفقیت اعمال شد'
        ]);
    }

    /**
     * دریافت لیست تخفیف‌های قابل استفاده
     */
    public function getAvailableDiscounts(Request $request)
    {
        $request->validate([
            'reservation_id' => 'required|exists:reservations,id',
            'current_price' => 'nullable|numeric|min:0',
            'car_category_id' => 'nullable|integer|exists:car_categories,id',
        ]);

        $reservation = Reservation::with([
            'primaryOriginLocation',
            'primaryDestinationLocation',
            'cities',
            'carCategory',
            'user' // Load user relation to ensure user_id is available
        ])->findOrFail($request->input('reservation_id'));

        \Log::debug('Getting available discounts', [
            'reservation_id' => $reservation->id,
            'user_id' => $reservation->user_id,
            'user_mobile' => $reservation->user ? $reservation->user->mobile : null,
        ]);

        // اگر car_category_id از request ارسال شده باشد، آن را به reservation اعمال می‌کنیم
        // این برای فیلتر کردن تخفیف‌های مربوط به دسته‌بندی است
        if ($request->has('car_category_id')) {
            $reservation->car_category_id = $request->input('car_category_id');
        }

        // اولویت با قیمت ارسال شده از frontend است
        $totalPrice = (float) $request->input('current_price', 0);

        // اگر قیمت از frontend ارسال نشده یا صفر است، از total_price استفاده می‌کنیم
        if ($totalPrice <= 0) {
            $totalPrice = (float) $reservation->total_price;
        }

        // اگر هنوز صفر است، قیمت را محاسبه می‌کنیم
        if ($totalPrice <= 0) {
            $distanceKm = (float) ($reservation->distance_km ?? 0);
            if ($distanceKm <= 0) {
                $distanceKm = (float) $reservation->cities->sum('distance_km');
            }

            $originTexts = $this->collectLocationTexts(
                $reservation->primaryOriginLocation,
                $reservation->origin_address
            );

            $destinationTexts = $this->collectLocationTexts(
                $reservation->primaryDestinationLocation,
                $reservation->destination_address
            );

            $routeCities = $reservation->cities->map(function ($city) {
                return [
                    'name' => $city->city_name,
                    'distance_km' => (float) $city->distance_km,
                ];
            })->filter(function ($city) {
                return !empty($city['name']);
            })->values()->all();

            $priceQuote = $this->pricingCalculator->calculateInitialPrice($distanceKm, [
                'origin_texts' => $originTexts,
                'destination_texts' => $destinationTexts,
                'route_cities' => $routeCities,
                'car_category_id' => $reservation->car_category_id,
            ]);

            $totalPrice = (float) ($priceQuote['amount'] ?? 0.0);
        }

        $discounts = $this->discountService->findApplicableAutomaticDiscounts($reservation, $totalPrice);

        // برای دیباگ: بررسی همه تخفیف‌های فعال
        $allActiveDiscounts = \Modules\Discount\Models\Discount::active()
            ->automatic()
            ->get();

        return response()->json([
            'success' => true,
            'debug' => [
                'total_price' => $totalPrice,
                'all_active_discounts_count' => $allActiveDiscounts->count(),
                'applicable_discounts_count' => $discounts->count(),
                'all_active_discount_ids' => $allActiveDiscounts->pluck('id')->toArray(),
                'applicable_discount_ids' => $discounts->pluck('id')->toArray(),
            ],
            'discounts' => $discounts->map(function ($discount) use ($totalPrice) {
                $calculatedAmount = $this->discountCalculator->calculate($discount, $totalPrice);
                return [
                    'id' => $discount->id,
                    'title' => $discount->title,
                    'description' => $discount->description,
                    'discount_type' => $discount->discount_type,
                    'discount_value' => $discount->discount_value,
                    'calculated_amount' => $calculatedAmount,
                    'code' => $discount->code,
                ];
            })
        ]);
    }

    /**
     * جمع‌آوری متون موقعیت (مشابه ReservationSiteController)
     */
    private function collectLocationTexts($location, ?string $fallbackAddress = null): array
    {
        $texts = [];

        if ($location && $location->address_text) {
            $texts[] = $location->address_text;
        }

        if ($fallbackAddress && !in_array($fallbackAddress, $texts)) {
            $texts[] = $fallbackAddress;
        }

        return array_filter($texts);
    }
}

