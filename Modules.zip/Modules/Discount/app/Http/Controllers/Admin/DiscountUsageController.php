<?php

namespace Modules\Discount\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Discount\Models\DiscountUsage;

class DiscountUsageController extends Controller
{
    public function index(Request $request)
    {
        $query = DiscountUsage::with(['discount', 'user', 'reservation']);

        // فیلتر بر اساس تخفیف
        if ($request->filled('discount_id')) {
            $query->where('discount_id', $request->discount_id);
        }

        // فیلتر بر اساس کاربر
        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        // فیلتر بر اساس تاریخ از
        if ($request->filled('date_from')) {
            $query->whereDate('used_at', '>=', $request->date_from);
        }

        // فیلتر بر اساس تاریخ تا
        if ($request->filled('date_to')) {
            $query->whereDate('used_at', '<=', $request->date_to);
        }

        $usages = $query->latest('used_at')->paginate(15)->withQueryString();
        return view('discount::admin.discount_usages.index', compact('usages'));
    }

    public function show(DiscountUsage $discountUsage)
    {
        $discountUsage->load(['discount', 'user', 'reservation']);
        return view('discount::admin.discount_usages.show', compact('discountUsage'));
    }
}

