<?php

namespace Modules\Discount\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Discount\Models\Discount;
use Modules\Discount\Http\Requests\Admin\StoreDiscountRequest;
use Modules\Discount\Http\Requests\Admin\UpdateDiscountRequest;
use Modules\Cars\Models\CarCategory;
use Modules\User\Models\User;

class DiscountController extends Controller
{
    public function index(Request $request)
    {
        $query = Discount::with(['carCategory', 'user']);

        // فیلتر بر اساس عنوان
        if ($request->filled('title')) {
            $query->where('title', 'like', '%' . $request->title . '%');
        }

        // فیلتر بر اساس کد
        if ($request->filled('code')) {
            $query->where('code', 'like', '%' . $request->code . '%');
        }

        // فیلتر بر اساس وضعیت
        if ($request->filled('is_active')) {
            $query->where('is_active', $request->is_active === '1');
        }

        // فیلتر بر اساس نوع فعال‌سازی
        if ($request->filled('trigger_type')) {
            $query->where('trigger_type', $request->trigger_type);
        }

        // فیلتر بر اساس نوع اعمال
        if ($request->filled('applicable_to')) {
            $query->where('applicable_to', $request->applicable_to);
        }

        // فیلتر بر اساس اولویت
        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }

        $discounts = $query->latest()->paginate(15)->withQueryString();
        return view('discount::admin.discounts.index', compact('discounts'));
    }

    public function create()
    {
        $carCategories = CarCategory::pluck('title', 'id');
        $users = User::query()
            ->get(['id', 'username'])
            ->mapWithKeys(fn (User $user) => [$user->id => $user->username]);

        return view('discount::admin.discounts.create', compact('carCategories', 'users'));
    }

    public function store(StoreDiscountRequest $request)
    {
        $data = $request->validated();
        
        // تبدیل day_of_week به JSON اگر array باشد
        if (isset($data['day_of_week']) && is_array($data['day_of_week'])) {
            $data['day_of_week'] = json_encode($data['day_of_week']);
        }

        // تبدیل user_group_ids به JSON اگر array باشد
        if (isset($data['user_group_ids']) && is_array($data['user_group_ids'])) {
            $data['user_group_ids'] = json_encode($data['user_group_ids']);
        }

        Discount::create($data);

        return redirect()->route('admin.discounts.index')
            ->with('success', 'تخفیف با موفقیت ایجاد شد.');
    }

    public function show(Discount $discount)
    {
        $discount->load(['carCategory', 'user', 'usages']);
        
        $usageStats = [
            'total_usage' => $discount->usages()->count(),
            'remaining_usage' => $discount->usage_limit ? ($discount->usage_limit - $discount->current_usage_count) : null,
        ];

        return view('discount::admin.discounts.show', compact('discount', 'usageStats'));
    }

    public function edit(Discount $discount)
    {
        $carCategories = CarCategory::pluck('title', 'id');
        $users = User::query()
            ->get(['id', 'username'])
            ->mapWithKeys(fn (User $user) => [$user->id => $user->username]);

        // تبدیل JSON به array برای نمایش در فرم
        if ($discount->day_of_week && is_string($discount->day_of_week)) {
            $discount->day_of_week = json_decode($discount->day_of_week, true);
        }

        if ($discount->user_group_ids && is_string($discount->user_group_ids)) {
            $discount->user_group_ids = json_decode($discount->user_group_ids, true);
        }

        return view('discount::admin.discounts.edit', compact('discount', 'carCategories', 'users'));
    }

    public function update(UpdateDiscountRequest $request, Discount $discount)
    {
        $data = $request->validated();
        
        // تبدیل day_of_week به JSON اگر array باشد
        if (isset($data['day_of_week']) && is_array($data['day_of_week'])) {
            $data['day_of_week'] = json_encode($data['day_of_week']);
        }

        // تبدیل user_group_ids به JSON اگر array باشد
        if (isset($data['user_group_ids']) && is_array($data['user_group_ids'])) {
            $data['user_group_ids'] = json_encode($data['user_group_ids']);
        }

        $discount->update($data);

        return redirect()->route('admin.discounts.index')
            ->with('success', 'تخفیف به‌روزرسانی شد.');
    }

    public function destroy(Discount $discount)
    {
        $discount->delete();
        return redirect()->route('admin.discounts.index')
            ->with('success', 'تخفیف حذف شد.');
    }
}
