<?php

namespace Modules\Discount\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreDiscountRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $rules = [
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'discount_type' => ['required', 'in:percentage,fixed_amount,free_delivery'],
            'discount_value' => ['required', 'numeric', 'min:0'],
            'max_discount_amount' => ['nullable', 'numeric', 'min:0'],
            'trigger_type' => ['required', 'in:code,automatic,both'],
            'auto_apply' => ['nullable', 'boolean'],
            'code' => ['nullable', 'string', 'max:255', 'unique:discounts,code'],
            'applicable_to' => ['required', 'in:all,specific_route,specific_car_category,route_and_category,specific_city'],
            'origin_city' => ['nullable', 'string', 'max:255'],
            'destination_city' => ['nullable', 'string', 'max:255'],
            'car_category_id' => ['nullable', 'exists:car_categories,id'],
            'min_distance_km' => ['nullable', 'numeric', 'min:0'],
            'max_distance_km' => ['nullable', 'numeric', 'min:0', 'gt:min_distance_km'],
            'min_order_amount' => ['nullable', 'numeric', 'min:0'],
            'max_order_amount' => ['nullable', 'numeric', 'min:0', 'gt:min_order_amount'],
            'min_passengers_count' => ['nullable', 'integer', 'min:1', 'max:99'],
            'max_passengers_count' => ['nullable', 'integer', 'min:1', 'max:99', 'gte:min_passengers_count'],
            'day_of_week' => ['nullable', 'array'],
            'day_of_week.*' => ['integer', 'min:1', 'max:7'],
            'time_from' => ['nullable', 'date_format:H:i'],
            'time_until' => ['nullable', 'date_format:H:i'],
            'first_time_only' => ['nullable', 'boolean'],
            'min_user_reservations' => ['nullable', 'integer', 'min:0'],
            'user_id' => ['nullable', 'exists:users,id'],
            'user_group_ids' => ['nullable', 'array'],
            'usage_limit' => ['nullable', 'integer', 'min:1'],
            'usage_limit_per_user' => ['nullable', 'integer', 'min:1'],
            'valid_from' => ['required', 'date'],
            'valid_until' => ['required', 'date', 'after:valid_from'],
            'priority' => ['required', 'in:high,medium,low'],
            'is_active' => ['nullable', 'boolean'],
            'stackable' => ['nullable', 'boolean'],
            'conditions_note' => ['nullable', 'string'],
            'image' => ['nullable', 'string', 'max:255'],
        ];

        // Conditional validation
        if ($this->input('applicable_to') === 'specific_route' || 
            $this->input('applicable_to') === 'route_and_category') {
            $rules['origin_city'][] = 'required';
            $rules['destination_city'][] = 'required';
        }

        if ($this->input('applicable_to') === 'specific_car_category' || 
            $this->input('applicable_to') === 'route_and_category') {
            $rules['car_category_id'][] = 'required';
        }

        if ($this->input('trigger_type') === 'code' || $this->input('trigger_type') === 'both') {
            $rules['code'][] = 'required';
        }

        if ($this->input('discount_type') === 'percentage') {
            $rules['discount_value'][] = 'max:100';
        }

        return $rules;
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'title.required' => 'عنوان تخفیف الزامی است.',
            'title.max' => 'عنوان نباید بیشتر از 255 کاراکتر باشد.',
            'discount_type.required' => 'نوع تخفیف الزامی است.',
            'discount_type.in' => 'نوع تخفیف معتبر نیست.',
            'discount_value.required' => 'مقدار تخفیف الزامی است.',
            'discount_value.numeric' => 'مقدار تخفیف باید عدد باشد.',
            'discount_value.min' => 'مقدار تخفیف نمی‌تواند منفی باشد.',
            'discount_value.max' => 'درصد تخفیف نمی‌تواند بیشتر از 100 باشد.',
            'trigger_type.required' => 'نوع فعال‌سازی الزامی است.',
            'trigger_type.in' => 'نوع فعال‌سازی معتبر نیست.',
            'code.unique' => 'این کد تخفیف قبلاً استفاده شده است.',
            'code.required' => 'کد تخفیف برای نوع انتخاب شده الزامی است.',
            'applicable_to.required' => 'نوع اعمال تخفیف الزامی است.',
            'applicable_to.in' => 'نوع اعمال تخفیف معتبر نیست.',
            'origin_city.required' => 'شهر مبدا برای مسیر خاص الزامی است.',
            'destination_city.required' => 'شهر مقصد برای مسیر خاص الزامی است.',
            'car_category_id.exists' => 'دسته‌بندی انتخاب شده معتبر نیست.',
            'car_category_id.required' => 'دسته‌بندی برای نوع انتخاب شده الزامی است.',
            'max_distance_km.gt' => 'حداکثر مسافت باید بیشتر از حداقل مسافت باشد.',
            'max_order_amount.gt' => 'حداکثر مبلغ باید بیشتر از حداقل مبلغ باشد.',
            'max_passengers_count.gte' => 'حداکثر تعداد مسافر باید بیشتر یا مساوی حداقل باشد.',
            'valid_from.required' => 'تاریخ شروع اعتبار الزامی است.',
            'valid_until.required' => 'تاریخ پایان اعتبار الزامی است.',
            'valid_until.after' => 'تاریخ پایان باید بعد از تاریخ شروع باشد.',
            'priority.required' => 'اولویت الزامی است.',
            'priority.in' => 'اولویت معتبر نیست.',
        ];
    }
}

