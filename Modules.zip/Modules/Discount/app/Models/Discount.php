<?php

namespace Modules\Discount\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Cars\Models\CarCategory;
use Modules\User\Models\User;
use Modules\Reservation\Models\Reservation;

class Discount extends Model
{
    use HasFactory, SoftDeletes;

    // ========== Constants ==========
    const DISCOUNT_TYPE_PERCENTAGE = 'percentage';
    const DISCOUNT_TYPE_FIXED_AMOUNT = 'fixed_amount';
    const DISCOUNT_TYPE_FREE_DELIVERY = 'free_delivery';

    const TRIGGER_TYPE_CODE = 'code';
    const TRIGGER_TYPE_AUTOMATIC = 'automatic';
    const TRIGGER_TYPE_BOTH = 'both';

    const APPLICABLE_TO_ALL = 'all';
    const APPLICABLE_TO_SPECIFIC_ROUTE = 'specific_route';
    const APPLICABLE_TO_SPECIFIC_CAR_CATEGORY = 'specific_car_category';
    const APPLICABLE_TO_ROUTE_AND_CATEGORY = 'route_and_category';
    const APPLICABLE_TO_SPECIFIC_CITY = 'specific_city';

    const PRIORITY_HIGH = 'high';
    const PRIORITY_MEDIUM = 'medium';
    const PRIORITY_LOW = 'low';

    protected $fillable = [
        'code',
        'title',
        'description',
        'discount_type',
        'discount_value',
        'max_discount_amount',
        'trigger_type',
        'auto_apply',
        'applicable_to',
        'origin_city',
        'destination_city',
        'car_category_id',
        'min_distance_km',
        'max_distance_km',
        'min_order_amount',
        'max_order_amount',
        'min_passengers_count',
        'max_passengers_count',
        'day_of_week',
        'time_from',
        'time_until',
        'first_time_only',
        'min_user_reservations',
        'user_id',
        'user_group_ids',
        'usage_limit',
        'usage_limit_per_user',
        'current_usage_count',
        'valid_from',
        'valid_until',
        'priority',
        'is_active',
        'stackable',
        'conditions_note',
        'image',
    ];

    protected $casts = [
        'discount_value' => 'decimal:2',
        'max_discount_amount' => 'decimal:2',
        'min_distance_km' => 'decimal:2',
        'max_distance_km' => 'decimal:2',
        'min_order_amount' => 'decimal:2',
        'max_order_amount' => 'decimal:2',
        'day_of_week' => 'array',
        'user_group_ids' => 'array',
        'auto_apply' => 'boolean',
        'first_time_only' => 'boolean',
        'is_active' => 'boolean',
        'stackable' => 'boolean',
        'valid_from' => 'datetime',
        'valid_until' => 'datetime',
    ];

    // ========== Relations ==========
    public function carCategory(): BelongsTo
    {
        return $this->belongsTo(CarCategory::class, 'car_category_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function usages(): HasMany
    {
        return $this->hasMany(DiscountUsage::class);
    }

    public function reservations(): BelongsToMany
    {
        return $this->belongsToMany(Reservation::class, 'discount_reservations')
            ->withPivot('discount_amount', 'original_price', 'final_price')
            ->withTimestamps();
    }

    // ========== Scopes ==========
    public function scopeActive($query)
    {
        return $query->where('is_active', true)
            ->where('valid_from', '<=', now())
            ->where('valid_until', '>=', now());
    }

    public function scopeAutomatic($query)
    {
        return $query->where('auto_apply', true)
            ->whereIn('trigger_type', ['automatic', 'both']);
    }

    public function scopeByCode($query, $code)
    {
        return $query->where('code', $code)
            ->whereIn('trigger_type', ['code', 'both']);
    }

    public function scopeByPriority($query)
    {
        return $query->orderByRaw("CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END");
    }

    // ========== Helper Methods ==========
    public function isPercentage(): bool
    {
        return $this->discount_type === self::DISCOUNT_TYPE_PERCENTAGE;
    }

    public function isFixedAmount(): bool
    {
        return $this->discount_type === self::DISCOUNT_TYPE_FIXED_AMOUNT;
    }

    public function isFreeDelivery(): bool
    {
        return $this->discount_type === self::DISCOUNT_TYPE_FREE_DELIVERY;
    }

    public function isAutomatic(): bool
    {
        return $this->auto_apply && in_array($this->trigger_type, ['automatic', 'both']);
    }

    public function requiresCode(): bool
    {
        return in_array($this->trigger_type, ['code', 'both']) && $this->code;
    }

    public function canStack(): bool
    {
        return $this->stackable;
    }

    public function isHighPriority(): bool
    {
        return $this->priority === self::PRIORITY_HIGH;
    }

    public function isMediumPriority(): bool
    {
        return $this->priority === self::PRIORITY_MEDIUM;
    }

    public function isLowPriority(): bool
    {
        return $this->priority === self::PRIORITY_LOW;
    }

    public function getPriorityLabel(): string
    {
        return match($this->priority) {
            self::PRIORITY_HIGH => 'بالا',
            self::PRIORITY_MEDIUM => 'متوسط',
            self::PRIORITY_LOW => 'پایین',
            default => 'نامشخص'
        };
    }

    public function getDiscountTypeLabel(): string
    {
        return match($this->discount_type) {
            self::DISCOUNT_TYPE_PERCENTAGE => 'درصدی',
            self::DISCOUNT_TYPE_FIXED_AMOUNT => 'مبلغ ثابت',
            self::DISCOUNT_TYPE_FREE_DELIVERY => 'ارسال رایگان',
            default => 'نامشخص'
        };
    }

    public function getTriggerTypeLabel(): string
    {
        return match($this->trigger_type) {
            self::TRIGGER_TYPE_CODE => 'فقط با کد',
            self::TRIGGER_TYPE_AUTOMATIC => 'فقط خودکار',
            self::TRIGGER_TYPE_BOTH => 'کد و خودکار',
            default => 'نامشخص'
        };
    }

    public function getApplicableToLabel(): string
    {
        return match($this->applicable_to) {
            self::APPLICABLE_TO_ALL => 'همه',
            self::APPLICABLE_TO_SPECIFIC_ROUTE => 'مسیر خاص',
            self::APPLICABLE_TO_SPECIFIC_CAR_CATEGORY => 'دسته‌بندی خاص',
            self::APPLICABLE_TO_ROUTE_AND_CATEGORY => 'مسیر + دسته‌بندی',
            self::APPLICABLE_TO_SPECIFIC_CITY => 'شهر خاص',
            default => 'نامشخص'
        };
    }
}

