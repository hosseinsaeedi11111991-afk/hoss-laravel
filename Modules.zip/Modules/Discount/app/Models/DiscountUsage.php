<?php

namespace Modules\Discount\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\Reservation\Models\Reservation;
use Modules\User\Models\User;

class DiscountUsage extends Model
{
    use HasFactory;

    protected $fillable = [
        'discount_id',
        'user_id',
        'reservation_id',
        'discount_amount',
        'original_price',
        'final_price',
        'applied_via',
        'code_used',
        'used_at',
    ];

    protected $casts = [
        'discount_amount' => 'decimal:2',
        'original_price' => 'decimal:2',
        'final_price' => 'decimal:2',
        'used_at' => 'datetime',
    ];

    // ========== Relations ==========
    public function discount(): BelongsTo
    {
        return $this->belongsTo(Discount::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function reservation(): BelongsTo
    {
        return $this->belongsTo(Reservation::class);
    }
}

