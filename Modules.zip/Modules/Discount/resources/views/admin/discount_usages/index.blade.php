@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.discount-usages.index') }}">پنل/</a></span>
        گزارش استفاده از تخفیف‌ها
    </h4>

    <!-- فرم فیلتر -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">فیلتر</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="{{ route('admin.discount-usages.index') }}">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تخفیف</label>
                        <input type="number" name="discount_id" class="form-control" value="{{ request('discount_id') }}" placeholder="ID تخفیف">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">کاربر</label>
                        <input type="number" name="user_id" class="form-control" value="{{ request('user_id') }}" placeholder="ID کاربر">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تاریخ از</label>
                        <input type="date" name="date_from" class="form-control" value="{{ request('date_from') }}">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">تاریخ تا</label>
                        <input type="date" name="date_to" class="form-control" value="{{ request('date_to') }}">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">جستجو</button>
                        <a href="{{ route('admin.discount-usages.index') }}" class="btn btn-secondary">پاک کردن</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>تخفیف</th>
                <th>کاربر</th>
                <th>رزرو</th>
                <th>مبلغ تخفیف</th>
                <th>قیمت اولیه</th>
                <th>قیمت نهایی</th>
                <th>نحوه اعمال</th>
                <th>تاریخ استفاده</th>
            </tr>
            </thead>
            <tbody>
            @foreach($usages as $key => $usage)
                <tr>
                    <td>{{ ($usages->currentPage() - 1) * $usages->perPage() + $key + 1 }}</td>
                    <td>{{ $usage->discount->title }}</td>
                    <td>{{ $usage->user->username ?? '-' }}</td>
                    <td>#{{ $usage->reservation_id ?? '-' }}</td>
                    <td>{{ number_format($usage->discount_amount) }} تومان</td>
                    <td>{{ number_format($usage->original_price) }} تومان</td>
                    <td>{{ number_format($usage->final_price) }} تومان</td>
                    <td>{{ $usage->applied_via == 'automatic' ? 'خودکار' : 'کد' }}</td>
                    <td>{{ verta($usage->used_at)->format('Y/m/d H:i') }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $usages->links('pagination::bootstrap-5') }}
    </div>
@endsection

