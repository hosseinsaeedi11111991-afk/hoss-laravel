@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.discount-usages.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.discount-usages.index') }}">گزارش استفاده/</a></span>
        نمایش جزئیات
    </h4>

    <div class="card mb-4">
        <div class="card-header">
            <h5>جزئیات استفاده از تخفیف</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>تخفیف:</strong> {{ $discountUsage->discount->title }}</p>
                    <p><strong>کاربر:</strong> {{ $discountUsage->user->username ?? '-' }}</p>
                    <p><strong>رزرو:</strong> #{{ $discountUsage->reservation_id ?? '-' }}</p>
                    <p><strong>نحوه اعمال:</strong> {{ $discountUsage->applied_via == 'automatic' ? 'خودکار' : 'کد' }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>مبلغ تخفیف:</strong> {{ number_format($discountUsage->discount_amount) }} تومان</p>
                    <p><strong>قیمت اولیه:</strong> {{ number_format($discountUsage->original_price) }} تومان</p>
                    <p><strong>قیمت نهایی:</strong> {{ number_format($discountUsage->final_price) }} تومان</p>
                    <p><strong>تاریخ استفاده:</strong> {{ verta($discountUsage->used_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>

    <a href="{{ route('admin.discount-usages.index') }}" class="btn btn-secondary">بازگشت</a>
@endsection

