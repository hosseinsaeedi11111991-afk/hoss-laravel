@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">تخفیف‌ها/</a></span>
        لیست تخفیف‌ها
    </h4>

    <a href="{{ route('admin.discounts.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن تخفیف</a>

    <!-- فرم جستجو -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">جستجو و فیلتر</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="{{ route('admin.discounts.index') }}">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">عنوان</label>
                        <input type="text" name="title" class="form-control" value="{{ request('title') }}" placeholder="جستجو...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">کد تخفیف</label>
                        <input type="text" name="code" class="form-control" value="{{ request('code') }}" placeholder="جستجو...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">وضعیت</label>
                        <select name="is_active" class="form-select">
                            <option value="">همه</option>
                            <option value="1" {{ request('is_active') == '1' ? 'selected' : '' }}>فعال</option>
                            <option value="0" {{ request('is_active') == '0' ? 'selected' : '' }}>غیرفعال</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">نوع فعال‌سازی</label>
                        <select name="trigger_type" class="form-select">
                            <option value="">همه</option>
                            <option value="code" {{ request('trigger_type') == 'code' ? 'selected' : '' }}>کد</option>
                            <option value="automatic" {{ request('trigger_type') == 'automatic' ? 'selected' : '' }}>خودکار</option>
                            <option value="both" {{ request('trigger_type') == 'both' ? 'selected' : '' }}>کد و خودکار</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">اولویت</label>
                        <select name="priority" class="form-select">
                            <option value="">همه</option>
                            <option value="high" {{ request('priority') == 'high' ? 'selected' : '' }}>بالا</option>
                            <option value="medium" {{ request('priority') == 'medium' ? 'selected' : '' }}>متوسط</option>
                            <option value="low" {{ request('priority') == 'low' ? 'selected' : '' }}>پایین</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary me-2">جستجو</button>
                        <a href="{{ route('admin.discounts.index') }}" class="btn btn-secondary">پاک کردن</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>عنوان</th>
                <th>کد</th>
                <th>نوع</th>
                <th>مقدار</th>
                <th>نوع فعال‌سازی</th>
                <th>اولویت</th>
                <th>استفاده شده</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($discounts as $key => $discount)
                <tr>
                    <td>{{ ($discounts->currentPage() - 1) * $discounts->perPage() + $key + 1 }}</td>
                    <td>{{ $discount->title }}</td>
                    <td>{{ $discount->code ?? '-' }}</td>
                    <td>{{ $discount->getDiscountTypeLabel() }}</td>
                    <td>
                        @if($discount->isPercentage())
                            {{ $discount->discount_value }}%
                        @else
                            {{ number_format($discount->discount_value) }} تومان
                        @endif
                    </td>
                    <td>{{ $discount->getTriggerTypeLabel() }}</td>
                    <td>
                        <span class="badge 
                            @if($discount->priority == 'high') bg-danger
                            @elseif($discount->priority == 'medium') bg-warning
                            @else bg-secondary
                            @endif">
                            {{ $discount->getPriorityLabel() }}
                        </span>
                    </td>
                    <td>{{ $discount->current_usage_count }} / {{ $discount->usage_limit ?? '∞' }}</td>
                    <td>
                        @if($discount->is_active)
                            <span class="badge bg-success">فعال</span>
                        @else
                            <span class="badge bg-secondary">غیرفعال</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.discounts.show', $discount) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.discounts.edit', $discount) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.discounts.destroy', $discount) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $discounts->links('pagination::bootstrap-5') }}
    </div>
@endsection

