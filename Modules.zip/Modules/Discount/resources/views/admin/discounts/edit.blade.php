@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">تخفیف‌ها/</a></span>
        ویرایش تخفیف
    </h4>

    <form action="{{ route('admin.discounts.update', $discount) }}" method="POST">
        @csrf
        @method('PUT')
        
        <!-- اطلاعات پایه -->
        <div class="card mb-4">
            <div class="card-header"><h5>اطلاعات پایه</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">عنوان <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" value="{{ old('title', $discount->title) }}" required>
                        @error('title')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">کد تخفیف</label>
                        <input type="text" name="code" class="form-control" value="{{ old('code', $discount->code) }}" id="code-input">
                        @error('code')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">توضیحات</label>
                        <textarea name="description" class="form-control" rows="3">{{ old('description', $discount->description) }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- نوع تخفیف -->
        <div class="card mb-4">
            <div class="card-header"><h5>نوع تخفیف</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع تخفیف <span class="text-danger">*</span></label>
                        <select name="discount_type" class="form-select" required>
                            <option value="percentage" {{ old('discount_type', $discount->discount_type) == 'percentage' ? 'selected' : '' }}>درصدی</option>
                            <option value="fixed_amount" {{ old('discount_type', $discount->discount_type) == 'fixed_amount' ? 'selected' : '' }}>مبلغ ثابت</option>
                            <option value="free_delivery" {{ old('discount_type', $discount->discount_type) == 'free_delivery' ? 'selected' : '' }}>ارسال رایگان</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">مقدار تخفیف <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="discount_value" class="form-control" value="{{ old('discount_value', $discount->discount_value) }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">حداکثر مبلغ تخفیف</label>
                        <input type="number" step="0.01" name="max_discount_amount" class="form-control" value="{{ old('max_discount_amount', $discount->max_discount_amount) }}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع فعال‌سازی <span class="text-danger">*</span></label>
                        <select name="trigger_type" class="form-select" id="trigger-type" required>
                            <option value="automatic" {{ old('trigger_type', $discount->trigger_type) == 'automatic' ? 'selected' : '' }}>فقط خودکار</option>
                            <option value="code" {{ old('trigger_type', $discount->trigger_type) == 'code' ? 'selected' : '' }}>فقط با کد</option>
                            <option value="both" {{ old('trigger_type', $discount->trigger_type) == 'both' ? 'selected' : '' }}>کد و خودکار</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="auto_apply" value="1" {{ old('auto_apply', $discount->auto_apply) ? 'checked' : '' }}>
                            <span class="form-check-label">اعمال خودکار</span>
                        </label>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="stackable" value="1" {{ old('stackable', $discount->stackable) ? 'checked' : '' }}>
                            <span class="form-check-label">قابل ترکیب</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های اعمال -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های اعمال</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">نوع اعمال <span class="text-danger">*</span></label>
                        <select name="applicable_to" class="form-select" id="applicable-to" required>
                            <option value="all" {{ old('applicable_to', $discount->applicable_to) == 'all' ? 'selected' : '' }}>همه</option>
                            <option value="specific_route" {{ old('applicable_to', $discount->applicable_to) == 'specific_route' ? 'selected' : '' }}>مسیر خاص</option>
                            <option value="specific_car_category" {{ old('applicable_to', $discount->applicable_to) == 'specific_car_category' ? 'selected' : '' }}>دسته‌بندی خاص</option>
                            <option value="route_and_category" {{ old('applicable_to', $discount->applicable_to) == 'route_and_category' ? 'selected' : '' }}>مسیر + دسته‌بندی</option>
                            <option value="specific_city" {{ old('applicable_to', $discount->applicable_to) == 'specific_city' ? 'selected' : '' }}>شهر خاص</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3" id="origin-city-field">
                        <label class="form-label">شهر مبدا</label>
                        <input type="text" name="origin_city" class="form-control" value="{{ old('origin_city', $discount->origin_city) }}">
                    </div>
                    <div class="col-md-4 mb-3" id="destination-city-field">
                        <label class="form-label">شهر مقصد</label>
                        <input type="text" name="destination_city" class="form-control" value="{{ old('destination_city', $discount->destination_city) }}">
                    </div>
                    <div class="col-md-4 mb-3" id="car-category-field">
                        <label class="form-label">دسته‌بندی خودرو</label>
                        <select name="car_category_id" class="form-select">
                            <option value="">انتخاب کنید...</option>
                            @foreach($carCategories as $id => $title)
                                <option value="{{ $id }}" {{ old('car_category_id', $discount->car_category_id) == $id ? 'selected' : '' }}>{{ $title }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های مسافت و مبلغ -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های مسافت و مبلغ</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداقل مسافت (km)</label>
                        <input type="number" step="0.01" name="min_distance_km" class="form-control" value="{{ old('min_distance_km', $discount->min_distance_km) }}">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداکثر مسافت (km)</label>
                        <input type="number" step="0.01" name="max_distance_km" class="form-control" value="{{ old('max_distance_km', $discount->max_distance_km) }}">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداقل مبلغ سفارش</label>
                        <input type="number" step="0.01" name="min_order_amount" class="form-control" value="{{ old('min_order_amount', $discount->min_order_amount) }}">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حداکثر مبلغ سفارش</label>
                        <input type="number" step="0.01" name="max_order_amount" class="form-control" value="{{ old('max_order_amount', $discount->max_order_amount) }}">
                    </div>
                </div>
            </div>
        </div>

        <!-- شرط‌های زمان -->
        <div class="card mb-4">
            <div class="card-header"><h5>شرط‌های زمان</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">روزهای هفته</label>
                        <div class="row">
                            @php
                                $selectedDays = is_array($discount->day_of_week) ? $discount->day_of_week : (is_string($discount->day_of_week) ? json_decode($discount->day_of_week, true) : []);
                                $oldDays = old('day_of_week', $selectedDays);
                            @endphp
                            @foreach([1 => 'دوشنبه', 2 => 'سه‌شنبه', 3 => 'چهارشنبه', 4 => 'پنج‌شنبه', 5 => 'جمعه', 6 => 'شنبه', 7 => 'یکشنبه'] as $day => $label)
                                <div class="col-md-3 mb-2">
                                    <label class="form-check">
                                        <input class="form-check-input" type="checkbox" name="day_of_week[]" value="{{ $day }}" {{ in_array($day, $oldDays ?? []) ? 'checked' : '' }}>
                                        <span class="form-check-label">{{ $label }}</span>
                                    </label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">ساعت شروع</label>
                        <input type="time" name="time_from" class="form-control" value="{{ old('time_from', $discount->time_from) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">ساعت پایان</label>
                        <input type="time" name="time_until" class="form-control" value="{{ old('time_until', $discount->time_until) }}">
                    </div>
                </div>
            </div>
        </div>

        <!-- محدودیت‌ها -->
        <div class="card mb-4">
            <div class="card-header"><h5>محدودیت‌ها و اعتبار</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">تاریخ شروع <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="valid_from" class="form-control" value="{{ old('valid_from', $discount->valid_from ? $discount->valid_from->format('Y-m-d\TH:i') : '') }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">تاریخ پایان <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="valid_until" class="form-control" value="{{ old('valid_until', $discount->valid_until ? $discount->valid_until->format('Y-m-d\TH:i') : '') }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">اولویت <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select" required>
                            <option value="high" {{ old('priority', $discount->priority) == 'high' ? 'selected' : '' }}>بالا</option>
                            <option value="medium" {{ old('priority', $discount->priority) == 'medium' ? 'selected' : '' }}>متوسط</option>
                            <option value="low" {{ old('priority', $discount->priority) == 'low' ? 'selected' : '' }}>پایین</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">محدودیت استفاده کل</label>
                        <input type="number" name="usage_limit" class="form-control" value="{{ old('usage_limit', $discount->usage_limit) }}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">محدودیت برای هر کاربر</label>
                        <input type="number" name="usage_limit_per_user" class="form-control" value="{{ old('usage_limit_per_user', $discount->usage_limit_per_user) }}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', $discount->is_active) ? 'checked' : '' }}>
                            <span class="form-check-label">فعال</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
        <a href="{{ route('admin.discounts.index') }}" class="btn btn-secondary">انصراف</a>
    </form>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const applicableTo = document.getElementById('applicable-to');
            const triggerType = document.getElementById('trigger-type');
            
            function toggleFields() {
                const applicableValue = applicableTo.value;
                const originField = document.getElementById('origin-city-field');
                const destinationField = document.getElementById('destination-city-field');
                const carCategoryField = document.getElementById('car-category-field');
                
                if (applicableValue === 'specific_route' || applicableValue === 'route_and_category') {
                    originField.style.display = 'block';
                    destinationField.style.display = 'block';
                } else if (applicableValue === 'specific_city') {
                    originField.style.display = 'block';
                    destinationField.style.display = 'none';
                } else {
                    originField.style.display = 'none';
                    destinationField.style.display = 'none';
                }
                
                if (applicableValue === 'specific_car_category' || applicableValue === 'route_and_category') {
                    carCategoryField.style.display = 'block';
                } else {
                    carCategoryField.style.display = 'none';
                }
            }
            
            function toggleCodeField() {
                const triggerValue = triggerType.value;
                const codeInput = document.getElementById('code-input');
                if (triggerValue === 'code' || triggerValue === 'both') {
                    codeInput.required = true;
                } else {
                    codeInput.required = false;
                }
            }
            
            applicableTo.addEventListener('change', toggleFields);
            triggerType.addEventListener('change', toggleCodeField);
            toggleFields();
            toggleCodeField();
        });
    </script>
    @endpush
@endsection

