@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.discounts.index') }}">تخفیف‌ها/</a></span>
        نمایش تخفیف
    </h4>

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between">
            <h5>جزئیات تخفیف</h5>
            <div>
                <a href="{{ route('admin.discounts.edit', $discount) }}" class="btn btn-warning btn-sm">ویرایش</a>
                <a href="{{ route('admin.discounts.index') }}" class="btn btn-secondary btn-sm">بازگشت</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>عنوان:</strong> {{ $discount->title }}</p>
                    <p><strong>کد:</strong> {{ $discount->code ?? '-' }}</p>
                    <p><strong>نوع تخفیف:</strong> {{ $discount->getDiscountTypeLabel() }}</p>
                    <p><strong>مقدار:</strong> 
                        @if($discount->isPercentage())
                            {{ $discount->discount_value }}%
                        @else
                            {{ number_format($discount->discount_value) }} تومان
                        @endif
                    </p>
                    <p><strong>نوع فعال‌سازی:</strong> {{ $discount->getTriggerTypeLabel() }}</p>
                    <p><strong>اولویت:</strong> {{ $discount->getPriorityLabel() }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>وضعیت:</strong> 
                        @if($discount->is_active)
                            <span class="badge bg-success">فعال</span>
                        @else
                            <span class="badge bg-secondary">غیرفعال</span>
                        @endif
                    </p>
                    <p><strong>استفاده شده:</strong> {{ $discount->current_usage_count }} / {{ $discount->usage_limit ?? '∞' }}</p>
                    <p><strong>تاریخ شروع:</strong> {{ verta($discount->valid_from)->format('Y/m/d H:i') }}</p>
                    <p><strong>تاریخ پایان:</strong> {{ verta($discount->valid_until)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            @if($discount->description)
                <div class="mt-3">
                    <strong>توضیحات:</strong>
                    <p>{{ $discount->description }}</p>
                </div>
            @endif
        </div>
    </div>
@endsection

