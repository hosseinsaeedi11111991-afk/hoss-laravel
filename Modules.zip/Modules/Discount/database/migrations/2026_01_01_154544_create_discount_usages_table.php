<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('discount_usages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('discount_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('reservation_id')->nullable()->constrained()->nullOnDelete();
            
            $table->decimal('discount_amount', 20, 2);
            $table->decimal('original_price', 20, 2);
            $table->decimal('final_price', 20, 2);
            
            $table->string('applied_via')->default('automatic');
            $table->string('code_used')->nullable();
            
            $table->timestamp('used_at');
            $table->timestamps();
            
            // Indexes
            $table->index(['discount_id', 'user_id']);
            $table->index('reservation_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('discount_usages');
    }
};

