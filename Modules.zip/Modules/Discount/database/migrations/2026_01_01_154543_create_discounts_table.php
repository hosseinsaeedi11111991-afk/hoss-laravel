<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('discounts', function (Blueprint $table) {
            $table->id();

            // اطلاعات پایه
            $table->string('code')->nullable()->unique();
            $table->string('title');
            $table->text('description')->nullable();

            // نوع تخفیف
            $table->enum('discount_type', ['percentage', 'fixed_amount', 'free_delivery'])->default('percentage');
            $table->decimal('discount_value', 10, 2);
            $table->decimal('max_discount_amount', 20, 2)->nullable();

            // نوع فعال‌سازی
            $table->enum('trigger_type', ['code', 'automatic', 'both'])->default('automatic');
            $table->boolean('auto_apply')->default(true);

            // شرط‌های مسیر
            $table->enum('applicable_to', [
                'all',
                'specific_route',
                'specific_car_category',
                'route_and_category',
                'specific_city'
            ])->default('all');

            $table->string('origin_city', 100)->nullable();
            $table->string('destination_city', 100)->nullable();
            $table->foreignId('car_category_id')->nullable()->constrained('car_categories')->nullOnDelete();

            // شرط‌های مسافت
            $table->decimal('min_distance_km', 10, 2)->nullable();
            $table->decimal('max_distance_km', 10, 2)->nullable();

            // شرط‌های مبلغ
            $table->decimal('min_order_amount', 20, 2)->nullable();
            $table->decimal('max_order_amount', 20, 2)->nullable();

            // شرط‌های مسافر
            $table->integer('min_passengers_count')->nullable();
            $table->integer('max_passengers_count')->nullable();

            // شرط‌های زمان
            $table->json('day_of_week')->nullable();
            $table->time('time_from')->nullable();
            $table->time('time_until')->nullable();

            // شرط‌های کاربر
            $table->boolean('first_time_only')->default(false);
            $table->integer('min_user_reservations')->nullable();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->json('user_group_ids')->nullable();

            // محدودیت‌های استفاده
            $table->integer('usage_limit')->nullable();
            $table->integer('usage_limit_per_user')->nullable();
            $table->integer('current_usage_count')->default(0);

            // تاریخ اعتبار
            $table->dateTime('valid_from');
            $table->dateTime('valid_until');

            // اولویت و وضعیت
            $table->enum('priority', ['high', 'medium', 'low'])->default('medium');
            $table->boolean('is_active')->default(true);
            $table->boolean('stackable')->default(false);

            // اطلاعات اضافی
            $table->text('conditions_note')->nullable();
            $table->string('image')->nullable();

            $table->timestamps();
            $table->softDeletes();

            // Indexes
            $table->index(['is_active', 'auto_apply', 'valid_from', 'valid_until']);
            $table->index(['origin_city', 'destination_city', 'car_category_id']);
            $table->index(['trigger_type', 'code']);
            $table->index('priority');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('discounts');
    }
};

