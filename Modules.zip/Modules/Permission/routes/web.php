<?php

require_once 'partials/admin.php';
