<?php

use Illuminate\Support\Facades\Route;
use Modules\Permission\Http\Controllers\Admin\PermissionController;
use Modules\Permission\Http\Controllers\Admin\RoleController;

Route::middleware(['web'])->prefix('admin-panel')->name('admin.')->group(function () {
    Route::controller(RoleController::class)
        ->middleware(['auth', 'role:super_user|admin'])
        ->prefix('role')
        ->name('role.')
        ->group(function () {
            Route::get('', 'index')->name('index');
            Route::get('create', 'create')->name('create');
            Route::post('store', 'store')->name('store');
            Route::get('{role}/edit', 'edit')->name('edit');
            Route::put('{role}/update', 'update')->name('update');
            Route::delete('{role}/destroy', 'destroy')->name('destroy');
        });

    Route::controller(PermissionController::class)
        ->middleware(['auth', 'role:super_user|admin'])
        ->prefix('permission')
        ->name('permission.')
        ->group(function () {
            Route::get('', 'index')->name('index');
            Route::get('create', 'create')->name('create');
            Route::post('store', 'store')->name('store');
            Route::get('{permission}/edit', 'edit')->name('edit');
            Route::put('{permission}/update', 'update')->name('update');
            Route::delete('{permission}/destroy', 'destroy')->name('destroy');
        });
});
