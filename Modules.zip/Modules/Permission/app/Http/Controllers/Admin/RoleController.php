<?php

namespace Modules\Permission\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Permission\Http\Requests\RoleRequest;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('permission::admin.role.index', [
            'roles' => Role::query()->with('permissions')->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('permission::admin.role.create', [
            'role' => '',
            'permissions' => Permission::all(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(RoleRequest $request)
    {
        $data = $request->validated();

        try {
            DB::transaction(function () use ($data) {
                foreach ($data['guard_name'] as $guard) {
                    $role = Role::create([
                        'name' => $data['name'],
                        'guard_name' => $guard,
                    ]);

                    $role->syncPermissions($data['permissions'] ?? []);
                }
            });

            return redirect()->route('admin.role.index')
                ->with('success', 'نقش جدید با موفقیت ایجاد شد.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'خطا در ایجاد نقش: ' . $e->getMessage());
        }
    }

    /**
     * Show the specified resource.
     */
    public function show(Role $role)
    {
        return view('permission::admin.role.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Role $role)
    {
        return view('permission::admin.role.edit', [
            'role' => $role,
            'permissions' => Permission::all(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(RoleRequest $request, Role $role)
    {
        $data = $request->validated();

        try {
            DB::transaction(function () use ($role, $data) {
                $role->update([
                    'name' => $data['name'],
                ]);
                $role->syncPermissions($data['permissions'] ?? []);
            });

            return redirect()->route('admin.role.index')
                ->with('success', 'نقش با موفقیت به‌روزرسانی شد.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'خطا در به‌روزرسانی نقش: ' . $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Role $role)
    {
        try {
            DB::transaction(function () use ($role) {
                $role->syncPermissions([]);
                $role->delete();
            });

            return redirect()->route('admin.role.index')
                ->with('success', 'نقش با موفقیت حذف شد.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'خطا در حذف نقش: ' . $e->getMessage());
        }
    }
}
