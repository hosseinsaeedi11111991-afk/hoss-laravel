<?php

namespace Modules\Permission\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Permission\Http\Requests\PermissionRequest;
use Spatie\Permission\Models\Permission;

class PermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('permission::admin.permission.index', [
            'permissions' => Permission::query()->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('permission::admin.permission.create', [
            'permission' => null,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PermissionRequest $request)
    {
        $data = $request->validated();

        foreach ($data['guard_name'] as $guard) {
            Permission::firstOrCreate([
                'name' => $data['name'],
                'guard_name' => $guard,
            ]);
        }

        return redirect()->route('admin.permission.index')
            ->with('success', 'Permission با موفقیت ایجاد شد.');
    }

    /**
     * Show the specified resource.
     */
    public function show(Permission $permission)
    {
        return view('permission::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Permission $permission)
    {
        return view('permission::admin.permission.edit', [
            'permission' => $permission,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(PermissionRequest $request, Permission $permission) 
    {
        $data = $request->validated();

        $permission->update($data);

        return redirect()->route('admin.permission.index')
            ->with('success', 'Permission با موفقیت ویرایش شد.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Permission $permission) 
    {
        $permission->delete();
        return redirect()->route('admin.permission.index')
            ->with('success', 'Permission با موفقیت حذف شد.');
    }
}
