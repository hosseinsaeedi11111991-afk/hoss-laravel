<?php

namespace Modules\Permission\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PermissionRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $routeName = $this->route()->getName();

        return match ($routeName) {
            'admin.permission.store' => [
                'name'         => 'required|string|unique:permissions,name|regex:/^[a-zA-Z_]+$/',
                'guard_name'   => 'required|array',
                'guard_name.*' => 'in:web,api',
            ],
            'admin.permission.update' => [
                'name'         => 'required|string|regex:/^[a-zA-Z_]+$/|unique:permissions,name,' . $this->route('permission'),
                'guard_name'   => 'required|array',
                'guard_name.*' => 'in:web,api',
            ],
            default => [],
        };
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages(): array
    {
        return [
            'name.required'       => 'وارد کردن نام Permission الزامی است.',
            'name.string'         => 'نام Permission باید یک رشته باشد.',
            'name.regex'          => 'نام Permission فقط می‌تواند شامل حروف انگلیسی و _ باشد.',
            'name.unique'         => 'این نام Permission قبلا ثبت شده است.',
            'guard_name.required' => 'حداقل یک Guard باید انتخاب شود.',
            'guard_name.array'    => 'فرمت Guard ها معتبر نیست.',
            'guard_name.*.in'     => 'فیلد Guard فقط می‌تواند web یا api باشد.',
        ];
    }
}
