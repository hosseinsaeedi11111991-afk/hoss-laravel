<?php

namespace Modules\Permission\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RoleRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $route_name = $this->route()->getName();

        return match ($route_name) {
            'admin.role.store' => [
                'name'          => 'required|string|unique:roles,name|regex:/^[a-zA-Z_]+$/',
                'guard_name'    => 'required|array',
                'guard_name.*'  => 'in:web,api',
                'permissions'   => 'nullable|array',
                'permissions.*' => 'exists:permissions,name',
            ],
            'admin.role.update' => [
                'name'          => 'required|string|regex:/^[a-zA-Z_]+$/|unique:roles,name,' . $this->route('role')->id,
                'guard_name'    => 'sometimes|array',
                'guard_name.*'  => 'in:web,api',
                'permissions'   => 'nullable|array',
                'permissions.*' => 'exists:permissions,name',
            ],
            default => [],
        };
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages(): array
    {
        return [
            'name.required'        => 'وارد کردن نام نقش الزامی است.',
            'name.string'          => 'نام نقش باید یک رشته متنی باشد.',
            'name.unique'          => 'این نام نقش قبلاً استفاده شده است.',
            'name.regex'           => 'نام نقش فقط می‌تواند شامل حروف انگلیسی و _ باشد.',
            'guard_name.required'  => 'انتخاب نوع guard الزامی است.',
            'guard_name.array'     => 'guard باید به صورت یک آرایه باشد.',
            'guard_name.*.in'      => 'guard انتخاب شده معتبر نیست.',
            'permissions.array'    => 'مجوزها باید به صورت آرایه ارسال شوند.',
            'permissions.*.exists' => 'مجوز انتخاب شده معتبر نیست.',
        ];
    }
}
