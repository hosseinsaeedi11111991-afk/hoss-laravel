@php use Modules\Menu\Models\Menu; @endphp
<form method="POST" enctype="multipart/form-data"
    action="@if($role) {{ route('admin.role.update', ['role' => $role]) }}
      @else {{ route('admin.role.store') }} @endif">
    @csrf
    @if($role)
    @method('PUT')
    @endif

    @if(!$role)
        <div class="d-flex mb-3 flex-wrap gap-3">
            <div class="col-12 col-lg-4 col-md-6">
                <label class="form-label" for="name">
                    <span>guard</span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_web" value="web"
                        {{ (collect(old('guard_name'))->contains('web')) ? 'checked' : '' }}>
                    <label class="form-check-label" for="guard_web">web</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_api" value="api"
                        {{ (collect(old('guard_name'))->contains('api')) ? 'checked' : '' }}>
                    <label class="form-check-label" for="guard_api">api</label>
                </div>
                @error('guard_name')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
    @endif

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="name">
                <span>نام</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="{{ old('name', $role ? $role->name : '') }}">
            </div>
            @error('name')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    @if (count($permissions) > 0)
        <div class="d-flex mb-3 flex-wrap gap-3">
            <h3>لیست گزینه‌ها</h3>
            <div class="d-flex mb-3 flex-wrap gap-3">
                @foreach($permissions as $permission)
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                value="{{ $permission->name }}" 
                                id="permission{{ $permission->id }}" 
                                name="permissions[]"
                                {{ ($role && in_array($permission->name, old('permissions', $role->permissions->pluck('name')->toArray()))) 
                                    ? 'checked' 
                                    : '' 
                                }}>
                            <label class="form-check-label" for="permission{{ $permission->id }}">
                                {{ $permission->name }}
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form>