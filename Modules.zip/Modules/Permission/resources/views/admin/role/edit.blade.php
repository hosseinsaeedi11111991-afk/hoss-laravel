@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش: {{ $role->name }}')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.role.index')}}">لیست نقش ها/</a></span>
    <span>ویرایش: {{ $role->name }}</span>
</h4>

@include('permission::admin.role.partials.form', [
    'role' => $role,
    'permissions' => $permissions,
])

@endsection