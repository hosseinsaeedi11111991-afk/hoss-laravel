<form method="POST" enctype="multipart/form-data"
    action="@if($permission) {{ route('admin.permission.update', ['permission' => $permission]) }}
      @else {{ route('admin.permission.store') }} @endif">
    @csrf
    @if($permission)
    @method('PUT')
    @endif

    @if(!$permission)
        <div class="d-flex mb-3 flex-wrap gap-3">
            <div class="col-12 col-lg-4 col-md-6">
                <label class="form-label" for="name">
                    <span>guard</span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_web" value="web"
                        {{ (collect(old('guard_name'))->contains('web')) ? 'checked' : '' }}>
                    <label class="form-check-label" for="guard_web">web</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="guard_name[]" id="guard_api" value="api"
                        {{ (collect(old('guard_name'))->contains('api')) ? 'checked' : '' }}>
                    <label class="form-check-label" for="guard_api">api</label>
                </div>
                @error('guard_name')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
    @endif

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-4 col-md-6">
            <label class="form-label" for="name">
                <span>نام</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="{{ old('name', $permission ? $permission->name : '') }}">
            </div>
            @error('name')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form>