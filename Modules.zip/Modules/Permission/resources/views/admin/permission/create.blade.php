@extends('Shared::layouts.admin.main')

@section('title', 'ساخت دسترسی جدید')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.permission.index')}}">لیست دسترسی ها/</a></span>
    <span>ساخت دسترسی جدید</span>
</h4>

@include('permission::admin.permission.partials.form', [
    'permission' => $permission,
])

@endsection