@extends('Shared::layouts.admin.main')

@section('title', 'مدیریت دسترسی ها')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span>مدیریت دسترسی ها</span>
</h4>

<a href="{{route('admin.permission.create')}}" type="button" class="btn rounded-pill me-2 btn-success">تعریف نقش جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>Guard</th>
                <th>نام دسترسی</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($permissions as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$row->guard_name}}</td>
                <td>{{$row->name}}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.permission.edit', $row->id) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.permission.destroy', $row->id) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $permissions->links('pagination::bootstrap-5') }}
</div>
@endsection