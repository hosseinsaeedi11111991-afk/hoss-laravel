@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش: {{ $permission->guard_name }} - {{ $permission->name }}')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.permission.index')}}">لیست دسترسی ها/</a></span>
    <span>ویرایش: {{ $permission->guard_name }} - {{ $permission->name }}</span>
</h4>

@include('permission::admin.permission.partials.form', [
    'permission' => $permission,
])

@endsection