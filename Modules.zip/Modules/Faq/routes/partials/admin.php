<?php

use Illuminate\Support\Facades\Route;
use Modules\Faq\Http\Controllers\Admin\FaqContentController;
use Modules\Faq\Http\Controllers\Admin\FaqController;
use Modules\Faq\Livewire\Admin\FaqForm;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {
        Route::get('faq/create', FaqForm::class)->name('faq.create');
        
        Route::controller(FaqController::class)
            ->prefix('faq')->name('faq.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('/create', 'create')->name('create');
                Route::get('{faq}/show', 'show')->name('show');
                Route::get('{faq}/edit', 'edit')->name('edit');
                Route::put('{faq}/update', 'update')->name('update');
                Route::put('{faq}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{faq}/destroy', 'destroy')->name('destroy');
            });
    });

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {
        Route::controller(FaqContentController::class)
            ->prefix('faq/{faq}/content')->name('faq_content.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('/create', 'create')->name('create');
                Route::post('/store', 'store')->name('store');
                Route::get('{faq_content}/show', 'show')->name('show');
                Route::get('{faq_content}/edit', 'edit')->name('edit');
                Route::put('{faq_content}/update', 'update')->name('update');
                Route::put('{faq_content}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{faq_content}/destroy', 'destroy')->name('destroy');
            });
    });