<?php

namespace Modules\Faq\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Faq\Http\Requests\FaqContentRequest;
use Modules\Faq\Models\Faq;
use Modules\Faq\Models\FaqContent;

class FaqContentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Faq $faq)
    {
        return view('faq::admin.faq_content.index', [
            'faq' => $faq,
            'contents' => FaqContent::query()->where('faq_id', $faq->id)
                ->whereNot('status', FaqContent::STATUS_DELETED)
                ->orderBy('sort_order')
                ->latest()->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Faq $faq)
    {
        return view('faq::admin.faq_content.create', [
            'faq' => $faq,
            'faq_content' => null,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(FaqContentRequest $request, Faq $faq)
    {
        $data = $request->validated();

        $faq->query()->create($data);

        return redirect()->route('admin.faq_content.index', $faq)
            ->with('تغییرات با موفقیت اعمال شد');
    }

    /**
     * Show the specified resource.
     */
    public function show(Faq $faq)
    {
        return view('faq::admin.faq_content.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Faq $faq, FaqContent $faq_content)
    {
        return view('faq::admin.faq_content.edit', [
            'faq' => $faq,
            'faq_content' => $faq_content,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(FaqContentRequest $request, Faq $faq, FaqContent $faq_content)
    {
        $data = $request->validated();

        $faq_content->update($data);
        return redirect()->route('admin.faq_content.index', $faq)
            ->with('تغییرات با موفقیت اعمال شد');
    }

    public function toggleStatus(Faq $faq, FaqContent $faq_content)
    {
        if ($faq_content->status == FaqContent::STATUS_ACTIVE) {
            $faq_content->update(['status' => FaqContent::STATUS_INACTIVE]);
        } else {
            $faq_content->update(['status' => FaqContent::STATUS_ACTIVE]);
        }

        return redirect()->route('admin.faq_content.index', $faq)
            ->with('تغییرات با موفقیت اعمال شد');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Faq $faq, FaqContent $faq_content)
    {
        $faq_content->update(['status', FaqContent::STATUS_DELETED]);

        return redirect()->route('admin.faq_content.index', $faq)
            ->with('تغییرات با موفقیت اعمال شد');
    }
}
