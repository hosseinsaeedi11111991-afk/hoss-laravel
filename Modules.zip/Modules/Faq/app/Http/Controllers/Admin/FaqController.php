<?php

namespace Modules\Faq\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Faq\Http\Requests\FaqRequest;
use Modules\Faq\Models\Faq;

class FaqController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('faq::admin.faq.index', [
            'faqs' => Faq::query()->whereNot('status', Faq::STATUS_DELETED)
                ->latest()->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('faq::admin.faq.create');
    }

    /**
     * Show the specified resource.
     */
    public function show(Faq $faq)
    {
        return view('faq::admin.faq.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Faq $faq)
    {
        return view('faq::admin.faq.edit', [
            'faq' => $faq,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(FaqRequest $request, Faq $faq) 
    {
        $data = $request->validated();

        $faq->update($data);

        return redirect()->route('admin.faq.index')
            ->with('success', 'اطلاعات با موفقیت ذخیره شد');
    }

    public function toggleStatus(Faq $faq)
    {
        if ($faq->status == Faq::STATUS_INACTIVE) {
            $faq->update(['status' => Faq::STATUS_ACTIVE]);
        } elseif ($faq->status == Faq::STATUS_ACTIVE) {
            $faq->update(['status' => Faq::STATUS_INACTIVE]);
        }

        return redirect()->route('admin.faq.index')->with('تغییرات با موفقیت اعمال شد');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Faq $faq) 
    {
        $faq->update(['status' => Faq::STATUS_DELETED]);

        return redirect()->route('admin.faq.index')
            ->with('آیتم مورد نظر با موفقیت حذف شد');
    }
}
