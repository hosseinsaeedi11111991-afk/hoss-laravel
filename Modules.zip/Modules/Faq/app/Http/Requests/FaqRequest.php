<?php

namespace Modules\Faq\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FaqRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'subject'              => 'required|string|max:255',
            'title'                => 'nullable|string|max:255',
            'contents.*.question'  => 'required|string',
            'contents.*.answer'    => 'required|string',
        ];
    }

    public function messages()
    {
        return [
            'subject.required'              => 'موضوع الزامی است.',
            'subject.string'                => 'موضوع باید متنی باشد.',
            'subject.max'                   => 'موضوع نمی‌تواند بیشتر از ۲۵۵ کاراکتر باشد.',

            'title.string'                  => 'عنوان باید متنی باشد.',
            'title.max'                     => 'عنوان نمی‌تواند بیشتر از ۲۵۵ کاراکتر باشد.',

            'contents.*.question.required' => 'پرسش نمی‌تواند خالی باشد.',
            'contents.*.question.string'   => 'پرسش باید متنی باشد.',

            'contents.*.answer.required'   => 'پاسخ نمی‌تواند خالی باشد.',
            'contents.*.answer.string'     => 'پاسخ باید متنی باشد.',
        ];
    }
}
