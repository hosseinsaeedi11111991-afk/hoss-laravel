<?php

namespace Modules\Faq\Http\Requests;

use App\Traits\StringHelpers;
use Illuminate\Foundation\Http\FormRequest;

class FaqContentRequest extends FormRequest
{
    use StringHelpers;
    
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'question' => 'required|string|max:255',
            'answer' => 'required|string|max:255',
            'sort_order' => 'required|integer',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages()
    {
        return [
            'question.required' => 'پرسش نمی‌تواند خالی باشد.',
            'question.string'   => 'پرسش باید متنی باشد.',

            'answer.required'   => 'پاسخ نمی‌تواند خالی باشد.',
            'answer.string'     => 'پاسخ باید متنی باشد.',
            
            'sort_order.required'     => 'ترتیب نمایش نمی‌تواند خالی باشد.',
        ];
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('sort_order')) {
            $this->merge([
                'sort_order' => $this->convertToEnglishDigits($this->input('sort_order')),
            ]);
        }
    }
}
