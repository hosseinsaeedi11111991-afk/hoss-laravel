<?php

namespace Modules\Faq\Livewire\Admin;

use Livewire\Component;
use Modules\Faq\Models\Faq;

class FaqForm extends Component
{
    public $subject, $title, $description, $status = 'active';
    public $contents = [];

    public function mount()
    {
        $this->contents = [
            ['question' => '', 'answer' => '', 'sort_order' => 1, 'status' => 'active']
        ];
    }

    public function addContent()
    {
        $this->contents[] = [
            'question' => '',
            'answer'  => '',
            'sort_order' => count($this->contents) + 1,
            'status'  => 'active'
        ];
    }

    public function removeContent($index)
    {
        unset($this->contents[$index]);
        $this->contents = array_values($this->contents);
    }

    public function save()
    {
        $this->validate([
            'subject'              => 'required|string|max:255',
            'title'                => 'nullable|string|max:255',
            'contents.*.question'  => 'required|string',
            'contents.*.answer'    => 'required|string',
        ]);

        $faq = Faq::create([
            'subject'     => $this->subject,
            'title'       => $this->title,
            'description' => $this->description,
            'status'      => $this->status,
        ]);

        foreach ($this->contents as $content) {
            $faq->contents()->create($content);
        }

        session()->flash('message', 'FAQ با موفقیت ذخیره شد.');
        return redirect()->route('admin.faq.index');
    }

    public function render()
    {
        return view('faq::livewire.admin.faq_form');
    }
}