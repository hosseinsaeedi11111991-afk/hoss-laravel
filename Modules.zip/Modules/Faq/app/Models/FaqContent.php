<?php

namespace Modules\Faq\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Faq\Database\Factories\FaqContentFactory;

class FaqContent extends Model
{
    use HasFactory;

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DELETED = 'deleted';

    protected $table = 'faq_content';
    
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'faq_id',
        'question',
        'answer',
        'sort_order',
        'status',
    ];

    public function faq()
    {
        return $this->belongsTo(Faq::class);
    }

    // protected static function newFactory(): FaqContentFactory
    // {
    //     // return FaqContentFactory::new();
    // }
}
