<?php

namespace Modules\Faq\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Faq\Database\Factories\FaqFactory;

class Faq extends Model
{
    use HasFactory;

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DELETED = 'deleted';

    protected $table = 'faq';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'subject',
        'title',
        'description',
        'status',
    ];

    public function contents()
    {
        return $this->hasMany(FaqContent::class);
    }

    // protected static function newFactory(): FaqFactory
    // {
    //     // return FaqFactory::new();
    // }
}
