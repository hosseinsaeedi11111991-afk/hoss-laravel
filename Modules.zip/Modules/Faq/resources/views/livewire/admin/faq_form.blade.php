<div>
    @if (session()->has('message'))
        <div class="alert alert-success">{{ session('message') }}</div>
    @endif

    <form wire:submit.prevent="save">
        
        <div class="d-flex mb-3 flex-wrap">
            {{-- موضوع FAQ --}}
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="subject">
                    <span>موضوع FAQ</span>
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-bookmark"></i></span>
                    <input id="subject" type="text" class="form-control" placeholder="موضوع FAQ" wire:model="subject">
                </div>
                @error('subject') <small class="text-danger">{{ $message }}</small> @enderror
            </div>

            {{-- عنوان FAQ --}}
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="title">
                    <span>عنوان</span>
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="title" type="text" class="form-control" placeholder="عنوان" wire:model="title">
                </div>
                @error('title') <small class="text-danger">{{ $message }}</small> @enderror
            </div>
        </div>

        {{-- توضیحات FAQ --}}
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4">
                <label class="form-label" for="description">
                    <span>توضیحات</span>
                </label>
                <textarea id="description" class="form-control" rows="3" placeholder="توضیحات" wire:model="description"></textarea>
            </div>
        </div>

        <h5 class="mb-3 px-4">پرسش و پاسخ‌ها</h5>
        
        @foreach($contents as $index => $content)
            <div class="border rounded p-3 mb-3 mx-4">
                <div class="d-flex flex-wrap mb-3">
                    <div class="col-12 col-lg-5 col-md-6 px-3 mb-2 mb-lg-0">
                        <label class="form-label" for="sort_order-{{ $index }}">
                            ترتیب
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-pen"></i></span>
                            <input id="sort_order-{{ $index }}" type="number" class="form-control form-control-sm ps-2"
                               placeholder="ترتیب" wire:model="contents.{{ $index }}.sort_order">
                        </div>
                        <label class="form-label" for="question-{{ $index }}">
                            پرسش
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-pen"></i></span>
                            <input id="question-{{ $index }}" type="text" class="form-control form-control-sm" placeholder="پرسش"
                               wire:model="contents.{{ $index }}.question">
                        </div>
                        @error('title') <small class="text-danger">{{ $message }}</small> @enderror
                    </div>
                    <div class="col-12 col-lg-6 col-md-6 px-3">
                        <label class="form-label" for="answer-{{ $index }}">
                            <span>پاسخ</span>
                            <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                        </label>
                        <textarea id="answer-{{ $index }}" class="form-control form-control-sm" rows="3" placeholder="پاسخ"
                                  wire:model="contents.{{ $index }}.answer"></textarea>
                        @error('contents.'.$index.'.answer') <small class="text-danger">{{ $message }}</small> @enderror
                    </div>
                    <div class="col-12 col-lg-1 col-md-12 px-3 pt-4 d-flex flex-column justify-content-between">
                        <button type="button" class="btn btn-sm btn-danger" wire:click="removeContent({{ $index }})">
                            <i class="bx bx-trash"></i>
                            حذف
                        </button>
                    </div>
                </div>
            </div>
        @endforeach
        <div class="px-4 mb-4">
            <button type="button" class="btn btn-sm btn-success" wire:click="addContent">
                <i class="bx bx-plus"></i>
                <span>افزودن پرسش و پاسخ</span>
            </button>
        </div>
        <div class="px-4 mb-5">
            <button type="submit" class="btn btn-primary">ثبت</button>
        </div>
    </form>
</div>
