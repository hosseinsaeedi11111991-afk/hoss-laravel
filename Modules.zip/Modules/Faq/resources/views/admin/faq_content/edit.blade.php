@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش پرسش و پاسخ')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.faq_content.index', $faq) }}">پرسش و پاسخ ها/</a></span>
        <span>ویرایش پرسش و پاسخ</span>
    </h4>

    @include('faq::admin.faq_content.partials.form', [
        'faq' => $faq,
        'faq_content' => $faq_content,
    ])
@endsection
