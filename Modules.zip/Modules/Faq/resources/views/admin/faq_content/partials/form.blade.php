<form method="POST" enctype="multipart/form-data"
    action="@if($faq_content) {{ route('admin.faq_content.update', ['faq' => $faq, 'faq_content' => $faq_content]) }}
      @else {{ route('admin.faq_content.store', $faq) }} @endif">
    @csrf
    @if($faq_content)
    @method('PUT')
    @endif

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-2 col-md-6 px-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="number" name="sort_order" class="form-control"
                    value="{{ old('sort_order', $faq_content ? $faq_content->sort_order : '') }}">
            </div>
            @error('sort_order')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="question">
                <span>پرسش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="question" type="text" name="question" class="form-control"
                    value="{{ old('question', $faq_content ? $faq_content->question : '') }}">
            </div>
            @error('question')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-6 px-4">
            <label class="form-label" for="answer">
                <span>پاسخ</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <textarea id="answer" name="answer" class="form-control" rows="5">
                    {{ old('answer', $faq_content ? $faq_content->answer : '') }}
                </textarea>
            </div>
            @error('answer')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
</form>