@php use Modules\Faq\Models\Faq; @endphp
@extends('Shared::layouts.admin.main')

@section('title', 'پرسش و پاسخ ها')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.faq.index')}}">لیست سوالات متداول/</a></span>
    <span>پرسش و پاسخ ها</span>
</h4>

<a href="{{route('admin.faq_content.create', $faq)}}" type="button" class="btn rounded-pill me-2 btn-success">
    افزودن پرسش و پاسخ جدید
</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>ترتیب نمایش</th>
                <th>سوال</th>
                <th>پاسخ</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($contents as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$row->sort_order}}</td>
                <td>{{$row->question}}</td>
                <td>{{$row->answer}}</td>
                <td>
                    @php
                    switch ($row->status) {
                        case Faq::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case Faq::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case Faq::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    @endphp
                </td>
                <td>{{ Verta::instance($row->updated_at)->format('Y/m/d') }}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.faq_content.edit', [$faq, $row->id]) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.faq_content.toggle_status', [$faq, $row->id]) }}"
                            class="d-inline">
                            @csrf
                            @method('PUT')
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="{{ route('admin.faq_content.destroy', [$faq, $row->id]) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $contents->links('pagination::bootstrap-5') }}
</div>
@endsection