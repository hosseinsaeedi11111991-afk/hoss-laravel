@extends('Shared::layouts.admin.main')

@section('title', 'افزودن FAQ')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.faq.index') }}">لیست سوالات متداول/</a></span>
        <span>افزودن FAQ</span>
    </h4>

    @livewire('faq_form')
@endsection
