@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش FAQ')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.faq.index') }}">لیست سوالات متداول/</a></span>
        <span>ویرایش FAQ</span>
    </h4>

    <form method="POST" enctype="multipart/form-data"
        action="{{ route('admin.faq.update', ['faq' => $faq]) }}">
        @csrf
        @method('PUT')

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="subject">
                    <span>موضوع FAQ </span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="subject" type="text" name="subject" class="form-control"
                        value="{{ old('subject', $faq ? $faq->subject : '') }}">
                </div>
                @error('subject')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="col-12 col-lg-4 col-md-6 px-4">
                <label class="form-label" for="title">
                    <span>عنوان صفحه</span>
                    <i class="bx bx-health font-size-1 text-danger mx-2"></i>
                </label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bx bx-pen"></i></span>
                    <input id="title" type="text" name="title" class="form-control" placeholder="عنوان صفحه"
                        value="{{ old('title', $faq ? $faq->title : '') }}">
                </div>
                @error('title')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4">
                <label class="form-label" for="description">
                    <span>توضیحات</span>
                </label>
                <textarea id="description" class="form-control" rows="8" placeholder="توضیحات" name="description">
                    {{ old('description', $faq ? $faq->description : '') }}
                </textarea>
                @error('description')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
    </form>
@endsection
