<?php

return [
    'name' => 'Faq',
];
