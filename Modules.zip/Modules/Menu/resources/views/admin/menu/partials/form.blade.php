@php use Modules\Menu\Models\Menu; @endphp
<form method="POST" enctype="multipart/form-data"
    action="@if($menu) {{ route('admin.menu.update', ['menu' => $menu]) }}
      @else {{ route('admin.menu.store') }} @endif">
    @csrf
    @if($menu)
    @method('PUT')
    @endif

    @if(!$menu)
        <input type="hidden" name="position" value="{{ $position }}">
    @endif

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-2 col-md-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="text" name="sort_order" class="form-control"
                    value="{{ old('sort_order', $menu ? $menu->sort_order : '') }}">
            </div>
            @error('sort_order')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="name">
                <span>نام</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="{{ old('name', $menu ? $menu->name : '') }}">
            </div>
            @error('name')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-3 col-md-4">
            <label class="form-label" for="icon">
                <span>آیکن</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="icon" type="text" name="icon" class="form-control"
                    value="{{ old('icon', $menu ? $menu->icon : '') }}">
            </div>
            @error('icon')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-8 col-md-8">
            <label class="form-label" for="style">
                <span>استایل</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="style" type="text" name="style" class="form-control"
                    value="{{ old('style', $menu ? $menu->style : '') }}">
            </div>
            @error('style')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    @if(($menu && $menu->position == Menu::POSITION_HEADER) || $position == Menu::POSITION_HEADER)
        <div class="form-check form-switch">
            <input type="hidden" name="mega_menu" value="0">
            <input 
                class="form-check-input" 
                type="checkbox" 
                role="switch" 
                id="mega_menu" 
                name="mega_menu" 
                value="1"
                @checked($menu && $menu->mega_menu)>

            <label class="form-check-label ms-2" for="mega_menu">
                مگامنو؟
            </label>
        </div>
    @endif

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form>