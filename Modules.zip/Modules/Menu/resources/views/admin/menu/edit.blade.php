@extends('Shared::layouts.admin.main')

@section('title', 'افزودن {{ $menu->name }}')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.menu.index', $menu->position) }}">لیست منوها/</a></span>
        <span>افزودن {{ $menu->name }}</span>
    </h4>

    @include('menu::admin.menu.partials.form', [
        'menu' => $menu,
        'position' => $menu->position,
    ])
@endsection
