@php use Modules\Menu\Models\Menu; @endphp
@extends('Shared::layouts.admin.main')

@php
switch ($position) {
    case(Menu::POSITION_HEADER):
        $title = 'لیست منوهای نوار اصلی';
        break;
    case(Menu::POSITION_FOOTER):
        $title = 'لیست منوهای فوتر';
        break;
    case(Menu::POSITION_TOPBAR):
        $title = 'لیست منوهای نوار بالایی';
        break;
    case(Menu::POSITION_SIDEBAR):
        $title = 'نوار کناری';
        break;
    default:
        $title = 'لیست منوها';
        break;
}
@endphp
@section('title', $title)

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span>{{ $title }}</span>
</h4>

<a href="{{ route('admin.menu.create', $position)}} " type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>ترتیب نمایش</th>
                <th>نام</th>
                <th>مگا منو؟</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($menu as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$row->sort_order}}</td>
                <td>{{$row->name}}</td>
                <td>
                    @if ($row->mega_menu == true)
                        <i class="text-success bx bx-check-circle"></i>
                    @else
                        <i class="text-danger bx bx-x-circle"></i>
                    @endif
                </td>
                <td>
                    @php
                    switch ($row->status) {
                        case Menu::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case Menu::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case Menu::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    @endphp
                </td>
                <td>{{ Verta::instance($row->updated_at)->format('Y/m/d') }}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.menu.edit', $row->id) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <a href="{{ route('admin.menu_item.index', $row->id) }}"
                            class="btn btn-dark btn-sm"
                            title="لینک‌ها">
                            <i class="bx bx-list-ul"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.menu.toggle_status', $row->id) }}"
                            class="d-inline">
                            @csrf
                            @method('PUT')
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="{{ route('admin.menu.destroy', $row->id) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $menu->links('pagination::bootstrap-5') }}
</div>
@endsection