@extends('Shared::layouts.admin.main')

@section('title', 'افزودن منو')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.menu.index', $position) }}">لیست منوها/</a></span>
        <span>افزودن منو</span>
    </h4>

    @include('menu::admin.menu.partials.form', [
        'menu' => $menu,
        'position' => $position,
    ])
@endsection
