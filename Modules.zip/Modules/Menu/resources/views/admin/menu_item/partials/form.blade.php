@php use Modules\Menu\Models\MenuItem; @endphp
<form method="POST" enctype="multipart/form-data"
    action="@if($menu_item) {{ route('admin.menu_item.update', ['menu' => $menu, 'menu_item' => $menu_item]) }}
      @else {{ route('admin.menu_item.store', $menu) }} @endif">
    @csrf
    @if($menu_item)
    @method('PUT')
    @endif

    @if(!$menu_item)
        <input type="hidden" name="menu_id" value="{{ $menu->id }}">
    @endif

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            @include('admin.components.tree_view', [
                'content' => $items,
                'selected' => old('parent_id'),
                'level' => 0,
                'name' => 'parent_id',
                'label' => 'title'
            ])
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-2 col-md-4">
            <label class="form-label" for="sort_order">
                <span>ترتیب نمایش</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="text" name="sort_order" class="form-control"
                    value="{{ old('sort_order', $menu_item ? $menu_item->sort_order : '') }}">
            </div>
            @error('sort_order')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="title">
                <span>عنوان</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="title" type="text" name="title" class="form-control"
                    value="{{ old('title', $menu_item ? $menu_item->title : '') }}">
            </div>
            @error('title')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-4 col-md-8">
            <label class="form-label" for="link">
                <span>لینک</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="link" type="text" name="link" class="form-control"
                    value="{{ old('link', $menu_item ? $menu_item->link : '') }}">
            </div>
            @error('link')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap gap-3">
        <div class="col-12 col-lg-3 col-md-4">
            <label class="form-label" for="icon">
                <span>آیکن</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="icon" type="text" name="icon" class="form-control"
                    value="{{ old('icon', $menu_item ? $menu_item->icon : '') }}">
            </div>
            @error('icon')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-8 col-md-8">
            <label class="form-label" for="style">
                <span>استایل</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="style" type="text" name="style" class="form-control"
                    value="{{ old('style', $menu_item ? $menu_item->style : '') }}">
            </div>
            @error('style')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="form-check form-switch">
        <input type="hidden" name="new_tab" value="0">
        <input 
            class="form-check-input" 
            type="checkbox" 
            role="switch" 
            id="new_tab" 
            name="new_tab" 
            value="1"
            @checked($menu_item && $menu_item->new_tab)>

        <label class="form-check-label ms-2" for="new_tab">
            ایجاد تب جدید
        </label>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mt-5">ذخیره اطلاعات</button>
</form>