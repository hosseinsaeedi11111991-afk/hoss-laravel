@php
    use Modules\Menu\Models\Menu;
    use Modules\Menu\Models\MenuItem;
@endphp
@extends('Shared::layouts.admin.main')

@php
switch ($menu->position) {
    case(Menu::POSITION_HEADER):
        $breadcrumb = 'لیست منوهای نوار اصلی';
        break;
    case(Menu::POSITION_FOOTER):
        $breadcrumb = 'لیست منوهای فوتر';
        break;
    case(Menu::POSITION_TOPBAR):
        $breadcrumb = 'لیست منوهای نوار بالایی';
        break;
    case(Menu::POSITION_SIDEBAR):
        $breadcrumb = 'نوار کناری';
        break;
    default:
        $breadcrumb = 'لیست منوها';
        break;
}
@endphp
@section('title', 'لینک‌‌های منو')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.menu.index', $menu->position)}}">{{ $breadcrumb }}/</a></span>
    <span>لینک‌‌های منو</span>
</h4>

<a href="{{ route('admin.menu_item.create', $menu)}} " type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>ترتیب نمایش</th>
                <th>شناسه والد</th>
                <th>عنوان</th>
                <th>آدرس لینک</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($items as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$row->sort_order}}</td>
                <td>
                    @if ($row->parent)
                        {{$row->parent->name}}
                    @else
                        (هیچکدام)
                    @endif
                </td>
                <td>{{$row->title}}</td>
                <td>{{$row->link}}</td>
                <td>
                    @php
                    switch ($row->status) {
                        case MenuItem::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case MenuItem::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case MenuItem::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    @endphp
                </td>
                <td>{{ Verta::instance($row->updated_at)->format('Y/m/d') }}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.menu_item.edit', ['menu' => $menu, 'menu_item' => $row]) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.menu_item.toggle_status', ['menu' => $menu, 'menu_item' => $row]) }}"
                            class="d-inline">
                            @csrf
                            @method('PUT')
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="{{ route('admin.menu_item.destroy', ['menu' => $menu, 'menu_item' => $row]) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $items->links('pagination::bootstrap-5') }}
</div>
@endsection