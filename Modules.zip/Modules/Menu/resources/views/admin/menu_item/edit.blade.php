@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش لینک {{ $menu_item->title }}')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.menu_item.index', $menu) }}">لینک‌‌های منو/</a></span>
        <span>ویرایش لینک {{ $menu_item->title }}</span>
    </h4>

    @include('menu::admin.menu_item.partials.form', [
        'menu' => $menu,
        'menu_item' => $menu_item,
        'items' => $items,
    ])
@endsection
