<?php

use Illuminate\Support\Facades\Route;
use Modules\Menu\Http\Controllers\Admin\MenuController;
use Modules\Menu\Http\Controllers\Admin\MenuItemController;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {        
        Route::controller(MenuController::class)
            ->prefix('menu')->name('menu.')->group(function () {
                Route::get('{position}/', 'index')->name('index');
                Route::get('{position}/create', 'create')->name('create');
                Route::post('store', 'store')->name('store');
                Route::get('{menu}/show', 'show')->name('show');
                Route::get('{menu}/edit', 'edit')->name('edit');
                Route::put('{menu}/update', 'update')->name('update');
                Route::put('{menu}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{menu}/destroy', 'destroy')->name('destroy');
            });

        Route::controller(MenuItemController::class)
            ->prefix('menu/{menu}/item')->name('menu_item.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('create', 'create')->name('create');
                Route::post('store', 'store')->name('store');
                Route::get('{menu_item}/show', 'show')->name('show');
                Route::get('{menu_item}/edit', 'edit')->name('edit');
                Route::put('{menu_item}/update', 'update')->name('update');
                Route::put('{menu_item}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{menu_item}/destroy', 'destroy')->name('destroy');
            });
    });
