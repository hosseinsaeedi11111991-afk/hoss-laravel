<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('menus', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->enum('position', ['header', 'footer', 'topbar', 'sidebar']);
            $table->string('icon', 255)->nullable();
            $table->string('style', 255)->nullable();
            $table->boolean('mega_menu')->default(false);
            $table->unsignedInteger('sort_order');
            $table->enum('status', ['active', 'inactive', 'deleted'])->default('active');
            $table->timestamps();

            $table->index(['position', 'sort_order', 'status']);
        });

        Schema::create('menu_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('menu_id')->constrained('menus')->onDelete('cascade');
            $table->foreignId('parent_id')->nullable()->constrained('menu_items')->onDelete('cascade');
            $table->string('title', 50);
            $table->string('link', 255);
            $table->boolean('new_tab')->default(false);
            $table->unsignedInteger('sort_order');
            $table->string('icon', 255)->nullable();
            $table->string('style', 255)->nullable();
            $table->enum('status', ['active', 'inactive', 'deleted'])->default('active');
            $table->timestamps();

            $table->index(['menu_id', 'parent_id', 'sort_order', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('menus');
        Schema::dropIfExists('menu_items');
    }
};
