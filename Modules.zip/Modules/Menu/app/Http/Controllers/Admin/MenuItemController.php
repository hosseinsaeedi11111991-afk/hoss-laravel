<?php

namespace Modules\Menu\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Menu\Http\Requests\MenuItemRequest;
use Modules\Menu\Models\Menu;
use Modules\Menu\Models\MenuItem;

class MenuItemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Menu $menu)
    {
        return view('menu::admin.menu_item.index', [
            'menu' => $menu,
            'items' => MenuItem::query()->where('menu_id', $menu->id)
                ->whereNot('status', MenuItem::STATUS_DELETED)
                ->orderBy('sort_order')->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Menu $menu)
    {
        return view('menu::admin.menu_item.create', [
            'menu' => $menu,
            'menu_item' => null,
            'items' => MenuItem::query()
                ->where('parent_id', MenuItem::ROOT_PAGE_ID)
                ->where('status', MenuItem::STATUS_ACTIVE)
                ->with('children')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(MenuItemRequest $request, Menu $menu) 
    {
        $data = $request->validated();

        MenuItem::query()->create($data);

        return redirect()->route('admin.menu_item.index', $menu)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    /**
     * Show the specified resource.
     */
    public function show(Menu $menu, MenuItem $menu_item)
    {
        return view('menu::admin.menu_item.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Menu $menu, MenuItem $menu_item)
    {
        return view('menu::admin.menu_item.edit', [
            'menu' => $menu,
            'menu_item' => $menu_item,
            'items' => MenuItem::query()
                ->where('parent_id', MenuItem::ROOT_PAGE_ID)
                ->where('status', MenuItem::STATUS_ACTIVE)
                ->with('children')->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(MenuItemRequest $request, Menu $menu, MenuItem $menu_item) 
    {
        $data = $request->validated();

        $menu_item->update($data);

        return redirect()->route('admin.menu_item.index', $menu)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    public function toggleStatus(Menu $menu, MenuItem $menu_item) 
    {
        if ($menu_item->status == MenuItem::STATUS_ACTIVE) {
            $menu_item->updateStatusRecursively(MenuItem::STATUS_INACTIVE);
        } else {
            $menu_item->update(['status' => MenuItem::STATUS_ACTIVE]);
        }
    
        return redirect()->route('admin.menu_item.index', $menu)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Menu $menu, MenuItem $menu_item) 
    {
        $menu_item->updateStatusRecursively(MenuItem::STATUS_DELETED);
    
        return redirect()->route('admin.menu_item.index', $menu)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }
}
