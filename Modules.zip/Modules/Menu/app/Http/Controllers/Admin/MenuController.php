<?php

namespace Modules\Menu\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Menu\Models\Menu;
use Modules\Menu\Http\Requests\MenuRequest;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index($position)
    {
        return view('menu::admin.menu.index', [
            'position' => $position,
            'menu' => Menu::query()
                ->where('position', $position)
                ->whereNot('status', Menu::STATUS_DELETED)
                ->latest()->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create($position)
    {
        return view('menu::admin.menu.create', [
            'menu' => null,
            'position' => $position,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(MenuRequest $request) 
    {
        $data = $request->validated();

        Menu::create($data);

        return redirect()->route('admin.menu.index', $data['position'])
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    /**
     * Show the specified resource.
     */
    public function show(Menu $menu)
    {
        return view('menu::admin.menu.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Menu $menu)
    {
        return view('menu::admin.menu.edit', [
            'menu' => $menu,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(MenuRequest $request, Menu $menu) 
    {
        $data = $request->validated();

        $menu->update($data);

        return redirect()->route('admin.menu.index', $menu->position)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    public function toggleStatus(Menu $menu)
    {
        if ($menu->status == Menu::STATUS_ACTIVE) {
            $menu->update(['status' => Menu::STATUS_INACTIVE]);
        } else {
            $menu->update(['status' => Menu::STATUS_ACTIVE]);
        }

        return redirect()->route('admin.menu.index', $menu->position)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Menu $menu) 
    {
        $menu->update(['status' => Menu::STATUS_DELETED]);

        return redirect()->route('admin.menu.index', $menu->position)
            ->with('اطلاعات با موفقیت ذخیره شدند');
    }
}
