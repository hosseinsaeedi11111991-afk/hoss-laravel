<?php

namespace Modules\Menu\Http\Requests;

use App\Traits\StringHelpers;
use Illuminate\Foundation\Http\FormRequest;

class MenuItemRequest extends FormRequest
{
    use StringHelpers;
    
    protected function prepareForValidation(): void
    {
        if ($this->has('sort_order')) {
            $this->merge([
                'sort_order' => $this->convertToEnglishDigits($this->input('sort_order')),
            ]);
        }
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $isUpdate = $this->isMethod('PUT') || $this->isMethod('PATCH');
        return [
            'menu_id'    => [$isUpdate ? 'nullable' : 'required', 'exists:menus,id'],
            'parent_id'  => ['nullable', 'exists:menu_items,id'],
            'title'      => ['required', 'string', 'max:50'],
            'link'       => ['required', 'string', 'max:255'],
            'new_tab'    => ['boolean'],
            'sort_order' => ['required', 'integer', 'min:0'],
            'icon'       => ['nullable', 'string', 'max:255'],
            'style'      => ['nullable', 'string', 'max:255'],
            'status'     => ['nullable', 'in:active,inactive,deleted'],
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages(): array
    {
        return [
            'menu_id.required'    => 'منو الزامی است.',
            'menu_id.exists'      => 'منوی انتخاب شده معتبر نیست.',
            'parent_id.exists'    => 'آیتم والد معتبر نیست.',
            'title.required'      => 'عنوان الزامی است.',
            'title.max'           => 'عنوان نباید بیشتر از 50 کاراکتر باشد.',
            'link.required'       => 'لینک الزامی است.',
            'sort_order.required' => 'ترتیب نمایش الزامی است.',
            'status.in'           => 'وضعیت انتخاب شده معتبر نیست.',
        ];
    }
}
