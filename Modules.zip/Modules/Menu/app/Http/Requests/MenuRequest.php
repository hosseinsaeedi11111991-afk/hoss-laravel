<?php

namespace Modules\Menu\Http\Requests;

use App\Traits\StringHelpers;
use Illuminate\Foundation\Http\FormRequest;
use Modules\Menu\Models\Menu;

class MenuRequest extends FormRequest
{
    use StringHelpers;

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $isUpdate = $this->isMethod('PUT') || $this->isMethod('PATCH');
        return [
            'name'       => ['required', 'string', 'max:50'],
            'position'   => [
                $isUpdate ? 'nullable' : 'required', 
                'string', 
                'in:header,footer,sidebar,topbar'
            ],
            'sort_order' => ['required', 'integer'],
            'icon'       => ['nullable', 'string', 'max:255'],
            'style'      => ['nullable', 'string', 'max:255'],
            'mega_menu'  => ['boolean'],
            'status'     => ['nullable', 'string', 'in:active,inactive,deleted'],
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages()
    {
        return [
            'name.required'       => 'فیلد نام الزامی است',
            'name.string'         => 'فیلد نام باید متن باشد',
            'name.max'            => 'فیلد نام نباید بیشتر از :max کاراکتر باشد',
            'sort_order.required' => 'ترتیب نمایش الزامی است',
            'sort_order.integer'  => 'ترتیب نمایش باید عدد صحیح باشد',
            'icon.string'         => 'آیکون باید متن باشد',
            'icon.max'            => 'آیکون نباید بیشتر از :max کاراکتر باشد',
            'style.string'        => 'استایل باید متن باشد',
            'style.max'           => 'استایل نباید بیشتر از :max کاراکتر باشد',
            'mega_menu.bool'      => 'مقدار منوی مگا باید بله یا خیر باشد',
            'status.string'       => 'وضعیت باید متن باشد',
            'status.in'           => 'وضعیت انتخابی معتبر نیست. مقادیر مجاز: active, inactive, deleted',
        ];
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('sort_order')) {
            $this->merge([
                'sort_order' => $this->convertToEnglishDigits($this->input('sort_order')),
            ]);
        }

        if ($this->has('mega_menu')) {
            $this->merge([
                'mega_menu' => (bool) $this->input('mega_menu'),
            ]);
        }

        if ($this->has('position') && $this->position != Menu::POSITION_HEADER && $this->mega_menu) {
            $this->merge([
                'mega_menu' => false,
            ]);
        }
    }
}
