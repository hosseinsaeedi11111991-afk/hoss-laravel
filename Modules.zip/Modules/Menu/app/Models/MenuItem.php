<?php

namespace Modules\Menu\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

// use Modules\Menu\Database\Factories\MenuItemFactory;

/**
 * @property mixed $id
 * @property mixed $menu_id
 * @property mixed $parent_id
 * @property mixed $title
 * @property mixed $link
 * @property mixed $new_tab
 * @property mixed $sort_order
 * @property mixed $icon
 * @property mixed $style
 * @property mixed $status
 * @property mixed $created_at
 * @property mixed $updated_at
 */
class MenuItem extends Model
{
    use HasFactory;

    const ROOT_PAGE_ID = null;

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DELETED = 'deleted';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'menu_id',
        'parent_id',
        'title',
        'link',
        'new_tab',
        'sort_order',
        'icon',
        'style',
        'status',
    ];

    public function menu() : BelongsTo {
        return $this->belongsTo(Menu::class);
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')
            ->where('status', self::STATUS_ACTIVE)
            ->with('children');
    }

    public function updateStatusRecursively($status)
    {
        if ($this->status != self::STATUS_DELETED) {
            $this->update(['status' => $status]);
        }
        $this->children()->get()->each(function ($child) use ($status) {
            $child->updateStatusRecursively($status);
        });
    }
}
