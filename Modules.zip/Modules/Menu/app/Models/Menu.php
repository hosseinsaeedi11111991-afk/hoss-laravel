<?php

namespace Modules\Menu\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property mixed $id
 * @property mixed $name
 * @property mixed $position
 * @property mixed $icon
 * @property mixed $style
 * @property mixed $mega_menu
 * @property mixed $sort_order
 * @property mixed $status
 * @property mixed $created_at
 * @property mixed $updated_at
 */
class Menu extends Model
{
    use HasFactory;

    const POSITION_HEADER = 'header';
    const POSITION_FOOTER = 'footer';
    const POSITION_TOPBAR = 'topbar';
    const POSITION_SIDEBAR = 'sidebar';

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DELETED = 'deleted';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'position',
        'icon',
        'style',
        'mega_menu',
        'sort_order',
        'status',
    ];

    public function items() : HasMany {
        return $this->hasMany(MenuItem::class);
    }
}
