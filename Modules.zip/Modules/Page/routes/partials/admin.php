<?php

use Illuminate\Support\Facades\Route;
use Modules\Page\Http\Controllers\Admin\PageController;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {
        Route::controller(PageController::class)
            ->prefix('page')->name('page.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('/create', 'create')->name('create');
                Route::post('/store', 'store')->name('store');
                Route::get('{page}/show', 'show')->name('show');
                Route::get('{page}/edit', 'edit')->name('edit');
                Route::put('{page}/update', 'update')->name('update');
                Route::put('{page}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{page}/destroy', 'destroy')->name('destroy');
            });
    });
