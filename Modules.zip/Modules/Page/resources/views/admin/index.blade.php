@php use Modules\Page\Models\Page; @endphp
@extends('Shared::layouts.admin.main')

@section('title', 'لیست صفحات')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span>لیست صفحات</span>
</h4>

<a href="{{route('admin.page.create')}}" type="button" class="btn rounded-pill me-2 btn-success">افزودن صفحه جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>صفحه والد</th>
                <th>نام صفحه</th>
                <th>عنوان صفحه</th>
                <th>آدرس url</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($pages as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>
                    @if ($row->parent)
                        {{$row->parent->name}}
                    @else
                        (هیچکدام)
                    @endif
                </td>
                <td>{{$row->name}}</td>
                <td>{{$row->title}}</td>
                <td>{{$row->getFullPath()}}</td>
                <td>
                    @php
                    switch ($row->status) {
                        case Page::STATUS_PUBLISHED:
                            echo '<span class="text-success">انتشار یافته</span>';
                            break;
                        case Page::STATUS_ACTIVE:
                            echo '<span class="text-success">فعال</span>';
                            break;
                        case Page::STATUS_INACTIVE:
                            echo '<span class="text-danger">غیر فعال</span>';
                            break;
                        case Page::STATUS_DELETED:
                            echo '<span class="text-danger">حذف شده</span>';
                            break;
                        default:
                            echo '<span class="text-mute">نامشخص</span>';
                            break;
                    }
                    @endphp
                </td>
                <td>{{ Verta::instance($row->updated_at)->format('Y/m/d') }}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.page.edit', $row->id) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.page.toggle_status', $row->id) }}"
                            class="d-inline">
                            @csrf
                            @method('PUT')
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="{{ route('admin.page.destroy', $row->id) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $pages->links('pagination::bootstrap-5') }}
</div>
@endsection