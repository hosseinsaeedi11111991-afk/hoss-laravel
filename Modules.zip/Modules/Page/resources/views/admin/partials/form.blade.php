<form method="POST" enctype="multipart/form-data"
    action="@if($page) {{ route('admin.page.update', ['page' => $page]) }}
      @else {{ route('admin.page.store') }} @endif">
    @csrf
    @if($page)
    @method('PUT')
    @endif

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            @include('admin.components.tree_view', [
                'content' => $pages,
                'selected' => old('parent_id'),
                'level' => 0,
                'name' => 'parent_id'
            ])
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="name">
                <span>نام صفحه</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control" placeholder="صفحه اصلی، درباره ما و ..."
                    value="{{ old('name', $page ? $page->name : '') }}">
            </div>
            @error('name')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="title">
                <span>عنوان صفحه</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="title" type="text" name="title" class="form-control" placeholder="عنوان صفحه"
                    value="{{ old('title', $page ? $page->title : '') }}">
            </div>
            @error('title')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>
    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="slug">
                <span>اسلاگ</span>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="slug" type="text" name="slug" class="form-control" placeholder="slug"
                    value="{{ old('slug', $page ? $page->slug : '') }}">
            </div>
            @error('slug')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4">ذخیره اطلاعات</button>
</form>