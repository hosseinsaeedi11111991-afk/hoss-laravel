@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش: {{ $page->name }}')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.page.index')}}">لیست صفحات/</a></span>
    <span>افزودن صفحه جدید</span>
</h4>

@include('page::admin.partials.form', [
    'page' => $page,
    'pages' => $pages,
])

@endsection