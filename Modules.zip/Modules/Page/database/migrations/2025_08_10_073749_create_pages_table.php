<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('parent_id')->nullable()->constrained('pages')->onDelete('cascade');
            $table->enum('type', ['static', 'dynamic', 'landing'])->default('static');
            $table->string('name')->unique();
            $table->string('title');
            $table->string('slug')->unique();
            $table->enum('status', ['published', 'active', 'inactive', 'deleted'])->default('published');
            $table->timestamps();

            $table->index(['parent_id', 'slug', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pages');
    }
};
