<?php

namespace Modules\Page\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

// use Modules\Page\Database\Factories\PageFactory;

/** @property mixed $id */
/** @property mixed $parent_id */
/** @property mixed $name */
/** @property mixed $title */
/** @property mixed $slug */
/** @property mixed $status */
/** @property mixed $created_at */
/** @property mixed $updated_at */
class Page extends Model
{
    use HasFactory;

    const ROOT_PAGE_ID = null;

    const STATUS_ACTIVE = 'active';
    const STATUS_DELETED = 'deleted';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_PUBLISHED = 'published';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'parent_id',
        'name',
        'title',
        'slug',
        'status',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Page::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')
            ->whereIn('status', [self::STATUS_PUBLISHED ,self::STATUS_ACTIVE])
            ->with('children');
    }

    public function getParents()
    {
        $parents = collect();
        $page = $this;
        while ($page->parent) {
            $parents->prepend($page->parent);
            $page = $page->parent;
        }
        return $parents;
    }

    public function getFullPath()
    {
        $segments = $this->getParents()->pluck('slug')->toArray();
        $segments[] = $this->slug;
        return '/' . implode('/', $segments);
    }

    /**
     * Resolve a path string to the slug and parent Page instance.
     * 
     * @param string $path The URL path like "/home/about/team"
     * @return array [$slug, $parentPage|null]
     */
    public static function resolvePath(string $path)
    {
        if (empty($path)) {
            return ['', null];
        }

        $segments = array_filter(explode('/', trim($path, '/')));
        if (empty($segments)) {
            return ['', null];
        }

        $slug = array_pop($segments);
        $prefixes = $segments;

        $pages = self::whereIn('slug', array_merge($prefixes, [$slug]))
            ->select('id', 'slug', 'parent_id')
            ->get()
            ->keyBy(function ($item) {
                return $item->slug . '_' . ($item->parent_id ?? 'null');
            });

        if ($pages->isEmpty()) {
            return [null, null];
        }

        $parent = null;
        foreach ($prefixes as $prefixSlug) {
            $key = $prefixSlug . '_' . ($parent ? $parent->id : 'null');
            if (!isset($pages[$key])) {
                return [null, null];
            }
            $parent = $pages[$key];
        }

        return [$slug, $parent];
    }
}
