<?php

namespace Modules\Page\Http\Requests;

use App\Traits\StringHelpers;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PageRequest extends FormRequest
{
    use StringHelpers;

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'parent_id' => [
                'nullable',
                'integer',
            ],
            'name' => [
                'required',
                'string',
                'max:150',
                Rule::unique('pages')->ignore($this->page),
            ],
            'title' => [
                'required',
                'string',
                'max:200',
                Rule::unique('pages')->ignore($this->page),
            ],
            'slug' => [
                'required',
                'string',
                'max:200',
                'alpha_dash',
                Rule::unique('pages')->ignore($this->page),
            ],
            'status' => 'nullable|string|in:published,active,inactive,deleted',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation()
    {
        if ($this->filled('name') && $this->isNotFilled('slug')) {
            $this->merge([
                'slug' => $this->slugify($this->name),
            ]);
        }
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'parent_id.integer' => 'شناسه والد صفحه باید عدد صحیح باشد.',

            'name_fa.required' => 'وارد کردن نام الزامی است.',
            'name_fa.string' => 'نام باید یک رشته متنی باشد.',
            'name_fa.max' => 'نام نباید بیشتر از ۱۵۰ کاراکتر باشد.',
            'name_fa.unique' => 'این نام قبلاً ثبت شده است.',

            'title.required' => 'وارد کردن عنوان الزامی است.',
            'title.string' => 'عنوان باید یک رشته متنی باشد.',
            'title.max' => 'عنوان نباید بیشتر از ۲۰۰ کاراکتر باشد.',
            'title.unique' => 'این عنوان قبلاً ثبت شده است.',

            'slug.required' => 'وارد کردن اسلاگ الزامی است.',
            'slug.string' => 'اسلاگ باید یک رشته متنی باشد.',
            'slug.max' => 'اسلاگ نباید بیشتر از ۲۰۰ کاراکتر باشد.',
            'slug.alpha_dash' => 'اسلاگ فقط می‌تواند شامل حروف، اعداد، خط تیره و آندرلاین باشد.',
            'slug.unique' => 'این اسلاگ قبلاً استفاده شده است.',

            'status.string' => 'وضعیت باید یک رشته متنی باشد.',
            'status.in' => 'وضعیت وارد شده معتبر نیست. (مجاز: active, inactive, published, deleted)',
        ];
    }
}
