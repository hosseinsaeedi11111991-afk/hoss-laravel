<?php

namespace Modules\Page\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Page\Http\Requests\PageRequest;
use Modules\Page\Models\Page;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('page::admin.index', [
            'pages' => Page::query()
                ->whereIn('status', [Page::STATUS_ACTIVE, Page::STATUS_PUBLISHED, Page::STATUS_INACTIVE])
                ->latest()->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $page = null;
        return view('page::admin.create', [
            'page' => $page,
            'pages' => Page::query()
                ->where('parent_id', Page::ROOT_PAGE_ID)
                ->whereIn('status', [Page::STATUS_PUBLISHED, Page::STATUS_ACTIVE])
                ->with('children')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PageRequest $request) 
    {
        $data = $request->validated();

        Page::query()->create($data);

        return redirect()->route('admin.page.index')
            ->with('success', 'اطلاعات با موفقیت ذخیره شد');
    }

    /**
     * Show the specified resource.
     */
    public function show(Page $page)
    {
        return view('page::show', [
            'page' => $page,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Page $page)
    {
        return view('page::admin.edit', [
            'page' => $page,
            'pages' => Page::query()
                ->where('parent_id', Page::ROOT_PAGE_ID)
                ->whereIn('status', [Page::STATUS_PUBLISHED, Page::STATUS_ACTIVE])
                ->with('children')->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(PageRequest $request, Page $page) 
    {
        $data = $request->validated();

        $page->update($data);

        return redirect()->route('admin.page.index')
            ->with('success', 'اطلاعات با موفقیت ذخیره شد');
    }

    public function toggleStatus(Page $page)
    {
        if ($page->status == Page::STATUS_PUBLISHED) {
            $page->update(['status' => Page::STATUS_ACTIVE]);
        } elseif ($page->status == Page::STATUS_ACTIVE) {
            $page->update(['status' => Page::STATUS_INACTIVE]);
        } else {
            $page->update(['status' => Page::STATUS_PUBLISHED]);
        }

        return redirect()->route('admin.page.index')->with('تغییرات با موفقیت اعمال شد');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Page $page) 
    {
        $page->update([
            'status' => Page::STATUS_DELETED
        ]);

        return redirect()->route('admin.page.index')
            ->with('صفحه با موفقیت حذف شد');
    }
}
