@extends('Shared::layouts.site.auth.layout')

@section('title', 'کد تایید را وارد کنید')

@section('main')
    <div class="container mt-5">
        <div class="row pt-5">
            <div class="col-lg-5 col-12 d-block mx-auto">
                <div class="card p-4">
                    <div class="card-header">
                        <div class="brand">
                            <img class="d-block mx-auto img-fluid" src="{{ asset('site/images/_logo.png') }}"
                                 alt="logo">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div>
                                <h3>کد تایید را وارد کنید</h3>
                                <div class="form-note">کد تایید برای شماره {{ $mobile }} پیامک شد</div>
                            </div>
                        </div>

                        <form method="POST" action="{{ route('auth.otp.verify.submit') }}">
                            @csrf

                            <input type="hidden" name="mobile" value="{{ $mobile }}">

                            <div class="mb-3">
                                <div class="input-group">
                                    <input id="code" class="form-control" name="code" type="text"
                                           placeholder="کد تایید" value="{{ old('code') }}"/>
                                </div>
                                @error('code') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                            </div>

                            <div class="d-grid mt-3">
                                <button type="submit" class="btn btn-outline w-100">تایید</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
