@extends('Shared::layouts.site.auth.layout')

@section('title', 'فراموشی رمز عبور')

@section('main')
    <div class="container mt-5">
        <div class="row pt-5">
            <div class="col-lg-5 col-12 d-block mx-auto">
                <div class="card p-4">
                    <div class="card-header">
                        <div class="brand">
                            <img class="d-block mx-auto img-fluid" src="{{ asset('site/images/_logo.png') }}"
                                 alt="logo">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div>
                                <h3>فراموشی رمز عبور</h3>
                                <div class="form-note">لطفا شماره موبایل خود را وارد کنید</div>
                            </div>
                        </div>

                        <form method="POST" action="{{ route('auth.forgot.pass.submit') }}">
                            @csrf
                            <div class="mb-3">
                                <div class="input-group">
                                    <input id="mobile" class="form-control" name="mobile" type="text"
                                           placeholder="شماره موبایل" value="{{ old('mobile') }}"/>
                                </div>
                                @error('mobile') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                            </div>

                            <div class="d-grid mt-3">
                                <button type="submit" class="btn btn-outline w-100">ارسال کد</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



