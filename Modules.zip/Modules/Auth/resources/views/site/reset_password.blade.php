@extends('Shared::layouts.site.auth.layout')

@section('title', 'ویرایش رمز عبور')

@section('main')
    <div class="container mt-5">
        <div class="row pt-5">
            <div class="col-lg-5 col-12 d-block mx-auto">
                <div class="card p-4">
                    <div class="card-header">
                        <div class="brand">
                            <img class="d-block mx-auto img-fluid" src="{{ asset('site/images/_logo.png') }}"
                                 alt="logo">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div>
                                <h3>ویرایش رمز عبور</h3>
                                <div class="form-note">لطفا رمز عبور جدید خود را وارد کنید</div>
                            </div>
                        </div>

                        <form method="POST" action="{{ route('auth.reset.pass.submit') }}">
                            @csrf
                            <input type="hidden" name="mobile" value="{{ $mobile }}">

                            <div class="row">
                                <div class="col-md-6 col-12">
                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input id="password" class="form-control" name="password" type="password"
                                                   placeholder="رمز عبور" value="{{ old('password') }}"/>
                                        </div>
                                        @error('password') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input id="password_confirmation" class="form-control" name="password_confirmation" type="password"
                                                   placeholder="تکرار رمز عبور"/>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid mt-3">
                                <button type="submit" class="btn btn-outline w-100">ورود</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



