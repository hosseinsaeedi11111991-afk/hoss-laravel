@extends('Shared::layouts.site.auth.layout')

@section('title', 'ثبت نام')

@section('main')
    <div class="auth-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                    <div class="card auth-card">
                        <div class="card-header">
                            <div class="brand">
                                <img class="d-block mx-auto img-fluid" src="{{ asset('site/images/_logo.png') }}"
                                     alt="logo">
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h3>ثبت نام</h3>
                                <div class="form-note">لطفا اطلاعات زیر را وارد کنید</div>
                            </div>

                            <form method="POST" action="{{ route('auth.register.submit') }}">
                                @csrf

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="first_name" class="form-control" name="first_name" type="text"
                                                       placeholder="نام" value="{{ old('first_name') }}"/>
                                            </div>
                                            @error('first_name') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="last_name" class="form-control" name="last_name" type="text"
                                                       placeholder="نام خانوادگی" value="{{ old('last_name') }}"/>
                                            </div>
                                            @error('last_name') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="national_code" class="form-control" name="national_code" type="text"
                                                       placeholder="کد ملی" value="{{ old('national_code') }}"/>
                                            </div>
                                            @error('national_code') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="email" class="form-control" name="email" type="email"
                                                       placeholder="ایمیل" value="{{ old('email') }}"/>
                                            </div>
                                            @error('email') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="password" class="form-control" name="password" type="password"
                                                       placeholder="رمز عبور" value="{{ old('password') }}"/>
                                            </div>
                                            @error('password') <small class="text-danger text-sm">{{ $message }}</small> @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="mb-3">
                                            <div class="input-group">
                                                <input id="password_confirmation" class="form-control" name="password_confirmation" type="password"
                                                       placeholder="تکرار رمز عبور"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-outline w-100">ثبت نام</button>
                                </div>
                            </form>

                            <hr/>
                            <div class="auth-link">
                                <span>قبلا ثبت نام کرده‌اید؟ </span>
                                <a href="{{ route('auth.login.form') }}">وارد شوید</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



