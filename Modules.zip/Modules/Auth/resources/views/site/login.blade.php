@extends('Shared::layouts.site.auth.layout')

@section('title', 'ورود با شماره موبایل')

@section('main')
    <div class="auth-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-7 col-12 mx-auto">
                    <div class="card auth-card">
                        <div class="card-header">
                            <div class="brand">
                                <img class="d-block mx-auto img-fluid" src="{{ asset('site/images/_logo.png') }}"
                                     alt="logo">
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h3>ورود به حساب</h3>
                                <div class="form-note">لطفا شماره موبایل خود را وارد کنید</div>
                            </div>

                            <form method="POST" action="{{ route('auth.login.submit') }}">
                                @csrf
                                <div class="mb-3">
                                    <div class="input-group">
                                        <input id="mobile" class="form-control" name="mobile" type="text"
                                               placeholder="شماره موبایل" value="{{ old('mobile') }}"/>
                                    </div>
                                    @error('mobile') <small class="text-danger text-sm">{{ $message }}</small> @enderror

                                    <div class="mt-3 text-primary">
                                        <a href="{{ route('auth.pass.login.form') }}">
                                            <i class="fa fa-key"></i>
                                            <span>ورود با رمز</span>
                                        </a>
                                    </div>
                                </div>

                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-outline w-100">ارسال کد</button>
                                </div>
                            </form>

                            <hr/>
                            <p class="small text-center text-muted mb-0">
                                <span>با ورود شما </span>
                                <a href="{{ route('home') }}">قوانین و حریم خصوصی</a>
                                <span>را پذیرفته‌ اید</span>
                            </p>

                            <div class="auth-link">
                                <span>حساب کاربری ندارید؟ </span>
                                <a href="{{ route('auth.register.form') }}">ثبت نام کنید</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



