<?php

use Illuminate\Support\Facades\Route;
use Modules\Auth\Http\Controllers\Site\AuthController as SiteAuthController;


Route::middleware(['web'])->group(function () {
    Route::prefix('auth')
        ->middleware('guest')
        ->controller(SiteAuthController::class)
        ->group(function () {
            Route::get('/login', 'loginForm')->name('auth.login.form');
            Route::post('/login', 'login')->name('auth.login.submit');
            Route::get('/login/password', 'loginByPassForm')->name('auth.pass.login.form');
            Route::post('/login/password', 'loginByPass')->name('auth.pass.login.submit');

            Route::get('/password/forgot', 'forgotPasswordForm')->name('auth.forgot.pass.form');
            Route::post('/password/forgot', 'forgotPassword')->name('auth.forgot.pass.submit');

            Route::get('/otp/verify', 'verifyOtpForm')->name('auth.otp.verify.form');
            Route::post('/otp/verify', 'verifyOtp')->name('auth.otp.verify.submit');
            Route::post('/otp/resend', 'resendOtp')->name('auth.otp.resend');
        });

    Route::prefix('auth')
        ->middleware('auth')
        ->controller(SiteAuthController::class)
        ->group(function () {
            Route::get('/register', 'registerForm')->name('auth.register.form');
            Route::post('/register', 'register')->name('auth.register.submit');

            Route::get('/password/reset', 'resetPasswordForm')->name('auth.reset.pass.form');
            Route::post('/password/reset', 'resetPassword')->name('auth.reset.pass.submit');

            // change method from GET to POST in production mode
            Route::get('/logout', 'logout')->name('auth.logout');
        });
});
