<?php

use Illuminate\Support\Facades\Route;
use Modules\Auth\Http\Controllers\Admin\AuthController as AdminAuthController;


Route::middleware(['web'])->prefix('admin-panel')->name('admin.')->group(function () {
    Route::prefix('auth')
        ->middleware('guest')
        ->controller(AdminAuthController::class)
        ->group(function () {
            Route::get('/login/password', 'loginByPassForm')->name('auth.pass.login.form');
            Route::post('/login/password', 'loginByPass')->name('auth.pass.login.submit');
        });

    Route::prefix('auth')
        ->middleware('auth')
        ->controller(AdminAuthController::class)
        ->group(function () {
            // change method from GET to POST in production mode
            Route::get('/logout', 'logout')->name('auth.logout');
        });
});