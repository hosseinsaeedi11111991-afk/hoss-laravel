<?php

require_once 'partials/admin.php';
require_once 'partials/site.php';
