<?php

namespace Modules\Auth\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Modules\Auth\Http\Requests\AuthRequest;
use Modules\User\Models\User;

class AuthController extends Controller
{
    /**
     * Show the login form where user can login with username and password.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function loginByPassForm()
    {
        return view('auth::admin.login_password');
    }

    /**
     * Handle login with username and password.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function loginByPass(AuthRequest $request)
    {
        $data = $request->validated();
        $user = User::where('username', $data['username'])->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            return back()->withErrors([
                'username' => 'نام کاربری یا رمز عبور اشتباه است'
            ])->withInput();
        }

        auth()->login($user);

        return redirect()->route('admin.reservations.index')->with('success', 'ورود موفقیت‌آمیز بود');
    }

    public function logout()
    {
        auth()->logout();
        return redirect()->route('admin.auth.pass.login.form')->with('success', 'با موفقیت خارج شدید');
    }
}
