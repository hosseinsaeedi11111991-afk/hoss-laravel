<?php

namespace Modules\Auth\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Modules\Auth\Http\Requests\AuthRequest;
use Modules\Notification\Models\Otp;
use Modules\Notification\Services\OtpService;
use Modules\User\Models\User;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    /**
     * Show the login form where the user can enter their mobile number.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function loginForm()
    {
        return view('auth::site.login');
    }

    /**
     * Handle the login request by validating the mobile number and sending an OTP.
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function login(AuthRequest $request)
    {
        $data = $request->validated();

        app(OtpService::class)->send(
            receiver: $data['mobile'],
            channel: 'sms',
            purpose: Otp::PURPOSE_AUTHENTICATE
        );

        session()->put('mobile', $data['mobile']);

        return redirect()->route('auth.otp.verify.form');
    }

    /**
     * Show the login form for mobile + password authentication.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function loginByPassForm()
    {
        return view('auth::site.login_password');
    }

    /**
     * Handle login with mobile number and password.
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function loginByPass(AuthRequest $request)
    {
        $data = $request->validated();
        $user = User::where('mobile', $data['mobile'])->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            return back()->withErrors([
                'mobile' => 'شماره موبایل یا رمز عبور اشتباه است.'
            ])->withInput();
        }

        auth()->login($user);

        return redirect()->route('categories.index')->with('success', 'ورود موفقیت‌آمیز بود.');
    }

    /**
     * Show the registration form.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function registerForm()
    {
        return view('auth::site.register');
    }

    /**
     * Handle user registration by updating the authenticated user's profile.
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function register(AuthRequest $request)
    {
        $user = auth()->user();
        $data = $request->validated();

        $user->update([
            'national_code' => $data['national_code'],
            'first_name'    => $data['first_name'],
            'last_name'     => $data['last_name'],
            'email'         => $data['email'],
            'password'      => bcrypt($data['password']),
        ]);

        return redirect()->route('home')->with('success', 'ثبت نام شما با موفقیت انجام شد');
    }

    /**
     * Show the form to request a password reset.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function forgotPasswordForm()
    {
        return view('auth::site.forgot_password');
    }

    /**
     * Handle the password reset request by sending an OTP to the user's mobile.
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forgotPassword(AuthRequest $request)
    {
        $data = $request->validated();
        $user = User::where('mobile', $data['mobile'])->first();

        if (!$user) {
            return back()->withErrors([
                'mobile' => 'شماره موبایل یافت نشد.'
            ])->withInput();
        }

        app(OtpService::class)->send(
            receiver: $data['mobile'],
            channel: 'sms',
            purpose: Otp::PURPOSE_RESET_PASS
        );

        session(['mobile' => $data['mobile']]);

        return redirect()->route('auth.otp.verify.form')
            ->with('success', 'کد بازیابی رمز عبور برای شما ارسال شد.');
    }

    /**
     * Show the form to reset the password.
     *
     * @return \Illuminate\Contracts\View\View|\Illuminate\Http\RedirectResponse
     */
    public function resetPasswordForm()
    {
        $mobile = session('mobile');
        if (!$mobile) {
            return redirect()->route('auth.forgot.pass.form');
        }

        return view('auth::site.reset_password', [
            'mobile' => $mobile,
        ]);
    }

    /**
     * Handle resetting the user's password.
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function resetPassword(AuthRequest $request)
    {
        $data = $request->validated();
        $mobile = $data['mobile'] ?? session('mobile');

        if (!$mobile) {
            return redirect()->route('auth.forgot.pass.form')
                ->withErrors(['mobile' => 'شماره موبایل نامعتبر است']);
        }

        $user = User::where('mobile', $mobile)->first();

        if (!$user) {
            return redirect()->route('auth.forgot.pass.form')
                ->withErrors(['mobile' => 'کاربری با این شماره یافت نشد']);
        }

        $user->password = Hash::make($data['password']);
        $user->save();

        session()->forget('mobile');

        return redirect()->route('home')->with('success', 'رمز عبور با موفقیت تغییر کرد.');
    }

    /**
     * Display the OTP verification form.
     *
     * Checks if a mobile number exists in the session.
     * - If not found, redirects to login form.
     * - If found, shows the OTP verification view.
     *
     * @return \Illuminate\Contracts\View\View|\Illuminate\Http\RedirectResponse
     */
    public function verifyOtpForm()
    {
        $mobile = session('mobile');
        if (!$mobile) {
            return redirect()->route('auth.login.form');
        }

        return view('auth::site.verify_otp', [
            'mobile' => $mobile,
        ]);
    }

    /**
     * Verify the OTP entered by the user and handle authentication flow.
     *
     * Depending on OTP purpose, user will be redirected to:
     * - Home page (login)
     * - Registration form (signup)
     * - Reset password form (password recovery)
     *
     * @param  \Modules\Auth\Http\Requests\AuthRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function verifyOtp(AuthRequest $request)
    {
        $data = $request->validated();

        $isValid = app(OtpService::class)->verify(
            $data['mobile'],
            $data['code'],
        );

        if (!$isValid) {
            return back()->withErrors(['code' => 'کد تایید اشتباه است'])->withInput();
        }

        $authMode = 'login';
        $user = User::query()->where('mobile', $data['mobile'])->first();
        if (!$user) {
            $authMode = 'signup';
            $user = User::create([
                'uuid'     => (string) Str::uuid(),
                'username' => $data['mobile'],
                'mobile'   => $data['mobile'],
            ]);
            $user->assignRole('user');
        }

        auth()->login($user);

        $otp = Otp::query()->where([
            'receiver' => $data['mobile'],
            'code'     => $data['code'],
            'used'     => true,
        ])->latest()->first();

        if ($otp) {
            switch ($otp->purpose) {
                case Otp::PURPOSE_AUTHENTICATE:
                    session()->forget(['mobile']);
                    return $authMode === 'login'
                        ? redirect()->route('home')
                        : redirect()->route('auth.register.form');

                case Otp::PURPOSE_RESET_PASS:
                    return redirect()->route('auth.reset.pass.form');

                default:
                    return redirect()->route('home');
            }
        }

        return redirect()->route('auth.login.form')
            ->withErrors(['code' => 'کد تایید معتبر یافت نشد.']);
    }

    /**
     * Logout the currently authenticated user and redirect to home page.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout()
    {
        auth()->logout();
        return redirect()->route('home');
    }
}
