<?php

namespace Modules\Auth\Http\Requests;

use App\Traits\StringHelpers;
use Illuminate\Foundation\Http\FormRequest;

class AuthRequest extends FormRequest
{
    use StringHelpers;

    /**
     * Common validation rules for the mobile field.
     *
     * @return array<string>
     */
    protected function mobileRules(): array
    {
        return ['required', 'regex:/^09\d{9}$/'];
    }

    /**
     * Common validation rules for the password field.
     *
     * @param bool $confirmed
     * @return array<string>
     */
    protected function passwordRules(bool $confirmed = false): array
    {
        $rules = ['required', 'string', 'min:8'];
        if ($confirmed) {
            $rules[] = 'confirmed';
        }
        return $rules;
    }

    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules for admin password login. Captcha is only required when
     * GD or Imagick extension is loaded (needed for captcha image generation).
     */
    protected function adminPassLoginRules(): array
    {
        $rules = [
            'username' => ['required', 'string', 'max:50'],
            'password' => ['required', 'string'],
        ];
        if ((extension_loaded('gd') || extension_loaded('imagick')) && !config('captcha.disable', false)) {
            $rules['captcha'] = ['required', 'captcha'];
        }
        return $rules;
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('mobile')) {
            $this->merge([
                'mobile' => $this->convertToEnglishDigits($this->input('mobile')),
            ]);
        }

        if ($this->has('national_code')) {
            $this->merge([
                'national_code' => $this->convertToEnglishDigits($this->input('national_code')),
            ]);
        }

        if ($this->has('code')) {
            $this->merge([
                'code' => $this->convertToEnglishDigits($this->input('code')),
            ]);
        }

        if ($this->has('captcha')) {
            $this->merge([
                'captcha' => $this->convertToEnglishDigits($this->input('captcha')),
            ]);
        }
    }

    public function rules(): array
    {
        $routeName = $this->route()->getName();

        return match ($routeName) {
            'auth.login.submit', 'auth.forgot.pass.submit' => [
                'mobile' => $this->mobileRules(),
            ],
            'auth.otp.verify.submit' => [
                'mobile' => $this->mobileRules(),
                'code'   => ['required', 'digits:5'],
            ],
            'auth.register.submit' => [
                'first_name'    => ['required', 'string', 'max:50'],
                'last_name'     => ['required', 'string', 'max:50'],
                'national_code' => ['required', 'digits:10', 'unique:users,national_code'],
                'email'         => ['nullable', 'email', 'unique:users,email'],
                'password'      => $this->passwordRules(true),
            ],
            'auth.pass.login.submit' => [
                'mobile'   => $this->mobileRules(),
                'password' => ['required', 'string'],
            ],
            'auth.reset.pass.submit' => [
                'mobile'   => $this->mobileRules(),
                'password' => $this->passwordRules(true),
            ],
            'admin.auth.pass.login.submit' => $this->adminPassLoginRules(),
            default => [],
        };
    }

    public function messages(): array
    {
        return [
            'username.required'      => 'لطفا نام کاربری خود را وارد کنید',
            'code.required'      => 'لطفا کد ارسالی به موبایل را وارد کنید',
            'mobile.required'        => 'لطفا شماره موبایل خود را وارد کنید',
            'mobile.regex'           => 'شماره موبایل وارد شده صحیح نیست',
            'first_name.required'    => 'لطفا نام خود را وارد کنید',
            'last_name.required'     => 'لطفا نام خانوادگی خود را وارد کنید',
            'national_code.required' => 'لطفا کد ملی خود را وارد کنید',
            'national_code.digits'   => 'کد ملی وارد شده اشتباه است',
            'national_code.unique'   => 'کد ملی قبلا ثبت شده است',
            'email.email'            => 'ایمیل وارد شده صحیح نیست',
            'email.unique'           => 'ایمیل قبلا ثبت شده است',
            'password.required'      => 'لطفا رمز عبور خود را وارد کنید',
            'password.min'      => 'رمز باید حداقل شامل ۸ کارکتر باشد',
            'password.confirmed'     => 'رمزهای وارد شده با یکدیگر تطابق ندارند',
            'captcha.required'       => 'لطفا کد امنیتی را وارد کنید',
            'captcha.captcha'        => 'کد امنیتی وارد شده اشتباه است',
        ];
    }
}
