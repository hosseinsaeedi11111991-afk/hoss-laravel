<?php

namespace Modules\Pricing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Cars\Models\CarCategory;
use Modules\Pricing\Models\Province;

class PricingRule extends Model
{
    use HasFactory;

    const PRIORITY_HIGH = 'high';
    const PRIORITY_MEDIUM = 'medium';
    const PRIORITY_LOW = 'low';

    const PRICING_TYPE_FIXED = 'fixed';
    const PRICING_TYPE_PER_KM = 'per_km';

    protected $fillable = [
        'origin_city',
        'destination_city',
        'car_category_id',
        'province_id',
        'fixed_price',
        'per_km_price',
        'pricing_type',
        'priority',
        'is_active',
    ];

    protected $casts = [
        'fixed_price' => 'decimal:2',
        'per_km_price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    /* Relations */
    public function carCategory()
    {
        return $this->belongsTo(CarCategory::class, 'car_category_id');
    }

    public function province()
    {
        return $this->belongsTo(Province::class, 'province_id');
    }

    /* Scopes */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByPriority($query, $priority)
    {
        return $query->where('priority', $priority);
    }

    public function scopeByProvince($query, $provinceId)
    {
        return $query->where('province_id', $provinceId);
    }

    public function scopeSearchOriginCity($query, $search)
    {
        return $query->where('origin_city', 'like', "%{$search}%");
    }

    public function scopeSearchDestinationCity($query, $search)
    {
        return $query->where('destination_city', 'like', "%{$search}%");
    }

    public function scopeByCarCategory($query, $categoryId)
    {
        return $query->where('car_category_id', $categoryId);
    }

    public function scopeByPricingType($query, $type)
    {
        return $query->where('pricing_type', $type);
    }

    public function scopeByFixedPriceRange($query, $min = null, $max = null)
    {
        if ($min !== null) {
            $query->where('fixed_price', '>=', $min);
        }
        if ($max !== null) {
            $query->where('fixed_price', '<=', $max);
        }
        return $query;
    }

    public function scopeByPerKmPriceRange($query, $min = null, $max = null)
    {
        if ($min !== null) {
            $query->where('per_km_price', '>=', $min);
        }
        if ($max !== null) {
            $query->where('per_km_price', '<=', $max);
        }
        return $query;
    }

    /* Helper methods */
    public function isHighPriority()
    {
        return $this->priority === self::PRIORITY_HIGH;
    }

    public function isMediumPriority()
    {
        return $this->priority === self::PRIORITY_MEDIUM;
    }

    public function isLowPriority()
    {
        return $this->priority === self::PRIORITY_LOW;
    }

    public function isFixedPricing()
    {
        return $this->pricing_type === self::PRICING_TYPE_FIXED;
    }

    public function isPerKmPricing()
    {
        return $this->pricing_type === self::PRICING_TYPE_PER_KM;
    }

    public function getPriorityLabel()
    {
        return match($this->priority) {
            self::PRIORITY_HIGH => 'بالا',
            self::PRIORITY_MEDIUM => 'متوسط',
            self::PRIORITY_LOW => 'پایین',
            default => 'نامشخص'
        };
    }

    public function getPricingTypeLabel()
    {
        return $this->isFixedPricing() ? 'قیمت ثابت' : 'قیمت به ازای کیلومتر';
    }
}
