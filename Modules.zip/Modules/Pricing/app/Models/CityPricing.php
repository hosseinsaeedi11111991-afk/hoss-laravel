<?php

namespace Modules\Pricing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Cars\Models\CarCategory;

class CityPricing extends Model
{
    use HasFactory;

    protected $fillable = [
        'city_name',
        'car_category_id',
        'per_km_price',
        'is_active',
    ];

    protected $casts = [
        'per_km_price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    /* Relations */
    public function carCategory()
    {
        return $this->belongsTo(CarCategory::class, 'car_category_id');
    }

    /* Scopes */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByCity($query, $cityName)
    {
        return $query->where('city_name', $cityName);
    }

    /* Helper methods */
    public function isActive()
    {
        return $this->is_active;
    }

    public function getFormattedPrice()
    {
        return number_format($this->per_km_price) . ' تومان';
    }

    public function calculatePrice($distanceKm)
    {
        return $this->per_km_price * $distanceKm;
    }
}
