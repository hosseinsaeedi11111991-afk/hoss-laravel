<?php

namespace Modules\Pricing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\User\Models\User;

class Province extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'province_cities';

    protected $fillable = [
        'user_id',
        'parent',
        'title',
        'sort',
    ];

    protected $casts = [
        'parent' => 'integer',
        'sort' => 'integer',
    ];

    /**
     * The "booted" method of the model.
     */
    protected static function booted(): void
    {
        static::addGlobalScope('provinces', function ($query) {
            $query->where('parent', 0);
        });
    }

    /* Relations */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function cities()
    {
        return $this->hasMany(City::class, 'parent', 'id');
    }

    /* Scopes */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort');
    }

    /* Helper methods */
    public function isProvince(): bool
    {
        return $this->parent === 0;
    }

    public function getCitiesCount()
    {
        return $this->cities()->count();
    }

    /**
     * Get all provinces without global scope
     */
    public static function allProvinces()
    {
        return static::withoutGlobalScope('provinces')->where('parent', 0);
    }
}
