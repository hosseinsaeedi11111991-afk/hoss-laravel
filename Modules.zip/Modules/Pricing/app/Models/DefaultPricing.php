<?php

namespace Modules\Pricing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class DefaultPricing extends Model
{
    use HasFactory;

    protected $fillable = [
        'per_km_price',
        'is_active',
    ];

    protected $casts = [
        'per_km_price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    /* Scopes */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /* Helper methods */
    public function isActive()
    {
        return $this->is_active;
    }

    public function getFormattedPrice()
    {
        return number_format($this->per_km_price) . ' تومان';
    }

    public function calculatePrice($distanceKm)
    {
        return $this->per_km_price * $distanceKm;
    }

    /* Static methods */
    public static function getActiveDefault()
    {
        return self::active()->first();
    }
}
