<?php

namespace Modules\Pricing\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Pricing\Models\CityPricing;
use Modules\Pricing\Http\Requests\Admin\StoreCityPricingRequest;
use Modules\Pricing\Http\Requests\Admin\UpdateCityPricingRequest;
use Modules\Cars\Models\CarCategory;

class CityPricingController extends Controller
{
    public function index()
    {
        $cityPricings = CityPricing::with('carCategory')->latest()->paginate(15);
        return view('pricing::admin.city_pricings.index', compact('cityPricings'));
    }

    public function create()
    {
        $carCategories = CarCategory::all();
        return view('pricing::admin.city_pricings.create', compact('carCategories'));
    }

    public function store(StoreCityPricingRequest $request)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');

        CityPricing::create($data);
        return redirect()->route('admin.city_pricings.index')
            ->with('success', 'قیمت‌گذاری شهری با موفقیت ثبت شد.');
    }

    public function show(CityPricing $cityPricing)
    {
        $cityPricing->load('carCategory');
        return view('pricing::admin.city_pricings.show', compact('cityPricing'));
    }

    public function edit(CityPricing $cityPricing)
    {
        $carCategories = CarCategory::all();
        return view('pricing::admin.city_pricings.edit', compact('cityPricing', 'carCategories'));
    }

    public function update(UpdateCityPricingRequest $request, CityPricing $cityPricing)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');

        $cityPricing->update($data);
        return redirect()->route('admin.city_pricings.index')
            ->with('success', 'قیمت‌گذاری شهری به‌روزرسانی شد.');
    }

    public function destroy(CityPricing $cityPricing)
    {
        $cityPricing->delete();
        return redirect()->route('admin.city_pricings.index')
            ->with('success', 'قیمت‌گذاری شهری حذف شد.');
    }
}
