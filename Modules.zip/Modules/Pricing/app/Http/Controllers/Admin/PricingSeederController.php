<?php

namespace Modules\Pricing\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Pricing\Database\Seeders\PricingRuleSeeder;
use Illuminate\Support\Facades\Artisan;

class PricingSeederController extends Controller
{
    /**
     * اجرای Seeder برای قوانین قیمت‌گذاری
     */
    public function runSeeder()
    {
        try {
            $seeder = new PricingRuleSeeder();
            $seeder->run();

            return redirect()->back()
                ->with('success', 'Seeder با موفقیت اجرا شد و قوانین قیمت‌گذاری ایجاد شدند.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'خطا در اجرای Seeder: ' . $e->getMessage());
        }
    }
}
