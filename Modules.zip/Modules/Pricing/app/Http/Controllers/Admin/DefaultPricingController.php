<?php

namespace Modules\Pricing\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Pricing\Models\DefaultPricing;
use Modules\Pricing\Http\Requests\Admin\StoreDefaultPricingRequest;
use Modules\Pricing\Http\Requests\Admin\UpdateDefaultPricingRequest;

class DefaultPricingController extends Controller
{
    public function index()
    {
        $defaultPricings = DefaultPricing::latest()->paginate(15);
        return view('pricing::admin.default_pricings.index', compact('defaultPricings'));
    }

    public function create()
    {
        return view('pricing::admin.default_pricings.create');
    }

    public function store(StoreDefaultPricingRequest $request)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');
        
        DefaultPricing::create($data);
        return redirect()->route('admin.default_pricings.index')
            ->with('success', 'قیمت‌گذاری پیش‌فرض با موفقیت ثبت شد.');
    }

    public function show(DefaultPricing $defaultPricing)
    {
        return view('pricing::admin.default_pricings.show', compact('defaultPricing'));
    }

    public function edit(DefaultPricing $defaultPricing)
    {
        return view('pricing::admin.default_pricings.edit', compact('defaultPricing'));
    }

    public function update(UpdateDefaultPricingRequest $request, DefaultPricing $defaultPricing)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');
        
        $defaultPricing->update($data);
        return redirect()->route('admin.default_pricings.index')
            ->with('success', 'قیمت‌گذاری پیش‌فرض به‌روزرسانی شد.');
    }

    public function destroy(DefaultPricing $defaultPricing)
    {
        $defaultPricing->delete();
        return redirect()->route('admin.default_pricings.index')
            ->with('success', 'قیمت‌گذاری پیش‌فرض حذف شد.');
    }
}
