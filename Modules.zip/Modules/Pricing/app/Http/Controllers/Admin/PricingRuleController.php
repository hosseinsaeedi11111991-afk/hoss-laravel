<?php

namespace Modules\Pricing\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Pricing\Models\PricingRule;
use Modules\Pricing\Models\Province;
use Modules\Pricing\Models\City;
use Modules\Pricing\Http\Requests\Admin\StorePricingRuleRequest;
use Modules\Pricing\Http\Requests\Admin\UpdatePricingRuleRequest;
use Modules\Pricing\Http\Requests\Admin\BulkStorePricingRuleRequest;
use Modules\Pricing\Http\Requests\Admin\BulkUpdatePricingRuleRequest;
use Modules\Cars\Models\CarCategory;

class PricingRuleController extends Controller
{
    public function index(Request $request)
    {
        $query = PricingRule::with(['carCategory', 'province']);

        // جستجو بر اساس شهر مبدا
        if ($request->filled('origin_city')) {
            $query->searchOriginCity($request->origin_city);
        }

        // جستجو بر اساس شهر مقصد
        if ($request->filled('destination_city')) {
            $query->searchDestinationCity($request->destination_city);
        }

        // فیلتر بر اساس استان
        if ($request->filled('province_id')) {
            $query->byProvince($request->province_id);
        }

        // فیلتر بر اساس دسته‌بندی ماشین
        if ($request->filled('car_category_id')) {
            $query->byCarCategory($request->car_category_id);
        }

        // فیلتر بر اساس نحوه محاسبه
        if ($request->filled('pricing_type')) {
            $query->byPricingType($request->pricing_type);
        }

        // فیلتر بر اساس اولویت
        if ($request->filled('priority')) {
            $query->byPriority($request->priority);
        }

        // فیلتر بر اساس وضعیت
        if ($request->has('is_active') && $request->is_active !== '') {
            if ($request->is_active == '1') {
                $query->active();
            } elseif ($request->is_active == '0') {
                $query->where('is_active', false);
            }
        }

        // فیلتر بر اساس محدوده قیمت ثابت
        if ($request->filled('fixed_price_min') || $request->filled('fixed_price_max')) {
            $query->byFixedPriceRange(
                $request->filled('fixed_price_min') ? $request->fixed_price_min : null,
                $request->filled('fixed_price_max') ? $request->fixed_price_max : null
            );
        }

        // فیلتر بر اساس محدوده قیمت هر کیلومتر
        if ($request->filled('per_km_price_min') || $request->filled('per_km_price_max')) {
            $query->byPerKmPriceRange(
                $request->filled('per_km_price_min') ? $request->per_km_price_min : null,
                $request->filled('per_km_price_max') ? $request->per_km_price_max : null
            );
        }

        $pricingRules = $query->latest()->paginate(15)->withQueryString();

        // داده‌های مورد نیاز برای فرم جستجو
        $carCategories = CarCategory::all();
        $provinces = Province::ordered()->get();

        return view('pricing::admin.pricing_rules.index', compact('pricingRules', 'carCategories', 'provinces'));
    }

    public function create()
    {
        $carCategories = CarCategory::all();
        return view('pricing::admin.pricing_rules.create', compact('carCategories'));
    }

    public function store(StorePricingRuleRequest $request)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');

        PricingRule::create($data);
        return redirect()->route('admin.pricing_rules.index')
            ->with('success', 'قانون قیمت‌گذاری با موفقیت ثبت شد.');
    }

    public function show(PricingRule $pricingRule)
    {
        $pricingRule->load('carCategory');
        return view('pricing::admin.pricing_rules.show', compact('pricingRule'));
    }

    public function edit(PricingRule $pricingRule)
    {
        $carCategories = CarCategory::all();
        return view('pricing::admin.pricing_rules.edit', compact('pricingRule', 'carCategories'));
    }

    public function update(UpdatePricingRuleRequest $request, PricingRule $pricingRule)
    {
        $data = $request->validated();
        $data['is_active'] = $request->has('is_active');

        $pricingRule->update($data);
        return redirect()->route('admin.pricing_rules.index')
            ->with('success', 'قانون قیمت‌گذاری به‌روزرسانی شد.');
    }

    public function destroy(PricingRule $pricingRule)
    {
        $pricingRule->delete();
        return redirect()->route('admin.pricing_rules.index')
            ->with('success', 'قانون قیمت‌گذاری حذف شد.');
    }

    public function bulkCreate()
    {
        $carCategories = CarCategory::all();
        $provinces = Province::ordered()->get();
        return view('pricing::admin.pricing_rules.bulk_create', compact('carCategories', 'provinces'));
    }

    public function getCities($provinceId)
    {
        $cities = City::byProvince($provinceId)->ordered()->get(['id', 'title']);
        return response()->json($cities);
    }

    public function bulkStore(BulkStorePricingRuleRequest $request)
    {
        $data = $request->validated();
        $originCityNamesText = $data['origin_city_names'];
        $destinationCityIds = $data['destination_city_ids'];
        $isActive = $request->has('is_active');
        $createReverse = $request->has('create_reverse');

        // تبدیل متن شهرهای مبدا به آرایه (با کاما یا خط جدید جدا می‌شوند)
        $originCityNames = array_filter(
            array_map('trim',
                preg_split('/[،,\n\r]+/u', $originCityNamesText)
            )
        );

        if (empty($originCityNames)) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['origin_city_names' => 'لطفا حداقل یک شهر مبدا وارد کنید.']);
        }

        $createdCount = 0;
        $rules = [];

        // دریافت شهرهای مقصد
        $destinationCities = City::whereIn('id', $destinationCityIds)->get()->keyBy('id');

        // ایجاد قوانین برای هر ترکیب شهر مبدا و مقصد
        foreach ($originCityNames as $originCityName) {
            foreach ($destinationCityIds as $destinationCityId) {
                $destinationCity = $destinationCities->get($destinationCityId);

                if (!$destinationCity) {
                    continue;
                }

                // اگر نام شهر مبدا و مقصد یکی باشد، رد می‌کنیم
                if (trim($originCityName) === trim($destinationCity->title)) {
                    continue;
                }

                $ruleData = [
                    'origin_city' => trim($originCityName),
                    'destination_city' => $destinationCity->title,
                    'car_category_id' => $data['car_category_id'] ?? null,
                    'province_id' => $data['province_id'],
                    'fixed_price' => $data['fixed_price'],
                    'per_km_price' => $data['per_km_price'],
                    'pricing_type' => $data['pricing_type'],
                    'priority' => $data['priority'],
                    'is_active' => $isActive,
                ];

                $rules[] = $ruleData;

                // اگر checkbox ایجاد قانون برعکس تیک خورده باشد، قانون برعکس هم ایجاد می‌کنیم
                if ($createReverse) {
                    $reverseRuleData = [
                        'origin_city' => $destinationCity->title,
                        'destination_city' => trim($originCityName),
                        'car_category_id' => $data['car_category_id'] ?? null,
                        'province_id' => $data['province_id'],
                        'fixed_price' => $data['fixed_price'],
                        'per_km_price' => $data['per_km_price'],
                        'pricing_type' => $data['pricing_type'],
                        'priority' => $data['priority'],
                        'is_active' => $isActive,
                    ];

                    $rules[] = $reverseRuleData;
                }
            }
        }

        // ایجاد همه قوانین به صورت دسته‌ای
        if (!empty($rules)) {
            $now = now();
            foreach ($rules as &$rule) {
                $rule['created_at'] = $now;
                $rule['updated_at'] = $now;
            }
            unset($rule);
            PricingRule::insert($rules);
            $createdCount = count($rules);
        }

        return redirect()->route('admin.pricing_rules.index')
            ->with('success', "{$createdCount} قانون قیمت‌گذاری با موفقیت ایجاد شد.");
    }

    public function bulkEdit(Request $request)
    {
        $carCategories = CarCategory::all();
        $provinces = Province::ordered()->get();
        $provinceId = $request->get('province_id');
        $pricingRules = collect();

        if ($provinceId) {
            $pricingRules = PricingRule::where('province_id', $provinceId)
                ->with('carCategory')
                ->orderBy('origin_city')
                ->orderBy('destination_city')
                ->get();
        }

        return view('pricing::admin.pricing_rules.bulk_edit', compact('carCategories', 'provinces', 'provinceId', 'pricingRules'));
    }

    public function bulkUpdate(BulkUpdatePricingRuleRequest $request)
    {
        $data = $request->validated();
        $ruleIds = $data['rule_ids'];

        // فقط فیلدهایی که ارسال شده‌اند را به‌روزرسانی می‌کنیم
        $updateData = [];

        if ($request->filled('car_category_id')) {
            $updateData['car_category_id'] = $data['car_category_id'];
        }

        if ($request->filled('fixed_price')) {
            $updateData['fixed_price'] = $data['fixed_price'];
        }

        if ($request->filled('per_km_price')) {
            $updateData['per_km_price'] = $data['per_km_price'];
        }

        if ($request->filled('pricing_type')) {
            $updateData['pricing_type'] = $data['pricing_type'];
        }

        if ($request->filled('priority')) {
            $updateData['priority'] = $data['priority'];
        }

        // فقط در صورتی که checkbox تیک خورده باشد، is_active را به‌روزرسانی می‌کنیم
        if ($request->has('is_active') && $request->input('is_active') == '1') {
            $updateData['is_active'] = true;
        } elseif ($request->has('update_is_active')) {
            // اگر checkbox برای تغییر وضعیت وجود دارد اما تیک نخورده، false می‌کنیم
            $updateData['is_active'] = false;
        }

        $updateData['updated_at'] = now();

        // به‌روزرسانی همه قوانین انتخاب شده
        $updatedCount = PricingRule::whereIn('id', $ruleIds)->update($updateData);

        return redirect()->route('admin.pricing_rules.bulk.edit', ['province_id' => $data['province_id']])
            ->with('success', "{$updatedCount} قانون قیمت‌گذاری با موفقیت به‌روزرسانی شد.");
    }

    public function bulkDelete(Request $request)
    {
        $provinces = Province::ordered()->get();
        $provinceId = $request->get('province_id');
        $pricingRules = collect();

        if ($provinceId) {
            $pricingRules = PricingRule::where('province_id', $provinceId)
                ->with('carCategory')
                ->orderBy('origin_city')
                ->orderBy('destination_city')
                ->get();
        }

        return view('pricing::admin.pricing_rules.bulk_delete', compact('provinces', 'provinceId', 'pricingRules'));
    }

    public function bulkDestroy(Request $request)
    {
        $request->validate([
            'rule_ids' => 'required|array',
            'rule_ids.*' => 'exists:pricing_rules,id',
        ]);

        $ruleIds = $request->input('rule_ids');
        $deletedCount = PricingRule::whereIn('id', $ruleIds)->delete();

        return redirect()->route('admin.pricing_rules.index')
            ->with('success', "{$deletedCount} قانون قیمت‌گذاری با موفقیت حذف شد.");
    }
}
