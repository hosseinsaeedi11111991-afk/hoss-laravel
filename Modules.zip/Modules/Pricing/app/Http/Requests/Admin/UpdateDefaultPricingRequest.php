<?php

namespace Modules\Pricing\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDefaultPricingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'per_km_price' => ['required', 'numeric', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return [
            'per_km_price' => 'قیمت هر کیلومتر (تومان)',
            'is_active' => 'فعال',
        ];
    }

    public function messages(): array
    {
        return [
            'required' => 'فیلد :attribute الزامی است.',
            'numeric' => 'فیلد :attribute باید عدد باشد.',
            'min' => 'فیلد :attribute باید حداقل :min باشد.',
            'boolean' => 'فیلد :attribute باید true یا false باشد.',
        ];
    }
}
