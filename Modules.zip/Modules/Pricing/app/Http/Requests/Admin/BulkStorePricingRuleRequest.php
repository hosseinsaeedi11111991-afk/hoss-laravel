<?php

namespace Modules\Pricing\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class BulkStorePricingRuleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'province_id' => ['required', 'exists:province_cities,id'],
            'origin_city_names' => ['required', 'string'],
            'destination_city_ids' => ['required', 'array', 'min:1'],
            'destination_city_ids.*' => ['required', 'exists:province_cities,id'],
            'car_category_id' => ['nullable', 'exists:car_categories,id'],
            'fixed_price' => ['required', 'numeric', 'min:0'],
            'per_km_price' => ['required', 'numeric', 'min:0'],
            'pricing_type' => ['required', 'in:fixed,per_km'],
            'priority' => ['required', 'in:high,medium,low'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return [
            'province_id' => 'استان مقصد',
            'origin_city_names' => 'شهرهای مبدا',
            'destination_city_ids' => 'شهرهای مقصد',
            'destination_city_ids.*' => 'شهر مقصد',
            'car_category_id' => 'دسته‌بندی ماشین',
            'fixed_price' => 'قیمت ثابت (تومان)',
            'per_km_price' => 'قیمت هر کیلومتر (تومان)',
            'pricing_type' => 'نحوه محاسبه قیمت',
            'priority' => 'اولویت',
            'is_active' => 'فعال',
        ];
    }

    public function messages(): array
    {
        return [
            'required' => 'فیلد :attribute الزامی است.',
            'array' => 'فیلد :attribute باید آرایه باشد.',
            'min' => 'فیلد :attribute باید حداقل :min مورد داشته باشد.',
            'numeric' => 'فیلد :attribute باید عدد باشد.',
            'exists' => 'مقدار انتخاب شده برای :attribute معتبر نیست.',
            'in' => 'مقدار :attribute نامعتبر است.',
            'boolean' => 'فیلد :attribute باید true یا false باشد.',
        ];
    }
}
