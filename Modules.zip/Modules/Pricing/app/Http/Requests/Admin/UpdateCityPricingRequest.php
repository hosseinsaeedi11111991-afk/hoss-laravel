<?php

namespace Modules\Pricing\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCityPricingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'city_name' => ['required', 'string', 'max:255', 'unique:city_pricings,city_name,' . $this->route('city_pricing')->id],
            'car_category_id' => ['nullable', 'exists:car_categories,id'],
            'per_km_price' => ['required', 'numeric', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return [
            'city_name' => 'نام شهر',
            'car_category_id' => 'دسته‌بندی ماشین',
            'per_km_price' => 'قیمت هر کیلومتر (تومان)',
            'is_active' => 'فعال',
        ];
    }

    public function messages(): array
    {
        return [
            'required' => 'فیلد :attribute الزامی است.',
            'string' => 'فیلد :attribute باید متن باشد.',
            'max' => 'فیلد :attribute نباید بیشتر از :max کاراکتر باشد.',
            'unique' => 'این :attribute قبلاً ثبت شده است.',
            'numeric' => 'فیلد :attribute باید عدد باشد.',
            'min' => 'فیلد :attribute باید حداقل :min باشد.',
            'boolean' => 'فیلد :attribute باید true یا false باشد.',
        ];
    }
}
