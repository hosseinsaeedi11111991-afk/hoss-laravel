<?php

namespace Modules\Pricing\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StorePricingRuleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'origin_city' => ['required', 'string', 'max:255'],
            'destination_city' => ['required', 'string', 'max:255'],
            'car_category_id' => ['nullable', 'exists:car_categories,id'],
            'fixed_price' => ['required', 'numeric', 'min:0'],
            'per_km_price' => ['required', 'numeric', 'min:0'],
            'pricing_type' => ['required', 'in:fixed,per_km'],
            'priority' => ['required', 'in:high,medium,low'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return [
            'origin_city' => 'شهر مبدا',
            'destination_city' => 'شهر مقصد',
            'car_category_id' => 'دسته‌بندی ماشین',
            'fixed_price' => 'قیمت ثابت (تومان)',
            'per_km_price' => 'قیمت هر کیلومتر (تومان)',
            'pricing_type' => 'نحوه محاسبه قیمت',
            'priority' => 'اولویت',
            'is_active' => 'فعال',
        ];
    }

    public function messages(): array
    {
        return [
            'required' => 'فیلد :attribute الزامی است.',
            'string' => 'فیلد :attribute باید متن باشد.',
            'max' => 'فیلد :attribute نباید بیشتر از :max کاراکتر باشد.',
            'numeric' => 'فیلد :attribute باید عدد باشد.',
            'min' => 'فیلد :attribute باید حداقل :min باشد.',
            'in' => 'مقدار :attribute نامعتبر است.',
            'boolean' => 'فیلد :attribute باید true یا false باشد.',
        ];
    }
}
