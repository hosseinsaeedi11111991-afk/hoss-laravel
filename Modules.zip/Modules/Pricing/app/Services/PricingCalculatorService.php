<?php

namespace Modules\Pricing\Services;

use Illuminate\Support\Arr;
use Modules\Pricing\Models\CityPricing;
use Modules\Pricing\Models\DefaultPricing;
use Modules\Pricing\Models\PricingRule;

class PricingCalculatorService
{
    /**
     * محاسبه قیمت پایه برای یک مسیر بر اساس داده‌های موجود در ماژول Pricing.
     *
     * @param  float       $distanceKm    مسافت مسیر به کیلومتر
     * @param  array       $context       اطلاعات تکمیلی شامل origin_city و destination_city
     * @return array{amount: float, source: string|null, meta: array}
     */
    public function calculateInitialPrice(float $distanceKm, array $context = []): array
    {

        $distanceKm = max(0, $distanceKm);

        $originTexts = $this->prepareTextCandidates(Arr::get($context, 'origin_texts', []));
        $destinationTexts = $this->prepareTextCandidates(Arr::get($context, 'destination_texts', []));

        if ($originCity = Arr::get($context, 'origin_city')) {
            $originTexts[] = $originCity;
        }

        if ($destinationCity = Arr::get($context, 'destination_city')) {
            $destinationTexts[] = $destinationCity;
        }

        $routeCities = $this->prepareRouteCities(Arr::get($context, 'route_cities', []));

        if ($distanceKm === 0.0) {
            return [
                'amount' => 0.0,
                'source' => null,
                'meta' => [],
            ];
        }

        $carCategoryId = Arr::get($context, 'car_category_id');
        $routeResult = $this->calculateFromRoute($originTexts, $destinationTexts, $distanceKm, $carCategoryId);
        if ($routeResult !== null) {
            // بررسی اینکه آیا سفر شهر به شهر است
            // اگر origin_city و destination_city در meta موجود باشند، از آنها استفاده می‌کنیم
            $isCityToCity = false;
            if (isset($routeResult['meta']['origin_city']) && isset($routeResult['meta']['destination_city'])) {
                $isCityToCity = $this->isCityToCityTripByCityNames(
                    $routeResult['meta']['origin_city'],
                    $routeResult['meta']['destination_city']
                );
            } else {
                $isCityToCity = $this->isCityToCityTrip($originTexts, $destinationTexts);
            }
            if (isset($routeResult['meta'])) {
                $routeResult['meta']['is_city_to_city'] = $isCityToCity;
            } else {
                $routeResult['meta'] = ['is_city_to_city' => $isCityToCity];
            }
            return $routeResult;
        }

        $cityResult = $this->calculateFromCityPricing($originTexts, $destinationTexts, $routeCities, $distanceKm, $carCategoryId);
        if ($cityResult !== null) {
            // بررسی اینکه آیا سفر شهر به شهر است
            $isCityToCity = $this->isCityToCityTrip($originTexts, $destinationTexts);
            if (isset($cityResult['meta'])) {
                $cityResult['meta']['is_city_to_city'] = $isCityToCity;
            } else {
                $cityResult['meta'] = ['is_city_to_city' => $isCityToCity];
            }
            return $cityResult;
        }

        $defaultResult = $this->calculateFromDefault($distanceKm);

        // بررسی اینکه آیا سفر شهر به شهر است (هم مبدا و هم مقصد در city_pricings هستند)
        $isCityToCity = $this->isCityToCityTrip($originTexts, $destinationTexts);

        // اضافه کردن اطلاعات is_city_to_city به نتیجه
        if (isset($defaultResult['meta'])) {
            $defaultResult['meta']['is_city_to_city'] = $isCityToCity;
        } else {
            $defaultResult['meta'] = ['is_city_to_city' => $isCityToCity];
        }

        return $defaultResult;
    }

    /**
     * بررسی اینکه آیا سفر شهر به شهر است (بررسی از طریق pricing_rules)
     * اگر یک pricing_rule با این مبدا و مقصد وجود داشته باشد، سفر شهر به شهر است
     */
    public function isCityToCityTrip(array $originTexts, array $destinationTexts): bool
    {
        $pricingRules = \Modules\Pricing\Models\PricingRule::query()
            ->active()
            ->get();

        if ($pricingRules->isEmpty()) {
            return false;
        }

        // بررسی اینکه آیا یک rule با این مبدا و مقصد وجود دارد
        foreach ($pricingRules as $rule) {
            if (
                $this->keywordMatchesAny($rule->origin_city, $originTexts) &&
                $this->keywordMatchesAny($rule->destination_city, $destinationTexts)
            ) {
                // اگر یک rule با این مبدا و مقصد پیدا شد، سفر شهر به شهر است
                return true;
            }
        }

        return false;
    }

    /**
     * بررسی اینکه آیا سفر شهر به شهر است بر اساس نام شهرها (برای استفاده از pricing_rule)
     * اگر یک pricing_rule با این مبدا و مقصد وجود داشته باشد، سفر شهر به شهر است
     */
    public function isCityToCityTripByCityNames(string $originCity, string $destinationCity): bool
    {
        // بررسی اینکه آیا یک pricing_rule با این مبدا و مقصد وجود دارد
        $pricingRules = \Modules\Pricing\Models\PricingRule::query()
            ->active()
            ->get();

        if ($pricingRules->isEmpty()) {
            return false;
        }

        // بررسی اینکه آیا یک rule با این مبدا و مقصد وجود دارد
        foreach ($pricingRules as $rule) {
            if (
                ($this->textContainsKeyword($rule->origin_city, $originCity) ||
                    $this->textContainsKeyword($originCity, $rule->origin_city)) &&
                ($this->textContainsKeyword($rule->destination_city, $destinationCity) ||
                    $this->textContainsKeyword($destinationCity, $rule->destination_city))
            ) {
                // اگر یک rule با این مبدا و مقصد پیدا شد، سفر شهر به شهر است
                return true;
            }
        }

        return false;
    }

    /**
     * تلاش برای یافتن قانون قیمت‌گذاری مسیر.
     */
    protected function calculateFromRoute(array $originTexts, array $destinationTexts, float $distanceKm, ?int $carCategoryId = null): ?array
    {
        if (empty($originTexts) || empty($destinationTexts)) {
            return null;
        }

        $rules = PricingRule::query()
            ->active()
            ->orderByRaw("CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END")
            ->orderByDesc('id')
            ->get();

        // اولویت: اگر car_category_id انتخاب شده باشد، اول rule با همان category را بررسی می‌کنیم
        // سپس rule با car_category_id = null را بررسی می‌کنیم
        $prioritizedRules = [];
        $fallbackRules = [];

        foreach ($rules as $rule) {
            if (
                $this->keywordMatchesAny($rule->origin_city, $originTexts) &&
                $this->keywordMatchesAny($rule->destination_city, $destinationTexts)
            ) {
                if ($carCategoryId !== null && $rule->car_category_id == $carCategoryId) {
                    // rule با car_category_id مطابق
                    $prioritizedRules[] = $rule;
                } elseif ($rule->car_category_id === null) {
                    // rule بدون car_category_id (برای استفاده وقتی دسته‌بندی انتخاب نشده)
                    $fallbackRules[] = $rule;
                }
            }
        }

        // اول rule با car_category_id را بررسی می‌کنیم
        foreach ($prioritizedRules as $rule) {
            $amount = $rule->isFixedPricing()
                ? (float) $rule->fixed_price
                : (float) $rule->per_km_price * $distanceKm;

            return [
                'amount' => max(0.0, $amount),
                'source' => 'pricing_rule',
                'meta' => [
                    'rule_id' => $rule->id,
                    'pricing_type' => $rule->pricing_type,
                    'origin_city' => $rule->origin_city,
                    'destination_city' => $rule->destination_city,
                    'car_category_id' => $rule->car_category_id, // اضافه کردن car_category_id به meta
                    'has_car_category' => true, // نشان می‌دهد که این rule شامل قیمت دسته‌بندی است
                ],
            ];
        }

        // اگر rule با car_category_id پیدا نشد، از rule بدون car_category_id استفاده می‌کنیم
        foreach ($fallbackRules as $rule) {
            $amount = $rule->isFixedPricing()
                ? (float) $rule->fixed_price
                : (float) $rule->per_km_price * $distanceKm;

            return [
                'amount' => max(0.0, $amount),
                'source' => 'pricing_rule',
                'meta' => [
                    'rule_id' => $rule->id,
                    'pricing_type' => $rule->pricing_type,
                    'origin_city' => $rule->origin_city,
                    'destination_city' => $rule->destination_city,
                    'car_category_id' => null,
                    'has_car_category' => false, // نشان می‌دهد که این rule شامل قیمت دسته‌بندی نیست
                ],
            ];
        }

        return null;
    }

    /**
     * تلاش برای محاسبه قیمت بر اساس تعرفه‌های شهری.
     */
    protected function calculateFromCityPricing(array $originTexts, array $destinationTexts, array $routeCities, float $distanceKm, ?int $carCategoryId = null): ?array
    {
        $candidateTexts = $this->prepareTextCandidates(array_merge($originTexts, $destinationTexts));

        foreach ($routeCities as $city) {
            $candidateTexts[] = $city['name'];
        }

        $candidateTexts = $this->prepareTextCandidates($candidateTexts);

        if (empty($candidateTexts)) {
            return null;
        }

        $cityPricings = CityPricing::query()
            ->active()
            ->get();

        if (!empty($routeCities)) {
            $segmentedResult = $this->calculateSegmentedCityPricing($routeCities, $cityPricings, $distanceKm, $carCategoryId);
            if ($segmentedResult !== null) {
                return $segmentedResult;
            }
        }

        // اولویت: اگر car_category_id انتخاب شده باشد، اول city_pricing با همان category را بررسی می‌کنیم
        // سپس city_pricing با car_category_id = null را بررسی می‌کنیم
        $prioritizedPricings = [];
        $fallbackPricings = [];

        foreach ($cityPricings as $cityPricing) {
            if (!$this->keywordMatchesAny($cityPricing->city_name, $candidateTexts)) {
                continue;
            }

            if ($carCategoryId !== null && $cityPricing->car_category_id == $carCategoryId) {
                // city_pricing با car_category_id مطابق
                $prioritizedPricings[] = $cityPricing;
            } elseif ($cityPricing->car_category_id === null) {
                // city_pricing بدون car_category_id (برای استفاده وقتی دسته‌بندی انتخاب نشده)
                $fallbackPricings[] = $cityPricing;
            }
        }

        // اول city_pricing با car_category_id را بررسی می‌کنیم
        foreach ($prioritizedPricings as $cityPricing) {
            $matchedDistance = $this->findDistanceForKeyword($routeCities, $cityPricing->city_name) ?? $distanceKm;
            $amount = (float) $cityPricing->per_km_price * $matchedDistance;

            return [
                'amount' => max(0.0, $amount),
                'source' => 'city_pricing',
                'meta' => [
                    'city_pricing_id' => $cityPricing->id,
                    'city_name' => $cityPricing->city_name,
                    'matched_distance_km' => $matchedDistance,
                    'car_category_id' => $cityPricing->car_category_id, // اضافه کردن car_category_id به meta
                    'has_car_category' => true, // نشان می‌دهد که این city_pricing شامل قیمت دسته‌بندی است
                ],
            ];
        }

        // اگر city_pricing با car_category_id پیدا نشد، از city_pricing بدون car_category_id استفاده می‌کنیم
        foreach ($fallbackPricings as $cityPricing) {
            $matchedDistance = $this->findDistanceForKeyword($routeCities, $cityPricing->city_name) ?? $distanceKm;
            $amount = (float) $cityPricing->per_km_price * $matchedDistance;

            return [
                'amount' => max(0.0, $amount),
                'source' => 'city_pricing',
                'meta' => [
                    'city_pricing_id' => $cityPricing->id,
                    'city_name' => $cityPricing->city_name,
                    'matched_distance_km' => $matchedDistance,
                    'car_category_id' => null,
                    'has_car_category' => false, // نشان می‌دهد که این city_pricing شامل قیمت دسته‌بندی نیست
                ],
            ];
        }

        return null;
    }

    /**
     * محاسبه بر اساس نرخ پیش‌فرض در صورت نبود سایر گزینه‌ها.
     */
    protected function calculateFromDefault(float $distanceKm): array
    {
        $defaultPricing = DefaultPricing::getActiveDefault();

        if (!$defaultPricing) {
            return [
                'amount' => 0.0,
                'source' => null,
                'meta' => [],
            ];
        }

        $amount = (float) $defaultPricing->per_km_price * $distanceKm;

        return [
            'amount' => max(0.0, $amount),
            'source' => 'default_pricing',
            'meta' => [
                'default_pricing_id' => $defaultPricing->id,
            ],
        ];
    }

    protected function prepareTextCandidates($values): array
    {
        if (is_null($values)) {
            return [];
        }

        if (!is_array($values)) {
            $values = [$values];
        }

        $normalized = [];
        foreach ($values as $value) {
            if (!is_string($value)) {
                continue;
            }

            $clean = trim($value);
            if ($clean === '') {
                continue;
            }

            $normalized[] = $clean;
        }

        return array_values(array_unique($normalized));
    }

    protected function prepareRouteCities($cities): array
    {
        if (!is_array($cities)) {
            return [];
        }

        $prepared = [];
        foreach ($cities as $city) {
            if (!is_array($city)) {
                continue;
            }

            $name = $city['city_name'] ?? $city['name'] ?? null;
            if (!is_string($name) || trim($name) === '') {
                continue;
            }

            $prepared[] = [
                'name' => trim($name),
                'distance_km' => isset($city['distance_km']) ? (float) $city['distance_km'] : 0.0,
            ];
        }

        return $prepared;
    }

    protected function keywordMatchesAny(?string $keyword, array $candidates): bool
    {
        if (!$keyword || trim($keyword) === '') {
            return false;
        }

        foreach ($candidates as $candidate) {
            if ($this->textContainsKeyword($candidate, $keyword)) {
                return true;
            }
        }

        return false;
    }

    protected function textContainsKeyword(string $text, string $keyword): bool
    {
        $normalizedText = $this->normalizeForComparison($text);
        $normalizedKeyword = $this->normalizeForComparison($keyword);

        if ($normalizedText === '' || $normalizedKeyword === '') {
            return false;
        }

        return mb_stripos($normalizedText, $normalizedKeyword) !== false;
    }

    protected function normalizeForComparison(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        $value = str_replace(['ي', 'ك', 'ة'], ['ی', 'ک', 'ه'], $value);
        $value = str_replace(['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $value);
        $value = preg_replace('/\s+/u', ' ', $value);

        return mb_strtolower($value, 'UTF-8');
    }

    protected function findDistanceForKeyword(array $routeCities, string $keyword): ?float
    {
        foreach ($routeCities as $city) {
            if ($this->textContainsKeyword($city['name'], $keyword)) {
                return (float) $city['distance_km'];
            }
        }

        return null;
    }

    protected function findCityPricingForName(string $cityName, $cityPricings): ?CityPricing
    {
        foreach ($cityPricings as $pricing) {
            if (
                $this->textContainsKeyword($cityName, $pricing->city_name) ||
                $this->textContainsKeyword($pricing->city_name, $cityName)
            ) {
                return $pricing;
            }
        }

        return null;
    }

    protected function calculateSegmentedCityPricing(array $routeCities, $cityPricings, float $fallbackDistance, ?int $carCategoryId = null): ?array
    {
        if (empty($routeCities)) {
            return null;
        }

        $defaultPricing = DefaultPricing::getActiveDefault();
        $defaultRate = $defaultPricing ? (float) $defaultPricing->per_km_price : null;

        $totalAmount = 0.0;
        $segmentsMeta = [];
        $distanceTotal = 0.0;
        $usedAnyRate = false;

        foreach ($routeCities as $index => $city) {
            $cityName = $city['name'] ?? null;
            if (!$cityName) {
                continue;
            }

            $distance = isset($city['distance_km']) ? (float) $city['distance_km'] : 0.0;
            if ($distance <= 0 && $fallbackDistance > 0) {
                $distance = $fallbackDistance;
            }

            if ($distance <= 0) {
                continue;
            }

            // اولویت: اگر car_category_id انتخاب شده باشد، اول city_pricing با همان category را بررسی می‌کنیم
            // سپس city_pricing با car_category_id = null را بررسی می‌کنیم
            $matchedPricing = null;
            $matchedPricingFallback = null;

            foreach ($cityPricings as $pricing) {
                if (
                    ($this->textContainsKeyword($cityName, $pricing->city_name) ||
                        $this->textContainsKeyword($pricing->city_name, $cityName))
                ) {
                    if ($carCategoryId !== null && $pricing->car_category_id == $carCategoryId) {
                        // city_pricing با car_category_id مطابق
                        $matchedPricing = $pricing;
                        break; // اولویت با این است
                    } elseif ($pricing->car_category_id === null && $matchedPricingFallback === null) {
                        // city_pricing بدون car_category_id (برای استفاده وقتی دسته‌بندی انتخاب نشده)
                        $matchedPricingFallback = $pricing;
                    }
                }
            }

            // استفاده از city_pricing با car_category_id یا fallback
            $finalMatchedPricing = $matchedPricing ?? $matchedPricingFallback;

            if ($finalMatchedPricing) {
                $rate = (float) $finalMatchedPricing->per_km_price;
                $source = 'city_pricing';
                $pricingId = $finalMatchedPricing->id;
            } elseif ($defaultRate !== null) {
                $rate = $defaultRate;
                $source = 'default_pricing';
                $pricingId = $defaultPricing?->id;
            } else {
                continue;
            }

            if ($rate <= 0) {
                continue;
            }

            $segmentAmount = $rate * $distance;
            $totalAmount += $segmentAmount;
            $distanceTotal += $distance;
            $usedAnyRate = true;

            $segmentsMeta[] = [
                'city_name' => $cityName,
                'distance_km' => $distance,
                'rate' => $rate,
                'amount' => $segmentAmount,
                'source' => $source,
                'pricing_id' => $pricingId,
                'order' => $index,
            ];
        }

        if (!$usedAnyRate || $totalAmount <= 0) {
            return null;
        }

        // بررسی اینکه آیا حداقل یک segment از city_pricing با car_category_id استفاده کرده است
        $hasCarCategoryInSegments = false;
        $carCategoryIdInSegments = null;
        foreach ($segmentsMeta as $segment) {
            if (isset($segment['pricing_id']) && $segment['source'] === 'city_pricing') {
                // پیدا کردن city_pricing برای بررسی car_category_id
                foreach ($cityPricings as $pricing) {
                    if ($pricing->id == $segment['pricing_id'] && $pricing->car_category_id !== null) {
                        $hasCarCategoryInSegments = true;
                        $carCategoryIdInSegments = $pricing->car_category_id;
                        break 2; // break از هر دو loop
                    }
                }
            }
        }

        return [
            'amount' => max(0.0, $totalAmount),
            'source' => 'city_pricing',
            'meta' => [
                'mode' => 'segments',
                'segments' => $segmentsMeta,
                'default_pricing_id' => $defaultPricing?->id,
                'distance_total_km' => $distanceTotal,
                'has_car_category' => $hasCarCategoryInSegments,
                'car_category_id' => $carCategoryIdInSegments,
            ],
        ];
    }
}


