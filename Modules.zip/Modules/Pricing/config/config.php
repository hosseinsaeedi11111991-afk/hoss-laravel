<?php

return [
    'name' => 'Pricing',
];
