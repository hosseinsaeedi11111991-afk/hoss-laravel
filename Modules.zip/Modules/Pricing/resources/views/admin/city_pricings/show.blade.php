@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.city_pricings.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.city_pricings.index') }}">قیمت‌گذاری شهری/</a></span>
        جزئیات قیمت شهری
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قیمت‌گذاری شهری</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>نام شهر:</strong>
                    <p class="text-muted fs-5">{{ $cityPricing->city_name }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>دسته‌بندی ماشین:</strong>
                    <p>
                        @if($cityPricing->carCategory)
                            <span class="badge bg-secondary">{{ $cityPricing->carCategory->title }}</span>
                        @else
                            <span class="text-muted">تعیین نشده</span>
                        @endif
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p>
                        <span class="badge bg-info fs-6">
                            {{ $cityPricing->getFormattedPrice() }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-{{ $cityPricing->is_active ? 'success' : 'danger' }}">
                            {{ $cityPricing->is_active ? 'فعال' : 'غیرفعال' }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted">{{ $cityPricing->created_at->format('Y/m/d H:i') }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted">{{ $cityPricing->updated_at->format('Y/m/d H:i') }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (100 کیلومتر):</strong>
                    <p class="text-success fs-5">
                        {{ number_format($cityPricing->calculatePrice(100)) }} تومان
                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('admin.city_pricings.edit', $cityPricing) }}" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="{{ route('admin.city_pricings.index') }}" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
@endsection
