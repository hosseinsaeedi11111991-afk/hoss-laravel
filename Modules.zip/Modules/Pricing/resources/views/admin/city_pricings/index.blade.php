@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.city_pricings.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.city_pricings.index') }}">قیمت‌گذاری شهری/</a></span>
        لیست قیمت‌ها
    </h4>

    <a href="{{ route('admin.city_pricings.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن قیمت شهری</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>نام شهر</th>
                <th>دسته‌بندی ماشین</th>
                <th>قیمت هر کیلومتر</th>
                <th>وضعیت</th>
                <th>تاریخ ایجاد</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($cityPricings as $key => $cityPricing)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>
                        <strong>{{ $cityPricing->city_name }}</strong>
                    </td>
                    <td>
                        @if($cityPricing->carCategory)
                            <span class="badge bg-secondary">{{ $cityPricing->carCategory->title }}</span>
                        @else
                            <span class="text-muted">-</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge bg-info fs-6">
                            {{ $cityPricing->getFormattedPrice() }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $cityPricing->is_active ? 'success' : 'danger' }}">
                            {{ $cityPricing->is_active ? 'فعال' : 'غیرفعال' }}
                        </span>
                    </td>
                    <td>{{ $cityPricing->created_at->format('Y/m/d H:i') }}</td>
                    <td>
                        <a href="{{ route('admin.city_pricings.show', $cityPricing) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.city_pricings.edit', $cityPricing) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.city_pricings.destroy', $cityPricing) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $cityPricings->links('pagination::bootstrap-5') }}
    </div>
@endsection
