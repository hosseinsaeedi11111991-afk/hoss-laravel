@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">قوانین قیمت‌گذاری/</a></span>
        جزئیات قانون
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قانون قیمت‌گذاری</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>شهر مبدا:</strong>
                    <p class="text-muted">{{ $pricingRule->origin_city }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>شهر مقصد:</strong>
                    <p class="text-muted">{{ $pricingRule->destination_city }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>دسته‌بندی ماشین:</strong>
                    <p>
                        @if($pricingRule->carCategory)
                            <span class="badge bg-secondary">{{ $pricingRule->carCategory->title }}</span>
                        @else
                            <span class="text-muted">تعیین نشده</span>
                        @endif
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>نحوه محاسبه قیمت:</strong>
                    <p>
                        <span class="badge bg-{{ $pricingRule->pricing_type == 'fixed' ? 'primary' : 'info' }}">
                            {{ $pricingRule->getPricingTypeLabel() }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>اولویت:</strong>
                    <p>
                        <span class="badge bg-{{ $pricingRule->priority == 'high' ? 'danger' : ($pricingRule->priority == 'medium' ? 'warning' : 'secondary') }}">
                            {{ $pricingRule->getPriorityLabel() }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت ثابت:</strong>
                    <p class="text-muted">{{ number_format($pricingRule->fixed_price) }} تومان</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p class="text-muted">{{ number_format($pricingRule->per_km_price) }} تومان</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-{{ $pricingRule->is_active ? 'success' : 'danger' }}">
                            {{ $pricingRule->is_active ? 'فعال' : 'غیرفعال' }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted">{{ $pricingRule->created_at->format('Y/m/d H:i') }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted">{{ $pricingRule->updated_at->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('admin.pricing_rules.edit', $pricingRule) }}" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="{{ route('admin.pricing_rules.index') }}" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
@endsection
