@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">قوانین قیمت‌گذاری/</a></span>
        حذف دسته‌ای قوانین
    </h4>

    <div class="alert alert-warning mb-4">
        <strong>هشدار:</strong> با حذف قوانین، این عملیات غیرقابل بازگشت است. لطفا با دقت قوانین مورد نظر را انتخاب کنید.
    </div>

    <form method="GET" action="{{ route('admin.pricing_rules.bulk.delete') }}" class="mb-4">
        <div class="row">
            <div class="col-md-6">
                <label class="form-label">استان</label>
                <select name="province_id" id="province_id" class="form-select" onchange="this.form.submit()">
                    <option value="">انتخاب استان</option>
                    @foreach($provinces as $province)
                        <option value="{{ $province->id }}" {{ $provinceId == $province->id ? 'selected' : '' }}>
                            {{ $province->title }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>
    </form>

    @if($provinceId && $pricingRules->count() > 0)
        <form action="{{ route('admin.pricing_rules.bulk.destroy') }}" method="POST" id="bulkDeleteForm">
            @csrf
            @method('DELETE')

            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">قوانین استان: {{ $provinces->firstWhere('id', $provinceId)->title ?? '' }}</h5>
                    <div>
                        <button type="button" class="btn btn-sm btn-primary" id="select_all_rules">انتخاب همه</button>
                        <button type="button" class="btn btn-sm btn-secondary" id="deselect_all_rules">لغو انتخاب همه</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-striped table-hover">
                            <thead class="table-light sticky-top">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select_all_checkbox" title="انتخاب همه">
                                    </th>
                                    <th>شهر مبدا</th>
                                    <th>شهر مقصد</th>
                                    <th>دسته‌بندی ماشین</th>
                                    <th>نحوه محاسبه</th>
                                    <th>قیمت ثابت</th>
                                    <th>قیمت هر کیلومتر</th>
                                    <th>اولویت</th>
                                    <th>وضعیت</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pricingRules as $rule)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="rule_ids[]" value="{{ $rule->id }}" class="rule-checkbox">
                                        </td>
                                        <td>{{ $rule->origin_city }}</td>
                                        <td>{{ $rule->destination_city }}</td>
                                        <td>
                                            @if($rule->carCategory)
                                                <span class="badge bg-secondary">{{ $rule->carCategory->title }}</span>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ $rule->pricing_type == 'fixed' ? 'primary' : 'info' }}">
                                                {{ $rule->getPricingTypeLabel() }}
                                            </span>
                                        </td>
                                        <td>{{ number_format($rule->fixed_price) }} تومان</td>
                                        <td>{{ number_format($rule->per_km_price) }} تومان</td>
                                        <td>
                                            <span class="badge bg-{{ $rule->priority == 'high' ? 'danger' : ($rule->priority == 'medium' ? 'warning' : 'secondary') }}">
                                                {{ $rule->getPriorityLabel() }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ $rule->is_active ? 'success' : 'danger' }}">
                                                {{ $rule->is_active ? 'فعال' : 'غیرفعال' }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">
                        <strong>تعداد قوانین انتخاب شده: <span id="selected_count">0</span></strong>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-danger" id="submit_btn">حذف قوانین انتخاب شده</button>
                <a href="{{ route('admin.pricing_rules.index') }}" class="btn btn-secondary">انصراف</a>
            </div>
        </form>
    @elseif($provinceId && $pricingRules->count() == 0)
        <div class="alert alert-warning">
            هیچ قانونی برای این استان یافت نشد.
        </div>
    @else
        <div class="alert alert-info">
            لطفا یک استان انتخاب کنید.
        </div>
    @endif

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectAllCheckbox = document.getElementById('select_all_checkbox');
            const ruleCheckboxes = document.querySelectorAll('.rule-checkbox');
            const selectAllBtn = document.getElementById('select_all_rules');
            const deselectAllBtn = document.getElementById('deselect_all_rules');
            const selectedCount = document.getElementById('selected_count');
            const bulkDeleteForm = document.getElementById('bulkDeleteForm');
            const submitBtn = document.getElementById('submit_btn');

            function updateSelectedCount() {
                const selected = document.querySelectorAll('.rule-checkbox:checked').length;
                selectedCount.textContent = selected;
                
                if (selectAllCheckbox) {
                    selectAllCheckbox.checked = selected === ruleCheckboxes.length && ruleCheckboxes.length > 0;
                }
            }

            // Select all checkbox
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    updateSelectedCount();
                });
            }

            // Individual checkboxes
            ruleCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateSelectedCount);
            });

            // Select all button
            if (selectAllBtn) {
                selectAllBtn.addEventListener('click', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = true;
                    });
                    if (selectAllCheckbox) selectAllCheckbox.checked = true;
                    updateSelectedCount();
                });
            }

            // Deselect all button
            if (deselectAllBtn) {
                deselectAllBtn.addEventListener('click', function() {
                    ruleCheckboxes.forEach(checkbox => {
                        checkbox.checked = false;
                    });
                    if (selectAllCheckbox) selectAllCheckbox.checked = false;
                    updateSelectedCount();
                });
            }

            // Form validation
            if (bulkDeleteForm) {
                bulkDeleteForm.addEventListener('submit', function(e) {
                    const selectedRules = document.querySelectorAll('.rule-checkbox:checked');
                    if (selectedRules.length === 0) {
                        e.preventDefault();
                        alert('لطفا حداقل یک قانون را برای حذف انتخاب کنید');
                        return false;
                    }

                    // Confirm deletion
                    const confirmMessage = `آیا از حذف ${selectedRules.length} قانون انتخاب شده اطمینان دارید؟\n\nاین عملیات غیرقابل بازگشت است!`;
                    if (!confirm(confirmMessage)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }

            // Initialize count
            updateSelectedCount();
        });
    </script>
    @endpush
@endsection

