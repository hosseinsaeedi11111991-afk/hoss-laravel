@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">قوانین قیمت‌گذاری/</a></span>
        ویرایش دسته‌ای قوانین
    </h4>

    <div class="alert alert-info mb-4">
        <strong>نکته:</strong> می‌توانید قوانین موجود را ویرایش کنید یا قوانین جدید ایجاد کنید. برای ویرایش: استان را انتخاب کنید، قوانین را انتخاب کرده و فیلدهای مشترک را ویرایش کنید. برای ایجاد: شهرهای مبدا را وارد کنید، استان و شهرهای مقصد را انتخاب کنید.
    </div>

    <!-- تب‌ها برای انتخاب بین ویرایش و ایجاد -->
    <ul class="nav nav-tabs mb-4" id="actionTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-pane" type="button" role="tab">
                ویرایش قوانین موجود
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="create-tab" data-bs-toggle="tab" data-bs-target="#create-pane" type="button" role="tab">
                ایجاد قوانین جدید
            </button>
        </li>
    </ul>

    <div class="tab-content" id="actionTabsContent">
        <!-- تب ویرایش -->
        <div class="tab-pane fade show active" id="edit-pane" role="tabpanel">
            <form method="GET" action="{{ route('admin.pricing_rules.bulk.edit') }}" class="mb-4">
                <div class="row">
                    <div class="col-md-6">
                        <label class="form-label">استان</label>
                        <select name="province_id" id="edit_province_id" class="form-select" onchange="this.form.submit()">
                            <option value="">انتخاب استان</option>
                            @foreach($provinces as $province)
                                <option value="{{ $province->id }}" {{ $provinceId == $province->id ? 'selected' : '' }}>
                                    {{ $province->title }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </form>

            @if($provinceId && $pricingRules->count() > 0)
                <form action="{{ route('admin.pricing_rules.bulk.update') }}" method="POST" id="bulkUpdateForm">
                    @csrf
                    <input type="hidden" name="province_id" value="{{ $provinceId }}">

                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">قوانین استان: {{ $provinces->firstWhere('id', $provinceId)->title ?? '' }}</h5>
                            <div>
                                <button type="button" class="btn btn-sm btn-primary" id="select_all_rules">انتخاب همه</button>
                                <button type="button" class="btn btn-sm btn-secondary" id="deselect_all_rules">لغو انتخاب همه</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-striped table-hover">
                                    <thead class="table-light sticky-top">
                                    <tr>
                                        <th width="50">
                                            <input type="checkbox" id="select_all_checkbox" title="انتخاب همه">
                                        </th>
                                        <th>شهر مبدا</th>
                                        <th>شهر مقصد</th>
                                        <th>دسته‌بندی ماشین</th>
                                        <th>نحوه محاسبه</th>
                                        <th>قیمت ثابت</th>
                                        <th>قیمت هر کیلومتر</th>
                                        <th>اولویت</th>
                                        <th>وضعیت</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($pricingRules as $rule)
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="rule_ids[]" value="{{ $rule->id }}" class="rule-checkbox">
                                            </td>
                                            <td>{{ $rule->origin_city }}</td>
                                            <td>{{ $rule->destination_city }}</td>
                                            <td>
                                                @if($rule->carCategory)
                                                    <span class="badge bg-secondary">{{ $rule->carCategory->title }}</span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
                                            <td>
                                            <span class="badge bg-{{ $rule->pricing_type == 'fixed' ? 'primary' : 'info' }}">
                                                {{ $rule->getPricingTypeLabel() }}
                                            </span>
                                            </td>
                                            <td>{{ number_format($rule->fixed_price) }} تومان</td>
                                            <td>{{ number_format($rule->per_km_price) }} تومان</td>
                                            <td>
                                            <span class="badge bg-{{ $rule->priority == 'high' ? 'danger' : ($rule->priority == 'medium' ? 'warning' : 'secondary') }}">
                                                {{ $rule->getPriorityLabel() }}
                                            </span>
                                            </td>
                                            <td>
                                            <span class="badge bg-{{ $rule->is_active ? 'success' : 'danger' }}">
                                                {{ $rule->is_active ? 'فعال' : 'غیرفعال' }}
                                            </span>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-3">
                                <strong>تعداد قوانین انتخاب شده: <span id="selected_count">0</span></strong>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">ویرایش فیلدهای مشترک</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">دسته‌بندی ماشین</label>
                                    <select name="car_category_id" class="form-select">
                                        <option value="">بدون تغییر (خالی بگذارید)</option>
                                        @foreach($carCategories as $category)
                                            <option value="{{ $category->id }}">
                                                {{ $category->title }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <small class="text-muted">برای تغییر ندادن، خالی بگذارید</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">نحوه محاسبه قیمت</label>
                                    <div>
                                        <label class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="pricing_type" value="fixed">
                                            <span class="form-check-label">قیمت ثابت</span>
                                        </label>
                                        <label class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="pricing_type" value="per_km">
                                            <span class="form-check-label">قیمت به ازای کیلومتر</span>
                                        </label>
                                    </div>
                                    <small class="text-muted">برای تغییر ندادن، هیچکدام را انتخاب نکنید</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">اولویت</label>
                                    <select name="priority" class="form-select">
                                        <option value="">بدون تغییر (خالی بگذارید)</option>
                                        <option value="high">بالا</option>
                                        <option value="medium">متوسط</option>
                                        <option value="low">پایین</option>
                                    </select>
                                    <small class="text-muted">برای تغییر ندادن، خالی بگذارید</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">قیمت ثابت (تومان)</label>
                                    <input type="text" id="fixed_price" class="form-control price-input" placeholder="برای تغییر ندادن خالی بگذارید">
                                    <input type="hidden" name="fixed_price" id="fixed_price_raw">
                                    <small class="text-muted">برای تغییر ندادن، خالی بگذارید</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">قیمت هر کیلومتر (تومان)</label>
                                    <input type="text" id="per_km_price" class="form-control price-input" placeholder="برای تغییر ندادن خالی بگذارید">
                                    <input type="hidden" name="per_km_price" id="per_km_price_raw">
                                    <small class="text-muted">برای تغییر ندادن، خالی بگذارید</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">وضعیت</label>
                                    <input type="hidden" name="update_is_active" value="1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active">
                                        <label class="form-check-label" for="is_active">فعال</label>
                                    </div>
                                    <small class="text-muted">تیک بزنید تا همه قوانین انتخاب شده فعال شوند، در غیر این صورت غیرفعال می‌شوند</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-warning" id="submit_btn">به‌روزرسانی قوانین انتخاب شده</button>
                        <a href="{{ route('admin.pricing_rules.index') }}" class="btn btn-secondary">انصراف</a>
                    </div>
                </form>
            @elseif($provinceId && $pricingRules->count() == 0)
                <div class="alert alert-warning">
                    هیچ قانونی برای این استان یافت نشد.
                </div>
            @else
                <div class="alert alert-info">
                    لطفا یک استان انتخاب کنید.
                </div>
            @endif
        </div>

        <!-- تب ایجاد -->
        <div class="tab-pane fade" id="create-pane" role="tabpanel">
            <form action="{{ route('admin.pricing_rules.bulk.store') }}" method="POST" id="bulkCreateForm">
                @csrf

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">شهرهای مبدا <span class="text-danger">*</span></label>
                        <textarea name="origin_city_names" id="origin_city_names" class="form-control" rows="5" placeholder="شهرهای مبدا را وارد کنید (با کاما یا خط جدید جدا کنید)&#10;مثال: تهران، اصفهان، مشهد&#10;یا:&#10;تهران&#10;اصفهان&#10;مشهد" required>{{ old('origin_city_names') }}</textarea>
                        <small class="text-muted">شهرها را با کاما (،) یا خط جدید جدا کنید</small>
                        @error('origin_city_names')<small class="text-danger d-block">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">استان مقصد <span class="text-danger">*</span></label>
                        <select name="province_id" id="create_province_id" class="form-select" required>
                            <option value="">انتخاب استان</option>
                            @foreach($provinces as $province)
                                <option value="{{ $province->id }}" {{ old('province_id') == $province->id ? 'selected' : '' }}>
                                    {{ $province->title }}
                                </option>
                            @endforeach
                        </select>
                        @error('province_id')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">شهرهای مقصد <span class="text-danger">*</span></label>
                        <div id="destination_cities_container" style="display: none;">
                            <div class="border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                                <div class="mb-2">
                                    <button type="button" class="btn btn-sm btn-primary" id="select_all_destination_cities">انتخاب همه</button>
                                    <button type="button" class="btn btn-sm btn-secondary" id="deselect_all_destination_cities">لغو انتخاب همه</button>
                                </div>
                                <div id="destination_cities_list"></div>
                            </div>
                        </div>
                        <div id="destination_cities_loading" style="display: none;" class="text-center py-3">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">در حال بارگذاری...</span>
                            </div>
                        </div>
                        <div id="destination_cities_empty" class="text-muted py-3" style="display: none;">
                            ابتدا یک استان انتخاب کنید
                        </div>
                        @error('destination_city_ids')<small class="text-danger d-block">{{ $message }}</small>@enderror
                        @error('destination_city_ids.*')<small class="text-danger d-block">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">دسته‌بندی ماشین</label>
                        <select name="car_category_id" class="form-select">
                            <option value="">انتخاب کنید (اختیاری)</option>
                            @foreach($carCategories as $category)
                                <option value="{{ $category->id }}" {{ old('car_category_id') == $category->id ? 'selected' : '' }}>
                                    {{ $category->title }}
                                </option>
                            @endforeach
                        </select>
                        @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                        <div>
                            <label class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="pricing_type" value="fixed" {{ old('pricing_type', 'fixed') == 'fixed' ? 'checked' : '' }} required>
                                <span class="form-check-label">قیمت ثابت</span>
                            </label>
                            <label class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="pricing_type" value="per_km" {{ old('pricing_type') == 'per_km' ? 'checked' : '' }}>
                                <span class="form-check-label">قیمت به ازای کیلومتر</span>
                            </label>
                        </div>
                        @error('pricing_type')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">اولویت <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select" required>
                            <option value="high" {{ old('priority') == 'high' ? 'selected' : '' }}>بالا</option>
                            <option value="medium" {{ old('priority', 'medium') == 'medium' ? 'selected' : '' }}>متوسط</option>
                            <option value="low" {{ old('priority') == 'low' ? 'selected' : '' }}>پایین</option>
                        </select>
                        @error('priority')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                        <input type="text" id="create_fixed_price" class="form-control price-input" value="{{ old('fixed_price', 0) }}" required>
                        <input type="hidden" name="fixed_price" id="create_fixed_price_raw" value="{{ old('fixed_price', 0) }}">
                        <div class="mt-2">
                            <strong>قیمت نمایشی: <span id="create_fixed_price_display" class="text-success">0</span> تومان</strong>
                        </div>
                        @error('fixed_price')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">قیمت هر کیلومتر (تومان) <span class="text-danger">*</span></label>
                        <input type="text" id="create_per_km_price" class="form-control price-input" value="{{ old('per_km_price', 0) }}" required>
                        <input type="hidden" name="per_km_price" id="create_per_km_price_raw" value="{{ old('per_km_price', 0) }}">
                        <div class="mt-2">
                            <strong>قیمت نمایشی: <span id="create_per_km_price_display" class="text-success">0</span> تومان</strong>
                        </div>
                        @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="alert alert-info">
                            <strong>محاسبه قیمت:</strong>
                            <div class="mt-2">
                                <span id="create_price_calculation_display" class="text-primary">-</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}>
                            <label class="form-check-label">فعال</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="create_reverse" value="1" id="create_reverse" {{ old('create_reverse') ? 'checked' : '' }}>
                            <label class="form-check-label" for="create_reverse">
                                ایجاد قانون برعکس (مقصد به مبدا)
                            </label>
                            <small class="text-muted d-block">اگر تیک بزنید، علاوه بر قانون اصلی، قانون برعکس هم ایجاد می‌شود (مثال: تهران->اصفهان و اصفهان->تهران)</small>
                        </div>
                        @error('is_active')<small class="text-danger">{{ $message }}</small>@enderror
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="alert alert-warning" id="create_rules_count_alert" style="display: none;">
                            <strong>تعداد قوانین که ایجاد خواهد شد: <span id="create_rules_count">0</span></strong>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" id="create_submit_btn">ذخیره</button>
                <a href="{{ route('admin.pricing_rules.index') }}" class="btn btn-secondary">انصراف</a>
            </form>
        </div>
    </div>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const selectAllCheckbox = document.getElementById('select_all_checkbox');
                const ruleCheckboxes = document.querySelectorAll('.rule-checkbox');
                const selectAllBtn = document.getElementById('select_all_rules');
                const deselectAllBtn = document.getElementById('deselect_all_rules');
                const selectedCount = document.getElementById('selected_count');
                const bulkUpdateForm = document.getElementById('bulkUpdateForm');
                const submitBtn = document.getElementById('submit_btn');

                // Price input handlers
                const fixedPriceInput = document.getElementById('fixed_price');
                const fixedPriceRaw = document.getElementById('fixed_price_raw');
                const perKmPriceInput = document.getElementById('per_km_price');
                const perKmPriceRaw = document.getElementById('per_km_price_raw');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                function setupPriceInput(input, rawInput) {
                    if (!input) return;
                    input.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/,/g, '');
                        if (value === '') {
                            rawInput.value = '';
                            return;
                        }
                        const numValue = parseFloat(value) || 0;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                    });
                }

                setupPriceInput(fixedPriceInput, fixedPriceRaw);
                setupPriceInput(perKmPriceInput, perKmPriceRaw);

                function updateSelectedCount() {
                    const selected = document.querySelectorAll('.rule-checkbox:checked').length;
                    selectedCount.textContent = selected;

                    if (selectAllCheckbox) {
                        selectAllCheckbox.checked = selected === ruleCheckboxes.length && ruleCheckboxes.length > 0;
                    }
                }

                // Select all checkbox
                if (selectAllCheckbox) {
                    selectAllCheckbox.addEventListener('change', function() {
                        ruleCheckboxes.forEach(checkbox => {
                            checkbox.checked = this.checked;
                        });
                        updateSelectedCount();
                    });
                }

                // Individual checkboxes
                ruleCheckboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', updateSelectedCount);
                });

                // Select all button
                if (selectAllBtn) {
                    selectAllBtn.addEventListener('click', function() {
                        ruleCheckboxes.forEach(checkbox => {
                            checkbox.checked = true;
                        });
                        if (selectAllCheckbox) selectAllCheckbox.checked = true;
                        updateSelectedCount();
                    });
                }

                // Deselect all button
                if (deselectAllBtn) {
                    deselectAllBtn.addEventListener('click', function() {
                        ruleCheckboxes.forEach(checkbox => {
                            checkbox.checked = false;
                        });
                        if (selectAllCheckbox) selectAllCheckbox.checked = false;
                        updateSelectedCount();
                    });
                }

                // Form validation
                if (bulkUpdateForm) {
                    bulkUpdateForm.addEventListener('submit', function(e) {
                        const selectedRules = document.querySelectorAll('.rule-checkbox:checked');
                        if (selectedRules.length === 0) {
                            e.preventDefault();
                            alert('لطفا حداقل یک قانون را انتخاب کنید');
                            return false;
                        }

                        // Check if at least one field is being updated
                        const hasCarCategory = document.querySelector('select[name="car_category_id"]').value !== '';
                        const hasPricingType = document.querySelector('input[name="pricing_type"]:checked') !== null;
                        const hasPriority = document.querySelector('select[name="priority"]').value !== '';
                        const hasFixedPrice = fixedPriceRaw.value !== '';
                        const hasPerKmPrice = perKmPriceRaw.value !== '';
                        const hasIsActive = document.getElementById('is_active').checked;

                        if (!hasCarCategory && !hasPricingType && !hasPriority && !hasFixedPrice && !hasPerKmPrice && !hasIsActive) {
                            e.preventDefault();
                            alert('لطفا حداقل یک فیلد را برای ویرایش انتخاب کنید');
                            return false;
                        }
                    });
                }

                // Initialize count
                updateSelectedCount();

                // ========== بخش ایجاد قوانین جدید ==========
                const createProvinceSelect = document.getElementById('create_province_id');
                const createOriginCityNamesTextarea = document.getElementById('origin_city_names');
                const createDestinationCitiesContainer = document.getElementById('destination_cities_container');
                const createDestinationCitiesList = document.getElementById('destination_cities_list');
                const createDestinationCitiesLoading = document.getElementById('destination_cities_loading');
                const createDestinationCitiesEmpty = document.getElementById('destination_cities_empty');
                const createSelectAllDestinationBtn = document.getElementById('select_all_destination_cities');
                const createDeselectAllDestinationBtn = document.getElementById('deselect_all_destination_cities');
                const createRulesCountAlert = document.getElementById('create_rules_count_alert');
                const createRulesCount = document.getElementById('create_rules_count');
                const createBulkCreateForm = document.getElementById('bulkCreateForm');

                // Price input handlers for create section
                const createFixedPriceInput = document.getElementById('create_fixed_price');
                const createFixedPriceRaw = document.getElementById('create_fixed_price_raw');
                const createFixedPriceDisplay = document.getElementById('create_fixed_price_display');
                const createPerKmPriceInput = document.getElementById('create_per_km_price');
                const createPerKmPriceRaw = document.getElementById('create_per_km_price_raw');
                const createPerKmPriceDisplay = document.getElementById('create_per_km_price_display');
                const createPricingTypeInputs = document.querySelectorAll('#create-pane input[name="pricing_type"]');
                const createPriceCalculationDisplay = document.getElementById('create_price_calculation_display');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                function updateCreatePriceCalculation() {
                    const pricingType = document.querySelector('#create-pane input[name="pricing_type"]:checked')?.value || 'fixed';
                    const fixedPrice = parseNumber(createFixedPriceRaw.value);
                    const perKmPrice = parseNumber(createPerKmPriceRaw.value);

                    if (pricingType === 'fixed') {
                        createPriceCalculationDisplay.textContent = `قیمت ثابت: ${formatNumber(Math.floor(fixedPrice))} تومان`;
                    } else {
                        createPriceCalculationDisplay.textContent = `قیمت به ازای هر کیلومتر: ${formatNumber(Math.floor(perKmPrice))} تومان (مثال: برای 10 کیلومتر = ${formatNumber(Math.floor(perKmPrice * 10))} تومان)`;
                    }
                    updateCreateRulesCount();
                }

                function setupCreatePriceInput(input, rawInput, display) {
                    if (!input) return;
                    input.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/,/g, '');
                        if (value === '') {
                            value = '0';
                        }
                        const numValue = parseFloat(value) || 0;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        if (display) {
                            display.textContent = formatNumber(Math.floor(numValue));
                        }
                        updateCreatePriceCalculation();
                    });
                }

                if (createFixedPriceInput) {
                    setupCreatePriceInput(createFixedPriceInput, createFixedPriceRaw, createFixedPriceDisplay);
                    setupCreatePriceInput(createPerKmPriceInput, createPerKmPriceRaw, createPerKmPriceDisplay);

                    createPricingTypeInputs.forEach(input => {
                        input.addEventListener('change', updateCreatePriceCalculation);
                    });

                    // Initialize price inputs
                    [createFixedPriceInput, createPerKmPriceInput].forEach(input => {
                        if (input.value) {
                            const numValue = parseNumber(input.value);
                            const rawInput = input.id === 'create_fixed_price' ? createFixedPriceRaw : createPerKmPriceRaw;
                            const display = input.id === 'create_fixed_price' ? createFixedPriceDisplay : createPerKmPriceDisplay;
                            rawInput.value = numValue;
                            input.value = formatNumber(Math.floor(numValue));
                            if (display) display.textContent = formatNumber(Math.floor(numValue));
                        }
                    });

                    updateCreatePriceCalculation();
                }

                // Function to load destination cities
                function loadCreateDestinationCities(provinceId) {
                    if (!provinceId) {
                        createDestinationCitiesContainer.style.display = 'none';
                        createDestinationCitiesLoading.style.display = 'none';
                        createDestinationCitiesEmpty.style.display = 'block';
                        createDestinationCitiesList.innerHTML = '';
                        updateCreateRulesCount();
                        return;
                    }

                    createDestinationCitiesContainer.style.display = 'none';
                    createDestinationCitiesLoading.style.display = 'block';
                    createDestinationCitiesEmpty.style.display = 'none';
                    createDestinationCitiesList.innerHTML = '';

                    fetch(`{{ route('admin.pricing_rules.cities', ':id') }}`.replace(':id', provinceId), {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                        .then(response => response.json())
                        .then(data => {
                            createDestinationCitiesLoading.style.display = 'none';

                            if (data && data.length > 0) {
                                createDestinationCitiesList.innerHTML = '';
                                data.forEach(city => {
                                    const div = document.createElement('div');
                                    div.className = 'form-check';
                                    div.innerHTML = `
                                <input class="form-check-input destination_city_ids-checkbox" type="checkbox" name="destination_city_ids[]" value="${city.id}" id="destination_city_${city.id}">
                                <label class="form-check-label" for="destination_city_${city.id}">
                                    ${city.title}
                                </label>
                            `;
                                    createDestinationCitiesList.appendChild(div);
                                });

                                // Add event listeners to checkboxes
                                document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                                    checkbox.addEventListener('change', updateCreateRulesCount);
                                });

                                createDestinationCitiesContainer.style.display = 'block';
                            } else {
                                createDestinationCitiesEmpty.style.display = 'block';
                                createDestinationCitiesEmpty.textContent = 'شهری برای این استان یافت نشد';
                            }
                            updateCreateRulesCount();
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            createDestinationCitiesLoading.style.display = 'none';
                            createDestinationCitiesEmpty.style.display = 'block';
                            createDestinationCitiesEmpty.textContent = 'خطا در بارگذاری شهرها';
                        });
                }

                // Load cities when province changes
                if (createProvinceSelect) {
                    createProvinceSelect.addEventListener('change', function() {
                        loadCreateDestinationCities(this.value);
                    });
                }

                // Select all destination cities
                if (createSelectAllDestinationBtn) {
                    createSelectAllDestinationBtn.addEventListener('click', function() {
                        document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                            checkbox.checked = true;
                        });
                        updateCreateRulesCount();
                    });
                }

                // Deselect all destination cities
                if (createDeselectAllDestinationBtn) {
                    createDeselectAllDestinationBtn.addEventListener('click', function() {
                        document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                            checkbox.checked = false;
                        });
                        updateCreateRulesCount();
                    });
                }

                // Calculate and display rules count
                function updateCreateRulesCount() {
                    if (!createOriginCityNamesTextarea) return;

                    // شمارش شهرهای مبدا از textarea
                    const originCityNamesText = createOriginCityNamesTextarea.value.trim();
                    let originCount = 0;
                    if (originCityNamesText) {
                        const originCities = originCityNamesText.split(/[،,\n\r]+/).filter(city => city.trim());
                        originCount = originCities.length;
                    }

                    // شمارش شهرهای مقصد انتخاب شده
                    const selectedDestinationCities = document.querySelectorAll('.destination_city_ids-checkbox:checked');
                    const destinationCount = selectedDestinationCities.length;

                    // بررسی اینکه آیا checkbox ایجاد قانون برعکس تیک خورده است
                    const createReverseCheckbox = document.getElementById('create_reverse');
                    const createReverse = createReverseCheckbox && createReverseCheckbox.checked;

                    if (originCount > 0 && destinationCount > 0) {
                        // تعداد قوانین = تعداد شهرهای مبدا * تعداد شهرهای مقصد
                        // اگر checkbox تیک خورده باشد، دو برابر می‌شود (قانون اصلی + قانون برعکس)
                        let rulesCountValue = originCount * destinationCount;
                        if (createReverse) {
                            rulesCountValue = rulesCountValue * 2;
                        }
                        createRulesCount.textContent = rulesCountValue;
                        createRulesCountAlert.style.display = 'block';
                    } else {
                        createRulesCountAlert.style.display = 'none';
                    }
                }

                // Update rules count when origin cities textarea changes
                if (createOriginCityNamesTextarea) {
                    createOriginCityNamesTextarea.addEventListener('input', updateCreateRulesCount);
                }

                // Update rules count when create reverse checkbox changes
                const createReverseCheckbox = document.getElementById('create_reverse');
                if (createReverseCheckbox) {
                    createReverseCheckbox.addEventListener('change', updateCreateRulesCount);
                }

                // Form validation before submit
                if (createBulkCreateForm) {
                    createBulkCreateForm.addEventListener('submit', function(e) {
                        const originCityNamesText = createOriginCityNamesTextarea.value.trim();
                        const selectedDestinationCities = document.querySelectorAll('.destination_city_ids-checkbox:checked');

                        if (!originCityNamesText) {
                            e.preventDefault();
                            alert('لطفا حداقل یک شهر مبدا وارد کنید');
                            return false;
                        }

                        if (selectedDestinationCities.length === 0) {
                            e.preventDefault();
                            alert('لطفا حداقل یک شهر مقصد را انتخاب کنید');
                            return false;
                        }
                    });
                }
            });
        </script>
    @endpush
@endsection
