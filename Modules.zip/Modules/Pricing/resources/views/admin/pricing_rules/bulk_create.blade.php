@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">قوانین قیمت‌گذاری/</a></span>
        افزودن دسته‌ای قوانین
    </h4>

    <div class="alert alert-info mb-4">
        <strong>نکته:</strong> شهرهای مبدا را به صورت متنی وارد کنید (با کاما یا خط جدید جدا کنید). سپس استان را انتخاب کرده و شهرهای مقصد را انتخاب کنید. قوانین قیمت‌گذاری برای تمام ترکیبات شهرهای مبدا با شهرهای مقصد ایجاد می‌شود.
    </div>

    <form action="{{ route('admin.pricing_rules.bulk.store') }}" method="POST" id="bulkCreateForm">
        @csrf

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">شهرهای مبدا <span class="text-danger">*</span></label>
                <textarea name="origin_city_names" id="origin_city_names" class="form-control" rows="5" placeholder="شهرهای مبدا را وارد کنید (با کاما یا خط جدید جدا کنید)&#10;مثال: تهران، اصفهان، مشهد&#10;یا:&#10;تهران&#10;اصفهان&#10;مشهد" required>{{ old('origin_city_names') }}</textarea>
                <small class="text-muted">شهرها را با کاما (،) یا خط جدید جدا کنید</small>
                @error('origin_city_names')<small class="text-danger d-block">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">استان مقصد <span class="text-danger">*</span></label>
                <select name="province_id" id="province_id" class="form-select" required>
                    <option value="">انتخاب استان</option>
                    @foreach($provinces as $province)
                        <option value="{{ $province->id }}" {{ old('province_id') == $province->id ? 'selected' : '' }}>
                            {{ $province->title }}
                        </option>
                    @endforeach
                </select>
                @error('province_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">شهرهای مقصد <span class="text-danger">*</span></label>
                <div id="destination_cities_container" style="display: none;">
                    <div class="border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                        <div class="mb-2">
                            <button type="button" class="btn btn-sm btn-primary" id="select_all_destination_cities">انتخاب همه</button>
                            <button type="button" class="btn btn-sm btn-secondary" id="deselect_all_destination_cities">لغو انتخاب همه</button>
                        </div>
                        <div id="destination_cities_list"></div>
                    </div>
                </div>
                <div id="destination_cities_loading" style="display: none;" class="text-center py-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">در حال بارگذاری...</span>
                    </div>
                </div>
                <div id="destination_cities_empty" class="text-muted py-3" style="display: none;">
                    ابتدا یک استان انتخاب کنید
                </div>
                @error('destination_city_ids')<small class="text-danger d-block">{{ $message }}</small>@enderror
                @error('destination_city_ids.*')<small class="text-danger d-block">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">انتخاب کنید (اختیاری)</option>
                    @foreach($carCategories as $category)
                        <option value="{{ $category->id }}" {{ old('car_category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->title }}
                        </option>
                    @endforeach
                </select>
                @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="fixed" {{ old('pricing_type', 'fixed') == 'fixed' ? 'checked' : '' }} required>
                        <span class="form-check-label">قیمت ثابت</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="per_km" {{ old('pricing_type') == 'per_km' ? 'checked' : '' }}>
                        <span class="form-check-label">قیمت به ازای کیلومتر</span>
                    </label>
                </div>
                @error('pricing_type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">اولویت <span class="text-danger">*</span></label>
                <select name="priority" class="form-select" required>
                    <option value="high" {{ old('priority') == 'high' ? 'selected' : '' }}>بالا</option>
                    <option value="medium" {{ old('priority', 'medium') == 'medium' ? 'selected' : '' }}>متوسط</option>
                    <option value="low" {{ old('priority') == 'low' ? 'selected' : '' }}>پایین</option>
                </select>
                @error('priority')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="fixed_price" class="form-control price-input" value="{{ old('fixed_price', 0) }}" required>
                <input type="hidden" name="fixed_price" id="fixed_price_raw" value="{{ old('fixed_price', 0) }}">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="fixed_price_display" class="text-success">0</span> تومان</strong>
                </div>
                @error('fixed_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="per_km_price" class="form-control price-input" value="{{ old('per_km_price', 0) }}" required>
                <input type="hidden" name="per_km_price" id="per_km_price_raw" value="{{ old('per_km_price', 0) }}">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="per_km_price_display" class="text-success">0</span> تومان</strong>
                </div>
                @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <div class="alert alert-info">
                    <strong>محاسبه قیمت:</strong>
                    <div class="mt-2">
                        <span id="price_calculation_display" class="text-primary">-</span>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-3">
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}>
                    <label class="form-check-label">فعال</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="create_reverse" value="1" id="create_reverse" {{ old('create_reverse') ? 'checked' : '' }}>
                    <label class="form-check-label" for="create_reverse">
                        ایجاد قانون برعکس (مقصد به مبدا)
                    </label>
                    <small class="text-muted d-block">اگر تیک بزنید، علاوه بر قانون اصلی، قانون برعکس هم ایجاد می‌شود (مثال: تهران->اصفهان و اصفهان->تهران)</small>
                </div>
                @error('is_active')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <div class="alert alert-warning" id="rules_count_alert" style="display: none;">
                    <strong>تعداد قوانین که ایجاد خواهد شد: <span id="rules_count">0</span></strong>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary" id="submit_btn">ذخیره</button>
        <a href="{{ route('admin.pricing_rules.index') }}" class="btn btn-secondary">انصراف</a>
    </form>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const provinceSelect = document.getElementById('province_id');
                const originCityNamesTextarea = document.getElementById('origin_city_names');

                // Destination cities elements
                const destinationCitiesContainer = document.getElementById('destination_cities_container');
                const destinationCitiesList = document.getElementById('destination_cities_list');
                const destinationCitiesLoading = document.getElementById('destination_cities_loading');
                const destinationCitiesEmpty = document.getElementById('destination_cities_empty');
                const selectAllDestinationBtn = document.getElementById('select_all_destination_cities');
                const deselectAllDestinationBtn = document.getElementById('deselect_all_destination_cities');

                const rulesCountAlert = document.getElementById('rules_count_alert');
                const rulesCount = document.getElementById('rules_count');
                const submitBtn = document.getElementById('submit_btn');
                const bulkCreateForm = document.getElementById('bulkCreateForm');

                // Price input handlers (same as create.blade.php)
                const fixedPriceInput = document.getElementById('fixed_price');
                const fixedPriceRaw = document.getElementById('fixed_price_raw');
                const fixedPriceDisplay = document.getElementById('fixed_price_display');

                const perKmPriceInput = document.getElementById('per_km_price');
                const perKmPriceRaw = document.getElementById('per_km_price_raw');
                const perKmPriceDisplay = document.getElementById('per_km_price_display');

                const pricingTypeInputs = document.querySelectorAll('input[name="pricing_type"]');
                const priceCalculationDisplay = document.getElementById('price_calculation_display');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                function updatePriceCalculation() {
                    const pricingType = document.querySelector('input[name="pricing_type"]:checked')?.value || 'fixed';
                    const fixedPrice = parseNumber(fixedPriceRaw.value);
                    const perKmPrice = parseNumber(perKmPriceRaw.value);

                    if (pricingType === 'fixed') {
                        priceCalculationDisplay.textContent = `قیمت ثابت: ${formatNumber(Math.floor(fixedPrice))} تومان`;
                    } else {
                        priceCalculationDisplay.textContent = `قیمت به ازای هر کیلومتر: ${formatNumber(Math.floor(perKmPrice))} تومان (مثال: برای 10 کیلومتر = ${formatNumber(Math.floor(perKmPrice * 10))} تومان)`;
                    }
                    updateRulesCount();
                }

                function setupPriceInput(input, rawInput, display) {
                    input.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/,/g, '');
                        if (value === '') {
                            value = '0';
                        }
                        const numValue = parseFloat(value) || 0;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                        updatePriceCalculation();
                    });
                }

                setupPriceInput(fixedPriceInput, fixedPriceRaw, fixedPriceDisplay);
                setupPriceInput(perKmPriceInput, perKmPriceRaw, perKmPriceDisplay);

                pricingTypeInputs.forEach(input => {
                    input.addEventListener('change', updatePriceCalculation);
                });

                // Initialize price inputs
                [fixedPriceInput, perKmPriceInput].forEach(input => {
                    if (input.value) {
                        const numValue = parseNumber(input.value);
                        const rawInput = input.id === 'fixed_price' ? fixedPriceRaw : perKmPriceRaw;
                        const display = input.id === 'fixed_price' ? fixedPriceDisplay : perKmPriceDisplay;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                    }
                });

                updatePriceCalculation();

                // Function to load destination cities
                function loadDestinationCities(provinceId) {
                    if (!provinceId) {
                        destinationCitiesContainer.style.display = 'none';
                        destinationCitiesLoading.style.display = 'none';
                        destinationCitiesEmpty.style.display = 'block';
                        destinationCitiesList.innerHTML = '';
                        updateRulesCount();
                        return;
                    }

                    destinationCitiesContainer.style.display = 'none';
                    destinationCitiesLoading.style.display = 'block';
                    destinationCitiesEmpty.style.display = 'none';
                    destinationCitiesList.innerHTML = '';

                    fetch(`{{ route('admin.pricing_rules.cities', ':id') }}`.replace(':id', provinceId), {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                        .then(response => response.json())
                        .then(data => {
                            destinationCitiesLoading.style.display = 'none';

                            if (data && data.length > 0) {
                                destinationCitiesList.innerHTML = '';
                                data.forEach(city => {
                                    const div = document.createElement('div');
                                    div.className = 'form-check';
                                    div.innerHTML = `
                                <input class="form-check-input destination_city_ids-checkbox" type="checkbox" name="destination_city_ids[]" value="${city.id}" id="destination_city_${city.id}">
                                <label class="form-check-label" for="destination_city_${city.id}">
                                    ${city.title}
                                </label>
                            `;
                                    destinationCitiesList.appendChild(div);
                                });

                                // Add event listeners to checkboxes
                                document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                                    checkbox.addEventListener('change', updateRulesCount);
                                });

                                destinationCitiesContainer.style.display = 'block';
                            } else {
                                destinationCitiesEmpty.style.display = 'block';
                                destinationCitiesEmpty.textContent = 'شهری برای این استان یافت نشد';
                            }
                            updateRulesCount();
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            destinationCitiesLoading.style.display = 'none';
                            destinationCitiesEmpty.style.display = 'block';
                            destinationCitiesEmpty.textContent = 'خطا در بارگذاری شهرها';
                        });
                }

                // Load cities when province changes
                provinceSelect.addEventListener('change', function() {
                    loadDestinationCities(this.value);
                });

                // Select all destination cities
                if (selectAllDestinationBtn) {
                    selectAllDestinationBtn.addEventListener('click', function() {
                        document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                            checkbox.checked = true;
                        });
                        updateRulesCount();
                    });
                }

                // Deselect all destination cities
                if (deselectAllDestinationBtn) {
                    deselectAllDestinationBtn.addEventListener('click', function() {
                        document.querySelectorAll('.destination_city_ids-checkbox').forEach(checkbox => {
                            checkbox.checked = false;
                        });
                        updateRulesCount();
                    });
                }

                // Calculate and display rules count
                function updateRulesCount() {
                    // شمارش شهرهای مبدا از textarea
                    const originCityNamesText = originCityNamesTextarea.value.trim();
                    let originCount = 0;
                    if (originCityNamesText) {
                        const originCities = originCityNamesText.split(/[،,\n\r]+/).filter(city => city.trim());
                        originCount = originCities.length;
                    }

                    // شمارش شهرهای مقصد انتخاب شده
                    const selectedDestinationCities = document.querySelectorAll('.destination_city_ids-checkbox:checked');
                    const destinationCount = selectedDestinationCities.length;

                    // بررسی اینکه آیا checkbox ایجاد قانون برعکس تیک خورده است
                    const createReverseCheckbox = document.getElementById('create_reverse');
                    const createReverse = createReverseCheckbox && createReverseCheckbox.checked;

                    if (originCount > 0 && destinationCount > 0) {
                        // تعداد قوانین = تعداد شهرهای مبدا * تعداد شهرهای مقصد
                        // اگر checkbox تیک خورده باشد، دو برابر می‌شود (قانون اصلی + قانون برعکس)
                        let rulesCountValue = originCount * destinationCount;
                        if (createReverse) {
                            rulesCountValue = rulesCountValue * 2;
                        }
                        rulesCount.textContent = rulesCountValue;
                        rulesCountAlert.style.display = 'block';
                    } else {
                        rulesCountAlert.style.display = 'none';
                    }
                }

                // Update rules count when origin cities textarea changes
                if (originCityNamesTextarea) {
                    originCityNamesTextarea.addEventListener('input', updateRulesCount);
                }

                // Update rules count when create reverse checkbox changes
                const createReverseCheckbox = document.getElementById('create_reverse');
                if (createReverseCheckbox) {
                    createReverseCheckbox.addEventListener('change', updateRulesCount);
                }

                // Form validation before submit
                bulkCreateForm.addEventListener('submit', function(e) {
                    const originCityNamesText = originCityNamesTextarea.value.trim();
                    const selectedDestinationCities = document.querySelectorAll('.destination_city_ids-checkbox:checked');

                    if (!originCityNamesText) {
                        e.preventDefault();
                        alert('لطفا حداقل یک شهر مبدا وارد کنید');
                        return false;
                    }

                    if (selectedDestinationCities.length === 0) {
                        e.preventDefault();
                        alert('لطفا حداقل یک شهر مقصد را انتخاب کنید');
                        return false;
                    }
                });

                // Trigger change if province is already selected (for old values)
                if (provinceSelect.value) {
                    provinceSelect.dispatchEvent(new Event('change'));
                }
            });
        </script>
    @endpush
@endsection
