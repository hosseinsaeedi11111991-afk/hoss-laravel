@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.pricing_rules.index') }}">قوانین قیمت‌گذاری/</a></span>
        ویرایش قانون
    </h4>

    <form action="{{ route('admin.pricing_rules.update', $pricingRule) }}" method="POST">
        @csrf @method('PUT')
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">شهر مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_city" class="form-control" value="{{ old('origin_city', $pricingRule->origin_city) }}" required>
                @error('origin_city')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">شهر مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_city" class="form-control" value="{{ old('destination_city', $pricingRule->destination_city) }}" required>
                @error('destination_city')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">انتخاب کنید (اختیاری)</option>
                    @foreach($carCategories as $category)
                        <option value="{{ $category->id }}" {{ old('car_category_id', $pricingRule->car_category_id) == $category->id ? 'selected' : '' }}>
                            {{ $category->title }}
                        </option>
                    @endforeach
                </select>
                @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="fixed" {{ old('pricing_type', $pricingRule->pricing_type) == 'fixed' ? 'checked' : '' }} required>
                        <span class="form-check-label">قیمت ثابت</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="per_km" {{ old('pricing_type', $pricingRule->pricing_type) == 'per_km' ? 'checked' : '' }}>
                        <span class="form-check-label">قیمت به ازای کیلومتر</span>
                    </label>
                </div>
                @error('pricing_type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">اولویت <span class="text-danger">*</span></label>
                <select name="priority" class="form-select" required>
                    <option value="high" {{ old('priority', $pricingRule->priority) == 'high' ? 'selected' : '' }}>بالا</option>
                    <option value="medium" {{ old('priority', $pricingRule->priority) == 'medium' ? 'selected' : '' }}>متوسط</option>
                    <option value="low" {{ old('priority', $pricingRule->priority) == 'low' ? 'selected' : '' }}>پایین</option>
                </select>
                @error('priority')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="fixed_price" class="form-control price-input" value="{{ old('fixed_price', number_format($pricingRule->fixed_price, 0, '.', ',')) }}" required>
                <input type="hidden" name="fixed_price" id="fixed_price_raw" value="{{ old('fixed_price', $pricingRule->fixed_price) }}">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="fixed_price_display" class="text-success">{{ number_format($pricingRule->fixed_price, 0, '.', ',') }}</span> تومان</strong>
                </div>
                @error('fixed_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="per_km_price" class="form-control price-input" value="{{ old('per_km_price', number_format($pricingRule->per_km_price, 0, '.', ',')) }}" required>
                <input type="hidden" name="per_km_price" id="per_km_price_raw" value="{{ old('per_km_price', $pricingRule->per_km_price) }}">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="per_km_price_display" class="text-success">{{ number_format($pricingRule->per_km_price, 0, '.', ',') }}</span> تومان</strong>
                </div>
                @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <div class="alert alert-info">
                    <strong>محاسبه قیمت:</strong>
                    <div class="mt-2">
                        <span id="price_calculation_display" class="text-primary">-</span>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', $pricingRule->is_active) ? 'checked' : '' }}>
                    <label class="form-check-label">فعال</label>
                </div>
                @error('is_active')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const fixedPriceInput = document.getElementById('fixed_price');
                const fixedPriceRaw = document.getElementById('fixed_price_raw');
                const fixedPriceDisplay = document.getElementById('fixed_price_display');

                const perKmPriceInput = document.getElementById('per_km_price');
                const perKmPriceRaw = document.getElementById('per_km_price_raw');
                const perKmPriceDisplay = document.getElementById('per_km_price_display');

                const pricingTypeInputs = document.querySelectorAll('input[name="pricing_type"]');
                const priceCalculationDisplay = document.getElementById('price_calculation_display');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                function updatePriceCalculation() {
                    const pricingType = document.querySelector('input[name="pricing_type"]:checked')?.value || 'fixed';
                    const fixedPrice = parseNumber(fixedPriceRaw.value);
                    const perKmPrice = parseNumber(perKmPriceRaw.value);

                    if (pricingType === 'fixed') {
                        priceCalculationDisplay.textContent = `قیمت ثابت: ${formatNumber(Math.floor(fixedPrice))} تومان`;
                    } else {
                        priceCalculationDisplay.textContent = `قیمت به ازای هر کیلومتر: ${formatNumber(Math.floor(perKmPrice))} تومان (مثال: برای 10 کیلومتر = ${formatNumber(Math.floor(perKmPrice * 10))} تومان)`;
                    }
                }

                function setupPriceInput(input, rawInput, display) {
                    input.addEventListener('input', function(e) {
                        let value = e.target.value.replace(/,/g, '');
                        if (value === '') {
                            value = '0';
                        }
                        const numValue = parseFloat(value) || 0;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                        updatePriceCalculation();
                    });
                }

                // Setup price inputs
                setupPriceInput(fixedPriceInput, fixedPriceRaw, fixedPriceDisplay);
                setupPriceInput(perKmPriceInput, perKmPriceRaw, perKmPriceDisplay);

                // Update calculation when pricing type changes
                pricingTypeInputs.forEach(input => {
                    input.addEventListener('change', updatePriceCalculation);
                });

                // Initialize on page load
                [fixedPriceInput, perKmPriceInput].forEach(input => {
                    if (input.value) {
                        const numValue = parseNumber(input.value);
                        const rawInput = input.id === 'fixed_price' ? fixedPriceRaw : perKmPriceRaw;
                        const display = input.id === 'fixed_price' ? fixedPriceDisplay : perKmPriceDisplay;
                        rawInput.value = numValue;
                        input.value = formatNumber(Math.floor(numValue));
                        display.textContent = formatNumber(Math.floor(numValue));
                    }
                });

                updatePriceCalculation();
            });
        </script>
    @endpush
@endsection
