@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">قیمت‌گذاری پیش‌فرض/</a></span>
        افزودن قیمت پیش‌فرض
    </h4>

    <form action="{{ route('admin.default_pricings.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان) <span class="text-danger">*</span></label>
                <input type="text" id="per_km_price" class="form-control price-input" value="{{ old('per_km_price', 0) }}" required>
                <input type="hidden" name="per_km_price" id="per_km_price_raw" value="{{ old('per_km_price', 0) }}">
                <div class="mt-2">
                    <strong>قیمت نمایشی: <span id="per_km_price_display" class="text-success">0</span> تومان</strong>
                </div>
                @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}>
                    <label class="form-check-label">فعال</label>
                </div>
                @error('is_active')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const priceInput = document.getElementById('per_km_price');
                const priceRaw = document.getElementById('per_km_price_raw');
                const priceDisplay = document.getElementById('per_km_price_display');

                function formatNumber(num) {
                    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function parseNumber(str) {
                    return parseFloat(str.replace(/,/g, '')) || 0;
                }

                priceInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/,/g, '');
                    if (value === '') {
                        value = '0';
                    }
                    const numValue = parseFloat(value) || 0;
                    priceRaw.value = numValue;
                    priceInput.value = formatNumber(Math.floor(numValue));
                    priceDisplay.textContent = formatNumber(Math.floor(numValue));
                });

                // Initialize on page load
                if (priceInput.value) {
                    const numValue = parseNumber(priceInput.value);
                    priceRaw.value = numValue;
                    priceInput.value = formatNumber(Math.floor(numValue));
                    priceDisplay.textContent = formatNumber(Math.floor(numValue));
                }
            });
        </script>
    @endpush
@endsection
