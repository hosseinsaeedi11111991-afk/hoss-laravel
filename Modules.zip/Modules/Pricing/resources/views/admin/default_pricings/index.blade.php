@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">قیمت‌گذاری پیش‌فرض/</a></span>
        لیست قیمت‌ها
    </h4>

    <a href="{{ route('admin.default_pricings.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن قیمت پیش‌فرض</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>قیمت هر کیلومتر</th>
                <th>وضعیت</th>
                <th>تاریخ ایجاد</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($defaultPricings as $key => $defaultPricing)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>
                        <span class="badge bg-primary fs-6">
                            {{ $defaultPricing->getFormattedPrice() }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $defaultPricing->is_active ? 'success' : 'danger' }}">
                            {{ $defaultPricing->is_active ? 'فعال' : 'غیرفعال' }}
                        </span>
                    </td>
                    <td>{{ $defaultPricing->created_at->format('Y/m/d H:i') }}</td>
                    <td>
                        <a href="{{ route('admin.default_pricings.show', $defaultPricing) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.default_pricings.edit', $defaultPricing) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.default_pricings.destroy', $defaultPricing) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $defaultPricings->links('pagination::bootstrap-5') }}
    </div>
@endsection
