@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.default_pricings.index') }}">قیمت‌گذاری پیش‌فرض/</a></span>
        جزئیات قیمت پیش‌فرض
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">جزئیات قیمت‌گذاری پیش‌فرض</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>قیمت هر کیلومتر:</strong>
                    <p>
                        <span class="badge bg-primary fs-6">
                            {{ $defaultPricing->getFormattedPrice() }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>وضعیت:</strong>
                    <p>
                        <span class="badge bg-{{ $defaultPricing->is_active ? 'success' : 'danger' }}">
                            {{ $defaultPricing->is_active ? 'فعال' : 'غیرفعال' }}
                        </span>
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>تاریخ ایجاد:</strong>
                    <p class="text-muted">{{ $defaultPricing->created_at->format('Y/m/d H:i') }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>آخرین بروزرسانی:</strong>
                    <p class="text-muted">{{ $defaultPricing->updated_at->format('Y/m/d H:i') }}</p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (100 کیلومتر):</strong>
                    <p class="text-success fs-5">
                        {{ number_format($defaultPricing->calculatePrice(100)) }} تومان
                    </p>
                </div>

                <div class="col-md-6 mb-3">
                    <strong>مثال محاسبه (50 کیلومتر):</strong>
                    <p class="text-info fs-5">
                        {{ number_format($defaultPricing->calculatePrice(50)) }} تومان
                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('admin.default_pricings.edit', $defaultPricing) }}" class="btn btn-warning">
                <i class="bx bx-edit-alt me-1"></i>ویرایش
            </a>
            <a href="{{ route('admin.default_pricings.index') }}" class="btn btn-secondary">
                <i class="bx bx-arrow-back me-1"></i>بازگشت
            </a>
        </div>
    </div>
@endsection
