<?php
use Modules\Pricing\Http\Controllers\Admin\PricingRuleController;
use Modules\Pricing\Http\Controllers\Admin\CityPricingController;
use Modules\Pricing\Http\Controllers\Admin\DefaultPricingController;
use Modules\Pricing\Http\Controllers\Admin\PricingSeederController;

// Admin routes
Route::prefix('admin')
    ->middleware(['auth', 'role:super_user|admin'])
    ->group(function () {
        Route::get('pricing_rules/cities/{provinceId}', [PricingRuleController::class, 'getCities'])->name('admin.pricing_rules.cities');
        Route::get('pricing_rules/bulk/create', [PricingRuleController::class, 'bulkCreate'])->name('admin.pricing_rules.bulk.create');
        Route::post('pricing_rules/bulk/store', [PricingRuleController::class, 'bulkStore'])->name('admin.pricing_rules.bulk.store');
        Route::get('pricing_rules/bulk/edit', [PricingRuleController::class, 'bulkEdit'])->name('admin.pricing_rules.bulk.edit');
        Route::post('pricing_rules/bulk/update', [PricingRuleController::class, 'bulkUpdate'])->name('admin.pricing_rules.bulk.update');
        Route::get('pricing_rules/bulk/delete', [PricingRuleController::class, 'bulkDelete'])->name('admin.pricing_rules.bulk.delete');
        Route::delete('pricing_rules/bulk/destroy', [PricingRuleController::class, 'bulkDestroy'])->name('admin.pricing_rules.bulk.destroy');
        Route::resource('pricing_rules', PricingRuleController::class)->names('admin.pricing_rules');
        Route::resource('city_pricings', CityPricingController::class)->names('admin.city_pricings');
        Route::resource('default_pricings', DefaultPricingController::class)->names('admin.default_pricings');

        // Route برای اجرای Seeder
        Route::get('pricing-rules/run-seeder', [PricingSeederController::class, 'runSeeder'])
            ->name('admin.pricing_rules.run_seeder');
    });
