<?php

use Illuminate\Support\Facades\Route;
use Modules\Pricing\Http\Controllers\PricingController;
use Modules\Pricing\Http\Controllers\Admin\PricingRuleController;
use Modules\Pricing\Http\Controllers\Admin\CityPricingController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('pricings', PricingController::class)->names('pricing');
});

require_once 'admin.php';
