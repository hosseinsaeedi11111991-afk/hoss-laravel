<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('city_pricings', function (Blueprint $table) {
            $table->id();
            $table->string('city_name')->unique();
            $table->foreignId('car_category_id')->unsigned()->nullable()->constrained('car_categories')->nullOnDelete();
            $table->decimal('per_km_price', 20, 2)->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('city_pricings');
    }
};
