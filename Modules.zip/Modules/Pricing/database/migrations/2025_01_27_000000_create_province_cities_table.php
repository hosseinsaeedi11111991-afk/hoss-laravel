<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('province_cities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unsigned()->default(1)->constrained('users')->onDelete('restrict');
            $table->integer('parent')->default(0);
            $table->string('title', 100);
            $table->unsignedTinyInteger('sort')->default(1);
            $table->softDeletes();
            $table->timestamps();

            $table->index('parent');
            $table->index('sort');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('province_cities');
    }
};
