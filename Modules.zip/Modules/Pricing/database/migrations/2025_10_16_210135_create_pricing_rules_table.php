<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pricing_rules', function (Blueprint $table) {
            $table->id();
            $table->string('origin_city');
            $table->string('destination_city');
            $table->foreignId('car_category_id')->unsigned()->nullable()->constrained('car_categories')->nullOnDelete();
            $table->decimal('fixed_price', 20, 2)->default(0);
            $table->decimal('per_km_price', 20, 2)->default(0);
            $table->enum('pricing_type', ['fixed', 'per_km'])->default('fixed');
            $table->enum('priority', ['high', 'medium', 'low'])->default('medium');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pricing_rules');
    }
};
