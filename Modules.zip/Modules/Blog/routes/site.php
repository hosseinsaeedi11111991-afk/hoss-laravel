<?php

use Illuminate\Support\Facades\Route;
use Modules\Blog\Http\Controllers\site\BlogController;

Route::name('blog.')->group(function () {
    Route::get('/blog-category', [BlogController::class, 'index'])->name('index');
    Route::post('/comment', [BlogController::class, 'storeComment'])->name('comment.store');
    Route::get('/tag/{slug}', [BlogController::class, 'tag'])->name('tag');
    Route::get('/مقالات', [BlogController::class, 'category'])->name('category');
    Route::get('/{slug}', [BlogController::class, 'show'])->name('show');
});
