<?php
// routes/web.php   (or: Modules/Blog/Routes/web.php if you use a module-skeleton)
// Add this inside the existing admin-panel group
// All routes are automatically wrapped by web + auth middleware and prefixed with /admin-panel

use Modules\Blog\Http\Controllers\admin\{
    BlogPostController,
    BlogPostCategoryController,
    BlogTagController,
    BlogCommentController,
    BlogRatingController,
    BlogLikeController,
    BlogSaveController,
    BlogSeoController
};
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')
    ->group(function () {

        /* ----------------------------------------------------------
         | Blog Post CRUD
         | ---------------------------------------------------------- */

        /*---  واردات از وردپرس (قبل از resource تا override نشود)  ---*/
        Route::get('blog-posts/import', [BlogPostController::class, 'importForm'])
            ->name('admin.blog-post.import');
        Route::post('blog-posts/test-connection', [BlogPostController::class, 'testWordPressConnection'])
            ->name('admin.blog-post.test-connection');
        Route::post('blog-posts/fetch-posts', [BlogPostController::class, 'fetchWordPressPosts'])
            ->name('admin.blog-post.fetch-posts');
        Route::post('blog-posts/import-posts', [BlogPostController::class, 'importWordPressPosts'])
            ->name('admin.blog-post.import-posts');

        Route::resource('blog-posts', BlogPostController::class)
            ->names([
                'index'   => 'admin.blog-post.index',
                'create'  => 'admin.blog-post.create',
                'store'   => 'admin.blog-post.store',
                'show'    => 'admin.blog-post.show',
                'edit'    => 'admin.blog-post.edit',
                'update'  => 'admin.blog-post.update',
                'destroy' => 'admin.blog-post.destroy',
            ]);

        /*---  تغییر وضعیت فوری (is_active / is_commentable)  ---*/
        Route::post('blog_posts/toggle-status', [BlogPostController::class, 'toggleStatus'])
            ->name('admin.blog-post.toggle.status');

        /*---  آپلود تصویر درون CKEditor  ---*/
        Route::post('blog_posts/upload-image-article', [BlogPostController::class, 'uploadImageArticle'])
            ->name('admin.blog-post.uploadImageArticle');


        /* ----------------------------------------------------------
         | Blog Post-Category CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-post-categories', BlogPostCategoryController::class)
            ->names([
                'index'   => 'admin.blog-post-category.index',
                'create'  => 'admin.blog-post-category.create',
                'store'   => 'admin.blog-post-category.store',
                'show'    => 'admin.blog-post-category.show',
                'edit'    => 'admin.blog-post-category.edit',
                'update'  => 'admin.blog-post-category.update',
                'destroy' => 'admin.blog-post-category.destroy',
            ]);

        /* ----------------------------------------------------------
         | Blog Tag CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-tags', BlogTagController::class)
            ->names([
                'index'   => 'admin.blog-tag.index',
                'create'  => 'admin.blog-tag.create',
                'store'   => 'admin.blog-tag.store',
                'show'    => 'admin.blog-tag.show',
                'edit'    => 'admin.blog-tag.edit',
                'update'  => 'admin.blog-tag.update',
                'destroy' => 'admin.blog-tag.destroy',
            ]);

        /* ----------------------------------------------------------
         | Blog Comment CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-comments', BlogCommentController::class)
            ->names([
                'index'   => 'admin.blog-comment.index',
                'create'  => 'admin.blog-comment.create',
                'store'   => 'admin.blog-comment.store',
                'show'    => 'admin.blog-comment.show',
                'edit'    => 'admin.blog-comment.edit',
                'update'  => 'admin.blog-comment.update',
                'destroy' => 'admin.blog-comment.destroy',
            ]);
        Route::post('blog-comments/toggle-status', [BlogCommentController::class, 'toggleStatus'])
            ->name('admin.blog-comment.toggle.status');

        Route::get('blog-comments/{blogComment}/reply', [BlogCommentController::class, 'replyForm'])
            ->name('admin.blog-comment.reply');
        /* ----------------------------------------------------------
         | Blog Rating CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-ratings', BlogRatingController::class)
            ->names([
                'index'   => 'admin.blog-rating.index',
                'create'  => 'admin.blog-rating.create',
                'store'   => 'admin.blog-rating.store',
                'show'    => 'admin.blog-rating.show',
                'edit'    => 'admin.blog-rating.edit',
                'update'  => 'admin.blog-rating.update',
                'destroy' => 'admin.blog-rating.destroy',
            ]);

        /* ----------------------------------------------------------
         | Blog Like CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-likes', BlogLikeController::class)
            ->names([
                'index'   => 'admin.blog-like.index',
                'create'  => 'admin.blog-like.create',
                'store'   => 'admin.blog-like.store',
                'show'    => 'admin.blog-like.show',
                'edit'    => 'admin.blog-like.edit',
                'update'  => 'admin.blog-like.update',
                'destroy' => 'admin.blog-like.destroy',
            ]);

        /* ----------------------------------------------------------
         | Blog Save (Bookmark) CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-saves', BlogSaveController::class)
            ->names([
                'index'   => 'admin.blog_save.index',
                'create'  => 'admin.blog_save.create',
                'store'   => 'admin.blog_save.store',
                'show'    => 'admin.blog_save.show',
                'edit'    => 'admin.blog_save.edit',
                'update'  => 'admin.blog_save.update',
                'destroy' => 'admin.blog_save.destroy',
            ]);

        /* ----------------------------------------------------------
         | Blog SEO (per post) CRUD
         | ---------------------------------------------------------- */
        Route::resource('blog-seo', BlogSeoController::class)
            ->names([
                'index'   => 'admin.blog-seo.index',
                'create'  => 'admin.blog-seo.create',
                'store'   => 'admin.blog-seo.store',
                'show'    => 'admin.blog-seo.show',
                'edit'    => 'admin.blog-seo.edit',
                'update'  => 'admin.blog-seo.update',
                'destroy' => 'admin.blog-seo.destroy',
            ]);
    });
