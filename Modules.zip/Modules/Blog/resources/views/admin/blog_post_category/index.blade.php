@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-post-category.index') }}">دسته‌بندی مقالات/</a></span>
        لیست دسته‌بندی‌ها
    </h4>

    <a href="{{ route('admin.blog-post-category.create') }}" class="btn rounded-pill btn-success mb-3">ایجاد دسته‌بندی جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>نام</th>
                <th>اسلاگ فارسی</th>
                <th>اسلاگ انگلیسی</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($categories as $key => $category)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $category->name }}</td>
                    <td>{{ $category->fa_slug }}</td>
                    <td>{{ $category->en_slug }}</td>
                    <td>
                        <div class="btn-group flex-wrap gap-2" role="group" aria-label="Actions">
                            <a href="{{ route('admin.blog-post-category.show', $category) }}" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>

                            <a href="{{ route('admin.blog-post-category.edit', $category) }}" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>

                            <form method="POST" action="{{ route('admin.blog-post-category.destroy', $category) }}"  class="d-inline delete-form">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $categories->links('pagination::bootstrap-5') }}
    </div>
@endsection
