@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-post-category.index') }}">دسته‌بندی مقالات/</a></span>
        مشاهده دسته‌بندی
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات دسته‌بندی</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>نام:</strong> {{ $blogPostCategory->name }}</li>
                        <li class="list-group-item"><strong>اسلاگ فارسی:</strong> {{ $blogPostCategory->fa_slug }}</li>
                        <li class="list-group-item"><strong>اسلاگ انگلیسی:</strong> {{ $blogPostCategory->en_slug }}</li>
                        <li class="list-group-item"><strong>توضیحات:</strong> {{ $blogPostCategory->description ?? 'بدون توضیحات' }}</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($blogPostCategory->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($blogPostCategory->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
