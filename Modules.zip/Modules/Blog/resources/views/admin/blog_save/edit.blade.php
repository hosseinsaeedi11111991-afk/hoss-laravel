@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog_save.index') }}">ذخیره‌ها/</a></span>
        ویرایش ذخیره
    </h4>

    <form action="{{ route('admin.blog_save.update', $blog_save) }}" method="POST">
        @csrf @method('PUT')
        <div class="mb-3">
            <label class="form-label">کاربر <span class="text-danger">*</span></label>
            <select name="user_id" class="form-select" required>
                @foreach($users as $user)
                    <option value="{{ $user->id }}" {{ old('user_id', $blog_save->user_id) == $user->id ? 'selected' : '' }}>
                        {{ $user->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">پست <span class="text-danger">*</span></label>
            <select name="blog_post_id" class="form-select" required>
                @foreach($posts as $post)
                    <option value="{{ $post->id }}" {{ old('blog_post_id', $blog_save->blog_post_id) == $post->id ? 'selected' : '' }}>
                        {{ $post->title }}
                    </option>
                @endforeach
            </select>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
@endsection
