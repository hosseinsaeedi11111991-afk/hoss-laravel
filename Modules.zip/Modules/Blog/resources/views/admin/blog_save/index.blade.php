@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog_save.index') }}">ذخیره‌ها/</a></span>
        لیست ذخیره‌ها
    </h4>

    <a href="{{ route('admin.blog_save.create') }}" class="btn rounded-pill btn-success mb-3">ایجاد ذخیره جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>کاربر</th>
                <th>پست</th>
                <th>تاریخ</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($blog_saves as $key => $blog_save)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $blog_save->user->name ?? '-' }}</td>
                    <td>{{ $blog_save->post->title ?? '-' }}</td>
                    <td>{{ verta($blog_save->created_at)->format('Y/m/d H:i') }}</td>
                    <td>
                        <div class="btn-group flex-wrap gap-2">
                            <a href="{{ route('admin.blog_save.show', $blog_save) }}" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="{{ route('admin.blog_save.edit', $blog_save) }}" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.blog_save.destroy', $blog_save) }}" class="delete-form d-inline">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $blog_saves->links('pagination::bootstrap-5') }}
    </div>
@endsection
