@extends('Shared::layouts.admin.main')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{route('admin.blog-post.index')}}"> مقالات/</a></span>
        واردات از وردپرس
    </h4>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">واردات پست‌های وردپرس</h5>
        </div>
        <div class="card-body">
            <!-- فرم اتصال -->
            <div class="mb-4">
                <h6 class="mb-3">اطلاعات اتصال به وردپرس</h6>
                <form id="connection-form">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label" for="wordpress_url">آدرس سایت وردپرس <span class="text-danger">*</span></label>
                            <input type="url" class="form-control" id="wordpress_url" name="wordpress_url" 
                                   placeholder="https://example.com" required>
                            <small class="text-muted">آدرس کامل سایت وردپرس (مثال: https://example.com)</small>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label" for="username">نام کاربری (اختیاری)</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="نام کاربری">
                            <small class="text-muted">در صورت نیاز به احراز هویت</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="password">رمز عبور (اختیاری)</label>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="رمز عبور">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="application_password">Application Password (اختیاری)</label>
                            <input type="password" class="form-control" id="application_password" name="application_password" 
                                   placeholder="Application Password">
                            <small class="text-muted">برای امنیت بیشتر از Application Password استفاده کنید</small>
                        </div>
                    </div>
                    <button type="button" id="test-connection-btn" class="btn btn-primary">
                        <i class="bx bx-link"></i> تست اتصال
                    </button>
                </form>
                <div id="connection-status" class="mt-3"></div>
            </div>

            <hr>

            <!-- انتخاب دسته‌بندی پیش‌فرض -->
            <div class="mb-4">
                <h6 class="mb-3">دسته‌بندی پیش‌فرض</h6>
                <div class="row">
                    <div class="col-md-6">
                        <label class="form-label" for="default_category_id">دسته‌بندی <span class="text-danger">*</span></label>
                        <select class="form-select" id="default_category_id" name="default_category_id" required>
                            <option value="">انتخاب کنید</option>
                            @foreach($categories as $category)
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>

            <hr>

            <!-- لیست پست‌ها -->
            <div id="posts-section" style="display: none;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0">لیست پست‌های وردپرس</h6>
                    <div>
                        <button type="button" id="select-all-btn" class="btn btn-sm btn-outline-primary">
                            انتخاب همه
                        </button>
                        <button type="button" id="deselect-all-btn" class="btn btn-sm btn-outline-secondary">
                            لغو انتخاب همه
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th width="50">
                                    <input type="checkbox" id="select-all-checkbox">
                                </th>
                                <th>عنوان</th>
                                <th>تاریخ</th>
                                <th>خلاصه</th>
                            </tr>
                        </thead>
                        <tbody id="posts-table-body">
                        </tbody>
                    </table>
                </div>

                <div id="pagination-section" class="mt-3"></div>

                <div class="mt-4">
                    <button type="button" id="import-btn" class="btn btn-success" disabled>
                        <i class="bx bx-import"></i> واردات پست‌های انتخاب شده
                    </button>
                </div>
            </div>

            <!-- نتایج واردات -->
            <div id="import-results" class="mt-4" style="display: none;"></div>
        </div>
    </div>

    @section('script')
    <script>
        let currentPage = 1;
        let totalPages = 1;
        let connectionData = {};

        // تست اتصال
        document.getElementById('test-connection-btn').addEventListener('click', function() {
            const btn = this;
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>در حال اتصال...';

            const formData = {
                wordpress_url: document.getElementById('wordpress_url').value,
                username: document.getElementById('username').value,
                password: document.getElementById('password').value,
                application_password: document.getElementById('application_password').value,
            };

            fetch('{{ route("admin.blog-post.test-connection") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                btn.disabled = false;
                btn.innerHTML = originalText;

                const statusDiv = document.getElementById('connection-status');
                if (data.status === 'success') {
                    statusDiv.innerHTML = `
                        <div class="alert alert-success">
                            <i class="bx bx-check-circle"></i> ${data.message}
                            <br><small>تعداد کل پست‌ها: ${data.total_posts}</small>
                        </div>
                    `;
                    connectionData = formData;
                    loadPosts(1);
                } else {
                    statusDiv.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="bx bx-error-circle"></i> ${data.message}
                        </div>
                    `;
                }
            })
            .catch(error => {
                btn.disabled = false;
                btn.innerHTML = originalText;
                document.getElementById('connection-status').innerHTML = `
                    <div class="alert alert-danger">
                        <i class="bx bx-error-circle"></i> خطا در اتصال: ${error.message}
                    </div>
                `;
            });
        });

        // بارگذاری پست‌ها
        function loadPosts(page) {
            if (!connectionData.wordpress_url) {
                return;
            }

            const loadingHtml = `
                <tr>
                    <td colspan="4" class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">در حال بارگذاری...</span>
                        </div>
                    </td>
                </tr>
            `;
            document.getElementById('posts-table-body').innerHTML = loadingHtml;

            const formData = {
                ...connectionData,
                page: page,
                per_page: 20
            };

            fetch('{{ route("admin.blog-post.fetch-posts") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    currentPage = data.pagination.current_page;
                    totalPages = data.pagination.total_pages;

                    let tableHtml = '';
                    if (data.posts.length === 0) {
                        tableHtml = `
                            <tr>
                                <td colspan="4" class="text-center text-muted">پستی یافت نشد</td>
                            </tr>
                        `;
                    } else {
                        data.posts.forEach(post => {
                            const date = new Date(post.date).toLocaleDateString('fa-IR');
                            tableHtml += `
                                <tr>
                                    <td>
                                        <input type="checkbox" class="post-checkbox" value="${post.id}" data-title="${post.title}">
                                    </td>
                                    <td>${post.title}</td>
                                    <td>${date}</td>
                                    <td>${post.excerpt.substring(0, 100)}...</td>
                                </tr>
                            `;
                        });
                    }
                    document.getElementById('posts-table-body').innerHTML = tableHtml;
                    document.getElementById('posts-section').style.display = 'block';
                    renderPagination();
                    updateImportButton();
                } else {
                    document.getElementById('posts-table-body').innerHTML = `
                        <tr>
                            <td colspan="4" class="text-center text-danger">${data.message}</td>
                        </tr>
                    `;
                }
            })
            .catch(error => {
                document.getElementById('posts-table-body').innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center text-danger">خطا: ${error.message}</td>
                    </tr>
                `;
            });
        }

        // رندر pagination
        function renderPagination() {
            if (totalPages <= 1) {
                document.getElementById('pagination-section').innerHTML = '';
                return;
            }

            let paginationHtml = '<nav><ul class="pagination justify-content-center">';
            
            // دکمه قبلی
            if (currentPage > 1) {
                paginationHtml += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" onclick="loadPosts(${currentPage - 1})">قبلی</a>
                    </li>
                `;
            }

            // شماره صفحات
            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                    paginationHtml += `
                        <li class="page-item ${i === currentPage ? 'active' : ''}">
                            <a class="page-link" href="javascript:void(0)" onclick="loadPosts(${i})">${i}</a>
                        </li>
                    `;
                } else if (i === currentPage - 3 || i === currentPage + 3) {
                    paginationHtml += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
            }

            // دکمه بعدی
            if (currentPage < totalPages) {
                paginationHtml += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" onclick="loadPosts(${currentPage + 1})">بعدی</a>
                    </li>
                `;
            }

            paginationHtml += '</ul></nav>';
            document.getElementById('pagination-section').innerHTML = paginationHtml;
        }

        // انتخاب/لغو انتخاب همه
        document.getElementById('select-all-checkbox').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.post-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
            updateImportButton();
        });

        document.getElementById('select-all-btn').addEventListener('click', function() {
            document.querySelectorAll('.post-checkbox').forEach(cb => cb.checked = true);
            document.getElementById('select-all-checkbox').checked = true;
            updateImportButton();
        });

        document.getElementById('deselect-all-btn').addEventListener('click', function() {
            document.querySelectorAll('.post-checkbox').forEach(cb => cb.checked = false);
            document.getElementById('select-all-checkbox').checked = false;
            updateImportButton();
        });

        // به‌روزرسانی وضعیت دکمه واردات
        function updateImportButton() {
            const checked = document.querySelectorAll('.post-checkbox:checked');
            const importBtn = document.getElementById('import-btn');
            const categoryId = document.getElementById('default_category_id').value;

            if (checked.length > 0 && categoryId) {
                importBtn.disabled = false;
            } else {
                importBtn.disabled = true;
            }
        }

        // گوش دادن به تغییرات checkbox ها
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('post-checkbox')) {
                updateImportButton();
                // به‌روزرسانی checkbox اصلی
                const allChecked = document.querySelectorAll('.post-checkbox:checked').length === document.querySelectorAll('.post-checkbox').length;
                document.getElementById('select-all-checkbox').checked = allChecked;
            }
            if (e.target.id === 'default_category_id') {
                updateImportButton();
            }
        });

        // واردات پست‌ها
        document.getElementById('import-btn').addEventListener('click', function() {
            const checked = document.querySelectorAll('.post-checkbox:checked');
            if (checked.length === 0) {
                alert('لطفاً حداقل یک پست انتخاب کنید');
                return;
            }

            const categoryId = document.getElementById('default_category_id').value;
            if (!categoryId) {
                alert('لطفاً دسته‌بندی پیش‌فرض را انتخاب کنید');
                return;
            }

            const postIds = Array.from(checked).map(cb => parseInt(cb.value));

            if (!confirm(`آیا از واردات ${postIds.length} پست مطمئن هستید؟`)) {
                return;
            }

            const btn = this;
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>در حال واردات...';

            const formData = {
                ...connectionData,
                post_ids: postIds,
                default_category_id: parseInt(categoryId)
            };

            fetch('{{ route("admin.blog-post.import-posts") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                btn.disabled = false;
                btn.innerHTML = originalText;

                const resultsDiv = document.getElementById('import-results');
                resultsDiv.style.display = 'block';

                if (data.status === 'success') {
                    let html = `
                        <div class="alert alert-success">
                            <h6><i class="bx bx-check-circle"></i> ${data.message}</h6>
                        </div>
                    `;

                    if (data.imported && data.imported.length > 0) {
                        html += `
                            <div class="alert alert-info">
                                <strong>پست‌های وارد شده (${data.imported.length}):</strong>
                                <ul class="mb-0 mt-2">
                        `;
                        data.imported.forEach(post => {
                            html += `<li>${post.title}</li>`;
                        });
                        html += `</ul></div>`;
                    }

                    if (data.failed && data.failed.length > 0) {
                        html += `
                            <div class="alert alert-warning">
                                <strong>پست‌های ناموفق (${data.failed.length}):</strong>
                                <ul class="mb-0 mt-2">
                        `;
                        data.failed.forEach(post => {
                            html += `<li>${post.title}: ${post.reason}</li>`;
                        });
                        html += `</ul></div>`;
                    }

                    resultsDiv.innerHTML = html;

                    // رفرش لیست پست‌ها
                    setTimeout(() => {
                        loadPosts(currentPage);
                    }, 2000);
                } else {
                    resultsDiv.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="bx bx-error-circle"></i> ${data.message}
                        </div>
                    `;
                }
            })
            .catch(error => {
                btn.disabled = false;
                btn.innerHTML = originalText;
                document.getElementById('import-results').innerHTML = `
                    <div class="alert alert-danger">
                        <i class="bx bx-error-circle"></i> خطا: ${error.message}
                    </div>
                `;
                document.getElementById('import-results').style.display = 'block';
            });
        });
    </script>
    @append
@endsection

