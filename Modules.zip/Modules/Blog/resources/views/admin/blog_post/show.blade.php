@extends('Shared::layouts.admin.main')

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-post.index') }}"> مقالات/</a></span>
        نمایش مقاله
    </h4>

    <div class="card">
        <div class="card-body">
            <h2>{{ $blog_post->title }}</h2>
            <p><strong>نامک فارسی:</strong> {{ $blog_post->fa_slug }}</p>
            <p><strong>نامک انگلیسی:</strong> {{ $blog_post->en_slug }}</p>
            <p><strong>خلاصه:</strong> {{ $blog_post->summary }}</p>
            <p><strong>محتوا:</strong></p>
            <div>{!! $blog_post->body !!}</div>

            <p><strong>تصویر شاخص:</strong></p>
            @if($blog_post->thumbnail)
                <img src="{{ asset('storage/' . $blog_post->thumbnail) }}" alt="تصویر شاخص" style="max-width: 300px; max-height: 200px;">
                <p>نامک تصویر شاخص: {{ $blog_post->thumbnail_tag }}</p>
            @else
                <p>تصویر شاخص وجود ندارد</p>
            @endif

            <p><strong>تصویر اصلی:</strong></p>
            @if($blog_post->image)
                <img src="{{ asset('storage/' . $blog_post->image) }}" alt="تصویر اصلی" style="max-width: 300px; max-height: 200px;">
                <p>نامک تصویر اصلی: {{ $blog_post->image_tag }}</p>
            @else
                <p>تصویر اصلی وجود ندارد</p>
            @endif

            <p><strong>وضعیت نمایش:</strong> {{ $blog_post->is_active ? 'فعال' : 'غیرفعال' }}</p>
            <p><strong>قابل کامنت گذاری:</strong> {{ $blog_post->is_commentable ? 'بله' : 'خیر' }}</p>
            <p><strong>وضعیت کلی:</strong> {{ $blog_post->status }}</p>
            <p><strong>تاریخ نمایش:</strong> {{ verta($blog_post->published_at)->format('Y-n-j H:i:s') }}</p>

            <p><strong>دسته بندی:</strong> {{ $blog_post->category->name ?? '-' }}</p>

            <p><strong>تگ ها:</strong>
                @foreach($blog_post->tags as $tag)
                    <span class="badge bg-primary">{{ $tag->tag_title }}</span>
                @endforeach
            </p>

            <hr>

            <h4>SEO</h4>
            <p><strong>نام صفحه (title):</strong> {{ $seo->title }}</p>
            <p><strong>کلمه کلیدی:</strong> {{ $seo->focus_keyword }}</p>
            <p><strong>توضیحات:</strong> {{ $seo->description }}</p>
            <p><strong>schema_markup:</strong></p>
            <pre>{{ $seo->schema_markup }}</pre>
            <p><strong>کلمات کلیدی:</strong> {{ $seo->keywords }}</p>
            <p><strong>مدت زمان مطالعه:</strong> {{ $seo->reading_time }}</p>

            <a href="{{ route('admin.blog-post.edit', $blog_post->id) }}" class="btn btn-warning mt-3">ویرایش مقاله</a>
            <a href="{{ route('admin.blog-post.index') }}" class="btn btn-secondary mt-3">بازگشت به لیست</a>
        </div>
    </div>
@endsection
