@extends('Shared::layouts.admin.main')

@section('css')
    <style>
        .toggle-switch-icon {
            position: relative;
            display: inline-block;
            width: 45px;
            height: 20px;
            border-radius: 34px;
            background-color: #e9ecef;
            overflow: hidden;
        }

        .toggle-switch-icon input[type="radio"] {
            display: none;
        }

        .toggle-label-icon {
            position: absolute;
            width: 50%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 2;
            color: #495057;
            transition: all 0.3s;
        }

        .toggle-label-icon:first-of-type {
            left: 0;
        }

        .toggle-label-icon:last-of-type {
            right: 0;
        }

        .toggle-slider-icon {
            position: absolute;
            width: 50%;
            height: 100%;
            background-color: #4CAF50;
            border-radius: 34px;
            z-index: 1;
            transition: all 0.3s;
            left: 0;
        }

        #commentable_no:checked ~ .toggle-slider-icon {
            left: 50%;
            background-color: #dc3545;
        }

        #status_no:checked ~ .toggle-slider-icon {
            left: 50%;
            background-color: #dc3545;
        }

        #commentable_yes:checked ~ .toggle-label-icon:first-of-type,
        #commentable_no:checked ~ .toggle-label-icon:last-of-type {
            color: white;
        }

        #status_yes:checked ~ .toggle-label-icon:first-of-type,
        #status_no:checked ~ .toggle-label-icon:last-of-type {
            color: white;
        }
    </style>
@endSection

@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">

        <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{route('admin.blog-post.index')}}"> مقالات/</a></span>
        ویرایش مقاله

    </h4>
    <form action="{{route('admin.blog-post.update',['blog_post'=>$blog_post->id])}}" method="POST" enctype="multipart/form-data">
        @method('put')
        @csrf
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="title">عنوان<i class='bx bx-health font-size-1 text-danger mx-2'></i></label>
                <div class="input-group input-group-merge">
                    <span id="title" class="input-group-text"><i class='bx bxs-rename'></i></span>
                    <input type="text" class="form-control" value="{{$blog_post->title}}" id="title" name="title" placeholder="عنوان مقاله " aria-label="John Doe" aria-describedby="basic-icon-default-fullname2">
                </div>
            </div>

        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="fa_slug">نامک فارسی</label>
                <div class="input-group input-group-merge">
                    <span id="fa_slug" class="input-group-text"><i class='bx bxl-slack-old'></i></span>
                    <input type="text" class="form-control" value="{{old('fa_slug',$blog_post->fa_slug)}}" id="fa_slug" name="fa_slug" placeholder=" نامک فارسی" aria-label="John Doe" aria-describedby="basic-icon-default-fullname2">
                </div>
            </div>
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="en_slug">نامک انگلیسی</label>
                <div class="input-group input-group-merge">
                    <span id="en_slug" class="input-group-text"><i class='bx bxl-slack-old'></i></span>
                    <input type="text" class="form-control" value="{{old('en_slug',$blog_post->en_slug)}}" id="en_slug" name="en_slug" placeholder=" نامک انگلیسی" aria-label="John Doe" aria-describedby="basic-icon-default-fullname2">
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-12">
                <label class="form-label" for="summary">خلاصه<i class='bx bx-health font-size-1 text-danger mx-2'></i></label>
                <div class="input-group input-group-merge">
                    <span id="summary" class="input-group-text"><i class='bx bx-text'></i></span>
                    <textarea id="summary" rows="3" class="form-control" name="summary" aria-label="Hi, Do you have a moment to talk Joe?" aria-describedby="basic-icon-default-message2">{{$blog_post->summary}}</textarea>
                </div>
            </div>

        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-12">
                <label class="form-label" for="editor">محتوا<i class='bx bx-health font-size-1 text-danger mx-2'></i></label>
                <textarea id="editor"  class="form-control " name="body"  >{{$blog_post->body}}</textarea>
            </div>

        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="thumbnail">تصویر شاخص <i class='bx bx-health font-size-1 text-danger mx-2'></i></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class='bx bx-image'></i></span>
                    <input type="file" class="form-control image-upload-input" id="thumbnail" name="thumbnail" accept="image/*" style="display: none;">
                    <input type="text" class="form-control image-placeholder" placeholder="@if(empty($blog_post->image)) تصویر شاخص انتخاب نشده @else عکس موجود است @endif" readonly>
                    <button class="btn btn-outline-secondary" type="button" onclick="openImagePicker('thumbnail')">انتخاب تصویر</button>
                </div>
                <div class="image-preview-container mt-3" style="display: @if(empty($blog_post->thumbnail)) none @else block @endif;">
                    <img class="image-preview img-thumbnail" src="{{ asset('/storage/'.$blog_post->thumbnail) }}" style="max-width: 200px; max-height: 150px;">
                </div>
            </div>
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="thumbnail_tag">نامک عکس شاخص</label>
                <div class="input-group input-group-merge">
                    <span id="thumbnail_tag" class="input-group-text"><i class='bx bx-purchase-tag-alt'></i></span>
                    <input type="text" class="form-control" value="{{$blog_post->thumbnail_tag}}" id="thumbnail_tag" name="thumbnail_tag" placeholder="نامک عکس شاخص " aria-label="John Doe" aria-describedby="basic-icon-default-fullname2">
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="image">تصویر اصلی <i class='bx bx-health font-size-1 text-danger mx-2'></i></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class='bx bx-image'></i></span>
                    <input type="file" class="form-control image-upload-input" id="image" name="image" accept="image/*" style="display: none;">
                    <input type="text" class="form-control image-placeholder" placeholder="@if(empty($blog_post->image)) تصویر اصلی انتخاب نشده @else عکس موجود است @endif" readonly>
                    <button class="btn btn-outline-secondary" type="button" onclick="openImagePicker('image')">انتخاب تصویر</button>
                </div>
                <div class="image-preview-container mt-3" style="display: @if(empty($blog_post->image)) none @else block @endif;">
                    <img class="image-preview img-thumbnail" src="{{ asset('/storage/'.$blog_post->image) }}" style="max-width: 200px; max-height: 150px;">
                </div>
            </div>
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="image_tag">نامک عکس اصلی</label>
                <div class="input-group input-group-merge">
                    <span id="image_tag" class="input-group-text"><i class='bx bx-purchase-tag-alt'></i></span>
                    <input type="text" class="form-control" value="{{$blog_post->image_tag}}" id="image_tag" name="image_tag" placeholder="نامک عکس اصلی " aria-label="John Doe" aria-describedby="basic-icon-default-fullname2">
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">

            <div class="col-6 px-4 col-md-3">

                <div class="  form-label  mb-3">  نمایش </div>
                <div class="toggle-switch-icon">
                    <input type="radio" name="is_active" id="status_yes" value="1" @if($blog_post->is_active == 1) checked @endif>
                    <label for="status_yes" class="toggle-label-icon">
                        <i class="bx bx-check"></i>
                    </label>

                    <input type="radio" name="is_active" id="status_no" value="0" @if($blog_post->is_active == 0) checked @endif>
                    <label for="status_no" class="toggle-label-icon">
                        <i class="bx bx-x"></i>
                    </label>

                    <span class="toggle-slider-icon"></span>
                </div>
            </div>
            <div class="col-6 px-4 col-md-3">
                <div class="  form-label  mb-3">قابل کامنت گذاری</div>
                <div class="toggle-switch-icon">
                    <input type="radio" name="is_commentable" id="commentable_yes" value="1" @if($blog_post->is_commentable == 1) checked @endif>
                    <label for="commentable_yes" class="toggle-label-icon">
                        <i class="bx bx-check"></i>
                    </label>

                    <input type="radio" name="is_commentable" id="commentable_no" value="0" @if($blog_post->is_commentable == 0) checked @endif>
                    <label for="commentable_no" class="toggle-label-icon">
                        <i class="bx bx-x"></i>
                    </label>

                    <span class="toggle-slider-icon"></span>
                </div>
            </div>
            <div class="col-12 px-4 col-md-6">
                <div class="mb-3">
                    <label for="select2Basic" class="form-label">وضعیت کلی</label>
                    <select name="status" id="select2Basic" class="select2 form-select form-select-lg" data-allow-clear="true">
                        <option @if($blog_post->status == 'draft') selected @endif value="draft">پیش‌نویس</option>
                        <option @if($blog_post->status == 'published') selected @endif value="published">انتشار یافته</option>
                        <option @if($blog_post->status == 'archived') selected @endif value="archived">آرشیو شده</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <div class="mb-3">
                    <label for="select2Basic" class="form-label">انتخواب دسته بندی</label>
                    <select name="blog_post_category_id" id="select2Basic" class="select2 form-select form-select-lg" data-allow-clear="true">
                        @foreach($categories as $category)
                            <option @if($blog_post->blog_post_category_id == $category->id) selected @endif value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-6 col-12 mb-4">
                <label for="flatpickr-datetime" class="form-label">تاریخ نمایش</label>
                <input type="text" name="published_at" class="form-control flatpickr-input" id="flatpickr-datetime" value="{{ verta($blog_post->published_at)->format('Y-n-j H:i:s') }}">
            </div>
        </div>
        <div class="col-12 px-4 col-md-6">
            @include('Shared::layouts.admin.components.inputs.select2Multiple',['update'=>$blog_post->tags,'data'=>$tags,'modeName'=>'tag_title','name'=>'tag-title','labelName'=>'تگ ها','is_required'=>''])
        </div>
        <div class="border-bottom"></div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <h3>SEO</h3>
            </div>
        </div>

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="SEO-title">
                    نام صفحه (title)
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span id="SEO-title" class="input-group-text"><i class='bx bxs-rename'></i></span>
                    <input type="text" class="form-control" value="{{ old('SEO-title',$seo->title) }}" id="SEO-title" name="SEO-title" placeholder="نام صفحه">
                </div>
            </div>

            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="focus_keyword">
                    کلمه کلیدی
                </label>
                <div class="input-group input-group-merge">
                    <span id="focus_keyword" class="input-group-text"><i class='bx bxl-slack-old'></i></span>
                    <input type="text" class="form-control" value="{{ old('focus_keyword',$seo->focus_keyword) }}" id="focus_keyword" name="focus_keyword" placeholder="کلمه کلیدی">
                </div>
            </div>
        </div>

        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-12">
                <label class="form-label" for="description">
                    توضیحات
                    <i class='bx bx-health font-size-1 text-danger mx-2'></i>
                </label>
                <div class="input-group input-group-merge">
                    <span id="description" class="input-group-text"><i class='bx bx-text'></i></span>
                    <textarea id="description" rows="3" class="form-control" name="description">{{ old('description',$seo->description) }}</textarea>
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-12">
                <label class="form-label" for="schema_markup">
                    schema_markup
                </label>
                <div class="input-group input-group-merge">
                    <span id="schema_markup" class="input-group-text"><i class='bx bx-text'></i></span>
                    <textarea id="schema_markup" rows="3" class="form-control" name="schema_markup">{{ old('schema_markup',$seo->schema_markup) }}</textarea>
                </div>
            </div>
        </div>
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 px-4 col-md-6">
                <label class="form-label" for="keywords">
                    کلمات کلیدی
                </label>
                <div class="input-group input-group-merge">
                    <span id="keywords" class="input-group-text"><i class='bx bx-shape-square'></i></span>
                    <input type="text" class="form-control" value="{{ old('keywords',$seo->keywords) }}" id="keywords" name="keywords" placeholder="کلمات کلیدی">
                </div>
            </div>

            <div class="col-md-6 col-12 mb-4">
                <label for="reading_time" class="form-label">
                    مدت زمان مطالعه
                </label>
                <input type="text" name="reading_time" value="{{ old('reading_time',$seo->reading_time) }}" class="form-control flatpickr-input" placeholder="15:00" id="reading_time">
            </div>
        </div>
        <button type="submit" class="btn rounded-pill btn-primary">ارسال</button>
    </form>


    @section('script')
        @include('Shared::layouts.admin.components.editor.ckeditor',['route'=>'admin.blog-post.uploadImageArticle'])
        <script>

            var flatpickrDateTime = document.querySelector("#flatpickr-datetime");
            var flatpickrTime = document.querySelector("#flatpickr-time");

            flatpickrTime.flatpickr({
                enableTime: true,
                noCalendar: true, // غیرفعال کردن تقویم
                dateFormat: "H:i", // فرمت 24 ساعته
                time_24hr: true, // نمایش 24 ساعته
                minuteIncrement: 15 // گام‌های 15 دقیقه‌ای

            });
            flatpickrDateTime.flatpickr({
                enableTime: true,
                dateFormat: "Y-m-d H:i:s",
                locale: "fa", // تنظیم زبان به فارسی
                jalali: true, // فعال‌سازی تقویم جلالی
                time_24hr: true, // نمایش زمان به صورت 24 ساعته

            });

            $(".select2").select2();
            // باز کردن دیالوگ انتخاب تصویر
            function openImagePicker(inputId) {
                document.getElementById(inputId).click();
            }


            // مدیریت پیش‌نمایش برای همه اینپوت‌های تصویر
            document.querySelectorAll('.image-upload-input').forEach(input => {
                input.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    const parentDiv = this.closest('.col-md-6');
                    const placeholder = parentDiv.querySelector('.image-placeholder');
                    const previewContainer = parentDiv.querySelector('.image-preview-container');
                    const preview = parentDiv.querySelector('.image-preview');

                    if (file) {
                        // بررسی نوع فایل
                        if (!file.type.match('image.*')) {
                            alert('لطفاً فقط تصویر انتخاب کنید');
                            return;
                        }

                        // نمایش نام فایل
                        placeholder.value = file.name;

                        // نمایش پیش‌نمایش
                        const reader = new FileReader();

                        reader.onload = function(event) {
                            preview.src = event.target.result;
                            previewContainer.style.display = 'block';
                        }

                        reader.readAsDataURL(file);
                    } else {
                        previewContainer.style.display = 'none';
                        placeholder.value = '';
                    }
                });
            });
        </script>
    @append

@endsection
