@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-tag.index') }}">برچسب‌ها/</a></span>
        ایجاد برچسب جدید
    </h4>

    <form action="{{ route('admin.blog-tag.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label class="form-label">عنوان برچسب <span class="text-danger">*</span></label>
            <input type="text" name="tag_title" class="form-control" value="{{ old('tag_title') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ فارسی <span class="text-danger">*</span></label>
            <input type="text" name="fa_slug" class="form-control" value="{{ old('fa_slug') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">اسلاگ انگلیسی <span class="text-danger">*</span></label>
            <input type="text" name="en_slug" class="form-control" value="{{ old('en_slug') }}" required>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
@endsection
