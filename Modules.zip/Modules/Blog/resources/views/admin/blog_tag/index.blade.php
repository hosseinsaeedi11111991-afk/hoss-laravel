@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-tag.index') }}">برچسب‌ها/</a></span>
        لیست برچسب‌ها
    </h4>

    <a href="{{ route('admin.blog-tag.create') }}" class="btn rounded-pill btn-success mb-3">ایجاد برچسب جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>عنوان برچسب</th>
                <th>اسلاگ فارسی</th>
                <th>اسلاگ انگلیسی</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($tags as $key => $tag)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $tag->tag_title }}</td>
                    <td>{{ $tag->fa_slug }}</td>
                    <td>{{ $tag->en_slug }}</td>
                    <td>
                        <div class="btn-group flex-wrap gap-2" role="group">
                            <a href="{{ route('admin.blog-tag.show', $tag) }}" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="{{ route('admin.blog-tag.edit', $tag) }}" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.blog-tag.destroy', $tag) }}" class="delete-form d-inline">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $tags->links('pagination::bootstrap-5') }}
    </div>
@endsection
