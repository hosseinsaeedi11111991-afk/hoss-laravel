@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-tag.index') }}">برچسب‌ها/</a></span>
        مشاهده برچسب
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات برچسب</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>عنوان:</strong> {{ $blogTag->tag_title }}</li>
                        <li class="list-group-item"><strong>اسلاگ فارسی:</strong> {{ $blogTag->fa_slug }}</li>
                        <li class="list-group-item"><strong>اسلاگ انگلیسی:</strong> {{ $blogTag->en_slug }}</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($blogTag->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($blogTag->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
