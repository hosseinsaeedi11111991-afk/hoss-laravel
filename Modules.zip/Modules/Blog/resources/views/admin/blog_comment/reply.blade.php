@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-comment.index') }}">دیدگاه‌ها/</a></span>
        پاسخ به دیدگاه «{{ $blogComment->name }}»
    </h4>

    <div class="card mb-4">
        <div class="card-body">
            <h6>متن دیدگاه:</h6>
            <blockquote class="blockquote">
                <p>{{ $blogComment->description }}</p>
                <footer class="blockquote-footer">{{ $blogComment->name }} – {{ verta($blogComment->created_at)->format('Y/m/d H:i') }}</footer>
            </blockquote>
        </div>
    </div>

    <form action="{{ route('admin.blog-comment.store') }}" method="POST">
        @csrf

        <!-- hidden parent & post -->
        <input type="hidden" name="blog_post_id" value="{{ $blogComment->blog_post_id }}">
        <input type="hidden" name="parent_id"   value="{{ $blogComment->id }}">

        <div class="mb-3">
            <label class="form-label">نام <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" value="{{ old('name', optional(auth()->user())->name) }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">ایمیل <span class="text-danger">*</span></label>
            <input type="email" name="email" class="form-control" value="{{ old('email', optional(auth()->user())->email) }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">متن پاسخ <span class="text-danger">*</span></label>
            <textarea name="description" class="form-control" rows="4" required>{{ old('description') }}</textarea>
        </div>

        <div class="mb-3 form-check">
            <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}>
            <label class="form-check-label">فعال باشد</label>
        </div>

        <button type="submit" class="btn btn-primary">ارسال پاسخ</button>
        <a href="{{ URL::previous() }}" class="btn btn-secondary">بازگشت</a>
    </form>
@endsection
