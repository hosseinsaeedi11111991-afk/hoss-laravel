@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-comment.index') }}">دیدگاه‌ها/</a></span>
        ایجاد دیدگاه جدید
    </h4>

    <form action="{{ route('admin.blog-comment.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label class="form-label">نام *</label>
            <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">ایمیل *</label>
            <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">مطلب *</label>
            <select name="blog_post_id" class="form-select" required>
                <option value="">انتخاب کنید</option>
                @foreach(\Modules\Blog\Models\BlogPost::latest()->get() as $post)
                    <option value="{{ $post->id }}" {{ old('blog_post_id') == $post->id ? 'selected' : '' }}>{{ $post->title }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">والد (اختیاری)</label>
            <select name="parent_id" class="form-select">
                <option value="">بدون والد</option>
                @foreach(\Modules\Blog\Models\BlogComment::whereNull('parent_id')->get() as $comment)
                    <option value="{{ $comment->id }}" {{ old('parent_id') == $comment->id ? 'selected' : '' }}>{{ $comment->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">متن دیدگاه *</label>
            <textarea name="description" class="form-control" rows="4" required>{{ old('description') }}</textarea>
        </div>

        <div class="mb-3 form-check">
            <input class="form-check-input" type="checkbox" name="is_active" value="1" {{ old('is_active') ? 'checked' : '' }}>
            <label class="form-check-label">فعال باشد</label>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
@endsection
