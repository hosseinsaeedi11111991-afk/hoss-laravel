@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-comment.index') }}">دیدگاه‌ها/</a></span>
        لیست دیدگاه‌ها
    </h4>

    <a href="{{ route('admin.blog-comment.create') }}" class="btn rounded-pill btn-success mb-3">دیدگاه جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>نام</th>
                <th>ایمیل</th>
                <th>مطلب</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($comments as $key => $comment)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $comment->name }}</td>
                    <td>{{ $comment->email }}</td>
                    <td>
                        <a href="{{ route('admin.blog-post.show', $comment->post) }}" target="_blank">
                            {{ $comment->post->title ?? '-' }}
                        </a>
                    </td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input toggle-status"
                                   type="checkbox"
                                   data-id="{{ $comment->id }}"
                                {{ $comment->is_active ? 'checked' : '' }}>
                        </div>
                    </td>
                    <td>
                        <div class="btn-group flex-wrap gap-2">
                            <a href="{{ route('admin.blog-comment.show', $comment) }}" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="{{ route('admin.blog-comment.edit', $comment) }}" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <a href="{{ route('admin.blog-comment.reply', $comment) }}" class="btn btn-sm btn-success" title="پاسخ">
                                <i class="bx bx-reply"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.blog-comment.destroy', $comment) }}" class="delete-form d-inline">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $comments->links('pagination::bootstrap-5') }}
    </div>

    @push('scripts')
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <script>
            $('.toggle-status').on('change', function () {
                let id   = $(this).data('id');
                let url  = '{{ route("admin.blog-comment.toggle.status") }}';
                let token = $('meta[name="csrf-token"]').attr('content');

                $.post(url, { _token: token, id: id })
                    .done(res => {
                        if (res.success) {
                            toastr.success('وضعیت دیدگاه تغییر کرد.');
                        }
                    })
                    .fail(() => toastr.error('خطا در تغییر وضعیت!'));
            });
        </script>
    @endpush
@endsection
