@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.home') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.blog-seo.index') }}">سئو/</a></span>
        لیست تنظیمات سئو
    </h4>

    <a href="{{ route('admin.blog-seo.create') }}" class="btn rounded-pill btn-success mb-3">افزودن سئو جدید</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>عنوان سئو</th>
                <th>متعلق به پست</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($blog_seos as $key => $blog_seo)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $blog_seo->title }}</td>
                    <td>{{ $blog_seo->post->title ?? '-' }}</td>
                    <td>
                        <div class="btn-group flex-wrap gap-2">
                            <a href="{{ route('admin.blog-seo.show', $blog_seo) }}" class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>
                            <a href="{{ route('admin.blog-seo.edit', $blog_seo) }}" class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.blog-seo.destroy', $blog_seo) }}" class="delete-form d-inline">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $blog_seos->links('pagination::bootstrap-5') }}
    </div>
@endsection
