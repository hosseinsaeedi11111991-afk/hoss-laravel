@extends('Shared::layouts.site.main')

@section('title', $metaTitle ?? ($post->title ?? 'مقاله'))
@section('description', $metaDescription ?? '')

@php
    use Modules\Blog\Models\BlogPost;
@endphp
@push('styles')
    <style>
        .post-navigation {
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            padding: 20px 0;
        }
        .post-navigation a {
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        .post-navigation a:hover {
            color: #aa8453;
        }
        .post-navigation h6 {
            font-size: 14px;
            margin-top: 5px;
        }
        .widget {
            background: #f9f9f9;
            padding: 25px;
            border-radius: 8px;
        }
        .widget-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #aa8453;
            color: #333;
        }
        .widget ul li a {
            text-decoration: none;
            color: #555;
            transition: all 0.3s ease;
            padding: 8px 0;
        }
        .widget ul li a:hover {
            color: #aa8453;
            padding-right: 5px;
        }
        .recent-post-item a,
        .related-post-item a {
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        .recent-post-item a:hover,
        .related-post-item a:hover {
            color: #aa8453;
        }
        .recent-post-item img,
        .related-post-item img {
            object-fit: cover;
            height: 60px;
        }
        .post-tags {
            border-top: 1px solid #e0e0e0;
            padding-top: 20px;
        }
        .tag-link {
            display: inline-block;
            padding: 5px 15px;
            background: #f0f0f0;
            border-radius: 20px;
            margin: 5px;
            text-decoration: none;
            color: #555;
            transition: all 0.3s ease;
        }
        .tag-link:hover {
            background: #aa8453;
            color: #fff;
        }
        .post-summary-box {
            border: 1px solid #e6e0d7;
            border-right: 4px solid #aa8453;
            border-radius: 8px;
            background: #fffaf3;
            padding: 18px 20px;
        }
        .post-summary-box h2 {
            font-size: 20px;
            margin-bottom: 12px;
            color: #333;
        }
        .post-summary-box p {
            margin-bottom: 0;
            line-height: 2;
        }
    </style>
@endpush

@section('main')

    <!-- Header Banner -->
    <section class="banner-header section-padding bg-img" data-overlay-dark="5" data-background="{{ !empty($post->thumbnail) ? asset('storage/' . $post->thumbnail) : asset('site/img/slider/1.jpg') }}">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="post-wrapper">
                            <div><a href="{{ route('home') }}" class="text-white">خانه</a></div>
                            <div class="divider"></div>
                            <div class="text-white"><a href="{{ route('blog.index') }}">مقاله</a></div>
                            @if(isset($post->category) && $post->category)
                                <div class="divider"></div>
                                <div class="text-white"><a href="{{ route('blog.category', $post->category->en_slug ?? '#') }}">{{ $post->category->name ?? '' }}</a></div>
                            @endif
                        </div>
                        <h1>{{ $post->title ?? 'بدون عنوان' }}</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Post -->
    @if(!empty($post->thumbnail))
        <div class="row mt-4">
            <div class="col-md-12 mb-30">
                <img src="{{ asset('storage/' . $post->thumbnail) }}" class="rounded-4 img-fluid" alt="{{ $post->title ?? 'مقاله' }}">
            </div>
        </div>
    @endif
    <section class="post section-padding">
        <div class="container">
            <div class="row">
                <!-- محتوای اصلی مقاله -->
                <div class="col-lg-8 col-md-12 mb-30">
                    @if(!empty($articleSummary))
                        <div class="post-summary-box mb-30">
                            <h2>خلاصه مطلب</h2>
                            <p>{{ $articleSummary }}</p>
                        </div>
                    @endif
                    <div class="post-content">
                        {!! $post->body ?? '' !!}
                    </div>

                    @if(isset($post->tags) && $post->tags->count() > 0)
                        <div class="post-tags mt-30">
                            <strong>برچسب‌ها: </strong>
                            @foreach($post->tags as $tag)
                                <a href="{{ route('blog.tag', $tag->en_slug ?? '#') }}" class="tag-link">{{ $tag->tag_title ?? '' }}</a>@if(!$loop->last), @endif
                            @endforeach
                        </div>
                    @endif

                    <!-- مقاله قبلی و بعدی -->
                    @if($previousPost || $nextPost)
                        <div class="post-navigation mt-5">
                            <div class="row">
                                @if($previousPost)
                                    <div class="col-md-6 mb-3">
                                        <div class="nav-previous">
                                            <a href="{{ route('blog.show', $previousPost->en_slug) }}" class="d-flex align-items-center">
                                                <i class="ti-arrow-right me-2"></i>
                                                <div>
                                                    <small class="text-muted">مقاله قبلی</small>
                                                    <h6 class="mb-0">{{ Str::limit($previousPost->title, 50) }}</h6>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                @endif
                                @if($nextPost)
                                    <div class="col-md-6 mb-3">
                                        <div class="nav-next text-end">
                                            <a href="{{ route('blog.show', $nextPost->en_slug) }}" class="d-flex align-items-center justify-content-end">
                                                <div>
                                                    <small class="text-muted">مقاله بعدی</small>
                                                    <h6 class="mb-0">{{ Str::limit($nextPost->title, 50) }}</h6>
                                                </div>
                                                <i class="ti-arrow-left ms-2"></i>
                                            </a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endif
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4 col-md-12">
                    <!-- دسته‌بندی‌ها -->
                    @if(isset($categories) && $categories->count() > 0)
                        <div class="widget mb-40">
                            <h5 class="widget-title">دسته‌بندی‌ها</h5>
                            <ul class="list-unstyled">
                                @foreach($categories as $category)
                                    <li class="mb-2">
                                        <a href="{{ route('blog.category', $category->en_slug ?? '#') }}" class="d-flex justify-content-between align-items-center">
                                            <span>{{ $category->name ?? '' }}</span>
                                            <span class="badge bg-secondary">{{ $category->posts()->where('is_active', 1)->where('status', BlogPost::STATUS_PUBLISHED)->count() }}</span>
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <!-- جدیدترین مقالات -->
                    @if(isset($recentPosts) && $recentPosts->count() > 0)
                        <div class="widget mb-40">
                            <h5 class="widget-title">جدیدترین مقالات</h5>
                            @foreach($recentPosts as $recentPost)
                                <div class="recent-post-item mb-3">
                                    <div class="row">
                                        @if(!empty($recentPost->thumbnail))
                                            <div class="col-4">
                                                <a href="{{ route('blog.show', $recentPost->en_slug) }}">
                                                    <img src="{{ asset('storage/' . $recentPost->thumbnail) }}" class="img-fluid rounded" alt="{{ $recentPost->title }}">
                                                </a>
                                            </div>
                                        @endif
                                        <div class="{{ !empty($recentPost->thumbnail) ? 'col-8' : 'col-12' }}">
                                            <h6 class="mb-1">
                                                <a href="{{ route('blog.show', $recentPost->en_slug) }}">{{ Str::limit($recentPost->title, 60) }}</a>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="ti-calendar"></i>
                                                {{ verta($recentPost->published_at)->format('d F Y') }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif

                    <!-- مقالات مرتبط -->
                    @if(isset($relatedPosts) && $relatedPosts->count() > 0)
                        <div class="widget mb-40">
                            <h5 class="widget-title">مقالات مرتبط</h5>
                            @foreach($relatedPosts as $relatedPost)
                                <div class="related-post-item mb-3">
                                    <div class="row">
                                        @if(!empty($relatedPost->thumbnail))
                                            <div class="col-4">
                                                <a href="{{ route('blog.show', $relatedPost->en_slug) }}">
                                                    <img src="{{ asset('storage/' . $relatedPost->thumbnail) }}" class="img-fluid rounded" alt="{{ $relatedPost->title }}">
                                                </a>
                                            </div>
                                        @endif
                                        <div class="{{ !empty($relatedPost->thumbnail) ? 'col-8' : 'col-12' }}">
                                            <h6 class="mb-1">
                                                <a href="{{ route('blog.show', $relatedPost->en_slug) }}">{{ Str::limit($relatedPost->title, 60) }}</a>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="ti-calendar"></i>
                                                {{ verta($relatedPost->published_at)->format('d F Y') }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>




@endsection
