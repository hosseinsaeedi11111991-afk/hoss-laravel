@extends('Shared::layouts.site.main')

@section('title', $metaTitle ?? 'مقالات و اخبار')
@section('description', $metaDescription ?? 'مقالات و اخبار به‌روز در زمینه اجاره خودرو')

@section('main')


    <!-- Header Banner -->
    <section class="banner-header section-padding bg-img" data-overlay-dark="5" data-background="{{ asset('site/img/slider/10.jpg') }}">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        @if(($seoMeta['page'] ?? 1) > 1)
                            <p class="text-white mb-2">صفحه {{ $seoMeta['page'] }}</p>
                        @endif
                        <h6>مقالات و اخبار</h6>
                        <h1>مقالات</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Blog 3 -->
    <section class="blog3 section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="row">
                        @forelse($posts ?? [] as $post)
                            <div class="col-md-12">
                                <div class="item">
                                    <div class="post-img">
                                        <a href="{{ route('blog.show', $post->en_slug ?? '#') }}">
                                            @if(!empty($post->thumbnail))
                                                <img src="{{ asset('storage/' . $post->thumbnail) }}" alt="{{ $post->title ?? 'مقاله' }}">
                                            @else
                                                <img src="{{ asset('site/img/slider/5.jpg') }}" alt="{{ $post->title ?? 'مقاله' }}">
                                            @endif
                                        </a>
                                    </div>
                                    <div class="post-cont">
                                        @if(isset($post->category) && $post->category)
                                            <span class="category">
                                                <h2><a href="{{ route('blog.category', $post->category->en_slug ?? '#') }}">{{ $post->category->name ?? '' }}</a></h2>
                                            </span>
                                        @endif
                                        <span class="calendar">
                                            <a href="#">
                                                @if(!empty($post->published_at))
                                                    {{ \Verta::instance($post->published_at)->format('j F Y') }}
                                                @elseif(!empty($post->created_at))
                                                    {{ \Verta::instance($post->created_at)->format('j F Y') }}
                                                @else
                                                    {{ \Verta::now()->format('j F Y') }}
                                                @endif
                                            </a>
                                        </span>
                                        <h5>
                                            <a href="{{ route('blog.show', $post->en_slug ?? '#') }}">{{ $post->title ?? 'بدون عنوان' }}</a>
                                        </h5>
                                        <p>{{ Str::limit(strip_tags($post->summary ?? $post->body ?? ''), 200) }}</p>
                                        <a href="{{ route('blog.show', $post->en_slug ?? '#') }}" class="button-4">بیشتر بخوانید</a>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="col-md-12">
                                <div class="alert alert-info text-center">
                                    <p>مقاله‌ای یافت نشد.</p>
                                </div>
                            </div>
                        @endforelse
                    </div>
                    <!-- Pagination -->
                    @if(isset($posts) && $posts->hasPages())
                        <div class="row">
                            <div class="col-md-12 mt-30 mb-30">
                                <ul class="pagination-wrap">
                                    @if($posts->onFirstPage())
                                        <li><span><i class="ti-angle-right"></i></span></li>
                                    @else
                                        <li><a href="{{ $posts->previousPageUrl() }}"><i class="ti-angle-right"></i></a></li>
                                    @endif

                                    @foreach($posts->getUrlRange(max(1, $posts->currentPage() - 2), min($posts->lastPage(), $posts->currentPage() + 2)) as $page => $url)
                                        <li>
                                            <a href="{{ $url }}" class="{{ $page == $posts->currentPage() ? 'active' : '' }}">
                                                {{ $page }}
                                            </a>
                                        </li>
                                    @endforeach

                                    @if($posts->hasMorePages())
                                        <li><a href="{{ $posts->nextPageUrl() }}"><i class="ti-angle-left"></i></a></li>
                                    @else
                                        <li><span><i class="ti-angle-left"></i></span></li>
                                    @endif
                                </ul>
                            </div>
                        </div>
                    @endif
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="blog3-sidebar row">
                        <div class="col-md-12">
                            <div class="widget search">
                                <form action="{{ route('blog.index') }}" method="GET">
                                    <input type="text" name="search" placeholder="بنویسید..." value="{{ request('search') }}">
                                    <button type="submit"><i class="ti-search" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </div>
                        @if($recentPosts->count() > 0)
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-title">
                                        <h6>مقالات اخیر</h6>
                                    </div>
                                    <ul class="recent">
                                        @foreach($recentPosts as $recentPost)
                                            <li>
                                                <div class="thum">
                                                    @if($recentPost->thumbnail)
                                                        <img src="{{ asset('storage/' . $recentPost->thumbnail) }}" class="img-fluid" alt="{{ $recentPost->title }}">
                                                    @else
                                                        <img src="{{ asset('site/img/slider/2.jpg') }}" class="img-fluid" alt="{{ $recentPost->title }}">
                                                    @endif
                                                </div>
                                                <a href="{{ route('blog.show', $recentPost->en_slug) }}">{{ Str::limit($recentPost->title, 50) }}</a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif
                        <div class="col-md-12">
                            <div class="widget">
                                <div class="widget-title">
                                    <h6>آرشیو</h6>
                                </div>
                                <ul>
                                    @forelse($archives as $archive)
                                        <li>
                                            <a href="{{ route('blog.index', ['year' => $archive['year'], 'month' => $archive['month']]) }}">
                                                {{ $archive['month_name'] }} {{ $archive['year'] }}
                                            </a>
                                        </li>
                                    @empty
                                        <li>آرشیوی یافت نشد</li>
                                    @endforelse
                                </ul>
                            </div>
                        </div>
                        @if($categories->count() > 0)
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-title">
                                        <h6>دسته بندی ها</h6>
                                    </div>
                                    <ul>
                                        @foreach($categories as $category)
                                            <li>
                                                <a href="{{ route('blog.category', $category->en_slug) }}">
                                                    <i class="ti-angle-right"></i>{{ $category->name }}
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="5" data-background="{{ asset('site/img/slider/3.jpg') }}">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>ماشینتو اجاره کن</h6>
                    <h5>دوست داری اجاره کنی؟</h5>
                    <p>درنگ نکن و به ما پیام بده.</p>
                    <a class="button-2 mt-15 mb-15" data-bs-target="#exampleModal" data-bs-toggle="modal" data-bs-whatever="@mdo" href="#0">الان اجاره کن<span class="ti-arrow-top-right"></span></a><a class="button-1 mt-15 mb-15 me-2" href="tel:+8001234567" dir="ltr"><i class="fa-brands fa-whatsapp"></i>واتس اپ</a>
                </div>
            </div>
        </div>
    </section>




@endsection
