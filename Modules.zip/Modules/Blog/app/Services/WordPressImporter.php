<?php

namespace Modules\Blog\Services;

use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Modules\Blog\Models\BlogPost;
use Modules\Blog\Models\BlogPostCategory;
use Modules\Blog\Models\BlogPostTag;
use Modules\Blog\Models\BlogSeo;
use Modules\Blog\Models\BlogTag;
use Hekmatinasser\Verta\Verta;
use DateTime;

class WordPressImporter
{
    protected string $baseUrl;
    protected ?string $username;
    protected ?string $password;
    protected ?string $applicationPassword;
    protected ?array $cachedCategories = null;

    public function __construct(string $baseUrl, ?string $username = null, ?string $password = null, ?string $applicationPassword = null)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->username = $username;
        $this->password = $password;
        $this->applicationPassword = $applicationPassword;
    }

    /**
     * دریافت لیست پست‌های وردپرس از REST API
     */
    public function fetchPosts(int $perPage = 100, int $page = 1): array
    {
        $url = "{$this->baseUrl}/wp-json/wp/v2/posts";
        
        $params = [
            'per_page' => $perPage,
            'page' => $page,
            'status' => 'publish',
            '_embed' => true,
        ];

        $response = Http::timeout(30);

        // اگر Application Password وجود دارد، از آن استفاده کن
        if ($this->applicationPassword) {
            $response->withBasicAuth($this->username, $this->applicationPassword);
        } elseif ($this->username && $this->password) {
            $response->withBasicAuth($this->username, $this->password);
        }

        $response = $response->get($url, $params);

        if (!$response->successful()) {
            throw new Exception("خطا در دریافت پست‌ها: " . $response->body());
        }

        return [
            'posts' => $response->json(),
            'total' => (int) $response->header('X-WP-Total'),
            'totalPages' => (int) $response->header('X-WP-TotalPages'),
        ];
    }

    /**
     * دریافت دسته‌بندی‌های وردپرس
     */
    public function fetchCategories(): array
    {
        $url = "{$this->baseUrl}/wp-json/wp/v2/categories";
        
        $response = Http::timeout(30)->get($url, ['per_page' => 100]);

        if (!$response->successful()) {
            throw new Exception("خطا در دریافت دسته‌بندی‌ها: " . $response->body());
        }

        return $response->json();
    }

    /**
     * دانلود و ذخیره تصویر از URL
     */
    protected function downloadImage(string $imageUrl, string $path): ?string
    {
        try {
            $response = Http::timeout(30)->get($imageUrl);

            if (!$response->successful()) {
                return null;
            }

            $extension = $this->getImageExtension($imageUrl, $response->header('Content-Type'));
            $fileName = Str::slug(basename(parse_url($imageUrl, PHP_URL_PATH))) . '-' . uniqid() . '.' . $extension;

            $fullPath = $path . '/' . $fileName;
            Storage::disk('public')->put($fullPath, $response->body());

            return $fullPath;
        } catch (Exception $e) {
            \Log::error("خطا در دانلود تصویر: {$imageUrl} - " . $e->getMessage());
            return null;
        }
    }

    /**
     * تشخیص پسوند تصویر
     */
    protected function getImageExtension(string $url, ?string $contentType): string
    {
        // از Content-Type استفاده کن
        if ($contentType) {
            $mimeToExt = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/gif' => 'gif',
                'image/webp' => 'webp',
            ];
            if (isset($mimeToExt[$contentType])) {
                return $mimeToExt[$contentType];
            }
        }

        // از URL استفاده کن
        $path = parse_url($url, PHP_URL_PATH);
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        
        return in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'gif', 'webp']) 
            ? strtolower($extension) 
            : 'jpg';
    }

    /**
     * تبدیل محتوای HTML وردپرس و دانلود تصاویر درون آن
     */
    protected function processBodyContent(string $html, string $bodyImageFolder): string
    {
        // استخراج تمام تصاویر از HTML (src, data-src, data-lazy-src)
        $imagePatterns = [
            '/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i',
            '/<img[^>]+data-src=["\']([^"\']+)["\'][^>]*>/i',
            '/<img[^>]+data-lazy-src=["\']([^"\']+)["\'][^>]*>/i',
        ];
        
        $allImageUrls = [];
        
        // پیدا کردن همه تصاویر
        foreach ($imagePatterns as $pattern) {
            preg_match_all($pattern, $html, $matches);
            if (!empty($matches[1])) {
                $allImageUrls = array_merge($allImageUrls, $matches[1]);
            }
        }
        
        // پیدا کردن تصاویر در srcset
        preg_match_all('/srcset=["\']([^"\']+)["\']/i', $html, $srcsetMatches);
        if (!empty($srcsetMatches[1])) {
            foreach ($srcsetMatches[1] as $srcset) {
                // استخراج URLها از srcset (فرمت: url1 700w, url2 300w)
                preg_match_all('/([^\s,]+)(?:\s+\d+w)?/i', $srcset, $srcsetUrls);
                if (!empty($srcsetUrls[1])) {
                    $allImageUrls = array_merge($allImageUrls, $srcsetUrls[1]);
                }
            }
        }
        
        // پیدا کردن تصاویر در style attributes (background-image)
        preg_match_all('/style=["\'][^"\']*background-image:\s*url\(["\']?([^"\')]+)["\']?\)[^"\']*["\']/i', $html, $styleMatches);
        if (!empty($styleMatches[1])) {
            $allImageUrls = array_merge($allImageUrls, $styleMatches[1]);
        }
        
        // حذف تکراری‌ها
        $allImageUrls = array_unique($allImageUrls);
        
        // ذخیره mapping URLهای قدیمی به جدید
        $urlMapping = [];
        
        // دانلود و جایگزینی تصاویر
        foreach ($allImageUrls as $imageUrl) {
            // نادیده گرفتن تصاویر data URI
            if (strpos($imageUrl, 'data:') === 0) {
                continue;
            }
            
            // نادیده گرفتن URLهای محلی که قبلاً ذخیره شده‌اند
            if (strpos($imageUrl, '/storage/') === 0 || 
                strpos($imageUrl, 'storage/') === 0 ||
                strpos($imageUrl, 'http://127.0.0.1') === 0 ||
                strpos($imageUrl, 'http://localhost') === 0) {
                continue;
            }
            
            // تبدیل URL نسبی به مطلق
            $absoluteUrl = $this->makeAbsoluteUrl($imageUrl);
            
            // دانلود تصویر از سایت وردپرس
            $downloadedPath = $this->downloadImage($absoluteUrl, BlogPost::BODY_PATH . $bodyImageFolder);
            
            if ($downloadedPath) {
                // URL جدید محلی
                $newUrl = asset('storage/' . $downloadedPath);
                $urlMapping[$imageUrl] = $newUrl;
            }
        }
        
        // جایگزینی همه URLها در HTML
        // ابتدا جایگزینی عمومی برای اطمینان از جایگزینی همه موارد
        foreach ($urlMapping as $oldUrl => $newUrl) {
            // جایگزینی مستقیم در تمام HTML (اولویت اول)
            $html = str_replace($oldUrl, $newUrl, $html);
        }
        
        // سپس جایگزینی دقیق‌تر با regex برای اطمینان
        foreach ($urlMapping as $oldUrl => $newUrl) {
            // Escape کردن URL برای استفاده در regex
            $escapedUrl = preg_quote($oldUrl, '/');
            
            // جایگزینی در src
            $html = preg_replace(
                '/(<img[^>]+src=["\'])(' . $escapedUrl . ')(["\'][^>]*>)/i',
                '$1' . $newUrl . '$3',
                $html
            );
            
            // جایگزینی در data-src
            $html = preg_replace(
                '/(<img[^>]+data-src=["\'])(' . $escapedUrl . ')(["\'][^>]*>)/i',
                '$1' . $newUrl . '$3',
                $html
            );
            
            // جایگزینی در data-lazy-src
            $html = preg_replace(
                '/(<img[^>]+data-lazy-src=["\'])(' . $escapedUrl . ')(["\'][^>]*>)/i',
                '$1' . $newUrl . '$3',
                $html
            );
            
            // جایگزینی در background-image در style attribute
            $html = preg_replace(
                '/(style=["\'][^"\']*background-image:\s*url\(["\']?)(' . $escapedUrl . ')(["\']?\)[^"\']*["\'])/i',
                '$1' . $newUrl . '$3',
                $html
            );
        }
        
        // جایگزینی در srcset (باید بعد از جایگزینی عمومی انجام شود)
        foreach ($urlMapping as $oldUrl => $newUrl) {
            $html = preg_replace_callback(
                '/srcset=["\']([^"\']+)["\']/i',
                function ($matches) use ($oldUrl, $newUrl) {
                    $srcset = $matches[1];
                    // جایگزینی URL در srcset
                    if (strpos($srcset, $oldUrl) !== false) {
                        $srcset = str_replace($oldUrl, $newUrl, $srcset);
                    }
                    return 'srcset="' . $srcset . '"';
                },
                $html
            );
        }
        
        // اطمینان از جایگزینی همه URLهای خارجی باقی‌مانده
        // پیدا کردن همه URLهای وردپرس باقی‌مانده در HTML (با روش قوی‌تر)
        $baseUrlPattern = preg_quote($this->baseUrl, '/');
        // پیدا کردن همه URLهای وردپرس که شامل wp-content هستند
        preg_match_all('/' . $baseUrlPattern . '[^"\'\s<>\)]+wp-content[^"\'\s<>\)]+\.(jpg|jpeg|png|gif|webp|svg)/i', $html, $remainingUrls);
        
        if (!empty($remainingUrls[0])) {
            foreach ($remainingUrls[0] as $remainingUrl) {
                // بررسی اینکه آیا قبلاً دانلود شده یا نه
                $alreadyDownloaded = false;
                foreach ($urlMapping as $oldUrl => $newUrl) {
                    if ($remainingUrl === $oldUrl || strpos($remainingUrl, $oldUrl) !== false) {
                        $alreadyDownloaded = true;
                        break;
                    }
                }
                
                // بررسی اینکه آیا URL محلی است یا نه
                if (strpos($remainingUrl, '/storage/') !== false || 
                    strpos($remainingUrl, asset('storage/')) !== false) {
                    $alreadyDownloaded = true;
                }
                
                if (!$alreadyDownloaded) {
                    // این یک تصویر وردپرس است که باید دانلود شود
                    $absoluteUrl = $remainingUrl;
                    $downloadedPath = $this->downloadImage($absoluteUrl, BlogPost::BODY_PATH . $bodyImageFolder);
                    
                    if ($downloadedPath) {
                        $newUrl = asset('storage/' . $downloadedPath);
                        // جایگزینی با escape کردن
                        $escapedRemainingUrl = preg_quote($remainingUrl, '/');
                        $html = preg_replace('/' . $escapedRemainingUrl . '/', $newUrl, $html);
                    }
                }
            }
        }

        return $html;
    }

    /**
     * تبدیل URL نسبی به مطلق
     */
    protected function makeAbsoluteUrl(string $url): string
    {
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            return $url;
        }

        return $this->baseUrl . '/' . ltrim($url, '/');
    }

    /**
     * ایجاد یا دریافت دسته‌بندی
     */
    protected function getOrCreateCategory(array $wpCategory): BlogPostCategory
    {
        return BlogPostCategory::firstOrCreate(
            ['en_slug' => Str::slug($wpCategory['name'])],
            [
                'name' => $wpCategory['name'],
                'fa_slug' => Str::slug($wpCategory['name']),
                'description' => $wpCategory['description'] ?? null,
            ]
        );
    }

    /**
     * ایجاد یا دریافت تگ
     */
    protected function getOrCreateTag(string $tagName): BlogTag
    {
        return BlogTag::firstOrCreate(
            ['en_slug' => Str::slug($tagName)],
            [
                'tag_title' => $tagName,
                'fa_slug' => Str::slug($tagName),
            ]
        );
    }

    /**
     * واردات یک پست وردپرس
     */
    public function importPost(array $wpPost, ?int $defaultCategoryId = null): BlogPost
    {
        $bodyImageFolder = time() . '-' . uniqid();

        // استخراج اطلاعات پست
        $title = $wpPost['title']['rendered'] ?? $wpPost['title'] ?? '';
        $content = $wpPost['content']['rendered'] ?? $wpPost['content'] ?? '';
        $excerpt = $wpPost['excerpt']['rendered'] ?? $wpPost['excerpt'] ?? '';
        
        // پردازش محتوا و دانلود تصاویر
        $processedContent = $this->processBodyContent($content, $bodyImageFolder);

        // استخراج تصویر شاخص
        $thumbnailUrl = null;
        if (isset($wpPost['_embedded']['wp:featuredmedia'][0]['source_url'])) {
            $thumbnailUrl = $wpPost['_embedded']['wp:featuredmedia'][0]['source_url'];
        } elseif (isset($wpPost['featured_media']) && $wpPost['featured_media'] > 0) {
            // اگر featured_media ID وجود دارد، می‌توانیم از API دریافت کنیم
            $thumbnailUrl = $this->getMediaUrl($wpPost['featured_media']);
        }

        // دانلود تصویر شاخص (thumbnail)
        $thumbnailPath = $thumbnailUrl 
            ? $this->downloadImage($thumbnailUrl, BlogPost::THUMB_PATH) 
            : null;
        
        // دانلود تصویر اصلی (image) - از همان URL استفاده می‌کنیم اما در پوشه جدا
        $imagePath = $thumbnailUrl 
            ? $this->downloadImage($thumbnailUrl, BlogPost::IMAGE_PATH) 
            : null;

        // استخراج دسته‌بندی
        $categoryId = $defaultCategoryId;
        if (isset($wpPost['categories']) && !empty($wpPost['categories'])) {
            $wpCategoryId = $wpPost['categories'][0];
            
            // استفاده از embedded categories اگر موجود باشد
            $wpCategory = null;
            if (isset($wpPost['_embedded']['wp:term'][0])) {
                foreach ($wpPost['_embedded']['wp:term'][0] as $term) {
                    if ($term['taxonomy'] === 'category' && $term['id'] == $wpCategoryId) {
                        $wpCategory = $term;
                        break;
                    }
                }
            }
            
            // اگر embedded موجود نبود، از API دریافت کن
            if (!$wpCategory) {
                if ($this->cachedCategories === null) {
                    $this->cachedCategories = $this->fetchCategories();
                }
                foreach ($this->cachedCategories as $wpCat) {
                    if ($wpCat['id'] == $wpCategoryId) {
                        $wpCategory = $wpCat;
                        break;
                    }
                }
            }
            
            if ($wpCategory) {
                $category = $this->getOrCreateCategory($wpCategory);
                $categoryId = $category->id;
            }
        }

        if (!$categoryId) {
            throw new Exception("دسته‌بندی برای پست یافت نشد");
        }

        // تبدیل تاریخ
        $publishedAt = null;
        if (isset($wpPost['date'])) {
            try {
                $publishedAt = (new DateTime($wpPost['date']))->format('Y-m-d H:i:s');
            } catch (Exception $e) {
                $publishedAt = now();
            }
        } else {
            $publishedAt = now();
        }

        // ایجاد slug
        $slug = isset($wpPost['slug']) ? $wpPost['slug'] : Str::slug($title);
        
        // اطمینان از یکتایی slug
        $baseSlug = $slug;
        $counter = 1;
        while (BlogPost::where('en_slug', $slug)->exists() || BlogPost::where('fa_slug', $slug)->exists()) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }
        
        $faSlug = $slug;
        $enSlug = $slug;

        // استخراج نویسنده
        $author = 'نویسنده نامشخص';
        if (isset($wpPost['_embedded']['author'][0]['name'])) {
            $author = $wpPost['_embedded']['author'][0]['name'];
        }

        // ایجاد پست
        $post = BlogPost::create([
            'title' => $title,
            'summary' => strip_tags($excerpt) ?: Str::limit(strip_tags($processedContent), 500),
            'fa_slug' => $faSlug,
            'en_slug' => $enSlug,
            'thumbnail' => $thumbnailPath,
            'image' => $imagePath,
            'body' => $processedContent,
            'body_image_folder' => $bodyImageFolder,
            'is_active' => true,
            'is_commentable' => true,
            'status' => BlogPost::STATUS_PUBLISHED,
            'author' => $author,
            'user_id' => 1, // می‌توانید از auth()->id() استفاده کنید
            'blog_post_category_id' => $categoryId,
            'published_at' => $publishedAt,
        ]);

        // اضافه کردن تگ‌ها
        if (isset($wpPost['tags']) && !empty($wpPost['tags'])) {
            $tagIds = [];
            foreach ($wpPost['tags'] as $tagId) {
                // استفاده از embedded tags اگر موجود باشد
                $tagData = null;
                if (isset($wpPost['_embedded']['wp:term'][1])) {
                    foreach ($wpPost['_embedded']['wp:term'][1] as $term) {
                        if ($term['taxonomy'] === 'post_tag' && $term['id'] == $tagId) {
                            $tagData = $term;
                            break;
                        }
                    }
                }
                
                // اگر embedded موجود نبود، از API دریافت کن
                if (!$tagData) {
                    $tagResponse = Http::timeout(30)->get("{$this->baseUrl}/wp-json/wp/v2/tags/{$tagId}");
                    if ($tagResponse->successful()) {
                        $tagData = $tagResponse->json();
                    }
                }
                
                if ($tagData) {
                    $tag = $this->getOrCreateTag($tagData['name']);
                    $tagIds[] = $tag->id;
                }
            }
            if (!empty($tagIds)) {
                $post->tags()->sync($tagIds);
            }
        }

        // ایجاد SEO
        $seoTitle = mb_substr($title, 0, 60);
        
        // محدود کردن description به 160 کاراکتر
        $excerptText = strip_tags($excerpt) ?: strip_tags($processedContent);
        $excerptText = preg_replace('/\s+/', ' ', $excerptText); // حذف فضاهای اضافی
        $excerptText = trim($excerptText);
        $seoDescription = mb_substr($excerptText, 0, 160);
        
        $publishedAtIso = (new DateTime($publishedAt))->format(DateTime::ATOM);
        $schemaMarkup = [
            '@context' => 'https://schema.org',
            '@type' => 'BlogPosting',
            'headline' => $seoTitle ?: mb_substr($title, 0, 60),
            'description' => $seoDescription,
            'image' => $thumbnailPath ? asset('storage/' . $thumbnailPath) : null,
            'author' => [
                '@type' => 'Person',
                'name' => $author,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name' => config('app.name'),
            ],
            'datePublished' => $publishedAtIso,
        ];

        $post->seo()->create([
            'title' => $seoTitle,
            'description' => $seoDescription,
            'keywords' => null,
            'focus_keyword' => null,
            'reading_time' => $this->calculateReadingTime($processedContent),
            'schema_markup' => json_encode($schemaMarkup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'author_name' => $author,
        ]);

        return $post;
    }

    /**
     * دریافت URL تصویر از Media ID
     */
    protected function getMediaUrl(int $mediaId): ?string
    {
        try {
            $response = Http::timeout(30)->get("{$this->baseUrl}/wp-json/wp/v2/media/{$mediaId}");
            
            if ($response->successful()) {
                $media = $response->json();
                return $media['source_url'] ?? null;
            }
        } catch (Exception $e) {
            \Log::error("خطا در دریافت Media: {$mediaId} - " . $e->getMessage());
        }

        return null;
    }

    /**
     * محاسبه زمان مطالعه
     */
    protected function calculateReadingTime(string $content): string
    {
        $wordCount = str_word_count(strip_tags($content));
        $minutes = ceil($wordCount / 200); // فرض: 200 کلمه در دقیقه
        
        if ($minutes < 60) {
            return sprintf("%02d:00", $minutes);
        }
        
        $hours = floor($minutes / 60);
        $mins = $minutes % 60;
        return sprintf("%02d:%02d", $hours, $mins);
    }

    /**
     * تست اتصال به WordPress
     */
    public function testConnection(): bool
    {
        try {
            $response = Http::timeout(10)->get("{$this->baseUrl}/wp-json/wp/v2/posts", ['per_page' => 1]);
            return $response->successful();
        } catch (Exception $e) {
            return false;
        }
    }
}

