<?php

// app/Models/BlogRating.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\User\Models\User;

class BlogRating extends Model
{
    protected $table   = 'blog_ratings';
    protected $fillable = [
        'rating',
        'user_id',
        'blog_post_id',
    ];

    /* Allowed range ------------------------------------------------------ */
    const MIN = 1;
    const MAX = 5;

    public function post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
