<?php

// app/Models/BlogLike.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\User\Models\User;

class BlogLike extends Model
{
    protected $table   = 'blog_likes';
    protected $fillable = [
        'user_id',
        'blog_post_id',
    ];

    public function post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
