<?php
// app/Models/BlogPostCategory.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\Blog\Models\BlogPost;

class BlogPostCategory extends Model
{

    protected $table   = 'blog_post_categories';
    protected $fillable = [
        'name',
        'fa_slug',
        'en_slug',
        'description',
    ];

    /* Relations ---------------------------------------------------------- */
    public function posts()
    {
        return $this->hasMany(BlogPost::class);
    }
}
