<?php
// app/Models/BlogPost.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\Blog\Models\BlogComment;
use Modules\Blog\Models\BlogLike;
use Modules\Blog\Models\BlogRating;
use Modules\Blog\Models\BlogSave;
use Modules\Blog\Models\BlogSeo;
use Modules\Blog\Models\BlogTag;
use Modules\User\Models\User;

class BlogPost extends Model
{

    const IMAGE_PATH = 'blog/posts/images/';
    const BODY_PATH = 'blog/posts/body/';
    const THUMB_PATH = 'blog/posts/thumbnail/';


    protected $table   = 'blog_posts';
    protected $fillable = [
        'title',
        'summary',
        'fa_slug',
        'en_slug',
        'thumbnail',
        'thumbnail_tag',
        'image',
        'image_tag',
        'body',
        'body_image_folder',
        'is_active',
        'is_commentable',
        'likes_count',
        'views_count',
        'status',
        'author',
        'user_id',
        'blog_post_category_id',
        'published_at',
    ];

    protected $casts = [
        'published_at' => 'datetime',
        'is_active'    => 'boolean',
        'is_commentable' => 'boolean',
    ];

    /* Status constants --------------------------------------------------- */
    const STATUS_DRAFT     = 'draft';
    const STATUS_PUBLISHED = 'published';
    const STATUS_ARCHIVED  = 'archived';

    /* Relations ---------------------------------------------------------- */
    public function category()
    {
        return $this->belongsTo(BlogPostCategory::class, 'blog_post_category_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class)->withDefault();
    }

    public function seo()
    {
        return $this->hasOne(BlogSeo::class);
    }

    public function comments()
    {
        return $this->hasMany(BlogComment::class);
    }

    public function ratings()
    {
        return $this->hasMany(BlogRating::class);
    }

    public function likes()
    {
        return $this->hasMany(BlogLike::class);
    }

    public function saves()
    {
        return $this->hasMany(BlogSave::class);
    }

    public function tags()
    {
        return $this->belongsToMany(BlogTag::class, 'blog_post_tags', 'blog_post_id', 'tag_id');
    }

    public function getStatusTextAttribute()
    {
        return match ($this->status) {
            self::STATUS_DRAFT     => 'پیش‌نویس',
            self::STATUS_PUBLISHED => 'منتشر شده',
            self::STATUS_ARCHIVED  => 'بایگانی',
            default                => $this->status,
        };
    }

    public function getStatusBadgeClassAttribute()
    {
        return match ($this->status) {
            self::STATUS_DRAFT     => 'bg-warning',
            self::STATUS_PUBLISHED => 'bg-success',
            self::STATUS_ARCHIVED  => 'bg-secondary',
            default                => 'bg-light',
        };
    }
}
