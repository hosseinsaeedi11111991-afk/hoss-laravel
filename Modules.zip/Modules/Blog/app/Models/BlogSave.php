<?php

// app/Models/BlogSave.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\User\Models\User;

class BlogSave extends Model
{
    protected $table   = 'blog_saves';
    protected $fillable = [
        'user_id',
        'blog_post_id',
    ];

    public function post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
