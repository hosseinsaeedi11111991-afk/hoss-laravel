<?php

// app/Models/BlogTag.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BlogTag extends Model
{

    protected $table   = 'blog_tags';
    protected $fillable = [
        'tag_title',
        'en_slug',
        'fa_slug',
    ];

    public function posts()
    {
        return $this->belongsToMany(BlogPost::class, 'blog_post_tags', 'tag_id', 'blog_post_id');
    }
}
