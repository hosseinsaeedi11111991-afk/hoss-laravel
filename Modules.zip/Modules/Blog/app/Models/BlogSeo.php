<?php

// app/Models/BlogSeo.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;

class BlogSeo extends Model
{
    protected $table   = 'blog_seo';
    protected $fillable = [
        'blog_post_id',
        'title',
        'description',
        'keywords',
        'author_name',
        'schema_markup',
        'focus_keyword',
        'reading_time',
    ];

    protected $casts = [
        'schema_markup' => 'array',
    ];

    public function post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }
}
