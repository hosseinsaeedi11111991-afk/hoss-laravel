<?php


// app/Models/BlogComment.php
namespace Modules\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\User\Models\User;

class BlogComment extends Model
{

    protected $table   = 'blog_comments';
    protected $fillable = [
        'name',
        'email',
        'description',
        'is_active',
        'user_id',
        'blog_post_id',
        'parent_id',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    /* Constants ---------------------------------------------------------- */
    const ACTIVE   = 1;
    const INACTIVE = 0;

    public function post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function parent()
    {
        return $this->belongsTo(BlogComment::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(BlogComment::class, 'parent_id');
    }
}
