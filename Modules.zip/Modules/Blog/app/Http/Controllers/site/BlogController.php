<?php

namespace Modules\Blog\Http\Controllers\site;

use App\Http\Controllers\Controller;
use App\Services\SeoMetaService;
use Modules\Blog\Models\BlogPost;
use Modules\Blog\Models\BlogPostCategory;
use Modules\Blog\Models\BlogTag;
use Modules\Blog\Models\BlogComment;
use Illuminate\Http\Request;
class BlogController extends Controller
{
    /**
     * Display a listing of blog posts
     */
    public function index(Request $request, SeoMetaService $seoMetaService)
    {
        // Get published blog posts with pagination
        $query = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->with(['category', 'user', 'tags']);

        // Add search functionality
        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'LIKE', "%{$searchTerm}%")
                    ->orWhere('summary', 'LIKE', "%{$searchTerm}%")
                    ->orWhere('body', 'LIKE', "%{$searchTerm}%")
                    ->orWhereHas('category', function ($categoryQuery) use ($searchTerm) {
                        $categoryQuery->where('name', 'LIKE', "%{$searchTerm}%");
                    })
                    ->orWhereHas('tags', function ($tagQuery) use ($searchTerm) {
                        $tagQuery->where('tag_title', 'LIKE', "%{$searchTerm}%");
                    });
            });
        }

        $posts = $query->orderBy('published_at', 'desc')->paginate(6);

        // Get recent posts for sidebar
        $recentPosts = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->with(['category', 'user'])
            ->orderBy('published_at', 'desc')
            ->limit(3)
            ->get();

        // Get categories for sidebar
        $categories = BlogPostCategory::all();

        // Get tags for sidebar
        $tags = BlogTag::all();

        // Get archives for sidebar
        $archives = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->whereNotNull('published_at')
            ->selectRaw('YEAR(published_at) as year, MONTH(published_at) as month, COUNT(*) as count')
            ->groupBy('year', 'month')
            ->orderBy('year', 'desc')
            ->orderBy('month', 'desc')
            ->limit(6)
            ->get();



        $seoMeta = $seoMetaService->blogCollection(
            'مقالات و اخبار',
            'مقالات و اخبار به روز درباره تاکسی بین شهری، رزرو سفر، راهنمای مسیر و نکات مهم سفر',
            $posts,
            $request
        );
        $metaTitle = $seoMeta['title'];
        $metaDescription = $seoMeta['description'];

        return view('blog::site.index', compact('posts', 'recentPosts', 'categories', 'tags', 'archives', 'metaTitle', 'metaDescription', 'seoMeta'));
    }

    /**
     * Display the specified blog post
     */
    public function show($slug, Request $request, SeoMetaService $seoMetaService)
    {

        $post = BlogPost::where('is_active', 1)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('en_slug', $slug)
            ->with(['category', 'user', 'tags', 'seo', 'comments' => function ($query) {
                $query->where('is_active', 1)->orderBy('created_at', 'desc');
            }])
            ->firstOrFail();

        // Increment view count
        $post->increment('views_count');

        // Get related posts
        $relatedPosts = BlogPost::where('is_active', 1)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('id', '!=', $post->id)
            ->where('blog_post_category_id', $post->blog_post_category_id)
            ->with(['category', 'user'])
            ->orderBy('published_at', 'desc')
            ->limit(4)
            ->get();

        // Get recent posts for sidebar
        $recentPosts = BlogPost::where('is_active', 1)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('id', '!=', $post->id)
            ->with(['category', 'user'])
            ->orderBy('published_at', 'desc')
            ->limit(3)
            ->get();

        // Get all categories for sidebar
        $categories = BlogPostCategory::all();

        // Get previous post (older)
        $previousPost = BlogPost::where('is_active', 1)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('published_at', '<', $post->published_at)
            ->orderBy('published_at', 'desc')
            ->first();

        // Get next post (newer)
        $nextPost = BlogPost::where('is_active', 1)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('published_at', '>', $post->published_at)
            ->orderBy('published_at', 'asc')
            ->first();

        $seoMeta = $seoMetaService->blogPost($post, $request);
        $metaTitle = $seoMeta['title'];
        $metaDescription = $seoMeta['description'];
        $articleSummary = $seoMeta['summary'] ?? '';

        return view('blog::site.show', compact('post', 'relatedPosts', 'recentPosts', 'categories', 'previousPost', 'nextPost', 'metaTitle', 'metaDescription', 'seoMeta', 'articleSummary'));
    }

    /**
     * Display posts by category
     */
    public function category(Request $request, SeoMetaService $seoMetaService)
    {
        $slug = 'مقالات';
        $category = BlogPostCategory::where('en_slug', $slug)
            ->firstOrFail();

        $recentPosts = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('blog_post_category_id', $category->id)
            ->with(['category', 'user'])
            ->orderBy('published_at', 'desc')
            ->limit(3)
            ->get();

        $archives = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->whereNotNull('published_at')
            ->selectRaw('YEAR(published_at) as year, MONTH(published_at) as month, COUNT(*) as count')
            ->where('blog_post_category_id', $category->id)
            ->groupBy('year', 'month')
            ->orderBy('year', 'desc')
            ->orderBy('month', 'desc')
            ->limit(6)
            ->get();

        $tags = BlogTag::all();


        $posts = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->where('blog_post_category_id', $category->id)
            ->with(['category', 'user', 'tags'])
            ->orderBy('published_at', 'desc')
            ->paginate(12);

        $categories = BlogPostCategory::all();
        $tags = BlogTag::all();

        $categoryTitle = $category->name ? 'مقالات ' . $category->name : 'مقالات و اخبار';
        $seoMeta = $seoMetaService->blogCollection(
            $categoryTitle,
            $categoryTitle . ' وی آی پی تاکسی ایران؛ مطالب آموزشی، خبری و راهنمای سفر مرتبط با این دسته بندی.',
            $posts,
            $request
        );
        $metaTitle = $seoMeta['title'];
        $metaDescription = $seoMeta['description'];

        return view('blog::site.category', compact('posts', 'recentPosts', 'categories', 'tags', 'archives', 'metaTitle', 'metaDescription', 'seoMeta', 'category'));
    }

    /**
     * Display posts by tag
     */
    public function tag($slug)
    {
        $tag = BlogTag::where('en_slug', $slug)
            ->firstOrFail();

        $posts = BlogPost::where('is_active', true)
            ->where('status', BlogPost::STATUS_PUBLISHED)
            ->whereHas('tags', function ($query) use ($tag) {
                $query->where('blog_tags.id', $tag->id);
            })
            ->with(['category', 'user', 'tags'])
            ->orderBy('published_at', 'desc')
            ->paginate(12);

        $categories = BlogPostCategory::all();
        $tags = BlogTag::all();

        return view('blog::site.tag', compact('posts', 'tag', 'categories', 'tags'));
    }

    /**
     * Store a newly created comment
     */
    public function storeComment(Request $request)
    {
        // Check if user is authenticated
        if (!auth()->check()) {
            return back()->with('error', 'برای ارسال دیدگاه باید وارد حساب کاربری خود شوید.');
        }

        $request->validate([
            'comment' => 'required|string|max:2000',
            'blog_post_id' => 'required|exists:blog_posts,id',
            'parent_id' => 'nullable|exists:blog_comments,id',
        ], [
            'comment.required' => 'متن دیدگاه الزامی است.',
            'comment.max' => 'متن دیدگاه نمی‌تواند بیش از 2000 کاراکتر باشد.',
            'blog_post_id.required' => 'پست مورد نظر یافت نشد.',
            'blog_post_id.exists' => 'پست مورد نظر یافت نشد.',
        ]);

        // Check if the post allows comments
        $post = BlogPost::findOrFail($request->blog_post_id);
        if (!$post->is_commentable) {
            return back()->with('error', 'ارسال دیدگاه برای این پست غیرفعال است.');
        }

        // Create the comment
        BlogComment::create([
            'name' => auth()->user()->name ?? 'کاربر',
            'email' => auth()->user()->email,
            'description' => $request->comment,
            'blog_post_id' => $request->blog_post_id,
            'parent_id' => $request->parent_id,
            'is_active' => 0, // Comments need approval by default
            'user_id' => auth()->id(),
        ]);

        return back()->with('success', 'دیدگاه شما با موفقیت ارسال شد و پس از تایید نمایش داده خواهد شد.');
    }
}
