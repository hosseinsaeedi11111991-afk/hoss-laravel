<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Modules\Blog\Models\BlogSave;
use Modules\Blog\Models\BlogPost;
use Modules\User\Models\User;
use Modules\Blog\Http\Requests\admin\BlogSaveRequest;
use Illuminate\Http\Request;

class BlogSaveController extends Controller
{
    public function index()
    {
        $blog_saves = BlogSave::with(['user', 'post'])->latest()->paginate(20);
        return view('blog::admin.blog_save.index', compact('blog_saves'));
    }

    public function create()
    {
        $users = User::select('id', 'name')->get();
        $posts = BlogPost::select('id', 'title')->get();
        return view('blog::admin.blog_save.create', compact('users', 'posts'));
    }

    public function store(BlogSaveRequest $request)
    {
        BlogSave::create($request->validated());
        return redirect()->route('admin.blog_save.index')
            ->with('success', 'ذخیره با موفقیت ایجاد شد.');
    }

    public function show(BlogSave $blog_save)
    {
        $blog_save->load(['user', 'post']);
        return view('blog::admin.blog_save.show', compact('blog_save'));
    }

    public function edit(BlogSave $blog_save)
    {
        $users = User::select('id', 'name')->get();
        $posts = BlogPost::select('id', 'title')->get();
        return view('blog::admin.blog_save.edit', compact('blog_save', 'users', 'posts'));
    }

    public function update(BlogSaveRequest $request, BlogSave $blog_save)
    {
        $blog_save->update($request->validated());
        return redirect()->route('admin.blog_save.index')
            ->with('success', 'ذخیره با موفقیت بروزرسانی شد.');
    }

    public function destroy(BlogSave $blog_save)
    {
        $blog_save->delete();
        return redirect()->route('admin.blog_save.index')
            ->with('success', 'ذخیره با موفقیت حذف شد.');
    }
}
