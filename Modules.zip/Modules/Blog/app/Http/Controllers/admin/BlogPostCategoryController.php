<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\Blog\Http\Requests\admin\BlogPostCategoryRequest;
use Modules\Blog\Models\BlogPostCategory;

class BlogPostCategoryController extends Controller
{
    public function index()
    {
        $categories = BlogPostCategory::latest()->paginate(20);
        return view('blog::admin.blog_post_category.index', compact('categories'));
    }

    public function create()
    {
        return view('blog::admin.blog_post_category.create');
    }

    public function store(BlogPostCategoryRequest $request)
    {
        BlogPostCategory::create($request->only(['name', 'fa_slug', 'en_slug', 'description']));
        return redirect()->route('admin.blog-post-category.index')
            ->with('toast-success', 'دسته‌بندی با موفقیت ایجاد شد.');
    }

    public function show(BlogPostCategory $blogPostCategory)
    {
        return view('blog::admin.blog_post_category.show', compact('blogPostCategory'));
    }

    public function edit(BlogPostCategory $blogPostCategory)
    {
        return view('blog::admin.blog_post_category.edit', compact('blogPostCategory'));
    }

    public function update(BlogPostCategoryRequest $request, BlogPostCategory $blogPostCategory)
    {
        // فقط فیلدهایی که مجازه رو آپدیت کن
        $blogPostCategory->update(
            $request->only(['name', 'fa_slug', 'en_slug', 'description'])
        );
        return redirect()->route('admin.blog-post-category.index')
            ->with('toast-success', 'دسته‌بندی به‌روزرسانی شد.');
    }

    public function destroy(BlogPostCategory $blogPostCategory)
    {
        $blogPostCategory->delete();
        return redirect()->route('admin.blog-post-category.index')
            ->with('toast-success', 'دسته‌بندی حذف گردید.');
    }
}
