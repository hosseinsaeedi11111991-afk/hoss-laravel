<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Modules\Blog\Http\Requests\admin\BlogSeoRequest;
use Modules\Blog\Models\BlogSeo;
use Modules\Blog\Models\BlogPost;

class BlogSeoController extends Controller
{
    /**
     * نمایش لیست تنظیمات سئو
     */
    public function index(): View
    {
        // هر رکورد seo متعلق به یک پست است؛ eager load برای جلوگیری از n+1
        $blog_seos = BlogSeo::with('post')->latest()->paginate(20);
        return view('blog::admin.blog_seo.index', compact('blog_seos'));
    }

    /**
     * فرم ایجاد سئوی جدید
     */
    public function create(): View
    {
        // برای نمایش dropdown انتخاب پست
        $blog_posts = BlogPost::select('id', 'title')->get();
        return view('blog::admin.blog_seo.create', compact('blog_posts'));
    }

    /**
     * ذخیره سئو در دیتابیس
     */
    public function store(BlogSeoRequest $request): RedirectResponse
    {
        BlogSeo::create($request->validated());
        return redirect()->route('admin.blog-seo.index')
            ->with('toast-success', 'اطلاعات سئو با موفقیت ایجاد شد.');
    }

    /**
     * نمایش جزئیات یک رکورد سئو
     */
    public function show(BlogSeo $blog_seo): View
    {
        $blog_seo->load('post'); // اطمینان از بارگذاری رابطه
        return view('blog::admin.blog_seo.show', compact('blog_seo'));
    }

    /**
     * فرم ویرایش سئو
     */
    public function edit(BlogSeo $blog_seo): View
    {
        $blog_posts = BlogPost::select('id', 'title')->get();
        return view('blog::admin.blog_seo.edit', compact('blog_seo', 'blog_posts'));
    }

    /**
     * بروزرسانی اطلاعات سئو
     */
    public function update(BlogSeoRequest $request, BlogSeo $blog_seo): RedirectResponse
    {
        $blog_seo->update($request->validated());
        return redirect()->route('admin.blog-seo.index')
            ->with('toast-success', 'اطلاعات سئو به‌روزرسانی شد.');
    }

    /**
     * حذف رکورد سئو
     */
    public function destroy(BlogSeo $blog_seo): RedirectResponse
    {
        $blog_seo->delete();
        return redirect()->route('admin.blog-seo.index')
            ->with('toast-success', 'اطلاعات سئو حذف گردید.');
    }
}
