<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\Blog\Http\Requests\admin\BlogTagRequest;
use Modules\Blog\Models\BlogTag;

class BlogTagController extends Controller
{
    public function index()
    {
        $tags = BlogTag::latest()->paginate(20);
        return view('blog::admin.blog_tag.index', compact('tags'));
    }

    public function create()
    {
        return view('blog::admin.blog_tag.create');
    }

    public function store(BlogTagRequest $request): RedirectResponse
    {
        BlogTag::create($request->only(['tag_title', 'en_slug', 'fa_slug']));
        return redirect()->route('admin.blog-tag.index')
            ->with('toast-success', 'برچسب با موفقیت ایجاد شد.');
    }

    public function show(BlogTag $blogTag)
    {
        return view('blog::admin.blog_tag.show', compact('blogTag'));
    }

    public function edit(BlogTag $blogTag)
    {
        return view('blog::admin.blog_tag.edit', compact('blogTag'));
    }

    public function update(BlogTagRequest $request, BlogTag $blogTag): RedirectResponse
    {
        $blogTag->update($request->only(['tag_title', 'en_slug', 'fa_slug']));
        return redirect()->route('admin.blog-tag.index')
            ->with('toast-success', 'برچسب به‌روزرسانی شد.');
    }

    public function destroy(BlogTag $blogTag): RedirectResponse
    {
        $blogTag->delete();
        return redirect()->route('admin.blog-tag.index')
            ->with('toast-success', 'برچسب حذف گردید.');
    }
}
