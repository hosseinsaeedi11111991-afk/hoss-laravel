<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\Blog\Http\Requests\admin\BlogCommentRequest;
use Modules\Blog\Models\BlogComment;

class BlogCommentController extends Controller
{
    public function index()
    {
        $comments = BlogComment::with(['post', 'user'])
            ->latest()
            ->paginate(20);

        return view('blog::admin.blog_comment.index', compact('comments'));
    }

    public function create()
    {
        return view('blog::admin.blog_comment.create');
    }

    public function store(BlogCommentRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $data['user_id'] = 1;
        BlogComment::create($data);
        return redirect()->route('admin.blog-comment.index')
            ->with('toast-success', 'دیدگاه با موفقیت ثبت شد.');
    }

    public function show(BlogComment $blogComment)
    {
        $blogComment->load(['post', 'user', 'parent', 'children']);
        return view('blog::admin.blog_comment.show', compact('blogComment'));
    }

    public function edit(BlogComment $blogComment)
    {
        return view('blog::admin.blog_comment.edit', compact('blogComment'));
    }

    public function update(BlogCommentRequest $request, BlogComment $blogComment): RedirectResponse
    {

        $blogComment->update($request->validated());
        return redirect()->route('admin.blog-comment.index')
            ->with('toast-success', 'دیدگاه بروزرسانی شد.');
    }

    public function destroy(BlogComment $blogComment): RedirectResponse
    {
        $blogComment->delete();
        return redirect()->route('admin.blog-comment.index')
            ->with('toast-success', 'دیدگاه حذف گردید.');
    }
    public function toggleStatus(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:blog_comments,id',
        ]);

        $comment = BlogComment::findOrFail($request->id);
        $comment->is_active = ! $comment->is_active;
        $comment->save();

        return response()->json([
            'success' => true,
            'newStatus' => $comment->is_active,
        ]);
    }
    public function replyForm(BlogComment $blogComment)
    {
        return view('blog::admin.blog_comment.reply', compact('blogComment'));
    }
}
