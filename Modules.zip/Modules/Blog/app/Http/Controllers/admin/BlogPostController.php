<?php

namespace Modules\Blog\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use DateTime;
use Hekmatinasser\Verta\Verta;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Modules\Blog\Http\Requests\admin\BlogPostRequest;
use Modules\Blog\Http\Requests\admin\UpdateBlogPostRequest;
use Modules\Blog\Models\BlogPost;
use Modules\Blog\Models\BlogPostCategory;
use Modules\Blog\Models\BlogPostTag;
use Modules\Blog\Models\BlogTag;
use Modules\Blog\Models\BlogSeo;
use Modules\Blog\Traits\FileHandler;
use Modules\Blog\Services\WordPressImporter;
use Illuminate\Http\JsonResponse;

class BlogPostController extends Controller
{
    use FileHandler;

    /* -------------------------------------------------
     *  نمایش لیست مقالات
     * -------------------------------------------------*/
    public function index()
    {
        $blog_posts = BlogPost::with(['category', 'tags', 'user'])
            ->latest()
            ->paginate(20);

        return view('blog::admin.blog_post.index', compact('blog_posts'));
    }

    /* -------------------------------------------------
     *  فرم ایجاد مقاله
     * -------------------------------------------------*/
    public function create()
    {
        session()->put('body_image_folder', time() . '-' . uniqid());

        $tags       = BlogTag::all();
        $categories = BlogPostCategory::all();

        return view('blog::admin.blog_post.create', compact('categories', 'tags'));
    }

    /* -------------------------------------------------
     *  ذخیره‌سازی مقاله
     * -------------------------------------------------*/
    public function store(BlogPostRequest $request): RedirectResponse
    {


        $validated = $request->validated();

        DB::beginTransaction();
        try {
            /* --- تبدیل تاریخ شمسی به میلادی --- */

            $validated['published_at'] = Verta::parse($request->get('published_at'))->datetime()->format('Y-m-d H:i:s');

            /* --- آپلود تصاویر --- */
            $validated['thumbnail'] = $request->hasFile('thumbnail')
                ? $this->uploadFile($request->file('thumbnail'), BlogPost::THUMB_PATH)['path']
                : null;

            $validated['image'] = $request->hasFile('image')
                ? $this->uploadFile($request->file('image'), BlogPost::IMAGE_PATH)['path']
                : null;

            /* --- اطلاعات تکمیلی --- */
            $validated['body_image_folder'] = session('body_image_folder');
            $validated['user_id']           =  1;
            $validated['author']            =  'lkdjsakdhk';
//
            /* --- ذخیره‌ی مقاله --- */
            $post = BlogPost::create($validated);

            /* --- ذخیره‌ی تگ‌ها --- */
//            if (!empty($validated['tag_title'])) {
//                foreach ($validated['tag_title'] as $tag) {
//                    BlogPostTag::create([
//                       'blog_post_id' => $post->id,
//                       'tag_id' => (int)$tag,
//                    ]);
//                }
//            }

            /* --- ذخیره‌ی سئو --- */
            // ابتدا تاریخ منتشر شدن را به ISO8601 تبدیل کن (که برای JSON-LD مناسب‌تر است)
            $publishedAt = Verta::parse($request->get('published_at'))->datetime()->format(DateTime::ATOM);

// ساخت آرایه schema_markup
            $schemaMarkup = [
                '@context' => 'https://schema.org',
                '@type' => 'BlogPosting',
                'headline' => $validated['title'],
                'description' => $validated['summary'] ?? '',
                'image' => $validated['thumbnail'] ? asset('storage/' . $validated['thumbnail']) : null,
                'author' => [
                    '@type' => 'Person',
                    'name' => $validated['author'] ?? 'نویسنده نامشخص',
                ],
                'publisher' => [
                    '@type' => 'Organization',
                    'name' => config('app.name'),
                    'logo' => [
                        '@type' => 'ImageObject',
                        'url' => asset('path/to/logo.png'), // مسیر لوگوی سایتت
                    ],
                ],
                'datePublished' => $publishedAt,
                'mainEntityOfPage' => [
                    '@type' => 'WebPage',
                    '@id' => url()->current(),
                ],
            ];

// سپس این آرایه را به رشته JSON تبدیل کن و داخل validated قرار بده
            $validated['schema_markup'] = json_encode($schemaMarkup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $post->seo()->create([
                'title'         => $validated['SEO-title'],
                'description'   => $validated['description'],
                'keywords'      => $validated['keywords'],
                'focus_keyword' => $validated['focus_keyword'],
                'reading_time'  => $validated['reading_time'],
                'schema_markup'  => $validated['schema_markup'],
//                'author_name'   => $validated['author'] ?? auth()->user()->name,
                'author_name'   => $validated['author'] ,
            ]);

            DB::commit();
            session()->forget('body_image_folder');

            return redirect()->route('admin.blog-post.index', $post)
                ->with('toast-success', 'مقاله با موفقیت ایجاد شد.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with(['toast-error' => 'خطا در ذخیره‌سازی: ' . $e->getMessage()]);
        }
    }

    /* -------------------------------------------------
     *  نمایش جزئیات مقاله
     * -------------------------------------------------*/
    public function show($id)
    {
        $blog_post = BlogPost::with(['category', 'tags', 'seo'])->findOrFail($id);

        // فرض کردم رابطه seo به این صورت است، اگر فرق دارد تغییر بده
        $seo = $blog_post->seo ?? new BlogSeo(); // اگر seo موجود نبود نمونه خالی می‌سازیم

        return view('blog::admin.blog_post.show', compact('blog_post', 'seo'));
    }


    /* -------------------------------------------------
     *  فرم ویرایش مقاله
     * -------------------------------------------------*/
    public function edit(BlogPost $blog_post)
    {
        session()->put('body_image_folder', $blog_post->body_image_folder ?? time() . '-' . uniqid());

        $tags       = BlogTag::all();
        $categories = BlogPostCategory::all();
        $seo = $blog_post->seo()->first();

        return view('blog::admin.blog_post.edit', compact('blog_post', 'categories','seo', 'tags'));
    }

    /* -------------------------------------------------
     *  بروزرسانی مقاله
     * -------------------------------------------------*/
    public function update(BlogPostRequest $request, BlogPost $blog_post): RedirectResponse
    {
        $validated = $request->validated();

        DB::beginTransaction();
        try {
            /* --- آپدیت تاریخ انتشار --- */
            if ($request->filled('published_at')) {
                $validated['published_at'] = Verta::parse($request->get('published_at'))->datetime()->format('Y-m-d H:i:s');
            }

            /* --- آپلود تصاویر جدید در صورت وجود --- */
            $validated['thumbnail'] = $request->hasFile('thumbnail')
                ? $this->uploadFile($request->file('thumbnail'), BlogPost::THUMB_PATH, old_file: $blog_post->thumbnail)['path']
                : $blog_post->thumbnail;

            $validated['image'] = $request->hasFile('image')
                ? $this->uploadFile($request->file('image'), BlogPost::IMAGE_PATH, old_file: $blog_post->image)['path']
                : $blog_post->image;

            /* --- حفظ اسلاگ‌های قبلی در صورت خالی بودن --- */
            if (empty($validated['fa_slug'])) {
                $validated['fa_slug'] = $blog_post->fa_slug;
            }
            if (empty($validated['en_slug'])) {
                $validated['en_slug'] = $blog_post->en_slug;
            }

            $validated['user_id']           =  1;
            $validated['author']            =  $blog_post->author;
            /* --- بروزرسانی مقاله --- */
            $blog_post->update($validated);

            /* --- بروزرسانی تگ‌ها --- */
//            if (!empty($validated['tag_title'])) {
//                $tag_ids = collect($validated['tag_title'])->map(function ($tag_name) {
//                    return BlogTag::firstOrCreate(['tag_title' => $tag_name])->id;
//                });
//                $blog_post->tags()->sync($tag_ids);
//            }

            /* --- بروزرسانی سئو --- */
            $blog_post->seo()->updateOrCreate(
                ['blog_post_id' => $blog_post->id],
                [
                    'title'         => $validated['SEO-title'],
                    'description'   => $validated['description'],
                    'keywords'      => $validated['keywords'],
                    'focus_keyword' => $validated['focus_keyword'],
                    'reading_time'  => $validated['reading_time'],
                    'schema_markup'  => $validated['schema_markup'],
//                'author_name'   => $validated['author'] ?? auth()->user()->name,
                    'author_name'   => $validated['author'] ,
                ]
            );

            DB::commit();
            session()->forget('body_image_folder');

            return redirect()->route('admin.blog-post.index', $blog_post)
                ->with('toast-success', 'مقاله با موفقیت بروزرسانی شد.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('toast-error', 'خطا در بروزرسانی: ' . $e->getMessage());
        }
    }

    /* -------------------------------------------------
     *  حذف مقاله
     * -------------------------------------------------*/
    public function destroy(BlogPost $blog_post): RedirectResponse
    {
        if ($blog_post->body_image_folder) {
            $this->deleteDirectory(BlogPost::BODY_PATH . $blog_post->body_image_folder);
        }

        $this->deleteFile($blog_post->thumbnail);
        $this->deleteFile($blog_post->image);

        $blog_post->delete(); // soft delete

        return redirect()->route('admin.blog-post.index')
            ->with('toast-success', 'مقاله با موفقیت حذف شد.');
    }

    /*-------------------------------------------------
    | 08. تغییر وضعیت ستون‌های boolean
    |-------------------------------------------------*/
    public function toggleStatus(Request $request)
    {
        $request->validate([
            'id'    => 'required|exists:blog_posts,id',
            'field' => 'required|in:is_active,is_commentable',
            'value' => 'required|boolean',
        ]);

        BlogPost::where('id', $request->id)
            ->update([$request->field => $request->value]);

        return response()->json(['status' => 'success']);
    }

    /*-------------------------------------------------
    | 09. آپلود تصاویر درون ادیتور CKEditor
    |-------------------------------------------------*/
    public function uploadImageArticle(Request $request)
    {
        $session_folder_name = session()->get('body_image_folder');
        $request->validate([
            'upload' => 'required|image|mimes:jpeg,png,jpg,webp,gif|max:2048',
        ]);

        if ($request->hasFile('upload')) {
            $uploaded = $this->uploadFile($request->file('upload'), BlogPost::BODY_PATH . $session_folder_name);
            return response()->json([
                'uploaded' => true,
                'url' => asset($uploaded['url'])
            ]);
        }

        return response()->json(['uploaded' => false, 'error' => 'فایل آپلود نشد.'], 400);
    }

    /*-------------------------------------------------
    | واردات پست‌های وردپرس
    |-------------------------------------------------*/
    public function importForm()
    {
        $categories = BlogPostCategory::all();
        return view('blog::admin.blog_post.import', compact('categories'));
    }

    /*-------------------------------------------------
    | تست اتصال به وردپرس
    |-------------------------------------------------*/
    public function testWordPressConnection(Request $request): JsonResponse
    {
        $request->validate([
            'wordpress_url' => 'required|url',
            'username' => 'nullable|string',
            'password' => 'nullable|string',
            'application_password' => 'nullable|string',
        ]);

        try {
            $importer = new WordPressImporter(
                $request->wordpress_url,
                $request->username,
                $request->password,
                $request->application_password
            );

            $isConnected = $importer->testConnection();

            if ($isConnected) {
                $data = $importer->fetchPosts(1, 1);
                return response()->json([
                    'status' => 'success',
                    'message' => 'اتصال موفق بود',
                    'total_posts' => $data['total'] ?? 0,
                ]);
            } else {
                return response()->json([
                    'status' => 'error',
                    'message' => 'امکان اتصال به سایت وردپرس وجود ندارد',
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'خطا: ' . $e->getMessage(),
            ], 400);
        }
    }

    /*-------------------------------------------------
    | دریافت لیست پست‌های وردپرس
    |-------------------------------------------------*/
    public function fetchWordPressPosts(Request $request): JsonResponse
    {
        $request->validate([
            'wordpress_url' => 'required|url',
            'username' => 'nullable|string',
            'password' => 'nullable|string',
            'application_password' => 'nullable|string',
            'page' => 'nullable|integer|min:1',
            'per_page' => 'nullable|integer|min:1|max:100',
        ]);

        try {
            $importer = new WordPressImporter(
                $request->wordpress_url,
                $request->username,
                $request->password,
                $request->application_password
            );

            $page = $request->get('page', 1);
            $perPage = $request->get('per_page', 20);

            $data = $importer->fetchPosts($perPage, $page);

            // فرمت کردن پست‌ها برای نمایش
            $posts = array_map(function ($post) {
                return [
                    'id' => $post['id'],
                    'title' => $post['title']['rendered'] ?? $post['title'] ?? '',
                    'date' => $post['date'] ?? '',
                    'excerpt' => strip_tags($post['excerpt']['rendered'] ?? $post['excerpt'] ?? ''),
                    'link' => $post['link'] ?? '',
                ];
            }, $data['posts']);

            return response()->json([
                'status' => 'success',
                'posts' => $posts,
                'pagination' => [
                    'current_page' => $page,
                    'total' => $data['total'],
                    'total_pages' => $data['totalPages'],
                    'per_page' => $perPage,
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'خطا: ' . $e->getMessage(),
            ], 400);
        }
    }

    /*-------------------------------------------------
    | واردات پست‌های انتخاب شده از وردپرس
    |-------------------------------------------------*/
    public function importWordPressPosts(Request $request): JsonResponse
    {
        $request->validate([
            'wordpress_url' => 'required|url',
            'username' => 'nullable|string',
            'password' => 'nullable|string',
            'application_password' => 'nullable|string',
            'post_ids' => 'required|array',
            'post_ids.*' => 'required|integer',
            'default_category_id' => 'required|exists:blog_post_categories,id',
        ]);

        DB::beginTransaction();
        try {
            $importer = new WordPressImporter(
                $request->wordpress_url,
                $request->username,
                $request->password,
                $request->application_password
            );

            $imported = [];
            $failed = [];

            // دریافت پست‌های انتخاب شده
            // WordPress REST API از فیلتر کردن با چند ID پشتیبانی نمی‌کند، پس باید همه را بگیریم
            $allPosts = [];
            $page = 1;
            $foundCount = 0;
            do {
                $data = $importer->fetchPosts(100, $page);
                $allPosts = array_merge($allPosts, $data['posts']);

                // بررسی اینکه آیا همه پست‌های مورد نظر را پیدا کردیم
                foreach ($data['posts'] as $post) {
                    if (in_array($post['id'], $request->post_ids)) {
                        $foundCount++;
                    }
                }

                $page++;
            } while ($page <= $data['totalPages'] && $foundCount < count($request->post_ids));

            // فیلتر کردن پست‌های انتخاب شده
            $selectedPosts = array_filter($allPosts, function ($post) use ($request) {
                return in_array($post['id'], $request->post_ids);
            });

            foreach ($selectedPosts as $wpPost) {
                try {
                    $post = $importer->importPost($wpPost, $request->default_category_id);
                    $imported[] = [
                        'id' => $post->id,
                        'title' => $post->title,
                    ];
                } catch (\Exception $e) {
                    $failed[] = [
                        'id' => $wpPost['id'],
                        'title' => $wpPost['title']['rendered'] ?? '',
                        'reason' => $e->getMessage(),
                    ];
                }
            }

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => count($imported) . ' پست با موفقیت وارد شد',
                'imported' => $imported,
                'failed' => $failed,
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => 'خطا در واردات: ' . $e->getMessage(),
            ], 400);
        }
    }
}
