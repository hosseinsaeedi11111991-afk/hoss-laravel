<?php
namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class BlogPostTagRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'blog_post_id' => $this->isMethod('POST') ? 'required|exists:blog_posts,id' : 'sometimes|exists:blog_posts,id',
            'tag_id'       => $this->isMethod('POST') ? 'required|exists:blog_tags,id'  : 'sometimes|exists:blog_tags,id',
        ];
    }

    public function messages(): array
    {
        return [
            'blog_post_id.required'=> 'شناسه پست الزامی است.',
            'tag_id.required'      => 'شناسه برچسب الزامی است.',
        ];
    }
}
