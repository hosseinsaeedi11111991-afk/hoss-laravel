<?php
namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class BlogRatingRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'rating'       => $this->isMethod('POST') ? 'required|integer|between:1,5' : 'sometimes|integer|between:1,5',
            'user_id'      => $this->isMethod('POST') ? 'required|exists:users,id'     : 'sometimes|exists:users,id',
            'blog_post_id' => $this->isMethod('POST') ? 'required|exists:blog_posts,id': 'sometimes|exists:blog_posts,id',
        ];
    }

    public function messages(): array
    {
        return [
            'rating.required' => 'امتیاز الزامی است.',
            'rating.between'  => 'امتیاز باید عددی بین ۱ تا ۵ باشد.',
            'user_id.required'=> 'کاربر الزامی است.',
            'blog_post_id.required'=> 'پست الزامی است.',
        ];
    }
}
