<?php

namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class BlogSeoRequest extends FormRequest
{
    /**
     * آیا کاربر اجازه دسترسی دارد؟
     */
    public function authorize(): bool
    {
        return true; // در صورت استفاده از middleware 'auth' نیازی به تغییر نیست
    }

    /**
     * قوانین اعتبارسنجی
     */
    public function rules(): array
    {
        // هنگام ایجاد (POST) فیلدها الزامی هستند؛ هنگام ویرایش (PUT/PATCH) اختیاری
        $required_if_post = $this->isMethod('POST') ? 'required' : 'sometimes';

        return [
            'blog_post_id'   => [$required_if_post, 'integer', 'exists:blog_posts,id'],
            'title'          => [$required_if_post, 'string', 'max:60'],
            'description'    => [$required_if_post, 'string', 'max:160'],
            'keywords'       => ['nullable', 'string'],
            'author_name'    => ['nullable', 'string', 'max:100'],
            'schema_markup'  => ['nullable', 'json'],
            'focus_keyword'  => ['nullable', 'string', 'max:50'],
            'reading_time'   => ['nullable', 'string', 'max:10'],
        ];
    }

    /**
     * پیام‌های خطای فارسی
     */
    public function messages(): array
    {
        return [
            'blog_post_id.required' => 'شناسه پست الزامی است.',
            'blog_post_id.exists'   => 'پست مورد نظر یافت نشد.',
            'title.required'        => 'عنوان سئو الزامی است.',
            'title.max'             => 'عنوان سئو حداکثر ۶۰ کاراکتر باشد.',
            'description.required'  => 'توضیحات سئو الزامی است.',
            'description.max'       => 'توضیحات سئو حداکثر ۱۶۰ کاراکتر باشد.',
            'author_name.max'       => 'نام نویسنده حداکثر ۱۰۰ کاراکتر باشد.',
            'focus_keyword.max'     => 'کلمه کلیدی تمرکز حداکثر ۵۰ کاراکتر باشد.',
            'reading_time.max'      => 'زمان مطالعه حداکثر ۱۰ کاراکتر باشد.',
            'schema_markup.json'    => 'فرمت داده‌ی结构化标记 باید JSON معتبر باشد.',
        ];
    }
}
