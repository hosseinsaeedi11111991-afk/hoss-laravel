<?php

namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class BlogPostRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */

    public function rules()
    {
        // این باید شناسه خود پست باشه، نه دسته‌بندی
        $blogPostId = $this->route('blog_post')?->id ?: null;


        if ($this->isMethod('post')) {
            return [
                'title' => 'required|string|max:255',
                'tag-title' => 'nullable|max:255',
                'summary' => 'required|string|max:500',
                'body' => 'required|string',
                'fa_slug' => [
                    'nullable',
                    'string',
                    'max:255',
                    Rule::unique('blog_posts', 'fa_slug')->ignore($blogPostId),
                ],
                'en_slug' => [
                    'nullable',
                    'string',
                    'max:255',
                    Rule::unique('blog_posts', 'en_slug')->ignore($blogPostId),
                ],
                'thumbnail' => 'required|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
                'thumbnail_tag' => 'nullable|string|max:255',
                'image' => 'required|image|mimes:jpeg,png,jpg,gif,webp|max:4096',
                'image_tag' => 'nullable|string|max:255',
                'is_active' => 'boolean',
                'is_commentable' => 'boolean',
                'status' => 'nullable|in:draft,published,archived',
                'blog_post_category_id' => 'required|exists:blog_post_categories,id',
                'published_at' => 'required|date',
//                SEO
                'SEO-title' => 'required|string|max:60',
                'description' => 'required|string|max:160',
                'keywords' => 'nullable|string',
                'author_name' => 'nullable|string|max:100',
                'focus_keyword' => 'nullable|string|max:50',
                'reading_time' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) {
                        if (!preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $value)) {
                            $fail('فرمت زمان مطالعه نامعتبر است. لطفاً به صورت ساعت:دقیقه (مثال: 01:30) وارد کنید.');
                        }
                    },
                ],
            ];
        } elseif ($this->isMethod('put')) {
            return [
                'title' => 'required|string|max:255',
                'tag-title' => 'nullable|max:255',
                'summary' => 'required|string|max:500',
                'body' => 'required|string',
                'fa_slug' => [
                    'nullable',
                    'string',
                    'max:255',
                    Rule::unique('blog_posts', 'fa_slug')->ignore($blogPostId),
                ],
                'en_slug' => [
                    'nullable',
                    'string',
                    'max:255',
                    Rule::unique('blog_posts', 'en_slug')->ignore($blogPostId),
                ],

                'thumbnail' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
                'thumbnail_tag' => 'nullable|string|max:255',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:4096',
                'image_tag' => 'nullable|string|max:255',
                'is_active' => 'boolean',
                'is_commentable' => 'boolean',
                'status' => 'nullable|in:draft,published,archived',
                'blog_post_category_id' => 'required|exists:blog_post_categories,id',
                'published_at' => 'required|date',
//
                'SEO-title' => 'required|string|max:60',
                'description' => 'required|string|max:160',
                'keywords' => 'nullable|string',
                'author_name' => 'nullable|string|max:100',
                'schema_markup' => 'required|json',
                'focus_keyword' => 'nullable|string|max:50',
                'reading_time' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) {
                        if (!preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $value)) {
                            $fail('فرمت زمان مطالعه نامعتبر است. لطفاً به صورت ساعت:دقیقه (مثال: 01:30) وارد کنید.');
                        }
                    },
                ],
            ];
        }
    }

    public function messages()
    {
        return [
            'title.required' => 'عنوان پست الزامی است.',
            'title.max' => 'عنوان پست نباید بیشتر از ۲۵۵ کاراکتر باشد.',
            'summary.required' => 'خلاصه پست الزامی است.',
            'summary.max' => 'خلاصه پست نباید بیشتر از ۵۰۰ کاراکتر باشد.',
            'body.required' => 'محتویات پست الزامی است.',
            'thumbnail.image' => 'فایل تصویر شاخص باید از نوع تصویر باشد.',
            'thumbnail.required' => 'فایل تصویر شاخص نمیتواند خالی باشد.',
            'thumbnail.mimes' => 'فرمت‌های مجاز برای تصویر شاخص: jpeg, png, jpg, gif, webp.',
            'thumbnail.max' => 'حجم تصویر شاخص نباید بیشتر از ۲ مگابایت باشد.',
            'thumbnail_tag.max' => 'تگ تصویر شاخص نباید بیشتر از ۲۵۵ کاراکتر باشد.',
            'image.required' => 'فایل تصویر اصلی نمیتواند خالی باشد.',
            'image.image' => 'فایل تصویر اصلی باید از نوع تصویر باشد.',
            'image.mimes' => 'فرمت‌های مجاز برای تصویر اصلی: jpeg, png, jpg, gif, webp.',
            'image.max' => 'حجم تصویر اصلی نباید بیشتر از ۴ مگابایت باشد.',
            'image_tag.max' => 'تگ تصویر اصلی نباید بیشتر از ۲۵۵ کاراکتر باشد.',
            'is_active.boolean' => 'وضعیت فعال باید 1 یا 0 باشد.',
            'is_commentable.boolean' => 'وضعیت قابلیت کامنت باید 1 یا 0 باشد.',
            'status.in' => 'وضعیت پست باید یکی از موارد: پیش‌نویس، منتشر شده، آرشیو باشد.',
            'blog_post_category_id.required' => 'انتخاب دسته‌بندی الزامی است.',
            'blog_post_category_id.exists' => 'دسته‌بندی انتخاب شده معتبر نیست.',
            'published_at.date' => 'تاریخ انتشار باید معتبر باشد.',
            'published_at.required' => 'تاریخ انتشار الزامی است.',
            'fa_slug.unique' => 'اسلاگ فارسی تکراری است.',
            'fa_slug.regex' => 'اسلاگ فارسی باید فقط شامل حروف فارسی، اعداد و خط تیره باشد.',
            'en_slug.unique' => 'اسلاگ انگلیسی تکراری است.',
//            SEO
            // عنوان
            'SEO-title.required' => 'عنوان مطلب الزامی است.',
            'SEO-title.string' => 'عنوان باید به صورت متن باشد.',
            'SEO-title.max' => 'عنوان نباید بیشتر از ۶۰ کاراکتر باشد.',

            // توضیحات
            'description.required' => 'توضیحات متا الزامی است.',
            'description.string' => 'توضیحات باید به صورت متن باشد.',
            'description.max' => 'توضیحات نباید بیشتر از ۱۶۰ کاراکتر باشد.',

            // کلمات کلیدی
            'keywords.required' => 'کلمات کلیدی الزامی است.',
            'keywords.string' => 'کلمات کلیدی باید به صورت متن باشد.',

            // نام نویسنده
            'author_name.string' => 'نام نویسنده باید به صورت متن باشد.',
            'author_name.max' => 'نام نویسنده نباید بیشتر از ۱۰۰ کاراکتر باشد.',

            // نشانه‌گذاری اسکیما
            'schema_markup.json' => 'فرمت نشانه‌گذاری اسکیما نامعتبر است.',

            // کلمه کلیدی اصلی
            'focus_keyword.required' => 'کلمه کلیدی اصلی الزامی است.',
            'focus_keyword.string' => 'کلمه کلیدی اصلی باید به صورت متن باشد.',
            'focus_keyword.max' => 'کلمه کلیدی اصلی نباید بیشتر از ۵۰ کاراکتر باشد.',

            // زمان مطالعه
            'reading_time.required' => 'زمان مطالعه الزامی است.',
            'reading_time.regex' => 'فرمت زمان مطالعه نامعتبر است. مثال صحیح: "30 دقیقه" یا "2 ساع'
        ];
    }

    public function attributes()
    {
        return [
            'title' => 'عنوان',
            'description' => 'توضیحات',
            'keywords' => 'کلمات کلیدی',
            'focus_keyword' => 'کلمه کلیدی',
            'reading_time' => 'زمان مطالعه',
            'SEO-title' => 'عنوان-title',
            'summary' => 'خلاصه',
            'body' => 'محتوا',
            'thumbnail' => 'تصویر شاخص',
            'thumbnail_tag' => 'تگ تصویر شاخص',
            'image' => 'تصویر اصلی',
            'image_tag' => 'تگ تصویر اصلی',
            'is_active' => 'وضعیت فعال',
            'is_commentable' => 'قابلیت کامنت',
            'status' => 'وضعیت',
            'post_category_id' => 'دسته‌بندی',
            'published_at' => 'تاریخ انتشار',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
