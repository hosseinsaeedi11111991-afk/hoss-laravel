<?php

namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class BlogTagRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $blogTagId = $this->route('blog_tag')?->id;

        return [
            'tag_title' => $this->isMethod('POST')
                ? 'required|string|max:255'
                : 'sometimes|string|max:255',

            'fa_slug' => [
                'required',
                'string',
                'max:255',
                'regex:/^[\x{0600}-\x{06FF}\d\-\s]+$/u',
                Rule::unique('blog_tags', 'fa_slug')->ignore($blogTagId),
            ],

            'en_slug' => [
                'required',
                'string',
                'max:255',
                Rule::unique('blog_tags', 'en_slug')->ignore($blogTagId),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'tag_title.required' => 'عنوان برچسب الزامی است.',
            'fa_slug.required' => 'اسلاگ فارسی الزامی است.',
            'en_slug.required' => 'اسلاگ انگلیسی الزامی است.',
            'fa_slug.unique' => 'اسلاگ فارسی تکراری است.',
            'en_slug.unique' => 'اسلاگ انگلیسی تکراری است.',
            'fa_slug.regex' => 'اسلاگ فارسی باید فقط شامل حروف فارسی، اعداد و خط تیره باشد.',
        ];
    }
}
