<?php

namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class BlogPostCategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $blogPostCategoryId = $this->route('blog_post_category')?->id;

        return [
            'name' => $this->isMethod('POST')
                ? 'required|string|max:255'
                : 'sometimes|string|max:255',

            'fa_slug' => [
                'required',
                'string',
                'max:255',
                'regex:/^[\x{0600}-\x{06FF}\d\-\s]+$/u',
                Rule::unique('blog_post_categories', 'fa_slug')->ignore($blogPostCategoryId),
            ],

            'en_slug' => [
                'required',
                'string',
                'max:255',
                Rule::unique('blog_post_categories', 'en_slug')->ignore($blogPostCategoryId),
            ],

            'description' => 'sometimes|nullable|string',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'نام دسته‌بندی الزامی است.',
            'fa_slug.required' => 'اسلاگ فارسی الزامی است.',
            'en_slug.required' => 'اسلاگ انگلیسی الزامی است.',
            'fa_slug.unique' => 'اسلاگ فارسی تکراری است.',
            'en_slug.unique' => 'اسلاگ انگلیسی تکراری است.',
            'fa_slug.regex' => 'اسلاگ فارسی باید فقط شامل حروف فارسی، اعداد و خط تیره باشد.',
        ];
    }

}
