<?php
namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class BlogLikeRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'user_id'      => $this->isMethod('POST') ? 'required|exists:users,id'      : 'sometimes|exists:users,id',
            'blog_post_id' => $this->isMethod('POST') ? 'required|exists:blog_posts,id' : 'sometimes|exists:blog_posts,id',
        ];
    }

    public function messages(): array
    {
        return [
            'user_id.required'     => 'شناسه کاربر الزامی است.',
            'blog_post_id.required'=> 'شناسه پست الزامی است.',
        ];
    }
}
