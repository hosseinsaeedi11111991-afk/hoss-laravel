<?php

namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreBlogPostRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title'                 => 'required|string|max:255',
            'summary'               => 'required|string',
            'body'                  => 'required|string',
            'blog_post_category_id' => 'required|exists:blog_post_categories,id',
            'thumbnail'             => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'image'                 => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'thumbnail_tag'         => 'nullable|string|max:255',
            'image_tag'             => 'nullable|string|max:255',
            'published_at'          => 'nullable|date',
            'is_active'             => 'boolean',
            'is_commentable'        => 'boolean',
            'status'                => 'nullable|in:draft,published,archived',
            'tag_title'             => 'nullable|array',
            'tag_title.*'           => 'string|max:50',

            /* --- فیلدهای سئو --- */
            'seo_title'        => 'required|string|max:60',
            'seo_description'  => 'required|string|max:160',
            'seo_keywords'     => 'required|string',
            'seo_focus_keyword'=> 'required|string|max:50',
            'seo_reading_time' => 'required|string|max:10',
        ];
    }

    public function messages(): array
    {
        return [
            'title.required'          => 'عنوان الزامی است.',
            'summary.required'        => 'خلاصه الزامی است.',
            'body.required'           => 'محتوا الزامی است.',
            'blog_post_category_id.required' => 'دسته‌بندی الزامی است.',
            'seo_title.required'      => 'عنوان سئو الزامی است.',
            'seo_description.required'=> 'توضیحات سئو الزامی است.',
        ];
    }
}
