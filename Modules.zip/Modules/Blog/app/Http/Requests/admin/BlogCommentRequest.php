<?php
namespace Modules\Blog\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class BlogCommentRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'         => $this->isMethod('POST') ? 'required|string|max:255' : 'sometimes|string|max:255',
            'email'        => 'sometimes|nullable|email|max:255',
            'description'  => $this->isMethod('POST') ? 'required|string'        : 'sometimes|string',
            'is_active'    => 'sometimes|boolean',
            'blog_post_id' => $this->isMethod('POST') ? 'required|exists:blog_posts,id' : 'sometimes|exists:blog_posts,id',
            'parent_id'    => 'sometimes|nullable|exists:blog_comments,id',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required'     => 'نام نویسنده نظر الزامی است.',
            'description.required'=> 'متن نظر الزامی است.',
            'blog_post_id.required'=> 'انتخاب پست الزامی است.',
            'email.email'       => 'فرمت ایمیل صحیح نیست.',
        ];
    }
}
