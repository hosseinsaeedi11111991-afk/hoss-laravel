<?php

namespace Modules\Blog\Traits;

use Illuminate\Support\Facades\Storage;

trait File
{
    public function uploadFile($file, $path)
    {
        $extension = $file->getClientOriginalExtension();
        $fileName = $path . time() . '.' . $extension;
        $file->move($path, $fileName);
        return $fileName;
    }

    public function UpdateFile($file, $path, $isFile, $RequestName)
    {
        $fileName = $isFile;
        if (!is_null($file->$RequestName)) {

            if (\Illuminate\Support\Facades\File::exists($isFile)) {
                \Illuminate\Support\Facades\File::delete($isFile);
            }
            $fileName = $this->uploadFile($file->file($RequestName), $path);
        }
        return $fileName;
    }

    public function deleteFile($isFile)
    {
        if (!is_null($isFile)) {
            if (\Illuminate\Support\Facades\File::exists($isFile)) {
                \Illuminate\Support\Facades\File::delete($isFile);
            }
        }
    }

    public function deleteDirectory($dir)
    {
        $direct = public_path($dir);

        if (!file_exists($direct)) {
            return true;
        }
        if (!is_dir($direct)) {
            return unlink($direct);
        }
        foreach (scandir($direct) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }

            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        return rmdir($direct);
    }

}
