<?php

namespace Modules\Blog\Traits;



use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

trait FileHandler
{
    /**
     * آپلود فایل به استوریج
     *
     * @param mixed $file
     * @param string $path
     * @param string|null $fileName
     * @param string $disk
     * @return array
     */
    public function uploadFile($file, string $path, ?string $fileName = null, string $disk = 'public',string $old_file = null): array
    {
        // اعتبارسنجی فایل
        if (!$file || !$file->isValid()) {
            throw new \Exception('فایل معتبر نمی‌باشد');
        }
        if ($old_file){
            $this->deleteFile($old_file);
        }

        // تولید نام فایل
        $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $extension = $file->getClientOriginalExtension();
        $fileName = $fileName ?: Str::slug($originalName) . '-' . uniqid() . '.' . $extension;

        // ذخیره فایل
        $storedPath = $file->storeAs($path, $fileName, $disk);

        return [
            'original_name' => $file->getClientOriginalName(),
            'file_name' => $fileName,
            'path' => $storedPath,
            'full_path' => Storage::disk($disk)->path($storedPath),
            'url' => Storage::disk($disk)->url($storedPath),
            'size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'extension' => $extension,
        ];
    }



    /**
     * حذف فایل از استوریج
     *
     * @param string $path
     * @param string $disk
     * @return bool
     */
    public function deleteFile(string $path, string $disk = 'public'): bool
    {
        if (Storage::disk($disk)->exists($path)) {
            return Storage::disk($disk)->delete($path);
        }

        return false;
    }

    /**
     * آپلود چندین فایل
     *
     * @param array $files
     * @param string $path
     * @param string $disk
     * @return array
     */
    public function uploadMultipleFiles(array $files, string $path, string $disk = 'public'): array
    {
        $uploadedFiles = [];

        foreach ($files as $file) {
            $uploadedFiles[] = $this->uploadFile($file, $path, null, $disk);
        }

        return $uploadedFiles;
    }
    /**
     * حذف پوشه و تمام محتویات آن از استوریج
     *
     * @param string $directoryPath
     * @param string $disk
     * @return bool
     */
    public function deleteDirectory(string $directoryPath, string $disk = 'public'): bool
    {
        // بررسی وجود پوشه
        if (Storage::disk($disk)->exists($directoryPath)) {
            // حذف کامل پوشه و تمام محتویات آن
            return Storage::disk($disk)->deleteDirectory($directoryPath);
        }

        return false;
    }
    /**
     * بررسی وجود فایل
     *
     * @param string $path
     * @param string $disk
     * @return bool
     */
    public function fileExists(string $path, string $disk = 'public'): bool
    {
        return Storage::disk($disk)->exists($path);
    }

    /**
     * دریافت URL فایل
     *
     * @param string $path
     * @param string $disk
     * @return string|null
     */
    public function getFileUrl(string $path, string $disk = 'public'): ?string
    {
        return Storage::disk($disk)->exists($path) ? Storage::disk($disk)->url($path) : null;
    }
}
