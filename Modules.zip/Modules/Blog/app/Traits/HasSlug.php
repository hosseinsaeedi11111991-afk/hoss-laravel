<?php

namespace Modules\Blog\Traits;

use Illuminate\Support\Str;

trait HasSlug
{
    protected static function bootHasSlug()
    {
        static::creating(function ($model) {
            $model->generateSlugOnCreate();
        });

        static::updating(function ($model) {
            $model->generateSlugOnUpdate();
        });
    }

    protected function generateSlugOnCreate()
    {
        if ($this->slug) {
            return;
        }
        $this->slug = $this->generateUniqueSlug($this->getSlugSource());
    }

    protected function generateSlugOnUpdate()
    {
        if (!$this->isDirty($this->getSlugSourceField())) {
            return;
        }
        $this->slug = $this->generateUniqueSlug($this->getSlugSource());
    }

    protected function generateUniqueSlug(string $source): string
    {
        $slug = $this->createSlug($source);
        $originalSlug = $slug;
        $counter = 1;

        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter++;
        }

        return $slug;
    }

    /**
     * تابع اصلی ساخت اسلاگ از متن فارسی
     */
    protected function createSlug(string $text): string
    {
        // تبدیل اعداد فارسی به انگلیسی (اختیاری)
        $text = $this->persianNumbersToEnglish($text);

        // تبدیل متن به اسلاگ فارسی
        $slug = str_replace(' ', '-', $text);
        $slug = preg_replace('/[^\p{L}\p{N}\-]/u', '', $slug);
        $slug = preg_replace('/-+/', '-', $slug);

        return trim($slug, '-');
    }

    /**
     * تبدیل اعداد فارسی به انگلیسی (اختیاری)
     */
    protected function persianNumbersToEnglish(string $text): string
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        return str_replace($persian, $english, $text);
    }

    protected function slugExists(string $slug): bool
    {
        $query = static::where('slug', $slug);

        if ($this->exists) {
            $query->where($this->getKeyName(), '!=', $this->getKey());
        }

        return $query->exists();
    }

    protected function getSlugSource(): string
    {

        return $this->{$this->getSlugSourceField()};
    }

    protected function getSlugSourceField(): string
    {
        return property_exists($this, 'slugSource')
            ? $this->slugSource
            : 'title';
    }
}
