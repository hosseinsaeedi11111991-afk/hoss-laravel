<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blog_posts', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('summary');
            $table->string('fa_slug')->unique()->nullable();
            $table->string('en_slug')->unique()->nullable();
            $table->string('thumbnail')->nullable();
            $table->string('thumbnail_tag')->nullable();
            $table->string('image')->nullable();
            $table->string('image_tag')->nullable();
            $table->longText('body');
            $table->string('body_image_folder')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('is_commentable')->default(true);
            $table->unsignedBigInteger('likes_count')->default(0);
            $table->unsignedBigInteger('views_count')->default(0);
            $table->enum('status', ['draft', 'published', 'archived'])->default('draft');
            $table->string('author')->nullable();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('blog_post_category_id')->constrained('blog_post_categories')->cascadeOnDelete();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blog_posts');
    }
};
