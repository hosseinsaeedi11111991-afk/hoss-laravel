<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blog_seo', function (Blueprint $table) {
            $table->id();
            $table->foreignId('blog_post_id')->constrained('blog_posts')->cascadeOnDelete(); // ✅ اصلاح نام
            $table->string('title', 60);
            $table->string('description', 160);
            $table->text('keywords')->nullable();
            $table->string('author_name', 100)->nullable();
            $table->json('schema_markup')->nullable();
            $table->string('focus_keyword', 50)->nullable();
            $table->string('reading_time', 50)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blog_seo');
    }
};
