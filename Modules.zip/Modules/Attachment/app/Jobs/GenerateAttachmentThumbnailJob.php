<?php

namespace Modules\Attachment\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Services\FileStorageService;

class GenerateAttachmentThumbnailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(protected Attachment $attachment) {}

    public function handle(FileStorageService $storage): void
    {
        if ($this->attachment->file_type !== Attachment::FILE_TYPE_IMAGE) {
            return;
        }

        $sizes = [
            'small'  => 150,
            'medium' => 300,
            'large'  => 600,
            'xlarge' => 1200,
        ];

        $originalPath = $storage->diskPath($this->attachment->disk, $this->attachment->path);

        foreach ($sizes as $sizeName => $dimension) {
            $thumbPath = "thumbnails/{$sizeName}/" . basename($this->attachment->path);
            $this->createThumbnail($originalPath, $storage->diskPath($this->attachment->disk, $thumbPath), $dimension);

            $this->attachment->thumbnails()->create([
                'size' => $sizeName,
                'path' => $thumbPath,
            ]);
        }
    }

    /**
     * Resize and crop image to square using GD
     */
    private function createThumbnail(string $sourcePath, string $destPath, int $dimension): void
    {
        [$width, $height, $type] = getimagesize($sourcePath);

        switch ($type) {
            case IMAGETYPE_JPEG:
                $src = imagecreatefromjpeg($sourcePath);
                break;
            case IMAGETYPE_PNG:
                $src = imagecreatefrompng($sourcePath);
                break;
            case IMAGETYPE_GIF:
                $src = imagecreatefromgif($sourcePath);
                break;
            case IMAGETYPE_WEBP:
                $src = imagecreatefromwebp($sourcePath);
                break;
            default:
                throw new \RuntimeException('Unsupported image type for thumbnail.');
        }

        if ($width > $height) {
            $new_width = $dimension;
            $new_height = (int)($height * ($dimension / $width));
        } else {
            $new_height = $dimension;
            $new_width = (int)($width * ($dimension / $height));
        }

        $thumb = imagecreatetruecolor($new_width, $new_height);

        // Preserve transparency for PNG and GIF
        if ($type === IMAGETYPE_PNG || $type === IMAGETYPE_GIF) {
            imagecolortransparent($thumb, imagecolorallocatealpha($thumb, 0, 0, 0, 127));
            imagealphablending($thumb, false);
            imagesavealpha($thumb, true);
        }

        imagecopyresampled($thumb, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

        $this->ensureDirectoryExists($destPath);

        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($thumb, $destPath, 90);
                break;
            case IMAGETYPE_PNG:
                imagepng($thumb, $destPath);
                break;
            case IMAGETYPE_GIF:
                imagegif($thumb, $destPath);
                break;
            case IMAGETYPE_WEBP:
                imagewebp($thumb, $destPath, 90);
                break;
        }

        imagedestroy($src);
        imagedestroy($thumb);
    }

    private function ensureDirectoryExists(string $filePath): void
    {
        $dir = dirname($filePath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}
