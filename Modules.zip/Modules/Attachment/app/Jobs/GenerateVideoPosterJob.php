<?php

namespace Modules\Attachment\Jobs;

use FFMpeg\FFMpeg;
use FFMpeg\Coordinate\TimeCode;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Http\File;
use Illuminate\Http\UploadedFile;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Services\AttachmentService;
use Modules\Attachment\Services\FileStorageService;

class GenerateVideoPosterJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        protected Attachment $attachment,
        protected AttachmentService $attachment_service,
        protected FileStorageService $storage
    ) {
    }

    public function handle(): void
    {
        if ($this->attachment->file_type !== Attachment::FILE_TYPE_VIDEO) {
            return;
        }

        $video_path = $this->storage->diskPath($this->attachment->disk, $this->attachment->path);

        $ffmpeg = FFMpeg::create();
        $video = $ffmpeg->open($video_path);

        $duration = $video->getStreams()->videos()->first()->get('duration');
        $frame_path = tempnam(sys_get_temp_dir(), 'poster') . '.jpg';
        $frame = $video->frame(TimeCode::fromSeconds(1));
        $frame->save($frame_path);

        $poster_file = new UploadedFile(
            $frame_path,
            basename($frame_path),
            'image/jpeg',
            null,
            true,
        );

        $poster = $this->attachment_service->uploadFile(
            $poster_file,
            $this->attachment->disk,
            'posters/' . date('Ymd')
        );

        if ($poster->file_type === Attachment::FILE_TYPE_IMAGE) {
            GenerateAttachmentThumbnailJob::dispatch($poster);
        }

        $this->attachment->video()->create([
            'poster_id' => $poster->id,
            'duration' => (int) $duration,
        ]);

        @unlink($frame_path);
    }
}
