<?php

namespace Modules\Attachment\Traits;

trait AttachmentTools
{
    /**
     * Get formatted attachments for display
     *
     * @param string|null $role
     * @param string|null $file_type
     * @param bool $with_thumbnail
     * @param bool $with_meta
     * @param bool $only_active
     * @param int $per_page
     * @return \Illuminate\Support\Collection|\Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function formattedAttachments(
        string $role = '',
        string $file_type = '',
        bool $only_active = true,
        bool $with_thumbnail = true,
        bool $with_meta = true,
        int $per_page = 0
    ) {
        $query = $this->attachments()
            ->with(['attachment' => function ($q) use ($file_type, $with_thumbnail, $with_meta) {
                $q->select('id', 'disk', 'path', 'file_size', 'file_type');

                if ($file_type) {
                    $q->where('file_type', $file_type);
                }

                if ($with_thumbnail && $file_type === 'image') {
                    $q->with('thumbnails');
                }

                if ($with_meta) {
                    $q->with('meta');
                }
            }]);

        $query = $only_active ? $query->active() : $query;

        if ($role) {
            $query->role($role);
        }

        $query->orderBy('sort_order', 'asc');

        // یک helper function برای transform
        $transform = function ($item) use ($with_thumbnail, $with_meta) {
            $result = [
                // attachable fields
                'attachable_id'   => $item->attachable_id,
                'attachable_type' => $item->attachable_type,
                'role'            => $item->role,
                'status'          => $item->status,
                'sort_order'      => $item->sort_order,

                // attachment fields
                'attachment_id'   => $item->attachment->id ?? null,
                'path'            => $item->attachment->path ?? null,
                'disk'            => $item->attachment->disk ?? null,
                'file_size'       => $item->attachment->file_size ?? null,
                'file_type'       => $item->attachment->file_type ?? null,
            ];

            if ($with_thumbnail && isset($item->attachment->thumbnails)) {
                $result['thumbnails'] = $item->attachment->thumbnails->mapWithKeys(fn($thumb) => [
                    $thumb->size => $thumb->path
                ])->toArray();
            }

            if ($with_meta && isset($item->attachment->meta)) {
                $result['meta'] = $item->attachment->meta->mapWithKeys(fn($meta) => [
                    $meta->attribute => $meta->value
                ])->toArray();
            }

            return $result;
        };

        if ($per_page > 0) {
            $attachments = $query->paginate($per_page);
            $attachments->getCollection()->transform($transform);
            return $attachments;
        }

        return $query->get()->transform($transform);
    }
}
