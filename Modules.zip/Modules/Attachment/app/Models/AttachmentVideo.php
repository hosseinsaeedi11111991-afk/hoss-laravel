<?php

namespace Modules\Attachment\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $attachment_id
 * @property int|null $poster_id
 * @property int|null $duration
 */
class AttachmentVideo extends Model
{
    protected $fillable = [
        'attachment_id', 
        'poster_id', 
        'duration'
    ];

    /**
     * The main attachment this video belongs to
     */
    public function attachment()
    {
        return $this->belongsTo(Attachment::class);
    }

    /**
     * Optional poster attachment
     */
    public function poster()
    {
        return $this->belongsTo(Attachment::class, 'poster_id');
    }

    /**
     * Scope videos that have a poster
     */
    public function scopeWithPoster($query)
    {
        return $query->whereNotNull('poster_id');
    }

    /**
     * Scope videos longer than specified duration
     */
    public function scopeDurationGreaterThan($query, int $seconds)
    {
        return $query->where('duration', '>', $seconds);
    }
}
