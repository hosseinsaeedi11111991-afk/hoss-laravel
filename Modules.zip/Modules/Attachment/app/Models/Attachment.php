<?php

namespace Modules\Attachment\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $disk
 * @property string $path
 * @property string $file_name
 * @property int $file_size
 * @property string $file_type
 * @property string $mime_type
 * @property string $checksum
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 */
class Attachment extends Model
{
    public const FILE_TYPE_IMAGE = "image";
    public const FILE_TYPE_VIDEO = "video";
    public const FILE_TYPE_AUDIO = "audio";
    public const FILE_TYPE_DOCUMENT = "document";
    public const FILE_TYPE_OTHER = "other";

    protected $fillable = [
        'disk',
        'path',
        'file_name',
        'file_size',
        'file_type',
        'mime_type',
        'checksum'
    ];

    public function thumbnails()
    {
        return $this->hasMany(AttachmentThumbnail::class);
    }

    public function video()
    {
        return $this->hasOne(AttachmentVideo::class);
    }

    public function attachables()
    {
        return $this->hasMany(Attachable::class);
    }

    public function meta()
    {
        return $this->hasMany(AttachmentMeta::class);
    }

    public function getMeta(string $attribute): ?string
    {
        return $this->meta()->where('attribute', $attribute)->value('value');
    }

    public function scopeImages($query)
    {
        return $query->where('file_type', self::FILE_TYPE_IMAGE);
    }

    public function scopeVideos($query)
    {
        return $query->where('file_type', self::FILE_TYPE_VIDEO);
    }
}
