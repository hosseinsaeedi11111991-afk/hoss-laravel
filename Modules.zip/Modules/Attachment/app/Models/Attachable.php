<?php

namespace Modules\Attachment\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $attachment_id
 * @property string $attachable_type
 * @property int $attachable_id
 * @property string|null $role
 * @property int $sort_order
 * @property string $status
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 */
class Attachable extends Model
{
    protected $fillable = [
        'attachment_id',
        'attachable_type',
        'attachable_id',
        'role',
        'sort_order',
        'status'
    ];

    /**
     * The attachment associated with this pivot
     */
    public function attachment()
    {
        return $this->belongsTo(Attachment::class);
    }

    /**
     * The parent attachable model (polymorphic)
     */
    public function attachable()
    {
        return $this->morphTo();
    }

    /**
     * Scope active attachables
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    /**
     * Scope by role
     */
    public function scopeRole($query, string $role)
    {
        return $query->where('role', $role);
    }
}
