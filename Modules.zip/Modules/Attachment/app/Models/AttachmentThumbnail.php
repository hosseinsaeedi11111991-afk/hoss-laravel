<?php

namespace Modules\Attachment\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $attachment_id
 * @property string $size
 * @property string $path
 */
class AttachmentThumbnail extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'attachment_id',
        'size',
        'path'
    ];

    /**
     * The attachment this thumbnail belongs to
     */
    public function attachment()
    {
        return $this->belongsTo(Attachment::class);
    }

    /**
     * Scope to filter by size
     */
    public function scopeSize($query, string $size)
    {
        return $query->where('size', $size);
    }
}
