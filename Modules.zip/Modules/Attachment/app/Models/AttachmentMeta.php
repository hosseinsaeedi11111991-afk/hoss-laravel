<?php

namespace Modules\Attachment\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $attachment_id
 * @property string $attribute
 * @property string|null $value
 */
class AttachmentMeta extends Model
{
    public $timestamps = false;

    protected $table = 'attachment_meta';
    
    protected $fillable = [
        'attachment_id',
        'attribute',
        'value',
    ];

    /**
     * The attachment this meta belongs to
     */
    public function attachment()
    {
        return $this->belongsTo(Attachment::class);
    }

    /**
     * Scope to filter by attribute name
     */
    public function scopeAttribute($query, string $attribute)
    {
        return $query->where('attribute', $attribute);
    }
}
