<?php

namespace Modules\Attachment\Services;

use Illuminate\Http\UploadedFile;
use Psr\Log\LoggerInterface;

class ChecksumService
{
    protected int $chunk_size;
    protected LoggerInterface $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->chunk_size = config('attachment.chunk_size', 8388608);
        $this->logger = $logger;
    }

    /** 
     * Compute SHA-256 checksum from an UploadedFile (php tmp file). 
     * 
     * @param UploadedFile $file * @return string Hex-encoded sha256 (64 chars) 
     * 
     * @throws \RuntimeException if file can't be read 
     * 
     * */
    public function sha256FromUploadedFile(UploadedFile $file): string
    {
        $real_path = $file->getRealPath();
        if ($real_path === false || !is_readable($real_path)) {
            throw new \RuntimeException("Uploaded file is not readable.");
        }

        return $this->sha256FromPath($real_path);
    }

    /** 
     * Compute SHA-256 checksum from a local filesystem path. 
     * 
     * @param string $path 
     * 
     * @return string 
     * @throws \RuntimeException 
     * 
     */
    public function sha256FromPath(string $path): string
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new \RuntimeException("File '{$path}' does not exist or is not readable.");
        }

        $handle = fopen($path, 'rb');
        if ($handle === false) {
            throw new \RuntimeException("Failed to open file for reading: {$path}");
        }

        $ctx = hash_init('sha256');
        try {
            while (!feof($handle)) {
                $data = fread($handle, $this->chunk_size);
                if ($data === false) {
                    $this->logger->error("Error reading file during checksum: {$path}");
                    throw new \RuntimeException("Error reading file during checksum.");
                }
                if ($data !== '') {
                    hash_update($ctx, $data);
                }
            }

            return hash_final($ctx);
        } finally {
            fclose($handle);
        }
    }

    /** 
     * Compute SHA-256 checksum from a PHP stream resource.  
     * Useful when you have a stream resource instead of a path. 
     * 
     *  @param resource $resource 
     * @return string 
     */
    public function sha256FromStream($resource): string
    {
        if (!is_resource($resource)) {
            throw new \InvalidArgumentException('Provided value is not a valid stream resource.');
        }

        $ctx = hash_init('sha256');

        $meta = stream_get_meta_data($resource);
        if (!empty($meta['seekable'])) {
            rewind($resource);
        }

        while (!feof($resource)) {
            $data = fread($resource, $this->chunk_size);
            if ($data === false) {
                throw new \RuntimeException("Failed reading from provided stream for checksum.");
            }
            if ($data !== '') {
                hash_update($ctx, $data);
            }
        }

        if (!empty($meta['seekable'])) {
            rewind($resource);
        }

        return hash_final($ctx);
    }
}
