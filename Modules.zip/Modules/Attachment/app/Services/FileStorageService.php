<?php

namespace Modules\Attachment\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class FileStorageService
{
    public function __construct(protected string $default_disk = 'public') {}

    /**
     * Save and store uploaded file
     */
    public function storeUploadedFile(UploadedFile $file, ?string $disk = null, ?string $directory = null): array
    {
        $disk ??= $this->default_disk;
        $directory = ($directory)
            ? $directory . '/' . date('Ymd')
            : date('Ymd');

        $file_name = Str::random(16) . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs($directory, $file_name, $disk);

        return [
            'disk'      => $disk,
            'path'      => $path,
            'file_name' => $file_name,
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
        ];
    }

    /**
     * Save and store file from stream
     */
    public function storeFromStream($stream, string $extension, ?string $disk = null, ?string $directory = null): array
    {
        $disk ??= $this->default_disk;
        $directory = ($directory)
            ? $directory . '/' . date('Ymd')
            : date('Ymd');

        $file_name = Str::random(16) . '.' . $extension;
        $path = "{$directory}/{$file_name}";

        $meta = is_resource($stream) ? stream_get_meta_data($stream) : null;
        if (!empty($meta['seekable'])) {
            rewind($stream);
        }

        Storage::disk($disk)->put($path, $stream);

        return [
            'disk' => $disk,
            'path' => $path,
            'file_name' => $file_name,
            'file_size' => Storage::disk($disk)->size($path),
            'mime_type' => Storage::disk($disk)->mimeType($path),
        ];
    }

    public function diskPath(string $disk, string $path): string
    {
        try {
            return Storage::disk($disk)->path($path);
        } catch (\Exception $e) {
            return Storage::disk($disk)->url($path);
        }
    }
}
