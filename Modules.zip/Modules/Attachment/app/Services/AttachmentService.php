<?php

namespace Modules\Attachment\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Model;

use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Models\Attachable;
use Modules\Attachment\Jobs\GenerateAttachmentThumbnailJob;
use Modules\Attachment\Jobs\GenerateVideoPosterJob;

class AttachmentService
{
    public function __construct(
        protected ChecksumService $checksum_service,
        protected FileStorageService $file_storage_service
    ) {}

    /**
     * Upload a file (UploadedFile) and create attachment record.
     */
    public function uploadFile(UploadedFile $file, ?string $disk = null, ?string $directory = null): Attachment
    {
        $checksum = $this->checksum_service->sha256FromUploadedFile($file);

        return DB::transaction(function () use ($file, $disk, $directory, $checksum) {
            $attachment = Attachment::where('checksum', $checksum)->first();
            if ($attachment) {
                return $attachment;
            }

            $file_info = $this->file_storage_service->storeUploadedFile($file, $disk, $directory);

            $attachment = Attachment::create([
                'disk' => $file_info['disk'],
                'path' => $file_info['path'],
                'file_name' => $file_info['file_name'],
                'file_size' => $file_info['file_size'],
                'file_type' => $this->detectFileType($file),
                'mime_type' => $file_info['mime_type'],
                'checksum' => $checksum,
            ]);

            $this->dispatchProcessingJob($attachment);

            return $attachment;
        });
    }

    /**
     * Upload a stream and create attachment.
     */
    public function uploadStream($stream, string $originalFileName, string $extension, string $mime, ?string $disk = null, ?string $directory = null): Attachment
    {
        $checksum = $this->checksum_service->sha256FromStream($stream);

        return DB::transaction(function () use ($stream, $originalFileName, $extension, $mime, $disk, $directory, $checksum) {
            $attachment = Attachment::where('checksum', $checksum)->first();
            if ($attachment) {
                return $attachment;
            }

            $file_info = $this->file_storage_service->storeFromStream($stream, $extension, $disk, $directory);

            $attachment = Attachment::create([
                'disk' => $file_info['disk'],
                'path' => $file_info['path'],
                'file_name' => $originalFileName,
                'file_size' => $file_info['file_size'],
                'file_type' => $this->detectFileTypeFromMime($mime),
                'mime_type' => $file_info['mime_type'],
                'checksum' => $checksum,
            ]);

            $this->dispatchProcessingJob($attachment);

            return $attachment;
        });
    }

    /**
     * Attach processing job for thumbnail/poster
     */
    protected function dispatchProcessingJob(Attachment $attachment): void
    {
        if ($attachment->file_type === Attachment::FILE_TYPE_IMAGE) {
            GenerateAttachmentThumbnailJob::dispatch($attachment);
        } elseif ($attachment->file_type === Attachment::FILE_TYPE_VIDEO) {
            GenerateVideoPosterJob::dispatch($attachment);
        }
    }

    /**
     * Upsert metadata for an attachment
     */
    public function upsertMeta(Attachment $attachment, string $attribute, ?string $value): void
    {
        $attachment->meta()->updateOrCreate(
            ['attribute' => $attribute],
            ['value' => $value]
        );
    }

    /**
     * Attach an attachment to an attachable model (polymorphic)
     */
    public function attachToAttachable(
        Attachment $attachment,
        Model $attachable,
        ?string $role = null,
        int $sort_order = 0,
        string $status = 'active'
    ): Attachable {
        return $attachment->attachables()->updateOrCreate(
            [
                'attachable_type' => $attachable->getMorphClass(),
                'attachable_id' => $attachable->getKey()
            ],
            [
                'role' => $role,
                'sort_order' => $sort_order,
                'status' => $status
            ]
        );
    }

    public function updateAttachmentForAttachable(
        Attachable $attachable,
        array $data,
        ?UploadedFile $newFile = null,
        ?string $directory = null
    ): void {
        
        DB::transaction(function () use ($attachable, $data, $newFile, $directory) {
            $currentAttachment = $attachable->attachment;

            if ($newFile) {
                $disk = $currentAttachment->disk ?? null;
                $newAttachment = $this->uploadFile($newFile, $disk, $directory);

                $attachable->attachment()->associate($newAttachment);
                $attachable->save();

                if ($currentAttachment && $currentAttachment->attachables()->count() === 0) {
                    $this->deleteWithThumbnails($currentAttachment);
                }
                $currentAttachment = $newAttachment;
            }

            if (isset($data['sort_order'])) {
                $attachable->sort_order = (int) $data['sort_order'];
                $attachable->save();
            }

            $metaData = $data['meta'] ?? [];
            $this->updateAttachmentMeta($currentAttachment, $metaData);
        });
    }

    public function updateAttachmentMeta(Attachment $attachment, array $metaData): void
    {
        foreach ($metaData as $key => $value) {
            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            }
            $this->upsertMeta($attachment, $key, $value);
        }
    }

    /**
     * Detach attachment from a model, or delete completely if unused.
     */
    public function detachOrDelete(Attachment $attachment, Model $attachable): void
    {
        DB::transaction(function () use ($attachment, $attachable) {
            $attachment->attachables()
                ->where('attachable_type', $attachable->getMorphClass())
                ->where('attachable_id', $attachable->getKey())
                ->delete();

            if ($attachment->attachables()->count() === 0) {
                $this->deleteWithThumbnails($attachment);
            }
        });
    }

    /**
     * Delete attachment and its thumbnails (DB + storage).
     */
    public function deleteWithThumbnails(Attachment $attachment): bool
    {
        return DB::transaction(function () use ($attachment) {
            try {
                foreach ($attachment->thumbnails ?? [] as $thumb) {
                    Storage::disk($attachment->disk)->delete($thumb->path);
                    $thumb->delete();
                }

                // TODO: check videos poster

                $this->deleteAttachment($attachment);
            } catch (\Exception $e) {
                Log::warning("Failed deleting attachment files: {$e->getMessage()}");
            }

            return (bool) $attachment->delete();
        });
    }

    /**
     * Delete attachment (file + DB) atomically
     */
    public function deleteAttachment(Attachment $attachment): bool
    {
        return DB::transaction(function () use ($attachment) {
            try {
                Storage::disk($attachment->disk)->delete($attachment->path);
            } catch (\Exception $e) {
                Log::warning('Failed deleting attachment file from disk: ' . $e->getMessage());
            }

            return (bool) $attachment->delete();
        });
    }

    /**
     * Detect file type
     */
    protected function detectFileType(UploadedFile $file): string
    {
        $extension = strtolower($file->getClientOriginalExtension());

        return match ($extension) {
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp' => Attachment::FILE_TYPE_IMAGE,
            'mp4', 'mov', 'avi', 'mkv', 'webm' => Attachment::FILE_TYPE_VIDEO,
            'mp3', 'wav', 'aac', 'ogg' => Attachment::FILE_TYPE_AUDIO,
            'pdf', 'txt', 'doc', 'docx' => Attachment::FILE_TYPE_DOCUMENT,
            default => $this->detectFileTypeFromMime($file->getClientMimeType()),
        };
    }

    /**
     * Detect file type from mime type
     */
    protected function detectFileTypeFromMime(string $mime): string
    {
        return match (true) {
            str_starts_with($mime, 'image/') => Attachment::FILE_TYPE_IMAGE,
            str_starts_with($mime, 'video/') => Attachment::FILE_TYPE_VIDEO,
            str_starts_with($mime, 'audio/') => Attachment::FILE_TYPE_AUDIO,
            in_array($mime, ['application/pdf', 'text/plain', 'application/msword']) => Attachment::FILE_TYPE_DOCUMENT,
            default => Attachment::FILE_TYPE_OTHER,
        };
    }
}
