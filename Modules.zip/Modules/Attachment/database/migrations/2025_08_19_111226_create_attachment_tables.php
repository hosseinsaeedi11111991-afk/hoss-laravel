<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('attachments', function (Blueprint $table) {
            $table->id();
            $table->string('disk', 50)->default('public');
            $table->string('path', 255);
            $table->string('file_name', 100);
            $table->bigInteger('file_size');
            $table->enum('file_type', ['image', 'video', 'audio', 'document', 'other']);
            $table->string('mime_type', 50);
            $table->string('checksum', 64)->unique();
            $table->timestamps();

            $table->index('file_type');
            $table->index('created_at');
            $table->index(['file_name', 'mime_type']);
        });

        Schema::create('attachment_thumbnails', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attachment_id')->constrained('attachments')->cascadeOnDelete();
            $table->enum('size', ['small', 'medium', 'large', 'xlarge']);
            $table->string('path', 255);

            $table->unique(['attachment_id', 'size']);
            $table->index('attachment_id');
        });

        Schema::create('attachment_videos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attachment_id')->constrained('attachments')->cascadeOnDelete();
            $table->foreignId('poster_id')->nullable()->constrained('attachments')->nullOnDelete();
            $table->integer('duration')->nullable();

            $table->index(['attachment_id', 'poster_id']);
        });

        Schema::create('attachment_meta', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attachment_id')->constrained('attachments')->cascadeOnDelete();
            $table->string('attribute', 50); // alt, caption, link, codec, bitrate, quality, album, composer, author, page_count
            $table->text('value')->nullable();

            $table->unique(['attachment_id', 'attribute']);
            $table->index('attribute');
        });

        Schema::create('attachables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attachment_id')->constrained('attachments')->cascadeOnDelete();
            $table->morphs('attachable');
            $table->enum('role', ['marketing', 'advertise', 'avatar', 'background', 'gallery', 'icon'])->nullable();
            $table->integer('sort_order')->default(0);
            $table->enum('status', ['active', 'inactive', 'deleted'])->default('active');
            $table->timestamps();

            $table->index(['role', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attachables');
        Schema::dropIfExists('attachment_thumbnails');
        Schema::dropIfExists('attachment_videos');
        Schema::dropIfExists('attachment_meta');
        Schema::dropIfExists('attachments');
    }
};
