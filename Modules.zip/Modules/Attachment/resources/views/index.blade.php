<x-attachment::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('attachment.name') !!}</p>
</x-attachment::layouts.master>
