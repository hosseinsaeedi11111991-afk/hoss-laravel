<?php

use Illuminate\Support\Facades\Route;
use Modules\Attachment\Http\Controllers\AttachmentController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('attachments', AttachmentController::class)->names('attachment');
});
