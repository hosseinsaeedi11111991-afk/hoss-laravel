<?php

return [
    'name' => 'Attachment',
];
