<?php

return [
    'name' => 'Catalog',
];
