<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('catalogs', function (Blueprint $table) {
            $table->id();
            $table->string('model_type');
            $table->string('name');
            $table->string('title')->nullable();
            $table->enum('figure', ['slide', 'grid', 'list']);
            $table->string('see_all_link');
            $table->integer('max_items');
            $table->boolean('auto_generated')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('figure');
            $table->index('is_active');
        });

        Schema::create('catalog_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('catalog_id')->constrained('catalogs')->onDelete('cascade');
            $table->unsignedBigInteger('model_id');
            $table->integer('sort_order')->default(1);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['catalog_id', 'sort_order']);
            $table->index('is_active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('catalog_items');
        Schema::dropIfExists('catalogs');
    }
};
