<?php

namespace Modules\Neshan\Database\Seeders;

use Illuminate\Database\Seeder;

class NeshanDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
