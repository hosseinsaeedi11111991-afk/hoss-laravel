<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('neshan_locations', function (Blueprint $table) {
            $table->id();

            // Link to reservations (can be nullable if created before reservation exists)
            $table->foreignId('reservation_id')
                ->nullable()
                ->constrained('reservations')
                ->cascadeOnDelete();

            // Geo coordinates
            $table->decimal('latitude', 10, 7);
            $table->decimal('longitude', 10, 7);

            // Human-readable address
            $table->string('address_text');

            // Type of point: origin or destination
            $table->enum('type', ['origin', 'destination']);

            // Whether this row is the primary location among possibly multiple points
            $table->boolean('is_primary')->default(false);

            $table->timestamps();

            $table->index(['reservation_id', 'type']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('neshan_locations');
    }
};


