<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('neshan_location_cities', function (Blueprint $table) {
            $table->id();

            // Links
            $table->foreignId('neshan_location_id')
                ->constrained('neshan_locations')
                ->cascadeOnDelete();

            $table->foreignId('reservation_id')
                ->nullable()
                ->constrained('reservations')
                ->cascadeOnDelete();

            // City and distance
            $table->string('city_name');
            $table->decimal('distance_km', 20, 2)->default(0);

            $table->timestamps();

            $table->index(['reservation_id']);
            $table->index(['neshan_location_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('neshan_location_cities');
    }
};


