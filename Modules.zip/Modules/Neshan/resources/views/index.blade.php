<x-neshan::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('neshan.name') !!}</p>
</x-neshan::layouts.master>
