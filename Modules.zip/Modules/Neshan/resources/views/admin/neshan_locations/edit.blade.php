@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        ویرایش موقعیت
    </h4>

    <form action="{{ route('admin.neshan-locations.update', $neshan_location) }}" method="POST">
        @csrf @method('PUT')
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">رزرو</label>
                <select name="reservation_id" class="form-select">
                    <option value="">— انتخاب —</option>
                    @foreach($reservations as $id => $label)
                        <option value="{{ $id }}" {{ old('reservation_id', $neshan_location->reservation_id) == $id ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
                @error('reservation_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Latitude <span class="text-danger">*</span></label>
                <input type="text" name="latitude" class="form-control" value="{{ old('latitude', $neshan_location->latitude) }}" required>
                @error('latitude')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Longitude <span class="text-danger">*</span></label>
                <input type="text" name="longitude" class="form-control" value="{{ old('longitude', $neshan_location->longitude) }}" required>
                @error('longitude')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <label class="form-label">آدرس <span class="text-danger">*</span></label>
                <input type="text" name="address_text" class="form-control" value="{{ old('address_text', $neshan_location->address_text) }}" required>
                @error('address_text')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">نوع <span class="text-danger">*</span></label>
                <select name="type" class="form-select" required>
                    <option value="origin" {{ old('type', $neshan_location->type) == 'origin' ? 'selected' : '' }}>مبدا</option>
                    <option value="destination" {{ old('type', $neshan_location->type) == 'destination' ? 'selected' : '' }}>مقصد</option>
                </select>
                @error('type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">اصلی</label>
                <select name="is_primary" class="form-select">
                    <option value="0" {{ old('is_primary', (int)$neshan_location->is_primary) == 0 ? 'selected' : '' }}>خیر</option>
                    <option value="1" {{ old('is_primary', (int)$neshan_location->is_primary) == 1 ? 'selected' : '' }}>بله</option>
                </select>
                @error('is_primary')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
@endsection


