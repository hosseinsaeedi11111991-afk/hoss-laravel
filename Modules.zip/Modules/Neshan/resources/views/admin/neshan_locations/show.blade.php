@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        جزئیات موقعیت
    </h4>

    <div class="card">
        <div class="card-body">
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">رزرو</div>
                <div class="col-md-9">{{ $neshan_location->reservation_id ?? '—' }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">آدرس</div>
                <div class="col-md-9">{{ $neshan_location->address_text }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">نوع</div>
                <div class="col-md-9">{{ $neshan_location->type === 'origin' ? 'مبدا' : 'مقصد' }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">Latitude</div>
                <div class="col-md-9">{{ $neshan_location->latitude }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">Longitude</div>
                <div class="col-md-9">{{ $neshan_location->longitude }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">اصلی</div>
                <div class="col-md-9">{{ $neshan_location->is_primary ? 'بله' : 'خیر' }}</div>
            </div>
            
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('admin.neshan-locations.edit', $neshan_location) }}" class="btn btn-warning">ویرایش</a>
        <a href="{{ route('admin.neshan-locations.index') }}" class="btn btn-secondary">بازگشت</a>
    </div>
@endsection


