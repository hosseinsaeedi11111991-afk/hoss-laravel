@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        لیست موقعیت‌ها
    </h4>

    <a href="{{ route('admin.neshan-locations.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن موقعیت</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>رزرو</th>
                <th>آدرس</th>
                <th>نوع</th>
                <th>Lat</th>
                <th>Lng</th>
                <th>اصلی؟</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($locations as $key => $loc)
                <tr>
                    <td>{{ $locations->firstItem() + $key }}</td>
                    <td>{{ $loc->reservation_id ?? '—' }}</td>
                    <td>{{ Str::limit($loc->address_text, 60) }}</td>
                    <td>
                        <span class="badge bg-{{ $loc->type === 'origin' ? 'primary' : 'info' }}">{{ $loc->type === 'origin' ? 'مبدا' : 'مقصد' }}</span>
                    </td>
                    <td>{{ $loc->latitude }}</td>
                    <td>{{ $loc->longitude }}</td>
                    <td>
                        <span class="badge bg-{{ $loc->is_primary ? 'success' : 'secondary' }}">{{ $loc->is_primary ? 'بله' : 'خیر' }}</span>
                    </td>
                    <td>
                        <a href="{{ route('admin.neshan-locations.show', $loc) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.neshan-locations.edit', $loc) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.neshan-locations.destroy', $loc) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $locations->links('pagination::bootstrap-5') }}
    </div>
@endsection


