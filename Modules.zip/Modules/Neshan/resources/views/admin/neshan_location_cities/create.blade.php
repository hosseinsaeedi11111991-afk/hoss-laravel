@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.city.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        افزودن شهر
    </h4>

    <form action="{{ route('admin.neshan-locations.city.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">لوکیشن نشان <span class="text-danger">*</span></label>
                <select name="neshan_location_id" class="form-select" required>
                    <option value="">— انتخاب —</option>
                    @foreach($locations as $id => $label)
                        <option value="{{ $id }}" {{ old('neshan_location_id') == $id ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
                @error('neshan_location_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">رزرو</label>
                <select name="reservation_id" class="form-select">
                    <option value="">— انتخاب —</option>
                    @foreach($reservations as $id => $label)
                        <option value="{{ $id }}" {{ old('reservation_id') == $id ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
                @error('reservation_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">نام شهر <span class="text-danger">*</span></label>
                <input type="text" name="city_name" class="form-control" value="{{ old('city_name') }}" required>
                @error('city_name')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">کیلومتر</label>
                <input type="number" step="0.01" min="0" name="distance_km" class="form-control" value="{{ old('distance_km', 0) }}">
                @error('distance_km')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
@endsection


