@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.city.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        جزئیات شهر
    </h4>

    <div class="card">
        <div class="card-body">
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">لوکیشن نشان</div>
                <div class="col-md-9">{{ $neshan_location_city->neshan_location_id }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">رزرو</div>
                <div class="col-md-9">{{ $neshan_location_city->reservation_id ?? '—' }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">نام شهر</div>
                <div class="col-md-9">{{ $neshan_location_city->city_name }}</div>
            </div>
            <div class="row mb-2">
                <div class="col-md-3 fw-bold">کیلومتر</div>
                <div class="col-md-9">{{ number_format($neshan_location_city->distance_km, 2) }}</div>
            </div>
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('admin.neshan-locations.city.edit', $neshan_location_city) }}" class="btn btn-warning">ویرایش</a>
        <a href="{{ route('admin.neshan-locations.city.index') }}" class="btn btn-secondary">بازگشت</a>
    </div>
@endsection


