@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.neshan-locations.city.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">نشان/</span>
        لیست شهرها
    </h4>

    <a href="{{ route('admin.neshan-locations.city.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن شهر</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>لوکیشن نشان</th>
                <th>رزرو</th>
                <th>نام شهر</th>
                <th>کیلومتر</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($cities as $key => $city)
                <tr>
                    <td>{{ $cities->firstItem() + $key }}</td>
                    <td>{{ $city->neshan_location_id }}</td>
                    <td>{{ $city->reservation_id ?? '—' }}</td>
                    <td>{{ $city->city_name }}</td>
                    <td>{{ number_format($city->distance_km, 2) }}</td>
                    <td>
                        <a href="{{ route('admin.neshan-locations.city.show', $city) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.neshan-locations.city.edit', $city) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.neshan-locations.city.destroy', $city) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $cities->links('pagination::bootstrap-5') }}
    </div>
@endsection


