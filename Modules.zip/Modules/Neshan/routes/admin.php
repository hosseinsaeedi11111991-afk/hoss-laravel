<?php

use Illuminate\Support\Facades\Route;
use Modules\Neshan\Http\Controllers\Admin\NeshanLocationController;
use Modules\Neshan\Http\Controllers\Admin\NeshanLocationCityController;
use Modules\Neshan\Http\Controllers\NeshanController;
use Modules\Neshan\Http\Controllers\Admin\NeshanController as AdminNeshanController;

Route::middleware(['web'])
    // ->middleware(['web','auth','admin'])
    ->prefix('admin-panel')
    ->name('admin.neshan-locations.')
    ->group(function () {
        Route::resource('neshan-locations', NeshanLocationController::class)
            ->parameters(['neshan-locations' => 'neshan_location'])
            ->names([
                'index'   => 'index',
                'create'  => 'create',
                'store'   => 'store',
                'show'    => 'show',
                'edit'    => 'edit',
                'update'  => 'update',
                'destroy' => 'destroy',
            ]);

        Route::resource('neshan-location-cities', NeshanLocationCityController::class)
            ->parameters(['neshan-location-cities' => 'neshan_location_city'])
            ->names([
                'index'   => 'city.index',
                'create'  => 'city.create',
                'store'   => 'city.store',
                'show'    => 'city.show',
                'edit'    => 'city.edit',
                'update'  => 'city.update',
                'destroy' => 'city.destroy',
            ]);
    });




Route::prefix('neshan')->group(function () {
    Route::get('/', [NeshanController::class, 'index'])->name('neshan.index');
    Route::get('/create', [NeshanController::class, 'create'])->name('neshan.create');
    Route::post('/', [NeshanController::class, 'store'])->name('neshan.store');
    Route::get('/{neshan}', [NeshanController::class, 'show'])->name('neshan.show');
    Route::get('/{neshan}/edit', [NeshanController::class, 'edit'])->name('neshan.edit');
    Route::put('/{neshan}', [NeshanController::class, 'update'])->name('neshan.update');
    Route::delete('/{neshan}', [NeshanController::class, 'destroy'])->name('neshan.destroy');
});

// Admin routes
Route::prefix('admin/neshan')->middleware(['web', 'auth', 'role:super_user|admin'])->group(function () {
    Route::get('/', [AdminNeshanController::class, 'index'])->name('admin.neshan.index');
    Route::get('/stats/cities', [AdminNeshanController::class, 'cityStats'])->name('admin.neshan.city-stats');
    Route::get('/test-service', [AdminNeshanController::class, 'testService'])->name('admin.neshan.test-service');
    Route::get('/{location}', [AdminNeshanController::class, 'show'])->name('admin.neshan.show');
    Route::get('/reservation/{reservation}/locations', [AdminNeshanController::class, 'reservationLocations'])->name('admin.neshan.reservation-locations');
    Route::put('/city/{city}', [AdminNeshanController::class, 'updateCity'])->name('admin.neshan.update-city');
    Route::delete('/city/{city}', [AdminNeshanController::class, 'deleteCity'])->name('admin.neshan.delete-city');
});



