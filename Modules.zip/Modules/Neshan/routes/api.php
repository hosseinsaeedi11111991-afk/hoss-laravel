<?php

use Illuminate\Support\Facades\Route;
use Modules\Neshan\Http\Controllers\NeshanController;

Route::prefix('neshan')
    ->name('neshan.')
    ->group(function () {
        Route::get('/search', [NeshanController::class, 'search'])->name('search');
    });


