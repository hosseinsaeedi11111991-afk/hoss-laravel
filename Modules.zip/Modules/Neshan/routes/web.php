<?php

use Illuminate\Support\Facades\Route;



require_once 'admin.php';


