<?php

namespace Modules\Neshan\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Reservation\Models\Reservation;

class NeshanLocationCity extends Model
{
    use HasFactory;

    protected $fillable = [
        'neshan_location_id',
        'reservation_id',
        'city_name',
        'distance_km',
    ];

    protected $casts = [
        'distance_km' => 'decimal:2',
    ];

    public function neshanLocation()
    {
        return $this->belongsTo(NeshanLocation::class);
    }

    public function reservation()
    {
        return $this->belongsTo(Reservation::class);
    }
}


