<?php

namespace Modules\Neshan\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Reservation\Models\Reservation;

class NeshanLocation extends Model
{
    use HasFactory;

    protected $fillable = [
        'reservation_id',
        'latitude',
        'longitude',
        'address_text',
        'type',
        'is_primary',
    ];

    protected $casts = [
        'latitude'   => 'decimal:7',
        'longitude'  => 'decimal:7',
        'is_primary' => 'boolean',
    ];

    public const TYPE_ORIGIN      = 'origin';
    public const TYPE_DESTINATION = 'destination';

    public function reservation()
    {
        return $this->belongsTo(Reservation::class);
    }

    public function scopeOrigin($query)
    {
        return $query->where('type', self::TYPE_ORIGIN);
    }

    public function scopeDestination($query)
    {
        return $query->where('type', self::TYPE_DESTINATION);
    }

    public function scopePrimary($query)
    {
        return $query->where('is_primary', true);
    }

    public function cities()
    {
        return $this->hasMany(NeshanLocationCity::class);
    }
}


