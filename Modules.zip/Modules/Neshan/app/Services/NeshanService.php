<?php

namespace Modules\Neshan\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Modules\Neshan\Models\NeshanLocation;
use Modules\Neshan\Models\NeshanLocationCity;
use Modules\Reservation\Models\Reservation;

class NeshanService
{
    private $apiKey = 'service.983e1c873c3d4de1b3d989b52355bec9';

    /**
     * ذخیره اطلاعات مکان‌ها برای یک رزرو
     */
    public function saveLocationsForReservation(Reservation $reservation, array $routes)
    {

        try {
            // استخراج تمام نقاط منحصر به فرد
            $uniqueOrigins = $this->extractUniquePoints($routes, 'origin');
            $uniqueDestinations = $this->extractUniquePoints($routes, 'destination');

            // ذخیره مبداها
            foreach ($uniqueOrigins as $origin) {
                $this->saveLocation($reservation, $origin, 'origin', false);
            }

            // ذخیره مقصدها
            foreach ($uniqueDestinations as $destination) {
                $this->saveLocation($reservation, $destination, 'destination', false);
            }

            // علامت‌گذاری مسیر طولانی‌ترین به عنوان primary
            $longestRoute = $this->findLongestRoute($routes);
            if ($longestRoute) {
                $this->markPrimaryLocations($reservation, $longestRoute);
                $this->updateCityDistancesForLongestRoute($reservation, $longestRoute);
            }

            Log::info('تمام نقاط در ماژول Neshan ذخیره شدند', [
                'reservation_id' => $reservation->id,
                'origins_count' => count($uniqueOrigins),
                'destinations_count' => count($uniqueDestinations)
            ]);

            return true;

        } catch (\Exception $e) {
            Log::error('خطا در ذخیره نقاط در Neshan', [
                'error' => $e->getMessage(),
                'reservation_id' => $reservation->id
            ]);
            return false;
        }
    }

    /**
     * استخراج نقاط منحصر به فرد از مسیرها
     */
    private function extractUniquePoints(array $routes, string $type): array
    {
        $uniquePoints = [];

        foreach ($routes as $route) {
            if ($route['success']) {
                $normalizedLat = $this->normalizeCoordinate($route["{$type}_lat"]);
                $normalizedLng = $this->normalizeCoordinate($route["{$type}_lng"]);

                $key = $normalizedLat . ',' . $normalizedLng;

                if (!isset($uniquePoints[$key])) {
                    $uniquePoints[$key] = [
                        'lat' => $normalizedLat,
                        'lng' => $normalizedLng,
                        'index' => $route["{$type}_index"] ?? 0
                    ];
                }
            }
        }

        return $uniquePoints;
    }

    /**
     * ذخیره یک مکان
     */
    private function saveLocation(Reservation $reservation, array $point, string $type, bool $isPrimary): void
    {

        $address = $this->getAddressFromCoordinates($point['lat'], $point['lng']);
        $cityInfo = $this->getCityInfoFromCoordinates($point['lat'], $point['lng']);

        $neshanLocation = NeshanLocation::create([
            'reservation_id' => $reservation->id,
            'latitude' => $this->normalizeCoordinate($point['lat']),
            'longitude' => $this->normalizeCoordinate($point['lng']),
            'address_text' => $address,
            'type' => $type,
            'is_primary' => $isPrimary,
        ]);

    }

    /**
     * یافتن مسیر طولانی‌ترین
     */
    private function findLongestRoute(array $routes): ?array
    {
        $longestRoute = null;
        $maxDistance = 0;

        foreach ($routes as $route) {
            if ($route['success'] && $route['distanceKm'] > $maxDistance) {
                $maxDistance = $route['distanceKm'];
                $longestRoute = $route;
            }
        }

        return $longestRoute;
    }

    /**
     * علامت‌گذاری مکان‌های primary
     */
    private function markPrimaryLocations(Reservation $reservation, array $longestRoute): void
    {

        // ابتدا تمام رکوردهای قبلی primary را برای این رزرو و هر نوع خنثی کن
        NeshanLocation::where('reservation_id', $reservation->id)
            ->update(['is_primary' => false]);

        // سپس تنها یک رکورد را برای مبدا primary کن
        $originLat = $this->normalizeCoordinate($longestRoute['origin_lat']);
        $originLng = $this->normalizeCoordinate($longestRoute['origin_lng']);

        $primaryOrigin = NeshanLocation::where('reservation_id', $reservation->id)
            ->where('type', 'origin')
            ->where('latitude', $originLat)
            ->where('longitude', $originLng)
            ->orderBy('id')
            ->first();


        if ($primaryOrigin) {
            $primaryOrigin->update(['is_primary' => true]);
        }

        // و تنها یک رکورد را برای مقصد primary کن
        $destinationLat = $this->normalizeCoordinate($longestRoute['destination_lat']);
        $destinationLng = $this->normalizeCoordinate($longestRoute['destination_lng']);

        $primaryDestination = NeshanLocation::where('reservation_id', $reservation->id)
            ->where('type', 'destination')
            ->where('latitude', $destinationLat)
            ->where('longitude', $destinationLng)
            ->orderBy('id')
            ->first();

        if ($primaryDestination) {
            $primaryDestination->update(['is_primary' => true]);
        }
    }

    /**
     * به‌روزرسانی مسافت‌های شهرها برای مسیر طولانی‌ترین
     */
    private function updateCityDistancesForLongestRoute(Reservation $reservation, array $longestRoute): void
    {
        // به‌روزرسانی مسافت‌ها به صورت تجمیعی و بر اساس استان‌ها در متد syncProvinceDistances انجام می‌شود
        Log::info('پرش از به‌روزرسانی کلی مسافت‌ها؛ به‌روزرسانی جزئی بر اساس استان انجام خواهد شد', [
            'reservation_id' => $reservation->id,
        ]);
    }

    /**
     * همگام‌سازی مسافت‌ها بر اساس استان برای یک رزرو
     * provinceDistances: آرایه‌ای از نام استان => مسافت (کیلومتر)
     */
    public function syncProvinceDistances(Reservation $reservation, array $provinceDistances): void
    {
//        echo '<pre>';
//        print_r($reservation);
//        echo '<br>';
//        echo '<br>';
//        echo '<br>';
//        echo '<br>';
//        print_r($provinceDistances);
//
//
//        exit();
        try {
            // یافتن یک لوکیشن برای اتصال ردیف‌های شهر (ترجیحاً مبدا اصلی)
            $primaryOrigin = NeshanLocation::where('reservation_id', $reservation->id)
                ->where('type', 'origin')
                ->where('is_primary', true)
                ->first();

            if (!$primaryOrigin) {
                $primaryOrigin = NeshanLocation::where('reservation_id', $reservation->id)->first();
            }

            foreach ($provinceDistances as $provinceName => $distanceKm) {
                if (!$provinceName) {
                    continue;
                }
                NeshanLocationCity::create([
                    'neshan_location_id' => $primaryOrigin->id,
                    'reservation_id' => $reservation->id,
                    'city_name' => $provinceName,
                    'distance_km' => round((float)$distanceKm, 2),
                ]);
                // به‌روزرسانی اگر ردیفی با همین نام شهر/استان وجود دارد، وگرنه ایجاد جدید
//                $cityRow = NeshanLocationCity::where('reservation_id', $reservation->id)
//                    ->where('city_name', $provinceName)
//                    ->first();
//
//                if ($cityRow) {
//                    $cityRow->update(['distance_km' => round((float)$distanceKm, 2)]);
//                } else if ($primaryOrigin) {
//                    NeshanLocationCity::create([
//                        'neshan_location_id' => $primaryOrigin->id,
//                        'reservation_id' => $reservation->id,
//                        'city_name' => $provinceName,
//                        'distance_km' => round((float)$distanceKm, 2),
//                    ]);
//                }
            }

            Log::info('به‌روزرسانی مسافت استان‌ها برای رزرو انجام شد', [
                'reservation_id' => $reservation->id,
                'province_count' => count($provinceDistances),
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در همگام‌سازی مسافت استان‌ها', [
                'reservation_id' => $reservation->id,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * دریافت آدرس از مختصات
     */
    private function getAddressFromCoordinates($lat, $lng): string
    {
        try {
            $url = "https://api.neshan.org/v5/reverse";
            $response = Http::timeout(15)->withHeaders([
                'Api-Key' => $this->apiKey
            ])->get($url, [
                'lat' => $lat,
                'lng' => $lng
            ]);

            if ($response->successful()) {
                $data = $response->json();

                $addressParts = [];

                if (isset($data['neighbourhood'])) {
                    $addressParts[] = $data['neighbourhood'];
                }

                if (isset($data['street'])) {
                    $addressParts[] = $data['street'];
                }

                if (isset($data['city'])) {
                    $addressParts[] = $data['city'];
                }

                if (isset($data['state'])) {
                    $addressParts[] = $data['state'];
                }

                if (isset($data['formatted_address']) && !empty($data['formatted_address'])) {
                    return $data['formatted_address'];
                }

                if (!empty($addressParts)) {
                    return implode('، ', $addressParts);
                }

                return "مختصات: {$lat}, {$lng}";
            }
        } catch (\Exception $e) {
            Log::warning("خطا در دریافت آدرس برای نقطه: {$lat}, {$lng}", ['error' => $e->getMessage()]);
        }

        return "مختصات: {$lat}, {$lng}";
    }

    /**
     * دریافت اطلاعات شهر از مختصات
     */
    private function getCityInfoFromCoordinates($lat, $lng): ?array
    {
        try {
            $url = "https://api.neshan.org/v5/reverse";
            $response = Http::timeout(15)->withHeaders([
                'Api-Key' => $this->apiKey
            ])->get($url, [
                'lat' => $lat,
                'lng' => $lng
            ]);

            if ($response->successful()) {
                $data = $response->json();

                // بهبود استخراج نام شهر
                $cityName = null;

                // اولویت 1: نام شهر
                if (isset($data['city']) && !empty($data['city'])) {
                    $cityName = $data['city'];
                }
                // اولویت 2: نام استان
                elseif (isset($data['state']) && !empty($data['state'])) {
                    $cityName = $data['state'];
                }
                // اولویت 3: نام محله
                elseif (isset($data['neighbourhood']) && !empty($data['neighbourhood'])) {
                    $cityName = $data['neighbourhood'];
                }
                // اولویت 4: نام خیابان
                elseif (isset($data['street']) && !empty($data['street'])) {
                    $cityName = $data['street'];
                }
                // اولویت 5: آدرس فرمت شده
                elseif (isset($data['formatted_address']) && !empty($data['formatted_address'])) {
                    $cityName = $this->extractCityFromFormattedAddress($data['formatted_address']);
                }

                // اگر هیچ نامی پیدا نشد
                if (empty($cityName)) {
                    $cityName = 'نامشخص';
                }

                // لاگ کردن اطلاعات دریافتی برای دیباگ
                Log::info('اطلاعات شهر از API نشان دریافت شد', [
                    'lat' => $lat,
                    'lng' => $lng,
                    'api_response' => $data,
                    'extracted_city_name' => $cityName
                ]);

                return [
                    'city_name' => $cityName,
                    'distance_km' => 0, // این مقدار بعداً محاسبه می‌شود
                    'province' => $data['state'] ?? null,
                    'neighbourhood' => $data['neighbourhood'] ?? null,
                    'street' => $data['street'] ?? null,
                    'raw_data' => $data // برای دیباگ
                ];
            }
        } catch (\Exception $e) {
            Log::warning("خطا در دریافت اطلاعات شهر برای نقطه: {$lat}, {$lng}", ['error' => $e->getMessage()]);
        }

        return null;
    }

    /**
     * استخراج نام شهر از آدرس فرمت شده
     */
    private function extractCityFromFormattedAddress($formattedAddress): string
    {
        // تقسیم آدرس بر اساس کاما
        $parts = explode(',', $formattedAddress);

        // حذف فاصله‌های اضافی
        $parts = array_map('trim', $parts);

        // جستجو برای کلمات کلیدی شهر
        $cityKeywords = ['تهران', 'اصفهان', 'مشهد', 'شیراز', 'تبریز', 'اهواز', 'کرج', 'قم', 'کاشان', 'یزد'];

        foreach ($parts as $part) {
            foreach ($cityKeywords as $keyword) {
                if (stripos($part, $keyword) !== false) {
                    return $part;
                }
            }
        }

        // اگر شهر پیدا نشد، اولین بخش غیر خالی را برگردان
        foreach ($parts as $part) {
            if (!empty($part) && strlen($part) > 2) {
                return $part;
            }
        }

        return 'نامشخص';
    }

    /**
     * جستجوی مکان بر اساس متن (نام منطقه/محله)
     */
    public function searchByText(string $query, ?float $lat = null, ?float $lng = null): array
    {
        try {
            $url = 'https://api.neshan.org/v1/search';
            $params = ['term' => $query];
            if ($lat !== null && $lng !== null) {
                $params['lat'] = $lat;
                $params['lng'] = $lng;
            }

            $response = Http::timeout(15)->withHeaders([
                'Api-Key' => $this->apiKey,
            ])->get($url, $params);

            if ($response->successful()) {
                $data = $response->json();
                $items = $data['items'] ?? $data['result'] ?? $data;
                if (!is_array($items)) {
                    return [];
                }

                $results = [];
                foreach ($items as $item) {
                    $latVal = $item['y'] ?? ($item['location']['y'] ?? ($item['lat'] ?? null));
                    $lngVal = $item['x'] ?? ($item['location']['x'] ?? ($item['lng'] ?? null));
                    if ($latVal === null || $lngVal === null) {
                        continue;
                    }
                    $results[] = [
                        'name' => $item['title'] ?? $item['name'] ?? ($item['formatted_address'] ?? 'نتیجه'),
                        'address' => $item['address'] ?? ($item['formatted_address'] ?? ''),
                        'lat' => (float) $latVal,
                        'lng' => (float) $lngVal,
                    ];
                }

                return $results;
            }
        } catch (\Exception $e) {
            Log::warning('Neshan search error', [
                'query' => $query,
                'error' => $e->getMessage(),
            ]);
        }

        return [];
    }

    private function normalizeCoordinate($value): string
    {
        return number_format((float) $value, 7, '.', '');
    }
}
