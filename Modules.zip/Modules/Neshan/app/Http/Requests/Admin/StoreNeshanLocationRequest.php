<?php

namespace Modules\Neshan\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreNeshanLocationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reservation_id' => ['nullable', 'exists:reservations,id'],
            'latitude'       => ['required', 'numeric', 'between:-90,90'],
            'longitude'      => ['required', 'numeric', 'between:-180,180'],
            'address_text'   => ['required', 'string', 'max:500'],
            'type'           => ['required', 'in:origin,destination'],
            'is_primary'     => ['boolean'],
        ];
    }

    public function validated($key = null, $default = null)
    {
        $data = parent::validated($key, $default);
        return $data;
    }

    public function attributes(): array
    {
        return [
            'reservation_id' => 'رزرو',
            'latitude'       => 'عرض جغرافیایی',
            'longitude'      => 'طول جغرافیایی',
            'address_text'   => 'آدرس',
            'type'           => 'نوع',
            'is_primary'     => 'اصلی',
        ];
    }

    public function messages(): array
    {
        return [
            'reservation_id.exists' => 'رزرو انتخاب‌شده معتبر نیست.',
            'latitude.required'     => 'وارد کردن :attribute الزامی است.',
            'latitude.numeric'      => ':attribute باید عددی باشد.',
            'latitude.between'      => ':attribute باید بین -90 و 90 باشد.',
            'longitude.required'    => 'وارد کردن :attribute الزامی است.',
            'longitude.numeric'     => ':attribute باید عددی باشد.',
            'longitude.between'     => ':attribute باید بین -180 و 180 باشد.',
            'address_text.required' => 'وارد کردن :attribute الزامی است.',
            'address_text.max'      => 'طول :attribute نباید بیش از :max کاراکتر باشد.',
            'type.required'         => 'انتخاب :attribute الزامی است.',
            'type.in'               => ':attribute باید یکی از مقادیر مبدا یا مقصد باشد.',
            'is_primary.boolean'    => 'مقدار :attribute نامعتبر است.',
        ];
    }
}


