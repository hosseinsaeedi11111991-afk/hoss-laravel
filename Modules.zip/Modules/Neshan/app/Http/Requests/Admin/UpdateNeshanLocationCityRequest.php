<?php

namespace Modules\Neshan\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateNeshanLocationCityRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'neshan_location_id' => ['sometimes', 'required', 'exists:neshan_locations,id'],
            'reservation_id'     => ['nullable', 'exists:reservations,id'],
            'city_name'          => ['sometimes', 'required', 'string', 'max:255'],
            'distance_km'        => ['nullable', 'numeric', 'min:0'],
        ];
    }

    public function attributes(): array
    {
        return [
            'neshan_location_id' => 'لوکیشن نشان',
            'reservation_id'     => 'رزرو',
            'city_name'          => 'نام شهر',
            'distance_km'        => 'کیلومتر',
        ];
    }

    public function messages(): array
    {
        return [
            'neshan_location_id.required' => 'انتخاب :attribute الزامی است.',
            'neshan_location_id.exists'   => ':attribute انتخاب‌شده معتبر نیست.',
            'reservation_id.exists'       => ':attribute انتخاب‌شده معتبر نیست.',
            'city_name.required'          => 'وارد کردن :attribute الزامی است.',
            'city_name.max'               => 'طول :attribute نباید بیش از :max کاراکتر باشد.',
            'distance_km.numeric'         => ':attribute باید عددی باشد.',
            'distance_km.min'             => ':attribute نباید کمتر از صفر باشد.',
        ];
    }
}


