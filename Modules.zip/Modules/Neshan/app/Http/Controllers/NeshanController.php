<?php

namespace Modules\Neshan\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\Neshan\Services\NeshanService;

class NeshanController extends Controller
{
    public function __construct(private NeshanService $neshanService) {}
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('neshan::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('neshan::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('neshan::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('neshan::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}

    /**
     * API: Search endpoint (fallback if Api\SearchController not resolved)
     */
    public function search(Request $request): JsonResponse
    {
        $request->validate([
            'q' => 'required|string|min:2',
            'lat' => 'nullable|numeric',
            'lng' => 'nullable|numeric',
        ]);

        $results = $this->neshanService->searchByText(
            $request->string('q'),
            $request->float('lat', null),
            $request->float('lng', null)
        );

        return response()->json(['results' => $results]);
    }
}
