<?php

namespace Modules\Neshan\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Neshan\Models\NeshanLocation;
use Modules\Neshan\Http\Requests\Admin\StoreNeshanLocationRequest;
use Modules\Neshan\Http\Requests\Admin\UpdateNeshanLocationRequest;
use Modules\Reservation\Models\Reservation;

class NeshanLocationController extends Controller
{
    public function index()
    {
        $locations = NeshanLocation::with('reservation')->latest()->paginate(20);
        return view('neshan::admin.neshan_locations.index', compact('locations'));
    }

    public function create()
    {
        $reservations = Reservation::orderByDesc('id')->pluck('id', 'id');
        return view('neshan::admin.neshan_locations.create', compact('reservations'));
    }

    public function store(StoreNeshanLocationRequest $request)
    {
        NeshanLocation::create($request->validated());
        return redirect()->route('admin.neshan-locations.index')->with('success', 'موقعیت با موفقیت ثبت شد.');
    }

    public function show(NeshanLocation $neshan_location)
    {
        $neshan_location->load('reservation');
        return view('neshan::admin.neshan_locations.show', compact('neshan_location'));
    }

    public function edit(NeshanLocation $neshan_location)
    {
        $reservations = Reservation::orderByDesc('id')->pluck('id', 'id');
        return view('neshan::admin.neshan_locations.edit', compact('neshan_location', 'reservations'));
    }

    public function update(UpdateNeshanLocationRequest $request, NeshanLocation $neshan_location)
    {
        $neshan_location->update($request->validated());
        return redirect()->route('admin.neshan-locations.index')->with('success', 'موقعیت به‌روزرسانی شد.');
    }

    public function destroy(NeshanLocation $neshan_location)
    {
        $neshan_location->delete();
        return redirect()->route('admin.neshan-locations.index')->with('success', 'موقعیت حذف شد.');
    }
}


