<?php

namespace Modules\Neshan\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Modules\Neshan\Models\NeshanLocationCity;
use Modules\Neshan\Models\NeshanLocation;
use Modules\Reservation\Models\Reservation;
use Modules\Neshan\Http\Requests\Admin\StoreNeshanLocationCityRequest;
use Modules\Neshan\Http\Requests\Admin\UpdateNeshanLocationCityRequest;

class NeshanLocationCityController extends Controller
{
    public function index()
    {
        $cities = NeshanLocationCity::with(['neshanLocation', 'reservation'])->latest()->paginate(20);
        return view('neshan::admin.neshan_location_cities.index', compact('cities'));
    }

    public function create()
    {
        $locations = NeshanLocation::orderByDesc('id')->pluck('id', 'id');
        $reservations = Reservation::orderByDesc('id')->pluck('id', 'id');
        return view('neshan::admin.neshan_location_cities.create', compact('locations', 'reservations'));
    }

    public function store(StoreNeshanLocationCityRequest $request)
    {
        NeshanLocationCity::create($request->validated());
        return redirect()->route('admin.neshan-locations.index')->with('success', 'شهر با موفقیت ثبت شد.');
    }

    public function show(NeshanLocationCity $neshan_location_city)
    {
        $neshan_location_city->load(['neshanLocation', 'reservation']);
        return view('neshan::admin.neshan_location_cities.show', compact('neshan_location_city'));
    }

    public function edit(NeshanLocationCity $neshan_location_city)
    {
        $locations = NeshanLocation::orderByDesc('id')->pluck('id', 'id');
        $reservations = Reservation::orderByDesc('id')->pluck('id', 'id');
        return view('neshan::admin.neshan_location_cities.edit', compact('neshan_location_city', 'locations', 'reservations'));
    }

    public function update(UpdateNeshanLocationCityRequest $request, NeshanLocationCity $neshan_location_city)
    {
        $neshan_location_city->update($request->validated());
        return redirect()->route('admin.neshan-locations.index')->with('success', 'شهر به‌روزرسانی شد.');
    }

    public function destroy(NeshanLocationCity $neshan_location_city)
    {
        $neshan_location_city->delete();
        return redirect()->route('admin.neshan-locations.index')->with('success', 'شهر حذف شد.');
    }
}


