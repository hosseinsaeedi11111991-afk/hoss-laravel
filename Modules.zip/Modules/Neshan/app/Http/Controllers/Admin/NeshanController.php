<?php

namespace Modules\Neshan\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Neshan\Models\NeshanLocation;
use Modules\Neshan\Models\NeshanLocationCity;
use Modules\Reservation\Models\Reservation;
use Modules\Neshan\Services\NeshanService;

class NeshanController extends Controller
{
    private $neshanService;

    public function __construct(NeshanService $neshanService)
    {
        $this->neshanService = $neshanService;
    }

    /**
     * نمایش لیست تمام مکان‌های نشان
     */
    public function index()
    {
        $locations = NeshanLocation::with(['reservation', 'cities'])
            ->latest()
            ->paginate(20);

        return view('neshan::admin.locations.index', compact('locations'));
    }

    /**
     * نمایش جزئیات یک مکان
     */
    public function show(NeshanLocation $location)
    {
        $location->load(['reservation', 'cities']);
        
        return view('neshan::admin.locations.show', compact('location'));
    }

    /**
     * نمایش مکان‌های یک رزرو خاص
     */
    public function reservationLocations(Reservation $reservation)
    {
        $locations = NeshanLocation::with(['cities'])
            ->where('reservation_id', $reservation->id)
            ->orderByDesc('is_primary')
            ->orderBy('type')
            ->get();

        return view('neshan::admin.locations.reservation', compact('reservation', 'locations'));
    }

    /**
     * نمایش آمار شهرها و مسافت‌ها
     */
    public function cityStats()
    {
        $cityStats = NeshanLocationCity::selectRaw('
                city_name,
                COUNT(*) as location_count,
                SUM(distance_km) as total_distance,
                AVG(distance_km) as avg_distance,
                MIN(distance_km) as min_distance,
                MAX(distance_km) as max_distance
            ')
            ->groupBy('city_name')
            ->orderBy('total_distance', 'desc')
            ->paginate(20);

        return view('neshan::admin.stats.cities', compact('cityStats'));
    }

    /**
     * به‌روزرسانی اطلاعات شهر
     */
    public function updateCity(Request $request, NeshanLocationCity $city)
    {
        $request->validate([
            'city_name' => 'required|string|max:255',
            'distance_km' => 'required|numeric|min:0'
        ]);

        $city->update($request->only(['city_name', 'distance_km']));

        return response()->json([
            'success' => true,
            'message' => 'اطلاعات شهر با موفقیت به‌روزرسانی شد'
        ]);
    }

    /**
     * حذف یک شهر
     */
    public function deleteCity(NeshanLocationCity $city)
    {
        $city->delete();

        return response()->json([
            'success' => true,
            'message' => 'شهر با موفقیت حذف شد'
        ]);
    }

    /**
     * تست سرویس نشان
     */
    public function testService()
    {
        try {
            // ایجاد یک رزرو تست
            $reservation = Reservation::create([
                'car_id' => 1,
                'user_id' => 1,
                'date' => \Carbon\Carbon::now()->addDay(),
                'distance_km' => 50,
                'total_price' => 50000,
                'status' => 'pending',
                'origin_address' => 'تهران، میدان آزادی',
                'destination_address' => 'تهران، میدان تجریش',
                'origin' => '35.6997,51.3381',
                'destination' => '35.8044,51.4345',
                'time' => '10:00',
            ]);

            // داده‌های تست مسیر
            $testRoutes = [
                [
                    'success' => true,
                    'origin_lat' => 35.6997,
                    'origin_lng' => 51.3381,
                    'destination_lat' => 35.8044,
                    'destination_lng' => 51.4345,
                    'distanceKm' => 50,
                    'origin_index' => 0,
                    'destination_index' => 1
                ]
            ];

            // استفاده از سرویس نشان
            $result = $this->neshanService->saveLocationsForReservation($reservation, $testRoutes);

            return response()->json([
                'success' => true,
                'message' => 'تست سرویس نشان با موفقیت انجام شد',
                'reservation_id' => $reservation->id,
                'neshan_service_result' => $result
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    }
}
