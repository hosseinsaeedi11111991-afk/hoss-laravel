# ماژول Neshan - مدیریت مکان‌ها و شهرها

## توضیحات
این ماژول برای مدیریت مکان‌های جغرافیایی و اطلاعات شهرها در سیستم رزرو تاکسی طراحی شده است.

## ویژگی‌ها
- ذخیره خودکار مکان‌های مبدا و مقصد
- محاسبه و ذخیره مسافت‌ها برای هر شهر
- علامت‌گذاری مکان‌های اصلی (primary)
- مدیریت اطلاعات شهرها و استان‌ها
- API برای دریافت آدرس از مختصات

## جداول دیتابیس

### neshan_locations
- `id`: شناسه یکتا
- `reservation_id`: شناسه رزرو مربوطه
- `latitude`: عرض جغرافیایی
- `longitude`: طول جغرافیایی
- `address_text`: آدرس متنی
- `type`: نوع مکان (origin/destination)
- `is_primary`: آیا مکان اصلی است
- `created_at`, `updated_at`: زمان ایجاد و به‌روزرسانی

### neshan_location_cities
- `id`: شناسه یکتا
- `neshan_location_id`: شناسه مکان مربوطه
- `reservation_id`: شناسه رزرو
- `city_name`: نام شهر
- `distance_km`: مسافت به کیلومتر
- `created_at`, `updated_at`: زمان ایجاد و به‌روزرسانی

## نحوه استفاده

### 1. استفاده از سرویس NeshanService

```php
use Modules\Neshan\Services\NeshanService;

class YourController extends Controller
{
    private $neshanService;

    public function __construct(NeshanService $neshanService)
    {
        $this->neshanService = $neshanService;
    }

    public function createReservation(Request $request)
    {
        // ایجاد رزرو
        $reservation = Reservation::create($request->validated());

        // داده‌های مسیر
        $routes = [
            [
                'success' => true,
                'origin_lat' => 35.6997,
                'origin_lng' => 51.3381,
                'destination_lat' => 35.8044,
                'destination_lng' => 51.4345,
                'distanceKm' => 50,
                'origin_index' => 0,
                'destination_index' => 1
            ]
        ];

        // ذخیره مکان‌ها
        $this->neshanService->saveLocationsForReservation($reservation, $routes);
    }
}
```

### 2. دریافت مکان‌های یک رزرو

```php
use Modules\Neshan\Models\NeshanLocation;

$locations = NeshanLocation::with(['cities'])
    ->where('reservation_id', $reservationId)
    ->orderByDesc('is_primary')
    ->orderBy('type')
    ->get();
```

### 3. دریافت آمار شهرها

```php
use Modules\Neshan\Models\NeshanLocationCity;

$cityStats = NeshanLocationCity::selectRaw('
        city_name,
        COUNT(*) as location_count,
        SUM(distance_km) as total_distance,
        AVG(distance_km) as avg_distance
    ')
    ->groupBy('city_name')
    ->orderBy('total_distance', 'desc')
    ->get();
```

## API Routes

### عمومی
- `GET /neshan` - لیست مکان‌ها
- `GET /neshan/{id}` - نمایش مکان
- `POST /neshan` - ایجاد مکان جدید
- `PUT /neshan/{id}` - به‌روزرسانی مکان
- `DELETE /neshan/{id}` - حذف مکان

### ادمین
- `GET /admin/neshan` - مدیریت مکان‌ها
- `GET /admin/neshan/stats/cities` - آمار شهرها
- `GET /admin/neshan/test-service` - تست سرویس
- `GET /admin/neshan/reservation/{id}/locations` - مکان‌های یک رزرو
- `PUT /admin/neshan/city/{id}` - به‌روزرسانی شهر
- `DELETE /admin/neshan/city/{id}` - حذف شهر

## تست سیستم

برای تست عملکرد سیستم، می‌توانید از route زیر استفاده کنید:

```
GET /test-neshan-service
```

این route یک رزرو تست ایجاد کرده و سرویس Neshan را تست می‌کند.

## نکات مهم

1. **API Key**: برای استفاده از API نشان، کلید API معتبر نیاز است
2. **Rate Limiting**: API نشان محدودیت تعداد درخواست دارد
3. **Error Handling**: همیشه خطاها را مدیریت کنید
4. **Logging**: تمام عملیات در فایل log ثبت می‌شوند

## عیب‌یابی

### مشکل: اطلاعات شهر ذخیره نمی‌شود
- بررسی کنید که API نشان در دسترس باشد
- کلید API معتبر باشد
- خطاها در فایل log بررسی شوند

### مشکل: مسافت‌ها محاسبه نمی‌شود
- بررسی کنید که داده‌های مسیر کامل باشند
- فیلد `distanceKm` در داده‌ها موجود باشد

## پشتیبانی
برای سوالات و مشکلات، لطفاً با تیم توسعه تماس بگیرید.
