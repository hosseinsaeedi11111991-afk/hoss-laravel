
<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{ asset('admin/assets/vendor/libs/jquery/jquery.js')}}"></script>
<script src="{{ asset('admin/assets/vendor/libs/popper/popper.js')}}"></script>
<script src="{{ asset('admin/assets/vendor/js/bootstrap.js')}}"></script>
<script src="{{ asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')}}"></script>

<script src="{{ asset('admin/assets/vendor/libs/hammer/hammer.js')}}"></script>

<script src="{{ asset('admin/assets/vendor/libs/i18n/i18n.js')}}"></script>
<script src="{{ asset('admin/assets/vendor/libs/typeahead-js/typeahead.js')}}"></script>

<script src="{{ asset('admin/assets/vendor/js/menu.js')}}"></script>
<!-- endbuild -->

<!-- toast -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/toastr/toastr.js')}}" ></script>
<!-- flatpickr -->
<script src="{{ asset('admin/assets/vendor/libs/flatpickr/flatpickr.js')}}" ></script>
<script src="{{ asset('admin/assets/vendor/libs/flatpickr/flatpickr-jdate.js')}}" ></script>
<script src="{{ asset('admin/assets/vendor/libs/flatpickr/l10n/fa-jdate.js')}}" ></script>
<!-- select2 -->
<script src="{{ asset('admin/assets/vendor/libs/select2/select2.js')}}"></script>
<!-- sweetalert2 -->
<script src="{{ asset('admin/assets/vendor/libs/sweetalert2/sweetalert2.js')}}" ></script>
<!-- Vendors JS -->
<script src="{{ asset('admin/assets/vendor/libs/apex-charts/apexcharts.js')}}"></script>

<!-- Main JS -->
<script src="{{ asset('admin/assets/js/main.js')}}"></script>

<!-- Page JS -->
<script src="{{ asset('admin/assets/js/dashboards-analytics.js')}}"></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('form.delete-form').forEach(function(form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'آیا مطمئن هستید؟',
                    text: "این عملیات قابل بازگشت نیست!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'بله، حذف کن!',
                    cancelButtonText: 'لغو'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    });
</script>


@yield('script')
@stack('scripts')
