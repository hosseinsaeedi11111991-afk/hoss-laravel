
@if($errors->any())
    <div class="alert alert-danger alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-save me-2"></i>اخطار!</h6>
            @foreach($errors->all() as $key => $error)
                    <p>{{$key+1}}_{{ $error }}</p>
            @endforeach
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif
