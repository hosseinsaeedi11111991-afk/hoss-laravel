<div class="mb-3">
    <label for="select2Tags" class="form-label">{{ $labelName }} {{ $is_required }}</label>
    <div class="select2-primary">
        <select id="select2Tags" name="{{ $name }}[]"  class="select2 form-select" multiple>
           @foreach($data as $row)
               <option @if(isset($update)) @foreach($update as $updateData) @if($updateData->id == $row->id) selected @endif @endforeach @endif value="{{ $row->id }}">{{ $row->$modeName }}</option>
           @endforeach
        </select>
    </div>
</div>

@section('script')
<script>
    $(document).ready(function() {
        $('#select2Tags').select2({
            tags: true,
            tokenSeparators: [',', ' '],
            createTag: function(params) {
                var term = $.trim(params.term);

                if (term === '') {
                    return null;
                }

                return {
                    id: term,
                    text: term,
                    newTag: true // اضافه کردن پراپرتی برای شناسایی تگ‌های جدید
                };
            }
        });

        // ارسال داده‌ها هنگام فرم سابمیت
        $('form').on('submit', function() {
            var selectedTags = $('#select2Tags').val() || [];
            var newTags = [];

            // بررسی تگ‌های جدید
            $('#select2Tags option').each(function() {
                if ($(this).data('newTag') && selectedTags.includes($(this).val())) {
                    newTags.push($(this).val());
                }
            });

            // اضافه کردن فیلد مخفی برای تگ‌های جدید
            if (newTags.length > 0) {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'new_tags',
                    value: JSON.stringify(newTags)
                }).appendTo('form');
            }
        });
    });
</script>
@append
