<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">

<title>@yield('title')</title>

<meta name="description" content="@yield('description')">
<meta name="csrf-token" content="{{ csrf_token() }}">

<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="{{ asset('admin/assets/img/favicon/favicon.ico')}}">

<!-- Icons -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/fonts/boxicons.css')}}">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/fonts/fontawesome.css')}}">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/fonts/flag-icons.css')}}">

<!-- Core CSS -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/rtl/core.css')}}" class="template-customizer-core-css">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/rtl/theme-default.css')}}" class="template-customizer-theme-css">
<link rel="stylesheet" href="{{ asset('admin/assets/css/demo.css')}}">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/rtl/rtl.css')}}">

<!-- Vendors CSS -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')}}">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/typeahead-js/typeahead.css')}}">
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/apex-charts/apex-charts.css')}}">

{{--toast--}}
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/toastr/toastr.css')}}" />
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/animate-css/animate.css')}}" />
<!-- flatpickr -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/flatpickr/flatpickr.css')}}" />
<!-- select2 -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/select2/select2.css')}} " />
<!-- sweetalert2 -->
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/animate-css/animate.css')}}" />
<link rel="stylesheet" href="{{ asset('admin/assets/vendor/libs/sweetalert2/sweetalert2.css')}}" />
<!-- Page CSS -->
@yield('css')
@stack('styles')
@include('Shared::layouts.partials.local-font')
<!-- Helpers -->
<script src="{{ asset('admin/assets/vendor/js/helpers.js')}}"></script>

<!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
<!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
<script src="{{ asset('admin/assets/vendor/js/template-customizer.js')}}"></script>
<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="{{ asset('admin/assets/js/config.js')}}"></script>
