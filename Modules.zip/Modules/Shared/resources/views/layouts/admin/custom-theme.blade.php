{{-- لایه‌ی استایل مدرن سراسری پنل ادمین — هم‌سبک داشبورد جدید --}}
<style>
    :root {
        --acc: #696cff;
        --acc-2: #8a8dff;
        --acc-soft: rgba(105, 108, 255, .12);
        --radius: 12px;
        --radius-lg: 16px;
    }

    /* پس‌زمینه‌ی ملایم تا کارت‌های شیشه‌ای دیده شوند */
    .content-wrapper {
        background:
            radial-gradient(1100px 380px at 100% -5%, rgba(105, 108, 255, .06), transparent),
            radial-gradient(900px 340px at -5% 15%, rgba(3, 195, 236, .05), transparent);
    }

    /* ---------- اینپوت‌ها ---------- */
    .form-control,
    .form-select,
    .input-group-text,
    textarea.form-control,
    .select2-container--default .select2-selection--single,
    .select2-container--default .select2-selection--multiple,
    .flatpickr-input {
        border-radius: var(--radius) !important;
        border: 1px solid #e2e5ee !important;
        transition: border-color .15s ease, box-shadow .15s ease;
    }
    .form-control:focus,
    .form-select:focus,
    textarea.form-control:focus {
        border-color: var(--acc) !important;
        box-shadow: 0 0 0 .18rem var(--acc-soft) !important;
    }
    .form-label,
    label.form-label {
        font-weight: 600;
        color: #566a7f;
        margin-bottom: .4rem;
    }

    /* ---------- دکمه‌ها ---------- */
    .btn {
        border-radius: 10px !important;
        font-weight: 500;
        transition: transform .12s ease, box-shadow .15s ease, filter .15s ease;
    }
    .btn:hover { transform: translateY(-1px); }
    .btn-primary {
        background: linear-gradient(270deg, var(--acc), var(--acc-2)) !important;
        border: none !important;
        box-shadow: 0 4px 12px rgba(105, 108, 255, .30);
    }
    .btn-primary:hover { filter: brightness(1.05); box-shadow: 0 6px 16px rgba(105, 108, 255, .38); }

    /* ---------- کارت‌ها (شیشه‌ای) ---------- */
    .card {
        background: rgba(255, 255, 255, .72) !important;
        -webkit-backdrop-filter: blur(12px) saturate(140%);
        backdrop-filter: blur(12px) saturate(140%);
        border: 1px solid rgba(255, 255, 255, .6) !important;
        border-radius: var(--radius-lg) !important;
        box-shadow: 0 6px 22px rgba(67, 89, 113, .06) !important;
    }
    .card-header { background: transparent !important; border-bottom: 1px solid rgba(67, 89, 113, .06); }

    /* ---------- فرم‌های لخت (بدون کارت) را کارت‌مانند کن ---------- */
    .container-p-y > form,
    .container-xxl > form {
        background: rgba(255, 255, 255, .72);
        -webkit-backdrop-filter: blur(12px) saturate(140%);
        backdrop-filter: blur(12px) saturate(140%);
        border: 1px solid rgba(255, 255, 255, .6);
        border-radius: var(--radius-lg);
        box-shadow: 0 6px 22px rgba(67, 89, 113, .06);
        padding: 1.5rem;
    }

    /* ---------- سربرگ صفحه (breadcrumb) ---------- */
    .breadcrumb-wrapper {
        font-weight: 700 !important;
        color: #566a7f !important;
    }
    .breadcrumb-wrapper a { text-decoration: none; }

    /* ---------- جدول‌ها ---------- */
    .table thead th {
        text-transform: none;
        letter-spacing: 0;
        color: #7a8699;
    }
    .table > :not(caption) > * > * { border-color: rgba(67, 89, 113, .06); }

    /* ---------- صفحه‌بندی ---------- */
    .pagination .page-link { border-radius: 8px !important; margin: 0 2px; border: none; }
    .pagination .active .page-link {
        background: linear-gradient(270deg, var(--acc), var(--acc-2));
        box-shadow: 0 3px 8px rgba(105, 108, 255, .3);
    }

    /* ---------- حالت تیره ---------- */
    html:not(.light-style) .card,
    html:not(.light-style) .container-p-y > form,
    html:not(.light-style) .container-xxl > form {
        background: rgba(40, 42, 66, .6) !important;
        border-color: rgba(255, 255, 255, .08) !important;
    }
    html:not(.light-style) .form-control,
    html:not(.light-style) .form-select,
    html:not(.light-style) textarea.form-control {
        border-color: rgba(255, 255, 255, .12) !important;
    }
</style>
