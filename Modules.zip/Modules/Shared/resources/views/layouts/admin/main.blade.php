<!DOCTYPE html>

<html lang="fa" class="light-style layout-navbar-fixed layout-menu-fixed" dir="rtl" data-theme="theme-default"
      data-assets-path="{{ asset('admin/assets')}}/" data-template="vertical-menu-template">
<head>

    @include('Shared::layouts.admin.head')
    @include('Shared::layouts.admin.custom-theme')
    @livewireStyles
</head>

<body>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">

    <div class="layout-container">

        @include('Shared::layouts.admin.side-bar-menu')

        <!-- Layout container -->
        <div class="layout-page">
            @include('Shared::layouts.admin.navbar')
            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="position-absolut " style="position: absolute;top: 2rem;right: 2rem ; z-index: 10000">
                        @include('Shared::layouts.admin.components.alerts.basic.error')
                        @include('Shared::layouts.admin.components.alerts.toaster.toasters')
                        @include('Shared::layouts.admin.components.alerts.sweetAlerts.deleteConfirm')
                    </div>
                    @section('main')
                    @show
                </div>
                <!-- / Content -->
                @include('Shared::layouts.admin.footer')

                <div class="content-backdrop fade"></div>
            </div>
        </div>

    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>

    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>
</div>

@include('Shared::layouts.admin.scripts')
@livewireScripts
</body>
</html>
