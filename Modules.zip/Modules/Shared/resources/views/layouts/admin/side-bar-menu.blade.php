@php
    use Modules\Menu\Models\Menu;
@endphp

<style>
    /* آیتم‌های منو: بردر آبی + گوشه‌ی ۱۲ پیکسل */
    #layout-menu .menu-inner > .menu-item > .menu-link,
    #layout-menu .menu-sub .menu-link {
        border-radius: 12px;
        border: 1px solid rgba(105, 108, 255, .22);
        margin: 3px 10px;
        transition: background-color .18s ease, border-color .18s ease, color .18s ease, box-shadow .18s ease;
    }
    /* هاور */
    #layout-menu .menu-link:hover {
        border-color: #696cff;
        background-color: rgba(105, 108, 255, .08);
    }
    /* آیتم فعال: بکگراند آبی */
    #layout-menu .menu-item.active > .menu-link {
        background: linear-gradient(270deg, #696cff, #8286ff) !important;
        border-color: #696cff;
        color: #fff !important;
        box-shadow: 0 4px 12px rgba(105, 108, 255, .35);
    }
    #layout-menu .menu-item.active > .menu-link .menu-icon,
    #layout-menu .menu-item.active > .menu-link::after {
        color: #fff !important;
    }
    /* زیرمنوی باز: بردر ملایم‌تر */
    #layout-menu .menu-sub .menu-link { border-color: rgba(105, 108, 255, .14); }
</style>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="#" class="app-brand-link">
            <span class="app-brand-text demo menu-text fw-bold ms-2">
                {{ env('APP_NAME', 'Dashboard') }}
            </span>
        </a>
        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
            <i class="bx menu-toggle-icon d-none d-xl-block fs-4 align-middle"></i>
            <i class="bx bx-x d-block d-xl-none bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-divider mt-0"></div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">مدیریت محتوا</span>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div>صفحات</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.page.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.page.index') }}" class="menu-link">
                        <div>لیست صفحات</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.page.create'))
                <li class="menu-item">
                    <a href="{{ route('admin.page.create') }}" class="menu-link">
                        <div>افزودن صفحه جدید</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div>بلاگ</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.blog-post-category.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog-post-category.index')}}" class="menu-link">
                        <div> دسته بندی مقالات</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.blog-post.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog-post.index')}}" class="menu-link">
                        <div>مقالات</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.blog-tag.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog-tag.index')}}" class="menu-link">
                        <div>برچسب‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.blog-comment.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog-comment.index')}}" class="menu-link">
                        <div>کامنت‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.blog_save.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog_save.index')}}" class="menu-link">
                        <div>ذخیره شده ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.blog-seo.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.blog-seo.index')}}" class="menu-link">
                        <div>SEO</div>
                    </a>
                </li>
                @endif
            </ul>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <div> برچسب ها</div>
                    </a>
                    <ul class="menu-sub">
                        @if(Route::has('admin.blog-tag.index'))
                        <li class="menu-item">
                            <a href="{{ route('admin.blog-tag.index') }}" class="menu-link">
                                <div>برچسب ها</div>
                            </a>
                        </li>
                        @endif
                        @if(Route::has('admin.blog-tag.create'))
                        <li class="menu-item">
                            <a href="{{ route('admin.blog-tag.create') }}" class="menu-link">
                                <div>ایجاد برچسب</div>
                            </a>
                        </li>
                        @endif

                    </ul>
                </li>
            </ul>
        </li>
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">مدیریت سفر ها</span>
        </li>
        @if(Route::has('admin.testimonials.index'))
        <li class="menu-item">
            <a href="{{ route('admin.testimonials.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-message-rounded-dots"></i>
                <div>رضایت مشتریان</div>
            </a>
        </li>
        @endif
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-car"></i>
                <div>ماشین ها</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.cars.categories.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.cars.categories.index') }}" class="menu-link">
                        <div>دسته بندی ماشین ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.cars.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.cars.index') }}" class="menu-link">
                        <div>ماشین ها</div>
                    </a>
                </li>
                @endif

            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar-check"></i>
                <div>رزرو ها</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.reservations.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.reservations.index') }}" class="menu-link">
                        <div>رزرو ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.popular-routes.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.popular-routes.index') }}" class="menu-link">
                        <div>رزرو سریع (مسیرهای پرطرفدار)</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.options.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.options.index') }}" class="menu-link">
                        <div>گزینه های اضافه</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-money"></i>
                <div>قیمت‌گذاری</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.pricing_rules.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.pricing_rules.index') }}" class="menu-link">
                        <div> قیمت‌گذاری شهر به شهر</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.city_pricings.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.city_pricings.index') }}" class="menu-link">
                        <div>قیمت‌گذاری شهری</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.default_pricings.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.default_pricings.index') }}" class="menu-link">
                        <div>قیمت‌گذاری پیش‌فرض</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bxs-discount"></i>
                <div>تخفیف‌ها</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.discounts.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.discounts.index') }}" class="menu-link">
                        <div>لیست تخفیف‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.discounts.create'))
                <li class="menu-item">
                    <a href="{{ route('admin.discounts.create') }}" class="menu-link">
                        <div>افزودن تخفیف</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.discount-usages.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.discount-usages.index') }}" class="menu-link">
                        <div>گزارش استفاده</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-map"></i>
                <div>نشان</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.neshan-locations.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.neshan-locations.index') }}" class="menu-link">
                        <div>لوکیشن‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.neshan-locations.city.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.neshan-locations.city.index') }}" class="menu-link">
                        <div>شهرهای لوکیشن</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">مدیریت افزونه‌ها</span>
        </li>
        @if(Route::has('admin.media.index'))
        <li class="menu-item">
            <a href="{{ route('admin.media.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-image"></i>
                <div>رسانه</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.client-logos.index'))
        <li class="menu-item">
            <a href="{{ route('admin.client-logos.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-carousel"></i>
                <div>لوگوهای برند</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.footer-service-links.index'))
        <li class="menu-item">
            <a href="{{ route('admin.footer-service-links.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-list-ul"></i>
                <div>خدمات فوتر</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.home-about.edit'))
        <li class="menu-item">
            <a href="{{ route('admin.home-about.edit') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-heart"></i>
                <div>معرفی صفحه اصلی</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.mobile-actions.index'))
        <li class="menu-item">
            <a href="{{ route('admin.mobile-actions.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-mobile-alt"></i>
                <div>اکشن‌های موبایل</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.sms-settings.index'))
        <li class="menu-item">
            <a href="{{ route('admin.sms-settings.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-message-square-detail"></i>
                <div>تنظیمات پیامک</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.logs.index'))
        <li class="menu-item">
            <a href="{{ route('admin.logs.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file-find"></i>
                <div>لاگ سیستم</div>
            </a>
        </li>
        @endif
        @if(Route::has('admin.seo.redirects.index') || Route::has('admin.seo.health.index') || Route::has('admin.seo.index-rules.index'))
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-search-alt"></i>
                <div>سئو</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.seo.health.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.seo.health.index') }}" class="menu-link">
                        <div>سلامت سئو</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.seo.redirects.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.seo.redirects.index') }}" class="menu-link">
                        <div>ریدایرکت</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.seo.index-rules.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.seo.index-rules.index') }}" class="menu-link">
                        <div>تنظیمات ایندکس</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        @endif
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-grid-alt"></i>
                <div>منوها</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.menu.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.menu.index', Menu::POSITION_FOOTER) }}" class="menu-link">
                        <div>منوهای فوتر</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.menu.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.menu.index', Menu::POSITION_HEADER) }}" class="menu-link">
                        <div>منوهای نوار اصلی</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.menu.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.menu.index', Menu::POSITION_TOPBAR) }}" class="menu-link">
                        <div>منوهای نوار بالایی</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.menu.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.menu.index', Menu::POSITION_SIDEBAR) }}" class="menu-link">
                        <div>منوهای نوار کناری</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-question-mark"></i>
                <div>سوالات متداول</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.faq.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.faq.index') }}" class="menu-link">
                        <div>سوالات متداول</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.faq.create'))
                <li class="menu-item">
                    <a href="{{ route('admin.faq.create') }}" class="menu-link">
                        <div>افزودن آیتم جدید</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-image-alt"></i>
                <div>بیلبورد</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.billboard.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.billboard.index') }}" class="menu-link">
                        <div>لیست بیلبورد‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.billboard.create'))
                <li class="menu-item">
                    <a href="{{ route('admin.billboard.create') }}" class="menu-link">
                        <div>افزودن آیتم جدید</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>

        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">مدیریت کاربران</span>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div>لیست کاربران</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.page.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.page.index') }}" class="menu-link">
                        <div>افزودن کاربر</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.page.create'))
                <li class="menu-item">
                    <a href="{{ route('admin.page.create') }}" class="menu-link">
                        <div>کاربران</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-universal-access"></i>
                <div>دسترسی و نقش‌ها</div>
            </a>
            <ul class="menu-sub">
                @if(Route::has('admin.role.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.role.index') }}" class="menu-link">
                        <div>مدیریت نقش‌ها</div>
                    </a>
                </li>
                @endif
                @if(Route::has('admin.permission.index'))
                <li class="menu-item">
                    <a href="{{ route('admin.permission.index') }}" class="menu-link">
                        <div>مدیریت دسترسی‌ها</div>
                    </a>
                </li>
                @endif
            </ul>
        </li>

        <li class="menu-header small text-uppercase"><span class="menu-header-text">متفرقه</span></li>
        <li class="menu-item">
            <a href="https://v3dboy.ir/previews/html/frest/documentation" target="_blank" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Documentation">مستندات</div>
            </a>
        </li>
    </ul>
</aside>

<script>
    // تشخیص خودکار آیتم فعال بر اساس آدرس فعلی و باز کردن زیرمنوی والد
    (function () {
        var current = window.location.pathname.replace(/\/+$/, '');
        var links = document.querySelectorAll('#layout-menu .menu-link[href]');
        links.forEach(function (link) {
            var href = link.getAttribute('href');
            if (!href || href === '#' || href.indexOf('javascript') === 0) return;
            var linkPath;
            try { linkPath = new URL(href, window.location.origin).pathname.replace(/\/+$/, ''); }
            catch (e) { return; }
            if (linkPath && linkPath === current) {
                var li = link.closest('.menu-item');
                if (li) li.classList.add('active');
                var parent = li ? li.parentElement.closest('.menu-item') : null;
                while (parent) {
                    parent.classList.add('open', 'active');
                    parent = parent.parentElement.closest('.menu-item');
                }
            }
        });
    })();
</script>
