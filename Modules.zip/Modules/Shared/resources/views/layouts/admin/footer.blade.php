
<!-- Footer -->
{{--<footer class="content-footer footer bg-footer-theme">--}}
{{--    <div class="container-fluid d-flex flex-wrap justify-content-between py-3 flex-md-row flex-column">--}}
{{--    </div>--}}
{{--</footer>--}}
<!-- / Footer -->
