<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    @include('Shared::layouts.site.head')
</head>

<body class="bg-gray">

    @include('Shared::layouts.site.navbar')
    <main class="main-style">
    @section('main')



    @show
    </main>
    @include('Shared::layouts.site.footer')



<a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>
@include('Shared::layouts.site.scripts')
</body>

</html>
