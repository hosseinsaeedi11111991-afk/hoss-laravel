
@php
    $footerServiceLinks = app(\App\Services\FooterServiceLinkService::class)->items();
@endphp

<!-- Footer -->
<footer class="footer vip-footer">
    <div class="container-fluid" >
        <div class="vip-footer-content" style="border-top: 1px solid white">

            <div class="row g-0">


                <!-- Menu Section -->
                <div class="col-lg-3 col-md-4 vip-footer-menu-section">
                    <div class="vip-footer-section">
                        <h4 class="vip-footer-title">وی ای پی تاکسی ایران</h4>
                        <ul class="vip-footer-menu">
                            <li><a href="{{ route('about-us') }}">درباره ما</a></li>
                            <li><a href="{{ route('contact-us') }}">تماس با ما</a></li>
                            <li><a href="#">قوانین و مقررات</a></li>
                            <li><a href="#">پیشنهاد و نظرات مشتریان</a></li>
                            <li><a href="#">ثبت نام رانندگان</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Services Section -->
                <div class="col-lg-3 col-md-3 vip-footer-services-section">
                    <div class="vip-footer-section">
                        <h4 class="vip-footer-title">لیست خدمات</h4>
                        <ul class="vip-footer-services">
                            @foreach($footerServiceLinks as $footerServiceLink)
                                <li>
                                    @if(!empty($footerServiceLink['url']))
                                        <a href="{{ $footerServiceLink['url'] }}">{{ $footerServiceLink['title'] }}</a>
                                    @else
                                        {{ $footerServiceLink['title'] }}
                                    @endif
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>

                <!-- Contact Section -->
                <div class="col-lg-2 col-md-2 vip-footer-contact-section">
                    <div class="vip-footer-section">
                        <h4 class="vip-footer-title">ارتباط با ما</h4>
                        <ul class="vip-footer-phones">
                            <li>
                                <span class="vip-phone-icon-svg" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                                <a dir="ltr" href="tel:+989120983462">۰۹۱۲۰۹۸۳۴۶۲</a>
                            </li>
                            <li>
                                <span class="vip-phone-icon-svg" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                                <a dir="ltr" href="tel:+989026665822">۰۹۰۲۶۶۶۵۸۲۲</a>
                            </li>
                            <li>
                                <span class="vip-phone-icon-svg" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                                <a dir="ltr" href="tel:+982156281778">۰۲۱۵۶۲۸۱۷۷۸</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Trust Seals Section -->
                <div class="col-lg-4 col-md-12 vip-footer-trust-section">
                    <div class="d-flex flex-column align-item-center">
                        <img style="width: 71%" src="{{ asset('site/img/gold_logo.webp') }}" alt="logo-footer" loading="lazy" decoding="async">
                    </div>

                </div>
            </div>

            <!-- Bottom Section: Email, Social Icons, Address -->
            <div class="vip-footer-bottom">
                <div class="row g-0 align-items-center">
                    <div class="col-lg-4 col-md-12 vip-footer-address">
                        <span class="vip-location-icon-svg" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></span>
                        <span>شهرک راه آهن بلوار جنگلبان میدان موج مجتمع ایزدیار</span>
                    </div>

                    <div class="col-lg-4 col-md-12 vip-footer-social">
                        <div class="vip-social-icons">
                            <a href="https://wa.me/989120983462" target="_blank" rel="noopener" class="vip-social-icon vip-whatsapp" title="واتساپ" aria-label="واتساپ">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                            </a>
                            <a href="https://www.instagram.com/viptaxiiran?igsh=NHAxdXdzd3hubmg=" target="_blank" rel="noopener" class="vip-social-icon vip-instagram" title="اینستاگرام" aria-label="اینستاگرام">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                            </a>
                            <a href="https://www.linkedin.com/in/viptaxiiran-viptaxiiran-834754140?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener" class="vip-social-icon vip-linkedin" title="لینکدین" aria-label="لینکدین">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                            </a>
                            <a href="https://t.me/viptaxiiran" target="_blank" rel="noopener" class="vip-social-icon vip-telegram" title="تلگرام" aria-label="تلگرام">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
                            </a>
                            <a href="mailto:info@viptaxiiran.com" class="vip-social-icon vip-email" title="ایمیل" aria-label="ایمیل">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 vip-footer-email">

                        <div class="vip-footer-trust-seals">
                            <a  href="https://trustseal.enamad.ir/?id=446726&amp;Code=wM8fFIjlRjVLA4pJztmZoW6GeOe2iYsC" target="_blank" rel="noopener">
                                <img style="cursor: pointer; width: 110px; margin: 5px;" src="https://trustseal.enamad.ir/logo.aspx?id=446726&amp;Code=wM8fFIjlRjVLA4pJztmZoW6GeOe2iYsC" alt="نماد اعتماد تاکسی بین شهری" loading="lazy" decoding="async" />
                            </a>
                            <a  href="https://eanjoman.ir/member/9XwoamnQ1AEHBAOBdjwQvguPd" target="_blank" rel="noopener">
                                <img style="width: 110px; margin: 5px;" title="انجمن صنفی کارفرمایی فروشگاه های اینترنتی شهر تهران(کسب و کار های اینترنتی)" src="https://eanjoman.ir/api/script?code=9XwoamnQ1AEHBAOBdjwQvguPd" alt="انجمن صنفی کارفرمایی فروشگاه های اینترنتی شهر تهران(کسب و کار های اینترنتی)" loading="lazy" decoding="async" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Copyright -->
            <div class="vip-footer-copyright">
                <p>&copy; تمامی حقوق این قالب محفوظ می باشد. طراحی شده توسط <a href="https://fireseo.net/" target="_blank">fireSoe</a></p>
            </div>
        </div>
    </div>
</footer>
