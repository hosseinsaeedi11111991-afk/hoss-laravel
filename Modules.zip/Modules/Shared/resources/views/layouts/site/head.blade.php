<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- DNS Prefetch and Preconnect - Early resource hints for faster loading -->
<link rel="dns-prefetch" href="https://api.neshan.org">
<link rel="dns-prefetch" href="https://a.tile.openstreetmap.org">
<link rel="dns-prefetch" href="https://b.tile.openstreetmap.org">
<link rel="dns-prefetch" href="https://c.tile.openstreetmap.org">
<link rel="preconnect" href="https://api.neshan.org" crossorigin>
<link rel="preconnect" href="https://a.tile.openstreetmap.org" crossorigin>
<link rel="preconnect" href="https://b.tile.openstreetmap.org" crossorigin>
<link rel="preconnect" href="https://c.tile.openstreetmap.org" crossorigin>

@php
    use App\Services\SeoIndexRuleService;
    use App\Services\SeoMetaService;

    $customMeta = trim($__env->yieldContent('meta'));
    $sectionTitle = trim($__env->yieldContent('title'));
    $sectionDescription = trim($__env->yieldContent('description'));
    $resolvedSeoMeta = isset($seoMeta) && is_array($seoMeta)
        ? $seoMeta
        : app(SeoMetaService::class)->generic($sectionTitle, $sectionDescription);
    $resolvedRobotsDirective = app(SeoIndexRuleService::class)->robotsForRequest(request());
@endphp

<title>{{ $resolvedSeoMeta['title'] ?? $sectionTitle }}</title>

<meta name="description" content="{{ $resolvedSeoMeta['description'] ?? $sectionDescription }}">
@if($customMeta === '' && $resolvedRobotsDirective)
    <meta name="robots" content="{{ $resolvedRobotsDirective }}">
@endif
<meta name="csrf-token" content="{{ csrf_token() }}">

@if($customMeta === '')
    <link rel="canonical" href="{{ $resolvedSeoMeta['canonical'] ?? url()->current() }}">
    <meta property="og:locale" content="{{ $resolvedSeoMeta['og']['locale'] ?? 'fa_IR' }}">
    <meta property="og:type" content="{{ $resolvedSeoMeta['og']['type'] ?? 'website' }}">
    <meta property="og:title" content="{{ $resolvedSeoMeta['og']['title'] ?? ($resolvedSeoMeta['title'] ?? $sectionTitle) }}">
    <meta property="og:description" content="{{ $resolvedSeoMeta['og']['description'] ?? ($resolvedSeoMeta['description'] ?? $sectionDescription) }}">
    <meta property="og:url" content="{{ $resolvedSeoMeta['og']['url'] ?? ($resolvedSeoMeta['canonical'] ?? url()->current()) }}">
    <meta property="og:image" content="{{ $resolvedSeoMeta['og']['image'] ?? asset('site/img/gold_logo.webp') }}">
    <meta property="og:site_name" content="{{ $resolvedSeoMeta['og']['site_name'] ?? 'وی آی پی تاکسی ایران' }}">
    <meta name="twitter:card" content="{{ $resolvedSeoMeta['twitter']['card'] ?? 'summary_large_image' }}">
    <meta name="twitter:title" content="{{ $resolvedSeoMeta['twitter']['title'] ?? ($resolvedSeoMeta['title'] ?? $sectionTitle) }}">
    <meta name="twitter:description" content="{{ $resolvedSeoMeta['twitter']['description'] ?? ($resolvedSeoMeta['description'] ?? $sectionDescription) }}">
    <meta name="twitter:image" content="{{ $resolvedSeoMeta['twitter']['image'] ?? asset('site/img/gold_logo.webp') }}">
    @if(($resolvedSeoMeta['og']['type'] ?? null) === 'article')
        @if(!empty($resolvedSeoMeta['article']['published_time']))
            <meta property="article:published_time" content="{{ $resolvedSeoMeta['article']['published_time'] }}">
        @endif
        @if(!empty($resolvedSeoMeta['article']['modified_time']))
            <meta property="article:modified_time" content="{{ $resolvedSeoMeta['article']['modified_time'] }}">
        @endif
        @if(!empty($resolvedSeoMeta['article']['author']))
            <meta property="article:author" content="{{ $resolvedSeoMeta['article']['author'] }}">
        @endif
    @endif
    @foreach(($resolvedSeoMeta['schema'] ?? []) as $schema)
        <script type="application/ld+json">@json($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)</script>
    @endforeach
@else
    {!! $customMeta !!}
@endif

<!-- Preload LCP Resources (from pages) -->
@stack('preload-lcp')

<!-- Preload Critical JavaScript for faster loading -->
<link rel="preload" href="{{ asset('site/js/jquery-3.7.1.min.js') }}" as="script">
<link rel="preload" href="{{ asset('site/js/bootstrap.min.js') }}" as="script">

<link rel="shortcut icon" href="{{ asset('site/img/gold_logo.webp') }}?v1.1" />

<!-- Preload Leaflet for map pages (if needed) -->
@stack('preload-leaflet')

<!-- Preload Critical CSS for faster download (Non-blocking) -->
<link rel="preload" href="{{ asset('site/css/plugins/bootstrap.min.css') }}" as="style" onload="this.onload=null;this.rel='stylesheet'">
<link rel="preload" href="{{ asset('site/css/style.css?v=2') }}?v1.1" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="stylesheet" href="{{ asset('site/css/plugins/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/style.css?v=2') }}?v1.1">
</noscript>

<!-- LoadCSS Polyfill for older browsers -->
<script>
    !function(e){"use strict";var t=function(t,n,o){var i,r=e.document,a=r.createElement("link");if(n)i=n;else{var l=(r.body||r.getElementsByTagName("head")[0]).childNodes;i=l[l.length-1]}var d=r.styleSheets;a.rel="stylesheet",a.href=t,a.media="only x",function e(t){if(r.body)return t();setTimeout(function(){e(t)})}(function(){i.parentNode.insertBefore(a,n?i:i.nextSibling)});var f=function(e){for(var t=a.href,n=d.length;n--;)if(d[n].href===t)return e();setTimeout(function(){f(e)})};return a.addEventListener&&a.addEventListener("load",function(){this.media=o||"all"}),a.onloadcssdefined=f,f(function(){a.media!==o&&(a.media=o||"all")}),a};"undefined"!=typeof exports?exports.loadCSS=t:e.loadCSS=t}("undefined"!=typeof global?global:this);
</script>

<!-- Preload Themify icon font so services carousel icons display correctly -->
<link rel="preload" href="{{ asset('site/fonts/themify.woff') }}" as="font" type="font/woff" crossorigin>
<!-- Non-Critical CSS - Load Asynchronously (Deferred to prevent render blocking) -->
<link rel="stylesheet" href="{{ asset('site/css/plugins/font-awesome-pro.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/omFont.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/vegas.slider.min.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/animate.min.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/datepicker.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/themify-icons.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/magnific-popup.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/flaticon.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/YouTubePopUp.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/owl.theme.default.min.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/owl.carousel.min.css') }}" media="print" onload="this.media='all'">
<link rel="stylesheet" href="{{ asset('site/css/plugins/select2.css') }}" media="print" onload="this.media='all'">

<!-- Fallback for browsers without JavaScript -->
<noscript>
    <link rel="stylesheet" href="{{ asset('site/css/plugins/font-awesome-pro.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/omFont.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/vegas.slider.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/animate.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/themify-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/flaticon.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/YouTubePopUp.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/owl.theme.default.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/plugins/select2.css') }}">
</noscript>

<style>
    /* WhatsApp Button Styles */
    .whatsapp-button {
        position: fixed;
        bottom: 30px;
        left: 30px;
        width: 55px;
        height: 55px;
        background: #25D366;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        box-shadow: 0 4px 12px rgba(37, 211, 102, 0.4);
        transition: all 0.3s ease;
        text-decoration: none;
        color: #fff;
        font-size: 28px;
    }

    .whatsapp-button:hover {
        display: flex;
        background: #20BA5A;
        box-shadow: 0 6px 20px rgba(37, 211, 102, 0.5);
        color: #fff;
    }

    .whatsapp-button i {
        transition: transform 0.3s ease;
    }

    .whatsapp-button:hover i {
        transform: scale(1.1);
    }

    .whatsapp-emoji-fallback {
        display: none;
        font-size: 28px;
        line-height: 1;
    }

    /* Fallback: اگر آیکون Font Awesome لود نشود، emoji نمایش داده می‌شود */
    @supports not (selector(:has(*))) {
        .whatsapp-emoji-fallback {
            display: inline-block;
        }
        .whatsapp-button i {
            display: none;
        }
    }

    /* Mobile Phone Number in Navbar */
    .navbar-phone-mobile {
        display: none;
        margin-top: 15px;
        padding-top: 15px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .mobile-phone-link {
        display: flex;
        align-items: center;
        gap: 10px;
        color: #fff;
        text-decoration: none;
        font-size: 16px;
        font-weight: 500;
        transition: color 0.3s ease;
        font-family: 'peyda', sans-serif;
    }

    .mobile-phone-link:hover {
        color: #f5b754;
    }

    .mobile-phone-link i {
        font-size: 20px;
        color: #f5b754;
    }

    .nav-scroll .navbar-phone-mobile {
        border-top-color: rgba(0, 0, 0, 0.1);
    }

    .nav-scroll .mobile-phone-link {
        color: #1b1b1b;
    }

    .nav-scroll .mobile-phone-link:hover {
        color: #f5b754;
    }

    /* Responsive */
    @media (max-width: 991px) {
        .navbar-phone-mobile {
            display: block;
        }

        .whatsapp-button {
            display: none;
            bottom: 20px;
            left: 20px;
            width: 50px;
            height: 50px;
            font-size: 24px;
        }
    }

    @media (max-width: 576px) {
        .whatsapp-button {
            display: none;
            bottom: 15px;
            left: 15px;
            width: 48px;
            height: 48px;
            font-size: 22px;
        }
    }

    /* فوتر: آیکون‌های SVG شبکه‌های اجتماعی و تماس */
    .vip-footer .vip-social-icon svg { fill: currentColor; flex-shrink: 0; }
    .vip-footer .vip-phone-icon-svg { display: inline-flex; align-items: center; margin-inline-end: 6px; color: #FFD700; }
    .vip-footer .vip-phone-icon-svg svg { fill: currentColor; }
    .vip-footer .vip-location-icon-svg { display: inline-flex; align-items: center; margin-inline-end: 6px; color: #FFD700; }
    .vip-footer .vip-location-icon-svg svg { fill: currentColor; }

    /* صفحه اصلی: اسلایدر خدمات ما – لینک و آیکون */
    .services1 .numb-curv a { cursor: pointer; display: inline-block; }
    .services1 .numb-curv .number { font-family: 'themify', sans-serif; display: inline-flex; align-items: center; justify-content: center; }

    /* هدر موبایل (پایین صفحه): آیکون‌های SVG */
    .mobile-header-icon-svg svg { flex-shrink: 0; color: inherit; fill: currentColor; }

    /* دکمه واتساپ شناور: آیکون SVG */
    .whatsapp-button { display: flex; align-items: center; justify-content: center; }
    .whatsapp-button svg { fill: currentColor; flex-shrink: 0; }

    /* ناوبر: آیکون تلفن و منو (SVG) */
    .navbar .icon.navbar-icon-svg { display: flex; align-items: center; justify-content: center; }
    .navbar .icon.navbar-icon-svg svg { fill: currentColor; }
    .navbar-toggler-icon { display: flex; align-items: center; justify-content: center; }
    .navbar-toggler-icon svg { fill: currentColor; }
    .mobile-phone-link .navbar-icon-svg { display: inline-flex; align-items: center; color: #f5b754; }
    .mobile-phone-link .navbar-icon-svg svg { fill: currentColor; }
</style>

@yield('css')
@stack('styles')
@include('Shared::layouts.partials.local-font')

<!-- Service Worker Registration for Map Tile Caching -->
<script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('{{ asset('sw.js') }}')
                .then((registration) => {
                    console.log('Service Worker registered:', registration.scope);
                })
                .catch((error) => {
                    console.log('Service Worker registration failed:', error);
                });
        });
    }
</script>
