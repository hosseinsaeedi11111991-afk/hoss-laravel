
<!-- Preloader -->
<div class="preloader-bg"></div>
<div id="preloader">
    <div id="preloader-status">
        <div class="preloader-position loader"> <span></span> </div>
    </div>
</div>
<!-- WhatsApp Button -->
@php
    $siteContact = app(\App\Services\SiteContactService::class)->contact();
    $whatsappNumber = $siteContact['whatsapp_number'];
    $displayPhone = $siteContact['display_phone'];
    $telPhone = $siteContact['tel_phone'];
@endphp
<a href="https://wa.me/{{ $whatsappNumber }}" target="_blank" rel="noopener" class="whatsapp-button" title="تماس با ما در واتساپ" aria-label="واتساپ">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="28" height="28" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg nav-scroll">
    <div class="container">
        <!-- Logo -->
        <div class="logo-wrapper">
            <a class="logo" href="{{ route('home') }}"><img alt="تاکسی بین شهری" class="logo-img" src="{{ asset('site/img/vip-logo.webp') }}"></a><!-- <a class="logo" href="index"><h2>Renta<span>x</span></h2></a> -->
        </div>
        <!-- Button -->
        <button aria-controls="navbar" aria-expanded="false" aria-label="منوی ناوبری" class="navbar-toggler" data-bs-target="#navbar" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24" aria-hidden="true"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg></span></button>
        <!-- Menu -->
        <div class="collapse navbar-collapse" id="navbar">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="{{ route('home') }}">خانه</a></li>
                <li class="nav-item"><a class="nav-link" href="/مقالات">وبلاگ</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('contact-us') }}">تماس با ما</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('about-us') }}">درباره ما</a></li>


            </ul>
            <div class="navbar-right">
                <div class="wrap">
                    <div class="icon navbar-icon-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24" aria-hidden="true"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></div>
                    <div class="text">
                        <p>به کمک نیاز دارید؟</p>
                        <h5 dir="ltr"><a href="tel:{{ $telPhone }}">{{ $displayPhone }}</a></h5>
                    </div>
                </div>
            </div>
            <!-- Mobile Phone Number -->
            <div class="navbar-phone-mobile">
                <a href="tel:{{ $telPhone }}" class="mobile-phone-link">
                    <span class="navbar-icon-svg" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></span>
                    <span dir="ltr">{{ $displayPhone }}</span>
                </a>
            </div>
        </div>
    </div>
</nav>
