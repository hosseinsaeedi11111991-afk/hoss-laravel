


<!-- Critical JavaScript - Load synchronously (required for other scripts) -->
<script src="{{ asset('site/js/jquery-3.7.1.min.js')}}"></script>
<script src="{{ asset('site/js/jquery-migrate-3.4.1.min.js')}}"></script>
<script src="{{ asset('site/js/popper.min.js')}}"></script>
<script src="{{ asset('site/js/bootstrap.min.js')}}"></script>

<!-- Non-critical JavaScript - Defer to reduce blocking -->
<script src="{{ asset('site/js/imagesloaded.pkgd.min.js')}}" defer></script>
<script src="{{ asset('site/js/jquery.isotope.v3.0.2.js')}}" defer></script>
<script src="{{ asset('site/js/scrollIt.min.js')}}" defer></script>
<script src="{{ asset('site/js/jquery.waypoints.min.js')}}" defer></script>
<script src="{{ asset('site/js/owl.carousel.min.js')}}" defer></script>
<script src="{{ asset('site/js/jquery.stellar.min.js')}}" defer></script>
<script src="{{ asset('site/js/jquery.magnific-popup.js')}}" defer></script>
<script src="{{ asset('site/js/select2.js')}}" defer></script>
<script src="{{ asset('site/js/datepicker.js')}}" defer></script>
<script src="{{ asset('site/js/YouTubePopUp.js')}}" defer></script>
<script src="{{ asset('site/js/custom.js')}}" defer></script>

@yield('script')
@stack('scripts')
