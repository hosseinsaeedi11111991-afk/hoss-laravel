<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <title>@yield('title')</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link href="{{ asset('site/css/plugins.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/style.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/rtl.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/custom.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/fonts.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/style-jalali.css')}}" rel="stylesheet">
    <link href="{{ asset('site/css/theme.css')}}" rel="stylesheet">
    <style>
        /* Auth Pages Styling */
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000000;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        .auth-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse"><path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            opacity: 0.3;
        }

        .auth-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .auth-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.35);
        }

        .auth-card .card-header {
            background: #f5b754;
            padding: 30px 20px;
            border: none;
            text-align: center;
        }

        .auth-card .card-header .brand img {
            max-width: 120px;
            height: auto;
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
            transition: transform 0.3s ease;
        }

        .auth-card .card-header .brand img:hover {
            transform: scale(1.05);
        }

        .auth-card .card-body {
            padding: 40px 35px;
        }

        .auth-card .card-body h3 {
            color: #2d3748;
            font-weight: 700;
            font-size: 28px;
            margin-bottom: 8px;
            text-align: right;
        }

        .auth-card .card-body .form-note {
            color: #718096;
            font-size: 14px;
            margin-bottom: 30px;
            text-align: right;
        }

        .auth-card .card-body .form-control {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 14px 18px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: #f7fafc;
            color: #2d3748;
            text-align: right;
        }

        .auth-card .card-body .form-control:focus {
            border-color: #f5b754;
            background: #ffffff;
            box-shadow: 0 0 0 4px rgba(245, 183, 84, 0.1);
            outline: none;
        }

        .auth-card .card-body .form-control::placeholder {
            color: #a0aec0;
        }

        .auth-card .card-body .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .auth-card .card-body .input-group .form-control {
            width: 100%;
        }

        .auth-card .card-body .btn-outline {
            background: #f5b754;
            border: none;
            color: #000000;
            padding: 14px 30px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(245, 183, 84, 0.4);
            cursor: pointer;
        }

        .auth-card .card-body .btn-outline:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(245, 183, 84, 0.5);
            background: #f5b754;
            opacity: 0.9;
        }

        .auth-card .card-body .btn-outline:active {
            transform: translateY(0);
        }

        .auth-card .card-body .text-danger {
            color: #e53e3e !important;
            font-size: 13px;
            margin-top: 5px;
            display: block;
            text-align: right;
        }

        .auth-card .card-body hr {
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 30px 0;
        }

        .auth-card .card-body .text-primary a {
            color: #f5b754;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .auth-card .card-body .text-primary a i {
            font-size: 14px;
        }

        .auth-card .card-body .text-primary a:hover {
            color: #f5b754;
            opacity: 0.8;
        }

        .auth-card .card-body .text-muted a {
            color: #f5b754;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .auth-card .card-body .text-muted a:hover {
            color: #f5b754;
            opacity: 0.8;
            text-decoration: underline;
        }

        .auth-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .auth-link a {
            color: #f5b754;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .auth-link a:hover {
            color: #f5b754;
            opacity: 0.8;
            text-decoration: underline;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-card {
            animation: fadeInUp 0.5s ease;
        }

        @media (max-width: 768px) {
            .auth-container {
                padding: 15px;
            }

            .auth-card {
                border-radius: 15px;
            }

            .auth-card .card-body {
                padding: 30px 20px;
            }

            .auth-card .card-body h3 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="body-inner">
    @section('main')
    @show
</div>

<script src="{{ asset('site/js/jquery.js')}}"></script>
<script src="{{ asset('site/js/plugins.js')}}"></script>
<script src="{{ asset('site/js/functions.js')}}"></script>
</body>

</html>
