@extends('Shared::layouts.admin.main')
    <h1>Hello World</h1>

    <p>Module: {!! config('shared.name') !!}</p>
