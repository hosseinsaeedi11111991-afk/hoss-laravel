<?php

namespace Modules\Cars\Database\Seeders;

use Illuminate\Database\Seeder;

class CarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $category = \Modules\Cars\Models\CarCategory::first();

        \Modules\Cars\Models\Car::create([
            'title'              => 'پژو ۲۰۷',
            'car_category_id'    => $category->id,
            'passenger_capacity' => 4,
            'cargo_capacity'     => 1,
            'status'             => 'available',
            'is_insurance'       => 'yes',
            'avatar'             => null,
            'cargo_weight'       => 50,
        ]);
    }
}
