<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('car_categories', function (Blueprint $table) {
            $table->id();
            $table->string('title');           // نام دسته‌بندی
            $table->text('description')->nullable(); // توضیحات دسته‌بندی
            $table->string('logo')->nullable();       // لوگوی دسته‌بندی
            $table->string('type');            // نوع اقتصادی، لوکس، خانوادگی و غیره
            $table->decimal('fixed_price', 20, 2)->nullable(); // قیمت ثابت (فیکس)
            $table->decimal('price_per_km', 20, 2)->nullable(); // قیمت به ازای کیلومتر
            $table->enum('price_type', ['fixed', 'per_km', 'negotiable'])->default('fixed'); // نوع قیمت: فیکس، به ازای کیلومتر یا توافقی
            $table->timestamps();
        });
    }



    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('car_categories');
    }
};
