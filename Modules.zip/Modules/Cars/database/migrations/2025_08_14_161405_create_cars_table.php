<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cars', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->foreignId('car_category_id')->constrained()->cascadeOnDelete();
            $table->unsignedTinyInteger('passenger_capacity')->default(1);
            $table->unsignedTinyInteger('cargo_capacity')->default(0);
            $table->enum('status', ['available', 'rented', 'maintenance'])->default('available');
            $table->enum('is_insurance', ['yes', 'no'])->default('no');
            $table->string('avatar')->nullable();
            $table->decimal('fixed_price', 20, 2)->default(0);
            $table->decimal('per_km_price', 20, 2)->default(0);
            $table->enum('pricing_type', ['fixed', 'per_km'])->default('fixed');
            $table->unsignedSmallInteger('cargo_weight')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cars');
    }
};
