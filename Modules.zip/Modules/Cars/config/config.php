<?php

return [
    'name' => 'Cars',
];
