@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">خودروها/</a></span>
        ویرایش خودرو
    </h4>

    <form action="{{ route('admin.cars.update', $car) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">عنوان <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" value="{{ old('title', $car->title) }}" required>
                @error('title')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">دسته‌بندی <span class="text-danger">*</span></label>
                <select name="car_category_id" class="form-select" required>
                    <option value="">انتخاب کنید...</option>
                    @foreach($categories as $id => $title)
                        <option value="{{ $id }}"
                            {{ old('car_category_id', $car->car_category_id) == $id ? 'selected' : '' }}>
                            {{ $title }}
                        </option>
                    @endforeach
                </select>
                @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ظرفیت سرنشین <span class="text-danger">*</span></label>
                <input type="number" name="passenger_capacity" class="form-control" value="{{  old('passenger_capacity', $car->passenger_capacity) }}" min="1" max="99" required>
                @error('passenger_capacity')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ظرفیت بار</label>
                <input type="number" name="cargo_capacity" class="form-control" value="{{   old('cargo_capacity', $car->cargo_capacity) }}" min="0" max="99">
                @error('cargo_capacity')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">وزن بار مجاز (کیلوگرم)</label>
                <input type="number" name="cargo_weight" class="form-control" value="{{ old('cargo_weight', $car->cargo_weight) }}" min="0">
                @error('cargo_weight')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">وضعیت <span class="text-danger">*</span></label>
                <select name="status" class="form-select" required>
                    <option value="available"
                        {{ old('status', $car->status) == 'available' ? 'selected' : '' }}>موجود</option>
                    <option value="rented"
                        {{ old('status', $car->status) == 'rented' ? 'selected' : '' }}>اجاره داده‌شده</option>
                    <option value="maintenance"
                        {{ old('status', $car->status) == 'maintenance' ? 'selected' : '' }}>در تعمیر</option>
                </select>
                @error('status')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">بیمه <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_insurance" value="yes"
                               {{ old('is_insurance', $car->is_insurance) == 'yes' ? 'checked' : '' }} required>
                        <span class="form-check-label">دارد</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_insurance" value="no"
                            {{ old('is_insurance', $car->is_insurance) == 'no' ? 'checked' : '' }}>
                        <span class="form-check-label">ندارد</span>
                    </label>
                </div>
                @error('is_insurance')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">تصویر خودرو</label>
                <input type="file" name="avatar" class="form-control">
                <img src="{{ $car->avatar ? Storage::url($car->avatar) : '' }}" width="120" class="rounded mb-2">
                @error('avatar')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">نحوه محاسبه قیمت <span class="text-danger">*</span></label>
                <div>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="fixed" {{ old('pricing_type', $car->pricing_type) == 'fixed' ? 'checked' : '' }} required>
                        <span class="form-check-label">قیمت ثابت</span>
                    </label>
                    <label class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="pricing_type" value="per_km" {{ old('pricing_type', $car->pricing_type) == 'per_km' ? 'checked' : '' }}>
                        <span class="form-check-label">قیمت به ازای کیلومتر</span>
                    </label>
                </div>
                @error('pricing_type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
                <input type="number" step="0.01" name="fixed_price" class="form-control" value="{{ old('fixed_price', $car->fixed_price) }}" min="0" required>
                @error('fixed_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان)</label>
                <input type="number" step="0.01" name="per_km_price" class="form-control" value="{{ old('per_km_price', $car->per_km_price) }}" min="0">
                @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
@endsection
