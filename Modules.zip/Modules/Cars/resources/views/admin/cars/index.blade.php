@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">خودروها/</a></span>
        لیست خودروها
    </h4>

    <a href="{{ route('admin.cars.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن خودرو</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>تصویر</th>
                <th>عنوان</th>
                <th>دسته‌بندی</th>
                <th>نحوه محاسبه</th>
                <th>قیمت ثابت</th>
                <th>قیمت هر کیلومتر</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($cars as $key => $car)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>
                        @if($car->avatar)
                            <img src="{{ Storage::url($car->avatar) }}" width="60" class="rounded">
                        @else
                            <span class="text-muted">—</span>
                        @endif
                    </td>
                    <td>{{ $car->title }}</td>
                    <td>{{ $car->category->title }}</td>
                    <td>
                        <span class="badge bg-{{ $car->pricing_type == 'fixed' ? 'primary' : 'info' }}">
                            {{ $car->getPricingTypeLabel() }}
                        </span>
                    </td>
                    <td>{{ number_format($car->fixed_price) }} تومان</td>
                    <td>{{ number_format($car->per_km_price) }} تومان</td>
                    <td>
                         <span class="badge bg-{{ $car->status == 'available' ? 'success' : ($car->status == 'rented' ? 'warning' : 'danger') }}">
                            {{ $car->status == 'available' ? 'موجود' : ($car->status == 'rented' ? 'اجاره داده‌شده' : 'در تعمیر') }}
                         </span>
                    </td>
                    <td>
                        <a href="{{ route('admin.cars.show', $car) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.cars.edit', $car) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.cars.destroy', $car) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $cars->links('pagination::bootstrap-5') }}
    </div>
@endsection
