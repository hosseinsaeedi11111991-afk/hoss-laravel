@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.index') }}">خودروها/</a></span>
        مشاهده خودرو
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات خودرو</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>عنوان:</strong> {{ $car->title }}</li>
                        <li class="list-group-item"><strong>دسته‌بندی:</strong> {{ $car->category->title }}</li>
                        <li class="list-group-item"><strong>ظرفیت سرنشین:</strong> {{ $car->passenger_capacity }}</li>
                        <li class="list-group-item"><strong>ظرفیت بار:</strong> {{ $car->cargo_capacity ?: '-' }}</li>
                        <li class="list-group-item"><strong>وزن بار مجاز:</strong> {{ $car->cargo_weight ? $car->cargo_weight . ' kg' : '-' }}</li>
                        <li class="list-group-item"><strong>وضعیت:</strong>
                            <span class="badge bg-{{ $car->status == 'available' ? 'success' : ($car->status == 'rented' ? 'warning' : 'danger') }}">
                                 {{ $car->status == 'available' ? 'موجود' : ($car->status == 'rented' ? 'اجاره داده‌شده' : 'در تعمیر') }}
                            </span>
                        </li>
                        <li class="list-group-item"><strong>بیمه:</strong> {{ $car->is_insurance == 'yes' ? 'دارد' : 'ندارد' }}</li>
                        <li class="list-group-item">
                            <strong>تصویر:</strong><br>
                            @if($car->avatar)
                                <img src="{{ Storage::url($car->avatar) }}" width="150" class="rounded mt-2 border">
                            @else
                                <span class="text-muted">بدون تصویر</span>
                            @endif
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($car->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($car->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
