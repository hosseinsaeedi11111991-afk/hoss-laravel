@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">دسته‌بندی ماشین‌ها/</a></span>
        مشاهده دسته‌بندی
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات دسته‌بندی</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>عنوان:</strong> {{ $car_category->title }}</li>
                        <li class="list-group-item"><strong>نوع:</strong> {{ \Modules\Cars\Models\CarCategory::TYPES[$car_category->type] ?? '-' }}</li>
                        <li class="list-group-item">
                            <strong>لوگو:</strong><br>
                            @if($car_category->logo)
                                <img src="{{ Storage::url($car_category->logo) }}" width="120" class="rounded border mt-2">
                            @else
                                <span class="text-muted">بدون لوگو</span>
                            @endif
                        </li>
                        <li class="list-group-item"><strong>توضیحات:</strong> {{ $car_category->description ?? 'بدون توضیحات' }}</li>
                        <li class="list-group-item"><strong>نوع قیمت:</strong> {{ $car_category->price_type_label }}</li>
                        <li class="list-group-item">
                            <strong>قیمت:</strong>
                            @if($car_category->price_type === 'fixed')
                                {{ number_format($car_category->fixed_price ?? 0) }} تومان (ثابت)
                            @elseif($car_category->price_type === 'per_km')
                                {{ number_format($car_category->price_per_km ?? 0) }} تومان به ازای هر کیلومتر
                            @else
                                توافقی
                            @endif
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($car_category->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($car_category->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
