@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">دسته‌بندی ماشین‌ها/</a></span>
        لیست دسته‌بندی‌ها
    </h4>

    <a href="{{ route('admin.cars.categories.create') }}"
       class="btn rounded-pill btn-success mb-3">
        ایجاد دسته‌بندی جدید
    </a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>عنوان</th>
                <th>نوع</th>
                <th>نوع قیمت</th>
                <th>قیمت</th>
                <th>logo</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($categories as $key => $category)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $category->title }}</td>
                    <td>{{ \Modules\Cars\Models\CarCategory::TYPES[$category->type] ?? '-' }}</td>
                    <td>{{ $category->price_type_label }}</td>
                    <td>
                        @if($category->price_type === 'fixed')
                            {{ number_format($category->fixed_price ?? 0) }} تومان
                        @elseif($category->price_type === 'per_km')
                            {{ number_format($category->price_per_km ?? 0) }} تومان/کیلومتر
                        @else
                            توافقی
                        @endif
                    </td>
                    <td>
                        @if($category->logo)
                            <img src="{{ Storage::url($category->logo) }}" width="120">
                        @else
                            -
                        @endif
                    </td>
                    <td>
                        <div class="btn-group flex-wrap gap-2" role="group">
                            <a href="{{ route('admin.cars.categories.show', $category) }}"
                               class="btn btn-info btn-sm" title="نمایش">
                                <i class="bx bxs-show"></i>
                            </a>

                            <a href="{{ route('admin.cars.categories.edit', $category) }}"
                               class="btn btn-warning btn-sm" title="ویرایش">
                                <i class="bx bx-edit-alt"></i>
                            </a>

                            <form method="POST"
                                  action="{{ route('admin.cars.categories.destroy', $category) }}"
                                  class="d-inline delete-form">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="حذف">
                                    <i class="bx bx-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $categories->links('pagination::bootstrap-5') }}
    </div>
@endsection
