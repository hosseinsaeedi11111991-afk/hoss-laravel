@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.cars.categories.index') }}">دسته‌بندی ماشین‌ها/</a></span>
        ویرایش دسته‌بندی
    </h4>

    <form action="{{ route('admin.cars.categories.update', $car_category) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="mb-3">
            <label class="form-label">عنوان <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control"
                   value="{{ old('title', $car_category->title) }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">نوع <span class="text-danger">*</span></label>
            <select name="type" class="form-select" required>
                @foreach(\Modules\Cars\Models\CarCategory::TYPES as $key => $label)
                    <option value="{{ $key }}" {{ old('type', $car_category->type) == $key ? 'selected' : '' }}>
                        {{ $label }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">لوگو</label>
            <input type="file" name="logo" class="form-control">
            @if($car_category->logo)
                <img src="{{ Storage::url($car_category->logo) }}" width="80" class="mt-2 rounded">
            @endif
        </div>

        <div class="mb-3">
            <label class="form-label">توضیحات</label>
            <textarea name="description" class="form-control">{{ old('description', $car_category->description) }}</textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">نوع قیمت <span class="text-danger">*</span></label>
            <select name="price_type" id="price_type" class="form-select" required>
                @foreach(\Modules\Cars\Models\CarCategory::PRICE_TYPES as $key => $label)
                    <option value="{{ $key }}" {{ old('price_type', $car_category->price_type) == $key ? 'selected' : '' }}>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3" id="fixed_price_field" style="display: none;">
            <label class="form-label">قیمت ثابت (تومان) <span class="text-danger">*</span></label>
            <input type="number" name="fixed_price" class="form-control" value="{{ old('fixed_price', $car_category->fixed_price) }}" step="0.01" min="0">
        </div>

        <div class="mb-3" id="price_per_km_field" style="display: none;">
            <label class="form-label">قیمت به ازای کیلومتر (تومان) <span class="text-danger">*</span></label>
            <input type="number" name="price_per_km" class="form-control" value="{{ old('price_per_km', $car_category->price_per_km) }}" step="0.01" min="0">
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>

    <script>
        document.getElementById('price_type').addEventListener('change', function() {
            const priceType = this.value;
            const fixedPriceField = document.getElementById('fixed_price_field');
            const pricePerKmField = document.getElementById('price_per_km_field');

            // مخفی کردن همه فیلدها
            fixedPriceField.style.display = 'none';
            pricePerKmField.style.display = 'none';

            // نمایش فیلد مربوطه
            if (priceType === 'fixed') {
                fixedPriceField.style.display = 'block';
            } else if (priceType === 'per_km') {
                pricePerKmField.style.display = 'block';
            }
        });

        // اجرای اولیه برای نمایش فیلد در صورت وجود مقدار قدیمی
        document.addEventListener('DOMContentLoaded', function() {
            const priceType = document.getElementById('price_type').value;
            if (priceType) {
                document.getElementById('price_type').dispatchEvent(new Event('change'));
            }
        });
    </script>
@endsection
