<?php

use Illuminate\Support\Facades\Route;
use Modules\Cars\Http\Controllers\Admin\CarCategoryController;
use Modules\Cars\Http\Controllers\Admin\CarController;

Route::prefix('admin-panel') // پیش‌فرض همه مسیرها با /admin شروع می‌شوند
->middleware(['web', 'auth', 'role:super_user|admin']) // فقط کاربر لاگین شده و ادمین
->name('admin.cars.') // پیشوند نام مسیرها
->group(function () {

// دسته‌بندی ماشین‌ها
    Route::prefix('car-categories')->group(function () {

        Route::get('/', [CarCategoryController::class, 'index'])
            ->name('categories.index');

        Route::get('/create', [CarCategoryController::class, 'create'])
            ->name('categories.create');

        Route::post('/', [CarCategoryController::class, 'store'])
            ->name('categories.store');

        Route::get('/{car_category}/edit', [CarCategoryController::class, 'edit'])
            ->name('categories.edit');

        Route::put('/{car_category}', [CarCategoryController::class, 'update'])
            ->name('categories.update');

        Route::delete('/{car_category}', [CarCategoryController::class, 'destroy'])
            ->name('categories.destroy');

        Route::get('/{car_category}', [CarCategoryController::class, 'show'])
            ->name('categories.show');
    });


    Route::prefix('cars')->group(function () {
        Route::get('/',          [CarController::class, 'index'])->name('index');
        Route::get('/create',    [CarController::class, 'create'])->name('create');
        Route::post('/',         [CarController::class, 'store'])->name('store');
        Route::get('/{car}',     [CarController::class, 'show'])->name('show');
        Route::get('/{car}/edit',[CarController::class, 'edit'])->name('edit');
        Route::put('/{car}',     [CarController::class, 'update'])->name('update');
        Route::delete('/{car}',  [CarController::class, 'destroy'])->name('destroy');
    });

});
