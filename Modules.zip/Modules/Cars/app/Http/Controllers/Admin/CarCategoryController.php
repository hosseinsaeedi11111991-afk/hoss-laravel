<?php

namespace Modules\Cars\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Cars\Http\Requests\Admin\StoreCarCategoryRequest;
use Modules\Cars\Http\Requests\Admin\UpdateCarCategoryRequest;
use Modules\Cars\Models\CarCategory;
use Modules\Cars\Traits\FileHandler;


class CarCategoryController extends Controller
{
    use FileHandler;
    public function index()
    {
        $categories = CarCategory::paginate(15); // یا هر تعداد که می‌خوای
        return view('cars::admin.car_categories.index', compact('categories'));
    }

    public function create()
    {
        return view('cars::admin.car_categories.create');
    }

    public function store(StoreCarCategoryRequest $request)
    {
        $validated = $request->validated();

        if ($request->hasFile('logo')) {
            $logoInfo = $this->uploadFile(
                $request->file('logo'),
                'car_categories/logos'      // storage/app/public/car_categories/logos
            );
            $validated['logo'] = $logoInfo['path'];
        }

        CarCategory::create($validated);

        return redirect()->route('admin.cars.categories.index')
            ->with('success', 'دسته‌بندی ماشین با موفقیت ایجاد شد.');
    }

    public function edit(CarCategory $car_category)
    {
        return view('cars::admin.car_categories.edit', compact('car_category'));
    }

    public function update(UpdateCarCategoryRequest $request, CarCategory $car_category)
    {
        $validated = $request->validated();

        if ($request->hasFile('logo')) {
            $logoInfo = $this->uploadFile(
                $request->file('logo'),
                'car_categories/logos',
                null,                   // auto-generated file name
                'public',
                $car_category->logo     // old file (will be deleted)
            );
            $validated['logo'] = $logoInfo['path'];
        }

        $car_category->update($validated);

        return redirect()->route('admin.cars.categories.index')
            ->with('success', 'دسته‌بندی ماشین با موفقیت بروزرسانی شد.');
    }

    public function show(CarCategory $car_category)
    {
        return view('cars::admin.car_categories.show', compact('car_category'));
    }

    public function destroy(CarCategory $car_category)
    {
        $car_category->delete();
        return redirect()->route('admin.cars.categories.index');
    }
}

