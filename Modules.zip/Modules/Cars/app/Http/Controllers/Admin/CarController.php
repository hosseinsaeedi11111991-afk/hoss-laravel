<?php

namespace Modules\Cars\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Cars\Models\Car;
use Modules\Cars\Models\CarCategory;
use Modules\Cars\Http\Requests\Admin\StoreCarRequest;
use Modules\Cars\Http\Requests\Admin\UpdateCarRequest;
use Modules\Cars\Traits\FileHandler;

class CarController extends Controller
{
    use FileHandler;   // برای آپلود avatar

    public function index()
    {
        $cars = Car::with('category')->paginate(15);
        return view('cars::admin.cars.index', compact('cars'));
    }

    public function create()
    {
        $categories = CarCategory::pluck('title', 'id');
        return view('cars::admin.cars.create', compact('categories'));
    }

    public function store(StoreCarRequest $request)
    {
        $data = $request->validated();

        if ($request->hasFile('avatar')) {
            $info = $this->uploadFile($request->file('avatar'), 'cars/avatars');
            $data['avatar'] = $info['path'];
        }

        Car::create($data);
        return redirect()->route('admin.cars.index')->with('success', 'خودرو با موفقیت ثبت شد.');
    }

    public function show(Car $car)
    {
        return view('cars::admin.cars.show', compact('car'));
    }

    public function edit(Car $car)
    {
        $categories = CarCategory::pluck('title', 'id');
        return view('cars::admin.cars.edit', compact('car', 'categories'));
    }

    public function update(UpdateCarRequest $request, Car $car)
    {
        $data = $request->validated();

        if ($request->hasFile('avatar')) {
            $info = $this->uploadFile(
                $request->file('avatar'),
                'cars/avatars',
                null,
                'public',
                $car->avatar
            );
            $data['avatar'] = $info['path'];
        }

        $car->update($data);
        return redirect()->route('admin.cars.index')->with('success', 'خودرو به‌روزرسانی شد.');
    }

    public function destroy(Car $car)
    {
        if ($car->avatar) {
            $this->deleteFile($car->avatar);
        }
        $car->delete();
        return redirect()->route('admin.cars.index')->with('success', 'خودرو حذف شد.');
    }
}
