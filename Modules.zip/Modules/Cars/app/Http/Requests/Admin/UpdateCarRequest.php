<?php

namespace Modules\Cars\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCarRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title'              => ['required', 'string', 'max:255'],
            'car_category_id'    => ['required', 'exists:car_categories,id'],
            'passenger_capacity' => ['required', 'integer', 'min:1', 'max:99'],
            'cargo_capacity'     => ['nullable', 'integer', 'min:0', 'max:99'],
            'status'             => ['required', 'in:available,rented,maintenance'],
            'is_insurance'       => ['required', 'in:yes,no'],
            'cargo_weight'       => ['nullable', 'integer', 'min:0'],
            'avatar'             => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'pricing_type'       => ['required', 'in:fixed,per_km'],
            'fixed_price'  => ['required', 'numeric', 'min:0'],
            'per_km_price' => ['nullable', 'numeric', 'min:0'],
        ];
    }

    public function attributes(): array
    {
        return [
            'title'              => 'عنوان خودرو',
            'car_category_id'    => 'دسته‌بندی',
            'passenger_capacity' => 'ظرفیت سرنشین',
            'cargo_capacity'     => 'ظرفیت بار',
            'status'             => 'وضعیت',
            'is_insurance'       => 'بیمه',
            'cargo_weight'       => 'وزن بار مجاز (کیلوگرم)',
            'avatar'             => 'تصویر خودرو',
            'pricing_type'       => 'نحوه محاسبه قیمت',
            'fixed_price'  => 'قیمت ثابت (تومان)',
            'per_km_price' => 'قیمت هر کیلومتر (تومان)',
        ];
    }

    public function messages(): array
    {
        return [
            'required'               => 'فیلد :attribute الزامی است.',
            'max'                    => 'فیلد :attribute نباید بیشتر از :max کاراکتر باشد.',
            'min'                    => 'فیلد :attribute باید حداقل :min باشد.',
            'integer'                => 'فیلد :attribute باید عدد صحیح باشد.',
            'exists'                 => 'مقدار :attribute انتخاب‌شده معتبر نیست.',
            'in'                     => 'مقدار :attribute نامعتبر است.',
            'image'                  => 'فیلد :attribute باید تصویر باشد.',
            'mimes'                  => 'فرمت :attribute باید jpg، jpeg، png یا webp باشد.',
            'avatar.max'             => 'حجم تصویر نباید بیشتر از ۲ مگابایت باشد.',
            'fixed_price.required' => 'قیمت ثابت الزامی است.',
            'fixed_price.numeric'  => 'قیمت ثابت باید عدد باشد.',
            'fixed_price.min'      => 'قیمت ثابت نمی‌تواند منفی باشد.',
            'per_km_price.numeric' => 'قیمت هر کیلومتر باید عدد باشد.',
            'per_km_price.min'     => 'قیمت هر کیلومتر نمی‌تواند منفی باشد.',
            'pricing_type.required' => 'نحوه محاسبه قیمت الزامی است.',
            'pricing_type.in'       => 'نحوه محاسبه قیمت نامعتبر است.',
        ];
    }
}
