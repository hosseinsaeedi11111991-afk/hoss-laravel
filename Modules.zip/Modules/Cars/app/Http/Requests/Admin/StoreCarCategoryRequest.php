<?php

namespace Modules\Cars\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreCarCategoryRequest extends FormRequest
{
    public function authorize()
    {
        return true;
//        return auth()->check() && auth()->user()->isAdmin();
    }


    public function rules(): array
    {
        return [
            'title'       => ['required', 'string', 'max:255'],
            'type'        => ['required', 'in:economical,luxury,family,vip'],
            'description' => ['nullable', 'string'],
            'logo'        => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'], // 2MB
            'price_type'  => ['required', 'in:fixed,per_km,negotiable'],
            'fixed_price' => ['nullable', 'numeric', 'min:0', 'required_if:price_type,fixed'],
            'price_per_km' => ['nullable', 'numeric', 'min:0', 'required_if:price_type,per_km'],
        ];
    }

    public function attributes(): array
    {
        return [
            'title'       => 'عنوان',
            'type'        => 'نوع',
            'description' => 'توضیحات',
            'logo'        => 'لوگو',
            'price_type'  => 'نوع قیمت',
            'fixed_price' => 'قیمت ثابت',
            'price_per_km' => 'قیمت به ازای کیلومتر',
        ];
    }

    public function messages()
    {
        return [
            'title.required'       => 'فیلد عنوان الزامی است.',
            'title.max'            => 'عنوان نباید بیشتر از ۲۵۵ کاراکتر باشد.',
            'type.required'        => 'انتخاب نوع الزامی است.',
            'type.in'              => 'نوع انتخابی معتبر نیست.',
            'logo.image'           => 'لوگو باید یک تصویر باشد.',
            'logo.mimes'           => 'فرمت لوگو باید jpg، jpeg، png یا webp باشد.',
            'logo.max'             => 'حجم لوگو نباید بیشتر از ۲ مگابایت باشد.',
            'price_type.required'  => 'انتخاب نوع قیمت الزامی است.',
            'price_type.in'        => 'نوع قیمت انتخابی معتبر نیست.',
            'fixed_price.required_if' => 'قیمت ثابت الزامی است زمانی که نوع قیمت "ثابت" انتخاب شده باشد.',
            'fixed_price.numeric'  => 'قیمت ثابت باید عدد باشد.',
            'fixed_price.min'      => 'قیمت ثابت نمی‌تواند منفی باشد.',
            'price_per_km.required_if' => 'قیمت به ازای کیلومتر الزامی است زمانی که نوع قیمت "به ازای کیلومتر" انتخاب شده باشد.',
            'price_per_km.numeric' => 'قیمت به ازای کیلومتر باید عدد باشد.',
            'price_per_km.min'     => 'قیمت به ازای کیلومتر نمی‌تواند منفی باشد.',
        ];
    }
}
