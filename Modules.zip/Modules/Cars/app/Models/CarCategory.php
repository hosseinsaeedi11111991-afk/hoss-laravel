<?php

namespace Modules\Cars\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
// use Modules\Cars\Database\Factories\CarCategoryFactory;

class CarCategory extends Model
{
    protected $fillable = [
        'title',
        'description',
        'logo',
        'type',
        'fixed_price',
        'price_per_km',
        'price_type',
    ];

    const TYPES = [
        'economical' => 'اقتصادی',
        'luxury' => 'لوکس',
        'family' => 'خانوادگی',
        'vip' => 'ویژه',
    ];

    const PRICE_TYPE_FIXED = 'fixed';
    const PRICE_TYPE_PER_KM = 'per_km';
    const PRICE_TYPE_NEGOTIABLE = 'negotiable';

    const PRICE_TYPES = [
        self::PRICE_TYPE_FIXED => 'قیمت ثابت',
        self::PRICE_TYPE_PER_KM => 'قیمت به ازای کیلومتر',
        self::PRICE_TYPE_NEGOTIABLE => 'قیمت توافقی',
    ];

    protected $casts = [
        'fixed_price' => 'decimal:2',
        'price_per_km' => 'decimal:2',
    ];

    /* ========== Relations ========== */
    public function cars(): HasMany
    {
        return $this->hasMany(Car::class, 'car_category_id');
    }

    /* ========== Helper Methods ========== */
    public function getPriceTypeLabelAttribute(): string
    {
        return self::PRICE_TYPES[$this->price_type] ?? '-';
    }
}

