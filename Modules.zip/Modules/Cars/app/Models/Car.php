<?php

namespace Modules\Cars\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Car extends Model
{
    const PRICING_TYPE_FIXED = 'fixed';
    const PRICING_TYPE_PER_KM = 'per_km';

    protected $fillable = [
        'title',
        'car_category_id',
        'passenger_capacity',
        'cargo_capacity',
        'status',
        'is_insurance',
        'avatar',
        'fixed_price',
        'per_km_price',
        'pricing_type',
        'cargo_weight',
    ];

    protected $casts = [
        'passenger_capacity' => 'integer',
        'cargo_capacity'     => 'integer',
        'cargo_weight'       => 'integer',
    ];

    /* relations */
    public function category()
    {
        return $this->belongsTo(CarCategory::class, 'car_category_id');
    }

    /* helper methods */
    public function isFixedPricing()
    {
        return $this->pricing_type === self::PRICING_TYPE_FIXED;
    }

    public function isPerKmPricing()
    {
        return $this->pricing_type === self::PRICING_TYPE_PER_KM;
    }

    public function getPricingTypeLabel()
    {
        return $this->isFixedPricing() ? 'قیمت ثابت' : 'قیمت به ازای کیلومتر';
    }
}
