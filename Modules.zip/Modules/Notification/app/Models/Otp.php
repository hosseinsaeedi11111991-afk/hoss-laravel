<?php

namespace Modules\Notification\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Notification\Database\Factories\OtpFactory;

class Otp extends Model
{
    use HasFactory;

    const CHANNEL_SMS = 'sms';
    const CHANNEL_EMAIL = 'email';

    const PURPOSE_AUTHENTICATE = 'authenticate';
    const PURPOSE_RESET_PASS = 'reset_password';
    const PURPOSE_VERIFY_EMAIL = 'verify_email';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'receiver',
        'channel',
        'code',
        'purpose',
        'expires_at',
        'used',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'used' => 'boolean',
    ];
    // protected static function newFactory(): OtpFactory
    // {
    //     // return OtpFactory::new();
    // }
}
