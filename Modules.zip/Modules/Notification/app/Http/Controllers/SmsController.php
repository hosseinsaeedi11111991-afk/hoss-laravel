<?php

namespace Modules\Notification\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Modules\Notification\Services\SmsService;

class SmsController extends Controller
{
    protected $smsService;

    public function __construct(SmsService $smsService)
    {
        $this->smsService = $smsService;
    }

    /**
     * Send simple SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function send(Request $request): JsonResponse
    {
        $request->validate([
            'recipient' => 'required|string|max:20',
            'message' => 'required|string|max:1000',
            'sender' => 'nullable|string|max:20',
        ]);

        $success = $this->smsService->send(
            $request->recipient,
            $request->message,
            $request->sender
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیامک با موفقیت ارسال شد' : 'خطا در ارسال پیامک'
        ]);
    }

    /**
     * Send OTP SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendOtp(Request $request): JsonResponse
    {
        $request->validate([
            'recipient' => 'required|string|max:20',
            'otp_code' => 'required|string|max:10',
            'purpose' => 'nullable|string|in:login,password_reset,verification,registration',
        ]);

        $success = $this->smsService->sendOtp(
            $request->recipient,
            $request->otp_code,
            $request->purpose ?? 'verification'
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'کد تایید ارسال شد' : 'خطا در ارسال کد تایید'
        ]);
    }

    /**
     * Send pattern-based SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendPattern(Request $request): JsonResponse
    {
        $request->validate([
            'recipient' => 'required|string|max:20',
            'pattern_code' => 'required|string',
            'variables' => 'required|array',
            'sender' => 'nullable|string|max:20',
        ]);

        $success = $this->smsService->sendPattern(
            $request->recipient,
            $request->pattern_code,
            $request->variables,
            $request->sender
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیامک الگویی ارسال شد' : 'خطا در ارسال پیامک الگویی'
        ]);
    }

    /**
     * Send bulk SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendBulk(Request $request): JsonResponse
    {
        $request->validate([
            'recipients' => 'required|array|min:1',
            'recipients.*' => 'string|max:20',
            'message' => 'required|string|max:1000',
            'sender' => 'nullable|string|max:20',
        ]);

        $success = $this->smsService->sendBulk(
            $request->recipients,
            $request->message,
            $request->sender
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیامک گروهی ارسال شد' : 'خطا در ارسال پیامک گروهی'
        ]);
    }

    /**
     * Send welcome SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendWelcome(Request $request): JsonResponse
    {
        $request->validate([
            'recipient' => 'required|string|max:20',
            'user_name' => 'required|string|max:100',
        ]);

        $success = $this->smsService->sendWelcome(
            $request->recipient,
            $request->user_name
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیام خوشامدگویی ارسال شد' : 'خطا در ارسال پیام خوشامدگویی'
        ]);
    }

    /**
     * Send reservation confirmation SMS
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendReservationConfirmation(Request $request): JsonResponse
    {
        $request->validate([
            'recipient' => 'required|string|max:20',
            'reservation_data' => 'required|array',
            'reservation_data.id' => 'required|string',
            'reservation_data.date' => 'required|string',
            'reservation_data.time' => 'required|string',
            'reservation_data.origin' => 'required|string',
            'reservation_data.destination' => 'required|string',
        ]);

        $success = $this->smsService->sendReservationConfirmation(
            $request->recipient,
            $request->reservation_data
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'تایید رزرو ارسال شد' : 'خطا در ارسال تایید رزرو'
        ]);
    }

    /**
     * Get account balance
     *
     * @return JsonResponse
     */
    public function getBalance(): JsonResponse
    {
        $balance = $this->smsService->getBalance();

        return response()->json([
            'success' => $balance !== null,
            'data' => $balance,
            'message' => $balance !== null ? 'موجودی دریافت شد' : 'خطا در دریافت موجودی'
        ]);
    }

    /**
     * Get account profile
     *
     * @return JsonResponse
     */
    public function getProfile(): JsonResponse
    {
        $profile = $this->smsService->getProfile();

        return response()->json([
            'success' => $profile !== null,
            'data' => $profile,
            'message' => $profile !== null ? 'پروفایل دریافت شد' : 'خطا در دریافت پروفایل'
        ]);
    }

    /**
     * Check SMS service status
     *
     * @return JsonResponse
     */
    public function status(): JsonResponse
    {
        $isConfigured = $this->smsService->isConfigured();

        return response()->json([
            'success' => true,
            'data' => [
                'configured' => $isConfigured,
                'status' => $isConfigured ? 'active' : 'inactive'
            ],
            'message' => $isConfigured ? 'سرویس پیامک فعال است' : 'سرویس پیامک پیکربندی نشده است'
        ]);
    }
}
