<?php

namespace Modules\Notification\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Modules\Notification\Services\BaleNotificationService;

class BaleController extends Controller
{
    protected $baleNotificationService;

    public function __construct(BaleNotificationService $baleNotificationService)
    {
        $this->baleNotificationService = $baleNotificationService;
    }

    /**
     * Send simple message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function send(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'message' => 'required|string|max:4096',
            'parse_mode' => 'nullable|string|in:HTML,Markdown,MarkdownV2',
        ]);

        $success = $this->baleNotificationService->send(
            $request->chat_id,
            $request->message,
            $request->parse_mode
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیام با موفقیت ارسال شد' : 'خطا در ارسال پیام'
        ]);
    }

    /**
     * Send OTP message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendOtp(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'otp_code' => 'required|string|max:10',
            'purpose' => 'nullable|string|in:login,password_reset,verification,registration',
        ]);

        $success = $this->baleNotificationService->sendOtp(
            $request->chat_id,
            $request->otp_code,
            $request->purpose ?? 'verification'
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'کد تایید ارسال شد' : 'خطا در ارسال کد تایید'
        ]);
    }

    /**
     * Send welcome message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendWelcome(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'user_name' => 'required|string|max:100',
        ]);

        $success = $this->baleNotificationService->sendWelcome(
            $request->chat_id,
            $request->user_name
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیام خوشامدگویی ارسال شد' : 'خطا در ارسال پیام خوشامدگویی'
        ]);
    }

    /**
     * Send reservation confirmation message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendReservationConfirmation(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'reservation_data' => 'required|array',
            'reservation_data.id' => 'required|string',
            'reservation_data.date' => 'required|string',
            'reservation_data.time' => 'required|string',
            'reservation_data.origin' => 'required|string',
            'reservation_data.destination' => 'required|string',
        ]);

        $success = $this->baleNotificationService->sendReservationConfirmation(
            $request->chat_id,
            $request->reservation_data
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'تایید رزرو ارسال شد' : 'خطا در ارسال تایید رزرو'
        ]);
    }

    /**
     * Send reservation reminder message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendReservationReminder(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'reservation_data' => 'required|array',
            'reservation_data.id' => 'required|string',
            'reservation_data.date' => 'required|string',
            'reservation_data.time' => 'required|string',
        ]);

        $success = $this->baleNotificationService->sendReservationReminder(
            $request->chat_id,
            $request->reservation_data
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'یادآوری رزرو ارسال شد' : 'خطا در ارسال یادآوری رزرو'
        ]);
    }

    /**
     * Send cancellation message
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendCancellation(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'reservation_data' => 'required|array',
            'reservation_data.id' => 'required|string',
            'reservation_data.date' => 'required|string',
            'reservation_data.time' => 'required|string',
        ]);

        $success = $this->baleNotificationService->sendCancellation(
            $request->chat_id,
            $request->reservation_data
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیام لغو رزرو ارسال شد' : 'خطا در ارسال پیام لغو رزرو'
        ]);
    }

    /**
     * Send message with keyboard
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendWithKeyboard(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'message' => 'required|string|max:4096',
            'keyboard' => 'required|array',
        ]);

        $success = $this->baleNotificationService->sendWithKeyboard(
            $request->chat_id,
            $request->message,
            $request->keyboard
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'پیام با کیبورد ارسال شد' : 'خطا در ارسال پیام با کیبورد'
        ]);
    }

    /**
     * Send photo
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function sendPhoto(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
            'photo_url' => 'required|string',
            'caption' => 'nullable|string|max:1024',
        ]);

        $success = $this->baleNotificationService->sendPhoto(
            $request->chat_id,
            $request->photo_url,
            $request->caption
        );

        return response()->json([
            'success' => $success,
            'message' => $success ? 'عکس ارسال شد' : 'خطا در ارسال عکس'
        ]);
    }

    /**
     * Get bot information
     *
     * @return JsonResponse
     */
    public function getBotInfo(): JsonResponse
    {
        $botInfo = $this->baleNotificationService->getBotInfo();

        return response()->json([
            'success' => $botInfo !== null,
            'data' => $botInfo,
            'message' => $botInfo !== null ? 'اطلاعات ربات دریافت شد' : 'خطا در دریافت اطلاعات ربات'
        ]);
    }

    /**
     * Get chat information
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getChatInfo(Request $request): JsonResponse
    {
        $request->validate([
            'chat_id' => 'required|string',
        ]);

        $chatInfo = $this->baleNotificationService->getChatInfo($request->chat_id);

        return response()->json([
            'success' => $chatInfo !== null,
            'data' => $chatInfo,
            'message' => $chatInfo !== null ? 'اطلاعات چت دریافت شد' : 'خطا در دریافت اطلاعات چت'
        ]);
    }

    /**
     * Check Bale service status
     *
     * @return JsonResponse
     */
    public function status(): JsonResponse
    {
        $isConfigured = $this->baleNotificationService->isConfigured();

        return response()->json([
            'success' => true,
            'data' => [
                'configured' => $isConfigured,
                'status' => $isConfigured ? 'active' : 'inactive'
            ],
            'message' => $isConfigured ? 'سرویس بله فعال است' : 'سرویس بله پیکربندی نشده است'
        ]);
    }
}

