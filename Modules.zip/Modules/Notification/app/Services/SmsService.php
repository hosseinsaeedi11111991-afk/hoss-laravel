<?php

namespace Modules\Notification\Services;

use Illuminate\Support\Facades\Log;

/**
 * Main SMS Service for managing SMS operations
 */
class SmsService
{
    protected $farazSmsService;

    public function __construct(FarazSmsService $farazSmsService)
    {
        $this->farazSmsService = $farazSmsService;
    }

    /**
     * Send SMS message
     *
     * @param string $recipient Mobile number
     * @param string $message SMS message content
     * @param string|null $sender Sender number (optional)
     * @return bool Success status
     */
    public function send(string $recipient, string $message, ?string $sender = null): bool
    {
        if (!$this->farazSmsService->isConfigured()) {
            Log::error('FarazSMS is not configured. Please set FARAZSMS_API_KEY in .env file');
            return false;
        }

        $result = $this->farazSmsService->sendSimpleSms($recipient, $message, $sender);

        return $result !== null;
    }

    /**
     * Send OTP SMS
     *
     * @param string $recipient Mobile number
     * @param string $otpCode OTP code
     * @param string $purpose Purpose of OTP (e.g., 'login', 'password_reset')
     * @return bool Success status
     */
    public function sendOtp(string $recipient, string $otpCode, string $purpose = 'verification'): bool
    {
        $message = $this->getOtpMessage($otpCode, $purpose);
        return $this->send($recipient, $message);
    }

    /**
     * Send pattern-based SMS
     *
     * @param string $recipient Mobile number
     * @param string $patternCode Pattern code from FarazSMS panel
     * @param array $variables Variables to replace in pattern
     * @param string|null $sender Sender number (optional)
     * @return bool Success status
     */
    public function sendPattern(string $recipient, string $patternCode, array $variables, ?string $sender = null): bool
    {
        if (!$this->farazSmsService->isConfigured()) {
            return false;
        }

        $result = $this->farazSmsService->sendPatternSms($recipient, $patternCode, $variables, $sender);

        return $result !== null;
    }

    /**
     * Send bulk SMS to multiple recipients
     *
     * @param array $recipients Array of mobile numbers
     * @param string $message SMS message content
     * @param string|null $sender Sender number (optional)
     * @return bool Success status
     */
    public function sendBulk(array $recipients, string $message, ?string $sender = null): bool
    {
        if (!$this->farazSmsService->isConfigured()) {
            Log::error('FarazSMS is not configured. Please set FARAZSMS_API_KEY in .env file');
            return false;
        }

        $result = $this->farazSmsService->sendBulkSms($recipients, $message, $sender);

        return $result !== null;
    }

    /**
     * Send welcome SMS to new user
     *
     * @param string $recipient Mobile number
     * @param string $userName User name
     * @return bool Success status
     */
    public function sendWelcome(string $recipient, string $userName): bool
    {
        $message = "سلام $userName! به تاکسی آژانس خوش آمدید. از خدمات ما لذت ببرید.";
        return $this->send($recipient, $message);
    }

    /**
     * Send reservation confirmation SMS
     *
     * @param string $recipient Mobile number
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendReservationConfirmation(string $recipient, array $reservationData): bool
    {
        $message = $this->getReservationMessage($reservationData);
        return $this->send($recipient, $message);
    }

    /**
     * Send reservation reminder SMS
     *
     * @param string $recipient Mobile number
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendReservationReminder(string $recipient, array $reservationData): bool
    {
        $message = $this->getReservationReminderMessage($reservationData);
        return $this->send($recipient, $message);
    }

    /**
     * Send cancellation SMS
     *
     * @param string $recipient Mobile number
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendCancellation(string $recipient, array $reservationData): bool
    {
        $message = $this->getCancellationMessage($reservationData);
        return $this->send($recipient, $message);
    }

    /**
     * Get account balance
     *
     * @return array|null
     */
    public function getBalance(): ?array
    {
        return $this->farazSmsService->getBalance();
    }

    /**
     * Get account profile
     *
     * @return array|null
     */
    public function getProfile(): ?array
    {
        return $this->farazSmsService->getProfile();
    }

    /**
     * Check if SMS service is configured
     *
     * @return bool
     */
    public function isConfigured(): bool
    {
        return $this->farazSmsService->isConfigured();
    }

    /**
     * Get OTP message based on purpose
     *
     * @param string $otpCode OTP code
     * @param string $purpose Purpose of OTP
     * @return string Formatted message
     */
    protected function getOtpMessage(string $otpCode, string $purpose): string
    {
        $messages = [
            'login' => "کد ورود شما: $otpCode\nاین کد تا 2 دقیقه معتبر است.",
            'password_reset' => "کد بازیابی رمز عبور: $otpCode\nاین کد تا 2 دقیقه معتبر است.",
            'verification' => "کد تایید شما: $otpCode\nاین کد تا 2 دقیقه معتبر است.",
            'registration' => "کد تایید ثبت نام: $otpCode\nاین کد تا 2 دقیقه معتبر است.",
        ];

        return $messages[$purpose] ?? $messages['verification'];
    }

    /**
     * Get reservation confirmation message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getReservationMessage(array $reservationData): string
    {
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';
        $origin = $reservationData['origin'] ?? 'نامشخص';
        $destination = $reservationData['destination'] ?? 'نامشخص';
        $reservationId = $reservationData['id'] ?? 'نامشخص';

        return "رزرو شما با موفقیت ثبت شد.\n" .
               "شماره رزرو: $reservationId\n" .
               "تاریخ: $date\n" .
               "ساعت: $time\n" .
               "مبدا: $origin\n" .
               "مقصد: $destination\n" .
               "با تشکر از انتخاب شما";
    }

    /**
     * Get reservation reminder message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getReservationReminderMessage(array $reservationData): string
    {
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';
        $reservationId = $reservationData['id'] ?? 'نامشخص';

        return "یادآوری رزرو\n" .
               "شماره رزرو: $reservationId\n" .
               "تاریخ: $date\n" .
               "ساعت: $time\n" .
               "لطفا 15 دقیقه قبل از زمان مقرر در محل حاضر باشید.";
    }

    /**
     * Get cancellation message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getCancellationMessage(array $reservationData): string
    {
        $reservationId = $reservationData['id'] ?? 'نامشخص';
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';

        return "رزرو شما لغو شد.\n" .
               "شماره رزرو: $reservationId\n" .
               "تاریخ: $date\n" .
               "ساعت: $time\n" .
               "در صورت نیاز می‌توانید رزرو جدیدی ثبت کنید.";
    }
}
