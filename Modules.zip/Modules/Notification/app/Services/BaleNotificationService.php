<?php

namespace Modules\Notification\Services;

use Illuminate\Support\Facades\Log;

/**
 * Main Bale Notification Service for managing Bale messenger operations
 */
class BaleNotificationService
{
    protected $baleService;

    public function __construct(BaleService $baleService)
    {
        $this->baleService = $baleService;
    }

    /**
     * Send message to a chat
     *
     * @param string|int $chatId Chat ID or username
     * @param string $message Message text
     * @param string|null $parseMode Parse mode (HTML, Markdown, MarkdownV2)
     * @return bool Success status
     */
    public function send($chatId, string $message, ?string $parseMode = null): bool
    {
        if (!$this->baleService->isConfigured()) {
            Log::error('Bale is not configured. Please set BALE_BOT_TOKEN in .env file');
            return false;
        }

        $result = $this->baleService->sendMessage($chatId, $message, $parseMode);

        return $result !== null;
    }

    /**
     * Send OTP message
     *
     * @param string|int $chatId Chat ID or username
     * @param string $otpCode OTP code
     * @param string $purpose Purpose of OTP (e.g., 'login', 'password_reset')
     * @return bool Success status
     */
    public function sendOtp($chatId, string $otpCode, string $purpose = 'verification'): bool
    {
        $message = $this->getOtpMessage($otpCode, $purpose);
        return $this->send($chatId, $message);
    }

    /**
     * Send welcome message to new user
     *
     * @param string|int $chatId Chat ID or username
     * @param string $userName User name
     * @return bool Success status
     */
    public function sendWelcome($chatId, string $userName): bool
    {
        $message = "سلام $userName! 👋\n\nبه تاکسی آژانس خوش آمدید. از خدمات ما لذت ببرید.";
        return $this->send($chatId, $message);
    }

    /**
     * Send reservation confirmation message
     *
     * @param string|int $chatId Chat ID or username
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendReservationConfirmation($chatId, array $reservationData): bool
    {
        $message = $this->getReservationMessage($reservationData);
        return $this->send($chatId, $message);
    }

    /**
     * Send reservation reminder message
     *
     * @param string|int $chatId Chat ID or username
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendReservationReminder($chatId, array $reservationData): bool
    {
        $message = $this->getReservationReminderMessage($reservationData);
        return $this->send($chatId, $message);
    }

    /**
     * Send cancellation message
     *
     * @param string|int $chatId Chat ID or username
     * @param array $reservationData Reservation details
     * @return bool Success status
     */
    public function sendCancellation($chatId, array $reservationData): bool
    {
        $message = $this->getCancellationMessage($reservationData);
        return $this->send($chatId, $message);
    }

    /**
     * Send message with keyboard buttons
     *
     * @param string|int $chatId Chat ID or username
     * @param string $message Message text
     * @param array $keyboard Keyboard buttons array
     * @return bool Success status
     */
    public function sendWithKeyboard($chatId, string $message, array $keyboard): bool
    {
        if (!$this->baleService->isConfigured()) {
            Log::error('Bale is not configured. Please set BALE_BOT_TOKEN in .env file');
            return false;
        }

        $result = $this->baleService->sendMessageWithKeyboard($chatId, $message, $keyboard);

        return $result !== null;
    }

    /**
     * Send photo
     *
     * @param string|int $chatId Chat ID or username
     * @param string $photoUrl Photo URL or file path
     * @param string|null $caption Photo caption
     * @return bool Success status
     */
    public function sendPhoto($chatId, string $photoUrl, ?string $caption = null): bool
    {
        if (!$this->baleService->isConfigured()) {
            Log::error('Bale is not configured. Please set BALE_BOT_TOKEN in .env file');
            return false;
        }

        $result = $this->baleService->sendPhoto($chatId, $photoUrl, $caption);

        return $result !== null;
    }

    /**
     * Get bot information
     *
     * @return array|null
     */
    public function getBotInfo(): ?array
    {
        return $this->baleService->getMe();
    }

    /**
     * Get chat information
     *
     * @param string|int $chatId Chat ID or username
     * @return array|null
     */
    public function getChatInfo($chatId): ?array
    {
        return $this->baleService->getChat($chatId);
    }

    /**
     * Check if Bale service is configured
     *
     * @return bool
     */
    public function isConfigured(): bool
    {
        return $this->baleService->isConfigured();
    }

    /**
     * Get OTP message based on purpose
     *
     * @param string $otpCode OTP code
     * @param string $purpose Purpose of OTP
     * @return string Formatted message
     */
    protected function getOtpMessage(string $otpCode, string $purpose): string
    {
        $messages = [
            'login' => "🔐 کد ورود شما:\n\n`$otpCode`\n\n⏰ این کد تا 2 دقیقه معتبر است.",
            'password_reset' => "🔑 کد بازیابی رمز عبور:\n\n`$otpCode`\n\n⏰ این کد تا 2 دقیقه معتبر است.",
            'verification' => "✅ کد تایید شما:\n\n`$otpCode`\n\n⏰ این کد تا 2 دقیقه معتبر است.",
            'registration' => "📝 کد تایید ثبت نام:\n\n`$otpCode`\n\n⏰ این کد تا 2 دقیقه معتبر است.",
        ];

        return $messages[$purpose] ?? $messages['verification'];
    }

    /**
     * Get reservation confirmation message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getReservationMessage(array $reservationData): string
    {
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';
        $origin = $reservationData['origin'] ?? 'نامشخص';
        $destination = $reservationData['destination'] ?? 'نامشخص';
        $reservationId = $reservationData['id'] ?? 'نامشخص';

        return "✅ رزرو شما با موفقیت ثبت شد.\n\n" .
               "🆔 شماره رزرو: $reservationId\n" .
               "📅 تاریخ: $date\n" .
               "🕐 ساعت: $time\n" .
               "📍 مبدا: $origin\n" .
               "🎯 مقصد: $destination\n\n" .
               "🙏 با تشکر از انتخاب شما";
    }

    /**
     * Get reservation reminder message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getReservationReminderMessage(array $reservationData): string
    {
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';
        $reservationId = $reservationData['id'] ?? 'نامشخص';

        return "⏰ یادآوری رزرو\n\n" .
               "🆔 شماره رزرو: $reservationId\n" .
               "📅 تاریخ: $date\n" .
               "🕐 ساعت: $time\n\n" .
               "⚠️ لطفا 15 دقیقه قبل از زمان مقرر در محل حاضر باشید.";
    }

    /**
     * Get cancellation message
     *
     * @param array $reservationData
     * @return string
     */
    protected function getCancellationMessage(array $reservationData): string
    {
        $reservationId = $reservationData['id'] ?? 'نامشخص';
        $date = $reservationData['date'] ?? 'نامشخص';
        $time = $reservationData['time'] ?? 'نامشخص';

        return "❌ رزرو شما لغو شد.\n\n" .
               "🆔 شماره رزرو: $reservationId\n" .
               "📅 تاریخ: $date\n" .
               "🕐 ساعت: $time\n\n" .
               "💡 در صورت نیاز می‌توانید رزرو جدیدی ثبت کنید.";
    }
}

