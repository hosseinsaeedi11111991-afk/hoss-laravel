<?php

namespace Modules\Notification\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Facades\Log;

/**
 * Bale Messenger Service for sending messages via Bale bot
 * Documentation: https://dev.bale.ai/
 */
class BaleService
{
    protected $client;
    protected $token;
    protected $baseUrl;
    protected $timeout;

    public function __construct()
    {
        $this->token = config('notification.bale.token');
        $this->baseUrl = rtrim(config('notification.bale.base_url', 'https://tapi.bale.ai'), '/');
        $this->timeout = config('notification.bale.timeout', 30);

        $this->client = new Client([
            'timeout' => $this->timeout,
            'verify' => false, // غیرفعال کردن SSL verification برای حل مشکل SSL
            'allow_redirects' => true, // اجازه دنبال کردن redirect (301 -> tapi.bale.chat)
        ]);
    }

    /**
     * Send message to a chat
     *
     * @param string|int $chatId Chat ID or username
     * @param string $message Message text
     * @param string|null $parseMode Parse mode (HTML, Markdown, MarkdownV2)
     * @param bool $disableWebPagePreview Disable web page preview
     * @return array|null
     */
    public function sendMessage($chatId, string $message, ?string $parseMode = null, bool $disableWebPagePreview = false): ?array
    {

        try {
            // استفاده از query parameters به جای JSON body (مطابق با curl)
            $queryParams = [
                'chat_id' => $chatId,
                'text' => $message,
            ];

            if ($parseMode) {
                $queryParams['parse_mode'] = $parseMode;
            }

            if ($disableWebPagePreview) {
                $queryParams['disable_web_page_preview'] = 'true';
            }

            // ساخت URL کامل برای اطمینان از استفاده از base_url درست
            // استفاده از URL کامل به جای relative path برای جلوگیری از redirect
            $url = "{$this->baseUrl}/bot{$this->token}/sendMessage";

            Log::info('Bale sending message', [
                'url' => $url,
                'base_url' => $this->baseUrl,
                'chat_id' => $chatId,
                'query_params' => $queryParams
            ]);

            // استفاده از form_params برای POST (بهتر از query string برای پیام‌های طولانی)
            // چون query string در URL محدودیت طول دارد و ممکن است HTML برگرداند
            Log::info('Bale sending message', [
                'url' => $url,
                'base_url' => $this->baseUrl,
                'chat_id' => $chatId,
                'message_length' => mb_strlen($message),
                'message_preview' => mb_substr($message, 0, 100),
                'parse_mode' => $parseMode
            ]);

            // استفاده از form_params برای POST (بهتر برای پیام‌های طولانی)
            $response = $this->client->request('POST', $url, [
                'form_params' => $queryParams,
                'http_errors' => false, // برای مدیریت خطاها به صورت دستی
            ]);

            $statusCode = $response->getStatusCode();
            $responseBody = $response->getBody()->getContents();

            // لاگ کامل response برای دیباگ
            Log::info('Bale API Response', [
                'status_code' => $statusCode,
                'response_body' => $responseBody,
                'url' => $url,
                'chat_id' => $chatId
            ]);

            $data = json_decode($responseBody, true);

            // بررسی اینکه آیا response JSON معتبر است
            if (json_last_error() !== JSON_ERROR_NONE) {
                Log::error('Bale JSON Parse Error', [
                    'chat_id' => $chatId,
                    'json_error' => json_last_error_msg(),
                    'response_body' => $responseBody,
                    'status_code' => $statusCode
                ]);
                return null;
            }

            if (isset($data['ok']) && $data['ok'] === true) {
                Log::info('Bale message sent successfully', [
                    'chat_id' => $chatId,
                    'message' => $message,
                    'response' => $data
                ]);
                return $data['result'];
            }

            // اگر ok === false است، خطا را لاگ کن
            Log::error('Bale Send Error', [
                'chat_id' => $chatId,
                'query_params' => $queryParams,
                'response' => $data,
                'response_body' => $responseBody,
                'status_code' => $statusCode,
                'error_code' => $data['error_code'] ?? null,
                'description' => $data['description'] ?? null
            ]);
            return null;

        } catch (GuzzleException $e) {
            $errorDetails = [
                'chat_id' => $chatId,
                'message' => $message,
                'error' => $e->getMessage(),
            ];

            // اگر response وجود دارد، آن را هم لاگ کن
            if (method_exists($e, 'getResponse') && $e->getResponse()) {
                $errorDetails['response_body'] = $e->getResponse()->getBody()->getContents();
                $errorDetails['response_status'] = $e->getResponse()->getStatusCode();
            }

            Log::error('Bale Send Exception', $errorDetails);
            return null;
        }
    }

    /**
     * Send message with keyboard buttons
     *
     * @param string|int $chatId Chat ID or username
     * @param string $message Message text
     * @param array $keyboard Keyboard buttons array
     * @param string|null $parseMode Parse mode
     * @return array|null
     */
    public function sendMessageWithKeyboard($chatId, string $message, array $keyboard, ?string $parseMode = null): ?array
    {
        try {
            $payload = [
                'chat_id' => $chatId,
                'text' => $message,
                'reply_markup' => [
                    'keyboard' => $keyboard,
                    'resize_keyboard' => true,
                    'one_time_keyboard' => false
                ]
            ];

            if ($parseMode) {
                $payload['parse_mode'] = $parseMode;
            }
            $url = "{$this->baseUrl}/bot{$this->token}/sendMessage";

            $response = $this->client->post($url, [
                'json' => $payload
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                Log::info('Bale message with keyboard sent successfully', [
                    'chat_id' => $chatId,
                    'message' => $message,
                ]);
                return $data['result'];
            }

            Log::error('Bale Send Keyboard Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('Bale Send Keyboard Exception: ' . $e->getMessage(), [
                'chat_id' => $chatId,
                'message' => $message
            ]);
            return null;
        }
    }

    /**
     * Send photo
     *
     * @param string|int $chatId Chat ID or username
     * @param string $photoUrl Photo URL or file path
     * @param string|null $caption Photo caption
     * @return array|null
     */
    public function sendPhoto($chatId, string $photoUrl, ?string $caption = null): ?array
    {
        try {
            $payload = [
                'chat_id' => $chatId,
            ];

            // Check if it's a URL or file path
            if (filter_var($photoUrl, FILTER_VALIDATE_URL)) {
                $payload['photo'] = $photoUrl;
            } else {
                // For file upload, use multipart
                $response = $this->client->post("/bot{$this->token}/sendPhoto", [
                    'multipart' => [
                        [
                            'name' => 'chat_id',
                            'contents' => (string)$chatId
                        ],
                        [
                            'name' => 'photo',
                            'contents' => fopen($photoUrl, 'r')
                        ],
                        ...($caption ? [['name' => 'caption', 'contents' => $caption]] : [])
                    ]
                ]);

                $data = json_decode($response->getBody()->getContents(), true);
                if (isset($data['ok']) && $data['ok'] === true) {
                    return $data['result'];
                }
                return null;
            }

            if ($caption) {
                $payload['caption'] = $caption;
            }

            $response = $this->client->post("/bot{$this->token}/sendPhoto", [
                'json' => $payload
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                Log::info('Bale photo sent successfully', [
                    'chat_id' => $chatId,
                ]);
                return $data['result'];
            }

            Log::error('Bale Send Photo Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('Bale Send Photo Exception: ' . $e->getMessage(), [
                'chat_id' => $chatId,
            ]);
            return null;
        }
    }

    /**
     * Get bot information
     *
     * @return array|null
     */
    public function getMe(): ?array
    {
        try {
            $response = $this->client->get("/bot{$this->token}/getMe");
            $data = json_decode($response->getBody()->getContents(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                return $data['result'];
            }

            Log::error('Bale GetMe Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('Bale GetMe Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get chat information
     *
     * @param string|int $chatId Chat ID or username
     * @return array|null
     */
    public function getChat($chatId): ?array
    {
        try {
            $response = $this->client->get("/bot{$this->token}/getChat", [
                'query' => ['chat_id' => $chatId]
            ]);
            $data = json_decode($response->getBody()->getContents(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                return $data['result'];
            }

            Log::error('Bale GetChat Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('Bale GetChat Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get updates (messages) from bot
     * This can be used to get chat_id from messages sent to the bot
     *
     * @param int $offset Offset for pagination
     * @param int $limit Limit of results
     * @return array|null
     */
    public function getUpdates(int $offset = 0, int $limit = 100): ?array
    {
        try {
            $response = $this->client->get("/bot{$this->token}/getUpdates", [
                'query' => [
                    'offset' => $offset,
                    'limit' => $limit
                ]
            ]);
            $data = json_decode($response->getBody()->getContents(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                return $data['result'];
            }

            Log::error('Bale GetUpdates Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('Bale GetUpdates Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Check if bot token is configured
     *
     * @return bool
     */
    public function isConfigured(): bool
    {
        return !empty($this->token);
    }
}

