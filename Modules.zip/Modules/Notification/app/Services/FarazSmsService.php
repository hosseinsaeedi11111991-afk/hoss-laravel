<?php

namespace Modules\Notification\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\Log;

/**
 * FarazSMS Service for sending SMS messages
 * Documentation: https://docs.iranpayamak.com/
 */
class FarazSmsService
{
    protected $client;
    protected $apiKey;
    protected $baseUrl;
    protected $timeout;
    protected $patternEndpoint;

    public function __construct()
    {
        $this->refreshConfiguration();
    }

    /**
     * Get account profile information
     *
     * @return array|null
     */
    public function getProfile(): ?array
    {
        try {
            $this->refreshConfiguration();
            $response = $this->client->get('/ws/v1/account/profile');
            $data = json_decode($response->getBody()->getContents(), true);

            if ($data['status'] === 'success') {
                return $data['data'];
            }

            Log::error('FarazSMS Profile Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('FarazSMS Profile Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get account balance
     *
     * @return array|null
     */
    public function getBalance(): ?array
    {
        try {
            $this->refreshConfiguration();
            $response = $this->client->get('/ws/v1/account/balance');
            $data = json_decode($response->getBody()->getContents(), true);

            if ($data['status'] === 'success') {
                return $data['data'];
            }

            Log::error('FarazSMS Balance Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('FarazSMS Balance Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Send simple SMS
     *
     * @param string $recipient Mobile number (e.g., 09123456789)
     * @param string $message SMS message content
     * @param string|null $sender Sender number (optional)
     * @return array|null
     */
    public function sendSimpleSms(string $recipient, string $message, ?string $sender = null): ?array
    {
        try {
            $this->refreshConfiguration();
            $payload = [
                'recipient' => $this->formatMobileNumber($recipient),
                'message' => $message,
            ];

            if ($sender) {
                $payload['sender'] = $sender;
            }

            $response = $this->client->post('/ws/v1/send/simple', [
                'json' => $payload
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if ($data['status'] === 'success') {
                Log::info('FarazSMS sent successfully', [
                    'recipient' => $recipient,
                    'message' => $message,
                    'response' => $data
                ]);
                return $data['data'];
            }

            Log::error('FarazSMS Send Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('FarazSMS Send Exception: ' . $e->getMessage(), [
                'recipient' => $recipient,
                'message' => $message
            ]);
            return null;
        }
    }

    /**
     * Send SMS with variables (pattern-based)
     *
     * @param string $recipient Mobile number
     * @param string $patternCode Pattern code from FarazSMS panel
     * @param array $variables Variables to replace in pattern
     * @param string|null $sender Sender number (optional)
     * @return array|null
     */
    public function sendPatternSms(string $recipient, string $patternCode, array $variables, ?string $sender = null): ?array
    {

        try {
            $this->refreshConfiguration();
            $sender = $sender ?? config('notification.sms.farazsms.sender', '3000505');
            $payload = [
                'code' => $patternCode,
                'sender' => $sender,
                'recipient' => $this->formatMobileNumber($recipient),
                'variable' => $variables,
            ];

            $response = $this->client->post('/api/v1/sms/pattern/normal/send', [
                'json' => $payload
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if (is_array($data) && (isset($data['status']) && $data['status'] === 'success' || isset($data['message_id']) || isset($data['data']))) {
                Log::info('FarazSMS pattern sent successfully', [
                    'recipient' => $recipient,
                    'pattern_code' => $patternCode,
                    'response' => $data
                ]);
                return $data;
            }

            Log::error('FarazSMS pattern send failed or invalid response', [
                'recipient' => $recipient,
                'pattern_code' => $patternCode,
                'response' => $data
            ]);
            return null;

        } catch (GuzzleException $e) {
            $errorDetails = [
                'recipient' => $recipient,
                'pattern_code' => $patternCode,
                'variables' => $variables,
                'message' => $e->getMessage(),
            ];

            if (method_exists($e, 'getResponse') && $e->getResponse()) {
                $errorDetails['response_body'] = $e->getResponse()->getBody()->getContents();
                $errorDetails['response_status'] = $e->getResponse()->getStatusCode();
            }

            Log::error('FarazSMS pattern send exception', $errorDetails);
            return null;
        }
    }

    /**
     * Send bulk SMS to multiple recipients
     *
     * @param array $recipients Array of mobile numbers
     * @param string $message SMS message content
     * @param string|null $sender Sender number (optional)
     * @return array|null
     */
    public function sendBulkSms(array $recipients, string $message, ?string $sender = null): ?array
    {
        try {
            $this->refreshConfiguration();
            $formattedRecipients = array_map([$this, 'formatMobileNumber'], $recipients);

            $payload = [
                'recipients' => $formattedRecipients,
                'message' => $message,
            ];

            if ($sender) {
                $payload['sender'] = $sender;
            }

            $response = $this->client->post('/ws/v1/send/bulk', [
                'json' => $payload
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if ($data['status'] === 'success') {
                Log::info('FarazSMS bulk sent successfully', [
                    'recipients_count' => count($recipients),
                    'message' => $message,
                    'response' => $data
                ]);
                return $data['data'];
            }

            Log::error('FarazSMS Bulk Send Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('FarazSMS Bulk Send Exception: ' . $e->getMessage(), [
                'recipients_count' => count($recipients),
                'message' => $message
            ]);
            return null;
        }
    }

    /**
     * Get inbox messages
     *
     * @param int $page Page number
     * @param int $perPage Items per page
     * @return array|null
     */
    public function getInboxMessages(int $page = 1, int $perPage = 10): ?array
    {
        try {
            $this->refreshConfiguration();
            $response = $this->client->get('/ws/v1/inbox', [
                'query' => [
                    'page' => $page,
                    'per_page' => $perPage
                ]
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            if ($data['status'] === 'success') {
                return $data['data'];
            }

            Log::error('FarazSMS Inbox Error: ' . json_encode($data));
            return null;

        } catch (GuzzleException $e) {
            Log::error('FarazSMS Inbox Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Format mobile number to standard format
     *
     * @param string $mobile Mobile number
     * @return string Formatted mobile number
     */
    protected function formatMobileNumber(string $mobile): string
    {
        // Remove any non-digit characters
        $mobile = preg_replace('/\D/', '', $mobile);

        // Add country code if missing
        if (strlen($mobile) === 10 && substr($mobile, 0, 1) === '9') {
            $mobile = '98' . $mobile;
        }

        // Remove leading 0 if present
        if (substr($mobile, 0, 1) === '0') {
            $mobile = substr($mobile, 1);
        }

        return $mobile;
    }

    /**
     * Check if API key is configured
     *
     * @return bool
     */
    public function isConfigured(): bool
    {
        $this->refreshConfiguration();

        return filled($this->apiKey);
    }

    protected function normalizeEndpoint(string $endpoint): string
    {
        if (filter_var($endpoint, FILTER_VALIDATE_URL)) {
            return $endpoint;
        }

        return '/' . ltrim($endpoint, '/');
    }

    protected function refreshConfiguration(): void
    {
        $apiKey = $this->configuredApiKey();
        $baseUrl = rtrim((string) config('notification.sms.farazsms.base_url'), '/');
        $timeout = (int) config('notification.sms.farazsms.timeout', 30);
        $patternEndpoint = (string) config('notification.sms.farazsms.pattern_endpoint', '/v1/messages/patterns/send');

        if (
            $this->client instanceof Client
            && $this->apiKey === $apiKey
            && $this->baseUrl === $baseUrl
            && $this->timeout === $timeout
            && $this->patternEndpoint === $patternEndpoint
        ) {
            return;
        }

        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
        $this->timeout = $timeout;
        $this->patternEndpoint = $patternEndpoint;
        $this->client = new Client([
            'base_uri' => $this->baseUrl,
            'timeout' => $this->timeout,
            'headers' => [
                'apikey' => $this->apiKey,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
        ]);
    }

    protected function configuredApiKey(): string
    {
        $apiKey = (string) config('notification.sms.farazsms.api_key', '');

        if ($apiKey !== '') {
            return $apiKey;
        }

        return (string) env('FARAZSMS_API_KEY', getenv('FARAZSMS_API_KEY') ?: '');
    }
}
