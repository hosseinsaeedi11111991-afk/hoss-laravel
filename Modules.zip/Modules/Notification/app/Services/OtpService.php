<?php

namespace Modules\Notification\Services;

use Carbon\Carbon;
use Modules\Notification\Models\Otp;

/**
 * Service for generating, sending, and verifying OTP codes.
 */
class OtpService
{
    /**
     * Generate and store a new OTP code for a given receiver, channel, and purpose.
     *
     * @param  string  $receiver  The destination identifier (e.g., mobile number or email).
     * @param  string  $channel   The communication channel (e.g., 'mobile', 'email').
     * @param  string  $purpose   The reason for sending the OTP (e.g., 'login', 'password_reset').
     * @return string             The generated OTP code.
     */
    public function send(string $receiver, string $channel, string $purpose): string
    {
        // $otp_code = rand(10000, 99999);
        $otp_code = 12345;

        $otp = Otp::query()->where([
            'receiver' => $receiver,
            'channel'  => $channel,
            'purpose'  => $purpose,
            'used'     => false
        ])->first();

        // Save OTP in DB (valid for 2 minutes)
        if ($otp) {
            $otp->update([
                'code'       => $otp_code,
                'expires_at' => Carbon::now()->addMinutes(2),
            ]);
        } else {
            Otp::create([
                'receiver'   => $receiver,
                'channel'    => $channel,
                'code'       => $otp_code,
                'purpose'    => $purpose,
                'expires_at' => Carbon::now()->addMinutes(2),
            ]);
        }        

        // TODO: Implement actual SMS sending logic here.
        logger("کد ارسال شده به $receiver: $otp_code");

        return $otp_code;
    }

    /**
     * Verify an OTP code for a given receiver and purpose.
     *
     * @param  string  $receiver  The destination identifier (e.g., mobile number or email).
     * @param  string  $code      The OTP code entered by the user.
     * @param  string  $purpose   The reason the OTP was sent (e.g., 'login').
     * @return bool               True if the code is valid, not used, and not expired; otherwise false.
     */
    public function verify(string $receiver, string $code): bool
    {
        $otp = Otp::where('receiver', $receiver)
            ->where('code', $code)
            ->where('used', false)
            ->where('expires_at', '>', Carbon::now())
            ->latest()
            ->first();

        if (!$otp) {
            return false;
        }

        $otp->update(['used' => true]);

        return true;
    }
}
