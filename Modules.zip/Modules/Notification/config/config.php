<?php

return [
    'name' => 'Notification',

    'sms' => [
        'farazsms' => [
            'api_key' => env('FARAZSMS_API_KEY'),
            'sender' => env('FARAZSMS_SENDER', '3000505'),
            'base_url' => 'https://api2.ippanel.com',
            'timeout' => 30,
            'pattern_endpoint' => '/api/send',
        ],
        // نوتیفیکیشن رزرو: شماره مدیر برای دریافت SMS بعد از ثبت هر رزرو جدید
        'reservation_admin_recipient' => env('SMS_RESERVATION_ADMIN_RECIPIENT', '09120983462'),
        'reservation_admin_pattern' => env('SMS_RESERVATION_ADMIN_PATTERN', 'd00wxqn35y8p6yf'),
        'reservation_passenger_pattern' => env('SMS_RESERVATION_PASSENGER_PATTERN', '1twembbnaiqkw3g'),
    ],

    'bale' => [
        'token' => env('BALE_BOT_TOKEN'),
        'base_url' => env('BALE_BASE_URL', 'https://tapi.bale.ai'),
        'timeout' => env('BALE_TIMEOUT', 30),
        'admin_chat_id' => env('BALE_ADMIN_CHAT_ID', 420884304), // Chat ID عددی مدیر برای دریافت نوتیفیکیشن‌ها
    ],
];
