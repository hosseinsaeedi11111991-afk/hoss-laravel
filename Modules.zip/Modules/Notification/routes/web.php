<?php

use Illuminate\Support\Facades\Route;
use Modules\Notification\Http\Controllers\NotificationController;
use Modules\Notification\Http\Controllers\SmsController;
use Modules\Notification\Http\Controllers\BaleController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('notifications', NotificationController::class)->names('notification');

    // SMS Routes
    Route::prefix('sms')->name('sms.')->group(function () {
        Route::post('send', [SmsController::class, 'send'])->name('send');
        Route::post('send-otp', [SmsController::class, 'sendOtp'])->name('send-otp');
        Route::post('send-pattern', [SmsController::class, 'sendPattern'])->name('send-pattern');
        Route::post('send-bulk', [SmsController::class, 'sendBulk'])->name('send-bulk');
        Route::post('send-welcome', [SmsController::class, 'sendWelcome'])->name('send-welcome');
        Route::post('send-reservation-confirmation', [SmsController::class, 'sendReservationConfirmation'])->name('send-reservation-confirmation');
        Route::get('balance', [SmsController::class, 'getBalance'])->name('balance');
        Route::get('profile', [SmsController::class, 'getProfile'])->name('profile');
        Route::get('status', [SmsController::class, 'status'])->name('status');
    });

    // Bale Routes
    Route::prefix('bale')->name('bale.')->group(function () {
        Route::post('send', [BaleController::class, 'send'])->name('send');
        Route::post('send-otp', [BaleController::class, 'sendOtp'])->name('send-otp');
        Route::post('send-welcome', [BaleController::class, 'sendWelcome'])->name('send-welcome');
        Route::post('send-reservation-confirmation', [BaleController::class, 'sendReservationConfirmation'])->name('send-reservation-confirmation');
        Route::post('send-reservation-reminder', [BaleController::class, 'sendReservationReminder'])->name('send-reservation-reminder');
        Route::post('send-cancellation', [BaleController::class, 'sendCancellation'])->name('send-cancellation');
        Route::post('send-with-keyboard', [BaleController::class, 'sendWithKeyboard'])->name('send-with-keyboard');
        Route::post('send-photo', [BaleController::class, 'sendPhoto'])->name('send-photo');
        Route::get('bot-info', [BaleController::class, 'getBotInfo'])->name('bot-info');
        Route::get('chat-info', [BaleController::class, 'getChatInfo'])->name('chat-info');
        Route::get('status', [BaleController::class, 'status'])->name('status');
    });
});

