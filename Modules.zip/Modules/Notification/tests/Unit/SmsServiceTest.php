<?php

namespace Modules\Notification\Tests\Unit;

use Tests\TestCase;
use Modules\Notification\Services\SmsService;
use Modules\Notification\Services\FarazSmsService;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SmsServiceTest extends TestCase
{
    use RefreshDatabase;

    protected $smsService;
    protected $farazSmsService;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->farazSmsService = $this->createMock(FarazSmsService::class);
        $this->smsService = new SmsService($this->farazSmsService);
    }

    /** @test */
    public function it_can_send_simple_sms()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $this->farazSmsService->expects($this->once())
            ->method('sendSimpleSms')
            ->with('09123456789', 'Test message', null)
            ->willReturn(['status' => 'success']);

        $result = $this->smsService->send('09123456789', 'Test message');

        $this->assertTrue($result);
    }

    /** @test */
    public function it_can_send_otp_sms()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $this->farazSmsService->expects($this->once())
            ->method('sendSimpleSms')
            ->willReturn(['status' => 'success']);

        $result = $this->smsService->sendOtp('09123456789', '12345', 'login');

        $this->assertTrue($result);
    }

    /** @test */
    public function it_can_send_pattern_sms()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $this->farazSmsService->expects($this->once())
            ->method('sendPatternSms')
            ->with('09123456789', 'pattern123', ['name' => 'علی'], null)
            ->willReturn(['status' => 'success']);

        $result = $this->smsService->sendPattern(
            '09123456789',
            'pattern123',
            ['name' => 'علی']
        );

        $this->assertTrue($result);
    }

    /** @test */
    public function it_can_send_bulk_sms()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $this->farazSmsService->expects($this->once())
            ->method('sendBulkSms')
            ->with(['09123456789', '09987654321'], 'Bulk message', null)
            ->willReturn(['status' => 'success']);

        $result = $this->smsService->sendBulk(
            ['09123456789', '09987654321'],
            'Bulk message'
        );

        $this->assertTrue($result);
    }

    /** @test */
    public function it_can_send_welcome_sms()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $this->farazSmsService->expects($this->once())
            ->method('sendSimpleSms')
            ->willReturn(['status' => 'success']);

        $result = $this->smsService->sendWelcome('09123456789', 'علی احمدی');

        $this->assertTrue($result);
    }

    /** @test */
    public function it_returns_false_when_not_configured()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(false);

        $result = $this->smsService->send('09123456789', 'Test message');

        $this->assertFalse($result);
    }

    /** @test */
    public function it_can_get_balance()
    {
        $expectedBalance = ['balance' => 1000];

        $this->farazSmsService->expects($this->once())
            ->method('getBalance')
            ->willReturn($expectedBalance);

        $result = $this->smsService->getBalance();

        $this->assertEquals($expectedBalance, $result);
    }

    /** @test */
    public function it_can_get_profile()
    {
        $expectedProfile = ['displayName' => 'Test User'];

        $this->farazSmsService->expects($this->once())
            ->method('getProfile')
            ->willReturn($expectedProfile);

        $result = $this->smsService->getProfile();

        $this->assertEquals($expectedProfile, $result);
    }

    /** @test */
    public function it_can_check_configuration_status()
    {
        $this->farazSmsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $result = $this->smsService->isConfigured();

        $this->assertTrue($result);
    }
}
