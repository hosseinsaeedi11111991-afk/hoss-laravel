<?php

namespace Modules\Notification\Tests\Unit;

use Modules\Notification\Services\FarazSmsService;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class FarazSmsServiceTest extends TestCase
{
    #[Test]
    public function it_refreshes_configuration_after_the_service_is_created(): void
    {
        config()->set('notification.sms.farazsms.api_key', '');
        config()->set('notification.sms.farazsms.base_url', 'https://api2.ippanel.com');
        config()->set('notification.sms.farazsms.timeout', 30);
        config()->set('notification.sms.farazsms.pattern_endpoint', '/api/send');

        $service = new FarazSmsService();

        $this->assertFalse($service->isConfigured());

        config()->set('notification.sms.farazsms.api_key', 'test-api-key');

        $this->assertTrue($service->isConfigured());
    }
}
