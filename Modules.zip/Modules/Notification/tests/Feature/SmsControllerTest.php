<?php

namespace Modules\Notification\Tests\Feature;

use Tests\TestCase;
use Modules\Notification\Services\SmsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;

class SmsControllerTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected $smsService;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->smsService = $this->createMock(SmsService::class);
        $this->app->instance(SmsService::class, $this->smsService);
    }

    /** @test */
    public function it_can_send_simple_sms()
    {
        $this->smsService->expects($this->once())
            ->method('send')
            ->with('09123456789', 'Test message', null)
            ->willReturn(true);

        $response = $this->postJson('/sms/send', [
            'recipient' => '09123456789',
            'message' => 'Test message'
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'پیامک با موفقیت ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_send_otp_sms()
    {
        $this->smsService->expects($this->once())
            ->method('sendOtp')
            ->with('09123456789', '12345', 'login')
            ->willReturn(true);

        $response = $this->postJson('/sms/send-otp', [
            'recipient' => '09123456789',
            'otp_code' => '12345',
            'purpose' => 'login'
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'کد تایید ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_send_pattern_sms()
    {
        $this->smsService->expects($this->once())
            ->method('sendPattern')
            ->with('09123456789', 'pattern123', ['name' => 'علی'], null)
            ->willReturn(true);

        $response = $this->postJson('/sms/send-pattern', [
            'recipient' => '09123456789',
            'pattern_code' => 'pattern123',
            'variables' => ['name' => 'علی']
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'پیامک الگویی ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_send_bulk_sms()
    {
        $this->smsService->expects($this->once())
            ->method('sendBulk')
            ->with(['09123456789', '09987654321'], 'Bulk message', null)
            ->willReturn(true);

        $response = $this->postJson('/sms/send-bulk', [
            'recipients' => ['09123456789', '09987654321'],
            'message' => 'Bulk message'
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'پیامک گروهی ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_send_welcome_sms()
    {
        $this->smsService->expects($this->once())
            ->method('sendWelcome')
            ->with('09123456789', 'علی احمدی')
            ->willReturn(true);

        $response = $this->postJson('/sms/send-welcome', [
            'recipient' => '09123456789',
            'user_name' => 'علی احمدی'
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'پیام خوشامدگویی ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_send_reservation_confirmation()
    {
        $reservationData = [
            'id' => 'R123456',
            'date' => '1403/01/15',
            'time' => '14:30',
            'origin' => 'تهران، میدان آزادی',
            'destination' => 'تهران، پارک وی'
        ];

        $this->smsService->expects($this->once())
            ->method('sendReservationConfirmation')
            ->with('09123456789', $reservationData)
            ->willReturn(true);

        $response = $this->postJson('/sms/send-reservation-confirmation', [
            'recipient' => '09123456789',
            'reservation_data' => $reservationData
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'message' => 'تایید رزرو ارسال شد'
            ]);
    }

    /** @test */
    public function it_can_get_balance()
    {
        $balance = ['balance' => 1000];

        $this->smsService->expects($this->once())
            ->method('getBalance')
            ->willReturn($balance);

        $response = $this->getJson('/sms/balance');

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'data' => $balance,
                'message' => 'موجودی دریافت شد'
            ]);
    }

    /** @test */
    public function it_can_get_profile()
    {
        $profile = ['displayName' => 'Test User'];

        $this->smsService->expects($this->once())
            ->method('getProfile')
            ->willReturn($profile);

        $response = $this->getJson('/sms/profile');

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'data' => $profile,
                'message' => 'پروفایل دریافت شد'
            ]);
    }

    /** @test */
    public function it_can_check_status()
    {
        $this->smsService->expects($this->once())
            ->method('isConfigured')
            ->willReturn(true);

        $response = $this->getJson('/sms/status');

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'data' => [
                    'configured' => true,
                    'status' => 'active'
                ],
                'message' => 'سرویس پیامک فعال است'
            ]);
    }

    /** @test */
    public function it_validates_required_fields_for_send()
    {
        $response = $this->postJson('/sms/send', []);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['recipient', 'message']);
    }

    /** @test */
    public function it_validates_required_fields_for_send_otp()
    {
        $response = $this->postJson('/sms/send-otp', []);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['recipient', 'otp_code']);
    }

    /** @test */
    public function it_validates_required_fields_for_send_pattern()
    {
        $response = $this->postJson('/sms/send-pattern', []);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['recipient', 'pattern_code', 'variables']);
    }

    /** @test */
    public function it_validates_required_fields_for_send_bulk()
    {
        $response = $this->postJson('/sms/send-bulk', []);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['recipients', 'message']);
    }
}
