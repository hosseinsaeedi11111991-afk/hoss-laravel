# Notification Module - SMS Service

این ماژول سرویس پیامکی فراز اس‌ام‌اس را برای پروژه تاکسی آژانس فراهم می‌کند.

## نصب و راه‌اندازی

### 1. تنظیم API Key

در فایل `.env` پروژه، کلید API فراز اس‌ام‌اس را اضافه کنید:

```env
FARAZSMS_API_KEY=your_api_key_here
```

### 2. دریافت API Key

برای دریافت کلید API:
1. به پنل فراز اس‌ام‌اس مراجعه کنید
2. از بخش API، کلید خود را دریافت کنید
3. کلید را در فایل `.env` قرار دهید

## استفاده

### ارسال پیامک ساده

```php
use Modules\Notification\Services\SmsService;

$smsService = app(SmsService::class);

$success = $smsService->send('09123456789', 'سلام! این یک پیامک تست است.');
```

### ارسال کد تایید (OTP)

```php
$success = $smsService->sendOtp('09123456789', '12345', 'login');
```

### ارسال پیامک الگویی

```php
$success = $smsService->sendPattern(
    '09123456789',
    'your_pattern_code',
    ['name' => 'علی', 'code' => '12345']
);
```

### ارسال پیامک گروهی

```php
$recipients = ['09123456789', '09987654321'];
$success = $smsService->sendBulk($recipients, 'پیام گروهی');
```

### ارسال پیام خوشامدگویی

```php
$success = $smsService->sendWelcome('09123456789', 'علی احمدی');
```

### ارسال تایید رزرو

```php
$reservationData = [
    'id' => 'R123456',
    'date' => '1403/01/15',
    'time' => '14:30',
    'origin' => 'تهران، میدان آزادی',
    'destination' => 'تهران، پارک وی'
];

$success = $smsService->sendReservationConfirmation('09123456789', $reservationData);
```

## API Endpoints

### ارسال پیامک ساده
```
POST /sms/send
{
    "recipient": "09123456789",
    "message": "متن پیامک",
    "sender": "optional_sender"
}
```

### ارسال کد تایید
```
POST /sms/send-otp
{
    "recipient": "09123456789",
    "otp_code": "12345",
    "purpose": "login"
}
```

### ارسال پیامک الگویی
```
POST /sms/send-pattern
{
    "recipient": "09123456789",
    "pattern_code": "your_pattern_code",
    "variables": {
        "name": "علی",
        "code": "12345"
    }
}
```

### ارسال پیامک گروهی
```
POST /sms/send-bulk
{
    "recipients": ["09123456789", "09987654321"],
    "message": "پیام گروهی"
}
```

### دریافت موجودی حساب
```
GET /sms/balance
```

### دریافت پروفایل حساب
```
GET /sms/profile
```

### بررسی وضعیت سرویس
```
GET /sms/status
```

## سرویس‌های موجود

### FarazSmsService
سرویس اصلی برای ارتباط با API فراز اس‌ام‌اس

### SmsService
سرویس مدیریت پیامک‌ها با قابلیت‌های مختلف

### OtpService
سرویس مدیریت کدهای تایید (OTP)

## لاگ‌ها

تمام عملیات ارسال پیامک در فایل لاگ ثبت می‌شوند:
- `storage/logs/laravel.log`

## خطاها

در صورت بروز خطا، پیام‌های خطا در لاگ ثبت شده و پاسخ مناسب به کاربر ارسال می‌شود.

## مستندات API فراز اس‌ام‌اس

برای اطلاعات بیشتر به [مستندات فراز اس‌ام‌اس](https://docs.iranpayamak.com/) مراجعه کنید.
