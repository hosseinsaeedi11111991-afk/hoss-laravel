<?php

return [
    'name' => 'Reservation',
];
