<?php

namespace Modules\Reservation\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Modules\Reservation\Events\ReservationCreated;
use Modules\Reservation\Events\ReservationStatusChanged;
use Modules\Reservation\Listeners\SendReservationNotificationBale;
use Modules\Reservation\Listeners\SendReservationNotificationSms;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event handler mappings for the application.
     *
     * @var array<string, array<int, string>>
     */
    protected $listen = [
        ReservationCreated::class => [
            SendReservationNotificationSms::class,
            SendReservationNotificationBale::class,
        ],
        ReservationStatusChanged::class => [
            SendReservationNotificationSms::class,
            SendReservationNotificationBale::class,
        ],
    ];

    /**
     * Indicates if events should be discovered.
     *
     * @var bool
     */
    protected static $shouldDiscoverEvents = true;

    /**
     * Configure the proper event listeners for email verification.
     */
    protected function configureEmailVerification(): void {}
}
