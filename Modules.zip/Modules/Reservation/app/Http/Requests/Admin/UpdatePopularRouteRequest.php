<?php

namespace Modules\Reservation\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePopularRouteRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'title' => ['sometimes', 'required', 'string', 'max:255'],
            'origin_address' => ['sometimes', 'required', 'string', 'max:500'],
            'destination_address' => ['sometimes', 'required', 'string', 'max:500'],
            'origin_lat' => ['sometimes', 'required', 'numeric'],
            'origin_lng' => ['sometimes', 'required', 'numeric'],
            'destination_lat' => ['sometimes', 'required', 'numeric'],
            'destination_lng' => ['sometimes', 'required', 'numeric'],
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:2048'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
