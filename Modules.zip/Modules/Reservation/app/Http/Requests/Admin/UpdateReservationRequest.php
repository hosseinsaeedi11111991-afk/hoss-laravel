<?php

namespace Modules\Reservation\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateReservationRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'car_id'              => ['nullable', 'exists:cars,id'],
            'car_category_id'     => ['nullable', 'exists:car_categories,id'],
            'user_id'             => ['required', 'exists:users,id'],
            'date'                => ['required', 'date'],
            'distance_km'         => ['required', 'numeric', 'min:0'],
            'origin_address'      => ['nullable', 'string', 'max:255'],
            'destination_address' => ['nullable', 'string', 'max:255'],
            'origin'              => ['nullable', 'string', 'max:255'],
            'destination'         => ['nullable', 'string', 'max:255'],
            'time'                => ['nullable', 'string', 'max:15'],
            'phone'               => ['nullable', 'string', 'max:20', 'regex:/^09\d{9}$/'],
            'second_phone'       => ['nullable', 'string', 'max:20'],
            'description'         => ['nullable', 'string'],
            'passengers_count'    => ['nullable', 'integer', 'min:1', 'max:99'],
            'needs_invoice'       => ['nullable', 'boolean'],
            'is_negotiable'       => ['nullable', 'boolean'],
            'options'             => ['nullable', 'array'],
            'options.*'           => ['exists:options,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'car_id.exists'         => 'خودرو انتخاب شده معتبر نیست.',
            'car_category_id.exists' => 'دسته‌بندی ماشین انتخاب شده معتبر نیست.',
            'user_id.required'      => 'انتخاب کاربر الزامی است.',
            'user_id.exists'        => 'کاربر انتخاب شده معتبر نیست.',
            'date.required'         => 'تاریخ رزرو الزامی است.',
            'date.after_or_equal'   => 'تاریخ باید امروز یا بعد از آن باشد.',
            'distance_km.required' => 'مسافت (کیلومتر) الزامی است.',
            'distance_km.numeric'  => 'مسافت باید عدد باشد.',
            'phone.regex'          => 'شماره تماس باید با فرمت 09XXXXXXXXX وارد شود.',
            'phone.max'            => 'شماره تماس نباید بیشتر از ۲۰ کاراکتر باشد.',
            'second_phone.max'      => 'شماره دوم نباید بیشتر از ۲۰ کاراکتر باشد.',
            'passengers_count.integer' => 'تعداد مسافران باید عدد صحیح باشد.',
            'passengers_count.min'     => 'حداقل تعداد مسافر ۱ نفر است.',
            'passengers_count.max'     => 'حداکثر تعداد مسافر ۹۹ نفر است.',
            'needs_invoice.boolean' => 'فیلد نیاز به فاکتور باید true یا false باشد.',
            'is_negotiable.boolean' => 'فیلد قیمت توافقی باید true یا false باشد.',
            'options.array'         => 'آپشن‌ها باید به صورت آرایه ارسال شوند.',
            'options.*.exists'      => 'آپشن انتخاب‌شده معتبر نیست.',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
