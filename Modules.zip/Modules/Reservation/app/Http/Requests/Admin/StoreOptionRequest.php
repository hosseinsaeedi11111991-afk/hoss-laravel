<?php

namespace Modules\Reservation\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreOptionRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name'              => ['required', 'string', 'max:255'],
            'car_category_id'   => ['nullable', 'exists:car_categories,id'],
            'fixed_price'       => ['nullable', 'numeric', 'min:0'],
            'per_km_price'      => ['nullable', 'numeric', 'min:0'],
            'percentage_price'  => ['nullable', 'numeric', 'min:0', 'max:100'],
            'type'              => ['required','in:text,checkbox'],
            'pricing_type'      => ['required', 'in:fixed,per_km,percentage'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required'        => 'فیلد *نام آپشن* الزامی است.',
            'name.max'             => 'نام آپشن نباید بیش از ۲۵۵ کاراکتر باشد.',
            'fixed_price.numeric'  => 'قیمت ثابت باید یک عدد باشد.',
            'fixed_price.min'      => 'قیمت ثابت نمی‌تواند منفی باشد.',
            'fixed_price.max'      => 'قیمت ثابت نمی‌تواند بیشتر از 20 عدد باشد باشد.',
            'per_km_price.numeric' => 'قیمت هر کیلومتر باید یک عدد باشد.',
            'per_km_price.min'     => 'قیمت هر کیلومتر نمی‌تواند منفی باشد.',
            'per_km_price.max'     => 'قیمت هر کیلومتر نمی‌تواند بیشتر از 20 عدد باشد باشد.',
            'type.required'        => 'انتخاب *نوع* الزامی است.',
            'type.in'              => 'نوع انتخاب‌شده نامعتبر است.',
            'pricing_type.required'=> 'انتخاب *نوع محاسبه* الزامی است.',
            'pricing_type.in'      => 'نوع محاسبه نامعتبر است.',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
