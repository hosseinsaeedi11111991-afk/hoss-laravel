<?php

namespace Modules\Reservation\Http\Controllers\site;

use App\Http\Controllers\Controller;
use Hekmatinasser\Verta\Verta;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Modules\Cars\Models\Car;
use Modules\Cars\Models\CarCategory;
use Modules\Neshan\Models\NeshanLocationCity;
use Modules\Pricing\Services\PricingCalculatorService;
use Modules\Reservation\Models\Option;
use Modules\Reservation\Models\Reservation;
use Modules\User\Models\User;
use Modules\Discount\Services\DiscountService;
use Modules\Discount\Services\DiscountCalculatorService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class ReservationSiteController extends Controller
{
    public function __construct(
        private PricingCalculatorService $pricingCalculator,
        private DiscountService $discountService,
        private DiscountCalculatorService $discountCalculator
    ) {
    }

    public function index(?Reservation $reservation = null): View
    {
        $options = Option::all();
        $carCategories = CarCategory::all();

        $priceQuote = null;

        if ($reservation && $reservation->exists) {
            $reservation->loadMissing([
                'primaryOriginLocation',
                'primaryDestinationLocation',
                'cities',
            ]);

            $distanceKm = (float) ($reservation->distance_km ?? 0);
            if ($distanceKm <= 0) {
                $distanceKm = (float) $reservation->cities->sum('distance_km');
            }

            $originTexts = $this->collectLocationTexts(
                $reservation->primaryOriginLocation,
                $reservation->origin_address
            );

            $destinationTexts = $this->collectLocationTexts(
                $reservation->primaryDestinationLocation,
                $reservation->destination_address
            );

            $routeCities = $reservation->cities->map(function ($city) {
                return [
                    'name' => $city->city_name,
                    'distance_km' => (float) $city->distance_km,
                ];
            })->filter(function ($city) {
                return !empty($city['name']);
            })->values()->all();

            $priceQuote = $this->pricingCalculator->calculateInitialPrice($distanceKm, [
                'origin_texts' => $originTexts,
                'destination_texts' => $destinationTexts,
                'route_cities' => $routeCities,
            ]);

            // اضافه کردن اطلاعات is_city_to_city به priceQuote برای استفاده در view
            if ($priceQuote && !isset($priceQuote['meta']['is_city_to_city'])) {
                $isCityToCity = $this->pricingCalculator->isCityToCityTrip($originTexts, $destinationTexts);
                if (!isset($priceQuote['meta'])) {
                    $priceQuote['meta'] = [];
                }
                $priceQuote['meta']['is_city_to_city'] = $isCityToCity;
            }
        }

        // خواندن شماره از session
        $phoneFromSession = session('reservation_phone');

        // پاک کردن شماره از session بعد از استفاده
        if ($phoneFromSession) {
            session()->forget('reservation_phone');
        }

        return view('reservation::site.reservation', [
            'reservation' => $reservation,
            'carCategories' => $carCategories,
            'options' => $options,
            'priceQuote' => $priceQuote,
            'phoneFromSession' => $phoneFromSession,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|min:2',
            'phone' => 'required|string|min:8',
            'date' => 'required|date',
            'passengers' => 'required|string',
            'car_name' => 'required|string',
            'car_price' => 'required|numeric',
            'round_trip' => 'nullable|boolean',
            'pet' => 'nullable|boolean',
            'child_seat' => 'nullable|boolean',
        ]);

        // TODO: Persist reservation in DB. For now, just flash success.
        return back()->with('success', 'رزرو شما با موفقیت ثبت شد.');
    }

    public function prepare(Request $request)
    {
        // Store arbitrary calculation data in session for the next page load
        $data = $request->all();
        session(['reservation_context' => $data]);

        // If already created by previous flow, try to extract id from payload
        $reservationId = $data['reservation_id'] ?? null;
        return response()->json(['reservation_id' => $reservationId]);
    }

    public function getPriceQuote(Request $request)
    {
        $validated = $request->validate([
            'reservation_id' => ['required', 'integer', 'exists:reservations,id'],
            'car_category_id' => ['nullable', 'integer', 'exists:car_categories,id'],
        ]);

        $reservation = Reservation::with([
            'primaryOriginLocation',
            'primaryDestinationLocation',
            'cities',
        ])->findOrFail($validated['reservation_id']);

        $distanceKm = (float) ($reservation->distance_km ?? 0);
        if ($distanceKm <= 0) {
            $distanceKm = (float) $reservation->cities->sum('distance_km');
        }

        $originTexts = $this->collectLocationTexts(
            $reservation->primaryOriginLocation,
            $reservation->origin_address
        );

        $destinationTexts = $this->collectLocationTexts(
            $reservation->primaryDestinationLocation,
            $reservation->destination_address
        );

        $routeCities = $reservation->cities->map(function ($city) {
            return [
                'name' => $city->city_name,
                'distance_km' => (float) $city->distance_km,
            ];
        })->filter(function ($city) {
            return !empty($city['name']);
        })->values()->all();

        $priceQuote = $this->pricingCalculator->calculateInitialPrice($distanceKm, [
            'origin_texts' => $originTexts,
            'destination_texts' => $destinationTexts,
            'route_cities' => $routeCities,
            'car_category_id' => $validated['car_category_id'] ?? null,
        ]);

        // اضافه کردن اطلاعات is_city_to_city به priceQuote
        if ($priceQuote && !isset($priceQuote['meta']['is_city_to_city'])) {
            $isCityToCity = $this->pricingCalculator->isCityToCityTrip($originTexts, $destinationTexts);
            if (!isset($priceQuote['meta'])) {
                $priceQuote['meta'] = [];
            }
            $priceQuote['meta']['is_city_to_city'] = $isCityToCity;
        }

        return response()->json([
            'success' => true,
            'price_quote' => $priceQuote,
        ]);
    }

    public function previewSelection(Request $request)
    {
        $validated = $this->validatePreviewPayload($request);
        if (empty($validated['reservation_id'])) {
            throw ValidationException::withMessages([
                'reservation_id' => 'شناسه رزرو برای به‌روزرسانی الزامی است.',
            ]);
        }

        DB::beginTransaction();

        try {
            $reservation = Reservation::with([
                'user',
                'primaryOriginLocation',
                'primaryDestinationLocation',
                'cities',
            ])->findOrFail($validated['reservation_id']);

            $user = $this->upsertUser($validated['passenger'] ?? null, $reservation->user ?? null);

            $reservation = $this->updateReservation($reservation, $validated, $user);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'رزرو با موفقیت انجام شد همکاران ما در اسرع وقت با شما تماس خواهند گرفت.',
                'reservation_id' => 1,
                'user_id' => 1,
                'total_price' => 1,
            ], 200);
        } catch (\Throwable $throwable) {
            DB::rollBack();

            report($throwable);

            throw ValidationException::withMessages([
                'general' => 'خطا در ذخیره‌سازی اطلاعات. لطفاً دوباره تلاش کنید.',
            ]);
        }
    }

    private function collectLocationTexts($location, ?string $fallbackAddress = null): array
    {
        $texts = [];

        if ($location && !empty($location->address_text)) {
            $texts[] = $location->address_text;
        }

        if (!empty($fallbackAddress)) {
            $texts[] = $fallbackAddress;
        }

        $texts = array_map('trim', $texts);
        $texts = array_filter($texts, static fn($text) => $text !== '');

        return array_values(array_unique($texts));
    }

    private function validatePreviewPayload(Request $request): array
    {

        $validated = $request->validate([
            'reservation_id' => ['required', 'integer', 'exists:reservations,id'],
            'base_trip_distance' => ['nullable', 'numeric', 'min:0'],
            'base_trip_price' => ['nullable', 'numeric', 'min:0'],
            'selected_car_category' => ['required', 'array'],
            'selected_car_category.id' => ['required', 'integer', 'exists:car_categories,id'],
            'toggles' => ['nullable', 'array'],
            'toggles.round_trip' => ['nullable', 'boolean'],
            'toggles.pet' => ['nullable', 'boolean'],
            'toggles.child_seat' => ['nullable', 'boolean'],
            'options' => ['nullable', 'array'],
            'options.*.id' => ['required', 'integer', 'exists:options,id'],
            'passenger' => ['nullable', 'array'],
            'passenger.name' => ['required', 'string', 'max:255'],
            'passenger.phone' => ['nullable', 'regex:/^09\d{9}$/'],
            'passenger.passengers_count' => ['nullable', 'integer', 'min:1', 'max:20'],
            'selected_date' => ['nullable', 'string', 'max:255'],
            'selected_date_timestamp' => ['nullable', 'numeric'],
            'selected_time' => ['nullable', 'date_format:H:i'],
            'second_phone' => ['nullable', 'string', 'max:20', 'regex:/^09\d{9}$/'],
            'needs_invoice' => ['nullable', 'boolean'],
            'description' => ['nullable', 'string', 'max:1000'],
            'is_negotiable' => ['nullable', 'boolean'],
            'final_price' => ['nullable', 'numeric', 'min:0'],
            'price_source' => ['nullable', 'string', 'max:50'],
        ], [
            'reservation_id.required' => 'شناسه رزرو را ارسال کنید.',
            'reservation_id.integer' => 'شناسه رزرو عددی معتبر نیست.',
            'reservation_id.exists' => 'رزرو موردنظر یافت نشد.',
            'base_trip_distance.numeric' => 'مسافت باید یک عدد باشد.',
            'base_trip_distance.min' => 'مسافت نمی‌تواند منفی باشد.',
            'base_trip_price.numeric' => 'قیمت پایه باید عددی باشد.',
            'base_trip_price.min' => 'قیمت پایه نمی‌تواند منفی باشد.',
            'selected_car_category.required' => 'اطلاعات دسته‌بندی انتخابی ارسال نشده است.',
            'selected_car_category.array' => 'ساختار اطلاعات دسته‌بندی نادرست است.',
            'selected_car_category.id.required' => 'شناسه دسته‌بندی الزامی است.',
            'selected_car_category.id.integer' => 'شناسه دسته‌بندی باید عدد باشد.',
            'selected_car_category.id.exists' => 'دسته‌بندی انتخابی موجود نیست.',
            'options.array' => 'ساختار گزینه‌ها نادرست است.',
            'options.*.id.required' => 'شناسه گزینه الزامی است.',
            'options.*.id.integer' => 'شناسه گزینه باید عدد باشد.',
            'options.*.id.exists' => 'گزینه انتخابی موجود نیست.',
            'passenger.array' => 'ساختار اطلاعات مسافر نادرست است.',
            'passenger.name.required' => 'نام مسافر را وارد کنید.',
            'passenger.name.string' => 'نام مسافر باید متن باشد.',
            'passenger.name.max' => 'نام مسافر نباید بیش از ۲۵۵ کاراکتر باشد.',
            'passenger.phone.regex' => 'شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود.',
            'passenger.passengers_count.integer' => 'تعداد مسافران باید عدد صحیح باشد.',
            'passenger.passengers_count.min' => 'حداقل تعداد مسافر ۱ نفر است.',
            'passenger.passengers_count.max' => 'حداکثر تعداد مسافر ۲۰ نفر است.',
            'selected_date.string' => 'تاریخ ارسال شده معتبر نیست.',
            'selected_date.max' => 'طول مقدار تاریخ بیش از حد مجاز است.',
            'selected_date_timestamp.numeric' => 'مقدار timestamp معتبر نیست.',
            'selected_time.date_format' => 'زمان ارسال شده معتبر نیست.',
            'second_phone.string' => 'شماره دوم باید متن باشد.',
            'second_phone.max' => 'شماره دوم نباید بیش از ۲۰ کاراکتر باشد.',
            'second_phone.regex' => 'شماره دوم باید با فرمت 09XXXXXXXXX وارد شود.',
            'needs_invoice.boolean' => 'مقدار نیاز به فاکتور باید true یا false باشد.',
            'description.string' => 'توضیحات باید متن باشد.',
            'description.max' => 'توضیحات نباید بیش از ۱۰۰۰ کاراکتر باشد.',
            'is_negotiable.boolean' => 'مقدار توافقی بودن قیمت باید true یا false باشد.',
            'final_price.numeric' => 'قیمت نهایی باید عدد باشد.',
            'final_price.min' => 'قیمت نهایی نمی‌تواند منفی باشد.',
        ]);

        $validated['toggles'] = $validated['toggles'] ?? [];
        $validated['options'] = $validated['options'] ?? [];

        return $validated;
    }

    private function upsertUser(?array $passenger, ?User $currentUser = null): ?User
    {
        if (!$passenger) {
            return $currentUser;
        }

        $mobile = $passenger['phone'] ?? null;
        $fullName = $passenger['name'] ?? null;

        if (!$mobile) {
            if ($currentUser) {
                $this->updateUserName($currentUser, $fullName);
                return $currentUser;
            }

            return null;
        }

        $user = User::where('mobile', $mobile)->first();

        if (!$user) {
            [$firstName, $lastName] = $this->splitName($fullName);

            $user = User::create([
                'uuid' => (string) Str::uuid(),
                'username' => $firstName.' '.$lastName,
                'mobile' => $mobile,
                'first_name' => $firstName ?? 'کاربر',
                'last_name' => $lastName ?? '',
                'password' => Hash::make(Str::random(12)),
            ]);

            if (method_exists($user, 'assignRole')) {
                try {
                    if (!$user->hasRole('user')) {
                        $user->assignRole('user');
                    }
                } catch (\Throwable $e) {
                    report($e);
                }
            }
        } else {
            $this->updateUserName($user, $fullName);
        }

        return $user;
    }

    private function updateReservation(Reservation $reservation, array $payload, ?User $user): Reservation
    {
        // دریافت دسته‌بندی انتخاب شده
        $categoryId = $payload['selected_car_category']['id'];
        $category = CarCategory::findOrFail($categoryId);

        // انتخاب اولین خودروی موجود از دسته‌بندی برای استفاده در محاسبات (اختیاری)
        $car = Car::where('car_category_id', $categoryId)
            ->where('status', 'available')
            ->first();

        $distance = isset($payload['base_trip_distance'])
            ? (float) $payload['base_trip_distance']
            : 0.0;

        if ($distance <= 0) {
            $distance = (float) $reservation->distance_km;
        }

        if ($distance <= 0) {
            $distanceFromCities = (float) $reservation->cities()->sum('distance_km');
            if ($distanceFromCities > 0) {
                $distance = $distanceFromCities;
            }
        }

        $optionIds = collect($payload['options'])
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->values();

        $options = Option::whereIn('id', $optionIds->all())->get();

        $toggles = [
            'round_trip' => (bool) ($payload['toggles']['round_trip'] ?? false),
            'pet' => (bool) ($payload['toggles']['pet'] ?? false),
            'child_seat' => (bool) ($payload['toggles']['child_seat'] ?? false),
        ];

        // اگر قیمت توافقی باشد، قیمت کل 0 است
        // در غیر این صورت، قیمت را محاسبه می‌کنیم
        $isNegotiable = (bool) ($payload['is_negotiable'] ?? false);

        if ($isNegotiable) {
            // در حالت توافقی، قیمت کل 0 است
            $totalPrice = 0.0;
        } else {
            // در حالت عادی، قیمت را محاسبه می‌کنیم
            $totalPrice = $this->calculateTotalPrice($reservation, $payload, $car, $category, $options, $distance, $toggles);
        }

        // ذخیره ID دسته‌بندی به جای ID خودرو
        $reservation->car_category_id = $categoryId;
        $reservation->car_id = null; // دیگر از car_id استفاده نمی‌کنیم

        if ($user) {
            $reservation->user_id = $user->id;
        }
        $reservation->distance_km = $distance;
        $reservation->total_price = round($totalPrice, 2);

        $submittedAt = now('Asia/Tehran');
        $selectedTime = !empty($payload['selected_time'])
            ? trim($payload['selected_time'])
            : $submittedAt->format('H:i');

        if (!empty($payload['selected_date'])) {
            $dateTime = Verta::parse($payload['selected_date'])->datetime();
            $reservation->date = Carbon::instance($dateTime)
                ->setTimeFromTimeString($selectedTime)
                ->format('Y-m-d H:i:s');
        } else {
            $reservation->date = $submittedAt->format('Y-m-d H:i:s');
        }
        $reservation->time = $selectedTime;

        // ذخیره فیلدهای جدید (شماره تماس مسافر برای SMS به مدیر)
        $reservation->phone = $payload['passenger']['phone'] ?? $reservation->phone;
        $reservation->second_phone = $payload['second_phone'] ?? null;
        $reservation->needs_invoice = (bool) ($payload['needs_invoice'] ?? false);
        $reservation->description = $payload['description'] ?? null;
        $reservation->is_negotiable = (bool) ($payload['is_negotiable'] ?? false);

        // ذخیره تعداد مسافران
        $passengerCount = isset($payload['passenger']['passengers_count'])
            ? (int) $payload['passenger']['passengers_count']
            : 1;
        $reservation->passengers_count = max(1, min(99, $passengerCount)); // محدود کردن بین 1 تا 99

        $reservation->status = Reservation::STATUS_COMPLETED;

        // ذخیره رزرو برای دریافت ID
        $reservation->save();

        // اعمال تخفیف‌های خودکار (بعد از save برای داشتن ID)
        if (!$isNegotiable && $reservation->total_price > 0) {
            // بارگذاری relations مورد نیاز
            $reservation->loadMissing(['cities', 'primaryOriginLocation', 'primaryDestinationLocation']);

            $applicableDiscounts = $this->discountService->findApplicableAutomaticDiscounts($reservation);

            if ($applicableDiscounts->isNotEmpty()) {
                $bestDiscount = $this->discountCalculator->selectBestDiscount($applicableDiscounts, $reservation->total_price);

                if ($bestDiscount) {
                    $discountAmount = $this->discountCalculator->calculate($bestDiscount, $reservation->total_price);
                    $this->discountService->applyToReservation($bestDiscount, $reservation, $discountAmount);
                    // total_price در applyToReservation به‌روزرسانی می‌شود
                }
            }

            // بررسی کد تخفیف ارسال شده
            if (!empty($payload['discount_code'])) {
                $codeDiscount = $this->discountService->validateCode($payload['discount_code'], $reservation);

                if ($codeDiscount) {
                    $discountAmount = $this->discountCalculator->calculate($codeDiscount, $reservation->total_price);
                    $this->discountService->applyToReservation($codeDiscount, $reservation, $discountAmount);
                }
            }
        }

        if ($optionIds->isNotEmpty()) {
            $reservation->options()->sync($optionIds->all());
        } else {
            $reservation->options()->detach();
        }

        return $reservation->fresh(['options']);
    }

    private function calculateTotalPrice(Reservation $reservation, array $payload, ?Car $car, CarCategory $category, Collection $options, float $distance, array $toggles): float
    {
        $reservation->loadMissing(['primaryOriginLocation', 'primaryDestinationLocation', 'cities']);

        $context = $payload['pricing_context'] ?? [];

        $originTexts = $context['origin_texts'] ?? $this->collectLocationTexts(
            $reservation->primaryOriginLocation,
            $reservation->origin_address
        );

        $destinationTexts = $context['destination_texts'] ?? $this->collectLocationTexts(
            $reservation->primaryDestinationLocation,
            $reservation->destination_address
        );

        $routeCities = $context['route_cities'] ?? $reservation->cities
            ->map(fn (NeshanLocationCity $city) => [
                'name' => $city->city_name,
                'distance_km' => (float) $city->distance_km,
            ])
            ->filter(fn ($city) => !empty($city['name']))
            ->values()
            ->all();

        // 1. محاسبه قیمت اولیه (baseTripPrice)
        // ارسال car_category_id برای فیلتر کردن pricing rules و city pricings
        $pricingResult = $this->pricingCalculator->calculateInitialPrice($distance, [
            'origin_texts' => $originTexts,
            'destination_texts' => $destinationTexts,
            'route_cities' => $routeCities,
            'car_category_id' => $category->id,
        ]);

        $baseTripPrice = (float) ($pricingResult['amount'] ?? 0.0);

        // 2. محاسبه قیمت دسته‌بندی بر اساس نوع قیمت‌گذاری
        $categoryPart = 0;
        $isNegotiable = $category->price_type === CarCategory::PRICE_TYPE_NEGOTIABLE;

        // تشخیص سفر شهر به شهر:
        // بررسی می‌کنیم که آیا هم مبدا و هم مقصد در city_pricings هستند
        $isCityToCity = false;

        // اول از meta نتیجه calculateInitialPrice بررسی می‌کنیم
        if (isset($pricingResult['meta']['is_city_to_city'])) {
            $isCityToCity = (bool) $pricingResult['meta']['is_city_to_city'];
        } else {
            // اگر در meta نبود، از pricingCalculator بررسی می‌کنیم
            $isCityToCity = $this->pricingCalculator->isCityToCityTrip($originTexts, $destinationTexts);
        }

        // بررسی اینکه آیا pricing rule یا city_pricing شامل قیمت دسته‌بندی است یا نه
        // اگر rule یا city_pricing با car_category_id خاص پیدا شده باشد، قیمت دسته‌بندی در آن گنجانده شده است
        $hasCarCategoryInPricing = isset($pricingResult['meta']['has_car_category']) &&
            (bool) $pricingResult['meta']['has_car_category'] &&
            isset($pricingResult['meta']['car_category_id']) &&
            $pricingResult['meta']['car_category_id'] == $category->id;

        // اگر سفر شهر به شهر است یا pricing شامل قیمت دسته‌بندی است، قیمت دسته‌بندی اضافه نمی‌شود
        if (!$isNegotiable && !$isCityToCity && !$hasCarCategoryInPricing) {
            if ($category->price_type === CarCategory::PRICE_TYPE_PER_KM) {
                // قیمت به ازای کیلومتر: در فاصله ضرب می‌شود
                $categoryPart = ((float) $category->price_per_km) * $distance;
            } elseif ($category->price_type === CarCategory::PRICE_TYPE_FIXED) {
                // قیمت ثابت
                $categoryPart = (float) $category->fixed_price;
            }

            // اگر سفر رفت و برگشت باشد
            if (!empty($toggles['round_trip']) && $toggles['round_trip']) {
                if ($category->price_type === CarCategory::PRICE_TYPE_PER_KM) {
                    $categoryPart += ((float) $category->price_per_km) * $distance;
                } elseif ($category->price_type === CarCategory::PRICE_TYPE_FIXED) {
                    $categoryPart += (float) $category->fixed_price;
                }
            }
        }

        // 3. محاسبه قیمت پایه (قیمت اولیه + دسته‌بندی) برای محاسبه درصدی
        $basePrice = $baseTripPrice + $categoryPart;

        // 4. جدا کردن گزینه‌ها بر اساس نوع قیمت‌گذاری
        $fixedOptionPart = 0; // گزینه‌های ثابت
        $perKmOptionPart = 0; // گزینه‌های به ازای کیلومتر
        $percentageOptionPart = 0; // گزینه‌های درصدی

        foreach ($options as $option) {
            if ($option->pricing_type === Option::PRICING_TYPE_PER_KM) {
                // قیمت به ازای کیلومتر: در کیلومتر ضرب می‌شود و با بقیه جمع می‌شود
                $perKmOptionPart += ((float) $option->per_km_price) * $distance;
            } elseif ($option->pricing_type === Option::PRICING_TYPE_PERCENTAGE) {
                // قیمت درصدی: در کل قیمت (قیمت پایه + دسته‌بندی) ضرب می‌شود
                $percentageOptionPart += ($basePrice * (float) $option->percentage_price) / 100;
            } else {
                // قیمت ثابت: با بقیه جمع می‌شود
                $fixedOptionPart += (float) $option->fixed_price;
            }
        }

        // 5. گزینه‌های ساده (pet, childSeat) به عنوان ثابت محاسبه می‌شوند
        if (!empty($toggles['pet']) && $toggles['pet']) {
            $fixedOptionPart += 100000;
        }
        if (!empty($toggles['child_seat']) && $toggles['child_seat']) {
            $fixedOptionPart += 50000;
        }

        // 6. محاسبه افزایش قیمت برای 4 نفر (20 درصد)
        $passengerCount = isset($payload['passenger']['passengers_count']) ? (int) $payload['passenger']['passengers_count'] : 1;
        $passengerSurcharge = 0;

        if ($passengerCount === 4) {
            // اگر 4 نفر باشد، 20 درصد به قیمت پایه اضافه می‌شود
            $priceBeforePassengerSurcharge = $basePrice + $fixedOptionPart + $perKmOptionPart + $percentageOptionPart;
            $passengerSurcharge = ($priceBeforePassengerSurcharge * 20) / 100;
        }

        // 7. محاسبه قیمت نهایی
        $total = $basePrice + $fixedOptionPart + $perKmOptionPart + $percentageOptionPart + $passengerSurcharge;

        return max(0, round($total, 2));
    }

    private function splitName(?string $name): array
    {
        $name = trim((string) $name);

        if ($name === '') {
            return [null, null];
        }

        $parts = preg_split('/\s+/', $name) ?: [];
        $firstName = array_shift($parts) ?: null;
        $lastName = empty($parts) ? null : implode(' ', $parts);

        return [$firstName, $lastName];
    }

    private function updateUserName(User $user, ?string $fullName): void
    {
        if (!$fullName) {
            return;
        }

        [$firstName, $lastName] = $this->splitName($fullName);

        $dirty = false;

        if ($firstName && $user->first_name !== $firstName) {
            $user->first_name = $firstName;
            $dirty = true;
        }

        if ($lastName !== null && $user->last_name !== $lastName) {
            $user->last_name = $lastName;
            $dirty = true;
        }

        if ($dirty) {
            $user->save();
        }
    }
}
