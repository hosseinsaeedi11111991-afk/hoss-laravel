<?php

namespace Modules\Reservation\Http\Controllers\site;

use App\Http\Controllers\Controller;
use App\Services\SmsSettingsService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Modules\Neshan\Services\NeshanService;
use Modules\Reservation\Models\PopularRoute;
use Modules\Reservation\Models\Reservation;
use Modules\User\Models\User;

class PopularRouteSiteController extends Controller
{
    private string $apiKey = 'service.983e1c873c3d4de1b3d989b52355bec9';

    public function __construct(
        private NeshanService $neshanService
    ) {
    }

    public function start(Request $request, PopularRoute $popularRoute): RedirectResponse
    {
        $requireEarlyPhone = app(SmsSettingsService::class)->requirePhoneBeforeRouteCalculation();
        $phoneRule = $requireEarlyPhone
            ? ['required', 'string', 'regex:/^09\d{9}$/']
            : ['nullable', 'string', 'regex:/^09\d{9}$/'];

        $request->validate([
            'phone' => $phoneRule,
        ], [
            'phone.required' => 'شماره موبایل الزامی است',
            'phone.regex' => 'شماره موبایل باید با فرمت 09XXXXXXXXX وارد شود',
        ]);

        $phone = $request->filled('phone') ? trim((string) $request->input('phone')) : null;

        $origin = (string) $popularRoute->origin_lat . ',' . (string) $popularRoute->origin_lng;
        $destination = (string) $popularRoute->destination_lat . ',' . (string) $popularRoute->destination_lng;

        try {
            $url = 'https://api.neshan.org/v4/direction/no-traffic';
            $response = Http::timeout(15)->withHeaders([
                'Api-Key' => $this->apiKey,
            ])->get($url, [
                'type' => 'car',
                'origin' => $origin,
                'destination' => $destination,
            ]);

            if ($response->failed()) {
                return redirect()->route('site.reservation.index')
                    ->with('error', 'خطا در دریافت اطلاعات مسیر از API نشان. لطفاً دوباره تلاش کنید.');
            }

            $result = $response->json();
            $distanceMeters = $result['routes'][0]['legs'][0]['distance']['value'] ?? null;
            $distanceKm = $distanceMeters ? $distanceMeters / 1000 : 0;
            $durationSeconds = $result['routes'][0]['legs'][0]['duration']['value'] ?? null;
            $durationMin = $durationSeconds ? $durationSeconds / 60 : 0;

            $hours = (int) floor($durationMin / 60);
            $minutes = (int) round($durationMin % 60);
            $time = sprintf('%02d:%02d', $hours, $minutes);

            $routeArray = [
                'success' => true,
                'origin_lat' => (float) $popularRoute->origin_lat,
                'origin_lng' => (float) $popularRoute->origin_lng,
                'destination_lat' => (float) $popularRoute->destination_lat,
                'destination_lng' => (float) $popularRoute->destination_lng,
                'origin_index' => 0,
                'destination_index' => 0,
                'distanceKm' => $distanceKm,
                'durationMin' => $durationMin,
            ];
        } catch (\Throwable $e) {
            \Log::warning('Popular route start: Neshan API failed, using stored data', [
                'popular_route_id' => $popularRoute->id,
                'error' => $e->getMessage(),
            ]);
            $distanceKm = 0;
            $time = '00:00';
            $routeArray = [
                'success' => true,
                'origin_lat' => (float) $popularRoute->origin_lat,
                'origin_lng' => (float) $popularRoute->origin_lng,
                'destination_lat' => (float) $popularRoute->destination_lat,
                'destination_lng' => (float) $popularRoute->destination_lng,
                'origin_index' => 0,
                'destination_index' => 0,
                'distanceKm' => $distanceKm,
                'durationMin' => 0,
            ];
        }

        DB::beginTransaction();
        try {
            $userId = auth()->id();
            if (!$userId && $phone) {
                $user = User::where('mobile', $phone)->first();
                if ($user) {
                    $userId = $user->id;
                }
            }

            $reservation = Reservation::withoutEvents(fn () => Reservation::create([
                'user_id' => $userId,
                'date' => null,
                'phone' => $phone,
                'distance_km' => $routeArray['distanceKm'],
                'status' => Reservation::STATUS_PENDING,
                'origin_address' => $popularRoute->origin_address,
                'destination_address' => $popularRoute->destination_address,
                'origin' => (string) $popularRoute->origin_lat . ',' . (string) $popularRoute->origin_lng,
                'destination' => (string) $popularRoute->destination_lat . ',' . (string) $popularRoute->destination_lng,
                'time' => $time,
            ]));

            $this->neshanService->saveLocationsForReservation($reservation, [$routeArray]);

            if ($phone) {
                session(['reservation_phone' => $phone]);
            }

            DB::commit();

            return redirect()->route('site.reservation.index', ['reservation' => $reservation->id]);
        } catch (\Throwable $e) {
            DB::rollBack();
            \Log::error('Popular route start: reservation create failed', [
                'error' => $e->getMessage(),
                'popular_route_id' => $popularRoute->id,
            ]);
            return redirect()->route('site.reservation.index')
                ->with('error', 'ذخیره رزرو با خطا مواجه شد. لطفاً دوباره تلاش کنید.');
        }
    }
}
