<?php

namespace Modules\Reservation\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Hekmatinasser\Verta\Verta;
use Modules\Reservation\Models\Reservation;
use Modules\Reservation\Models\Option;
use Modules\Reservation\Http\Requests\Admin\StoreReservationRequest;
use Modules\Reservation\Http\Requests\Admin\UpdateReservationRequest;
use Modules\Cars\Models\Car;
use Modules\Cars\Models\CarCategory;
use Modules\User\Models\User;
use Modules\Neshan\Models\NeshanLocation;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReservationController extends Controller
{
    public function index(Request $request)
    {
        $query = Reservation::with(['car', 'carCategory', 'user']);

        $this->applyFilters($query, $request);

        $reservations = $query->latest()->paginate(15)->withQueryString();
        return view('reservation::admin.reservations.index', compact('reservations'));
    }

    public function bulkDestroy(Request $request)
    {
        $data = $request->validate([
            'reservation_ids' => ['required', 'array', 'min:1'],
            'reservation_ids.*' => ['integer', 'exists:reservations,id'],
        ], [
            'reservation_ids.required' => 'لطفا حداقل یک رزرو را انتخاب کنید.',
            'reservation_ids.min' => 'لطفا حداقل یک رزرو را انتخاب کنید.',
        ]);

        Reservation::whereIn('id', $data['reservation_ids'])->delete();

        return redirect()
            ->route('admin.reservations.index')
            ->with('success', count($data['reservation_ids']) . ' رزرو حذف شد.');
    }

    public function export(Request $request): StreamedResponse
    {
        $query = Reservation::with(['car', 'carCategory', 'user']);
        $this->applyFilters($query, $request);

        $filename = 'reservations-' . now()->format('Y-m-d-His') . '.csv';

        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        return response()->streamDownload(function () use ($query) {
            $output = fopen('php://output', 'w');
            fwrite($output, "\xEF\xBB\xBF");

            fputcsv($output, [
                'ردیف',
                'کاربر',
                'شماره تماس',
                'شماره دوم',
                'دسته‌بندی',
                'خودرو',
                'تعداد مسافران',
                'مبدا',
                'مقصد',
                'تاریخ',
                'زمان',
                'مسافت km',
                'مبلغ کل',
                'فاکتور',
                'قیمت توافقی',
                'وضعیت',
            ]);

            $rowNumber = 1;
            $query->latest()->chunk(200, function ($reservations) use ($output, &$rowNumber) {
                foreach ($reservations as $reservation) {
                    fputcsv($output, [
                        $rowNumber++,
                        $reservation->user->username ?? '-',
                        $this->csvTextCell($reservation->phone ?? $reservation->user->mobile ?? '-'),
                        $this->csvTextCell($reservation->second_phone ?? '-'),
                        $reservation->carCategory->title ?? '-',
                        $reservation->car->title ?? '-',
                        $reservation->passengers_count ?? 1,
                        $reservation->origin_address ?: $reservation->origin ?: '-',
                        $reservation->destination_address ?: $reservation->destination ?: '-',
                        $reservation->date ? verta($reservation->date)->format('Y/m/d') : '-',
                        $reservation->time ?: ($reservation->date ? verta($reservation->date)->format('H:i') : '-'),
                        number_format((float) $reservation->distance_km, 2, '.', ''),
                        number_format((float) $reservation->total_price, 0, '.', ''),
                        $reservation->needs_invoice ? 'بله' : 'خیر',
                        $reservation->is_negotiable ? 'بله' : 'خیر',
                        $reservation->status_label,
                    ]);
                }
            });

            fclose($output);
        }, $filename, $headers);
    }

    private function csvTextCell($value): string
    {
        $value = trim((string) $value);

        if ($value === '' || $value === '-') {
            return '-';
        }

        $escaped = str_replace('"', '""', $value);

        return '="' . $escaped . '"';
    }

    private function applyFilters($query, Request $request): void
    {
        // فیلتر بر اساس نام کاربر
        if ($request->filled('username')) {
            $username = $request->username;
            $mojibakeUsername = $this->toMojibake($username);

            $query->whereHas('user', function($q) use ($username, $mojibakeUsername) {
                $q->where('username', 'like', '%' . $username . '%');

                if ($mojibakeUsername !== $username) {
                    $q->orWhere('username', 'like', '%' . $mojibakeUsername . '%');
                }
            });
        }

        // فیلتر بر اساس شماره تماس (از فیلد phone یا user->mobile)
        if ($request->filled('phone')) {
            $phone = $request->phone;
            $query->where(function($q) use ($phone) {
                $q->where('phone', 'like', '%' . $phone . '%')
                  ->orWhereHas('user', function($userQuery) use ($phone) {
                      $userQuery->where('mobile', 'like', '%' . $phone . '%');
                  });
            });
        }

        // فیلتر بر اساس مبدا
        if ($request->filled('origin_address')) {
            $query->where('origin_address', 'like', '%' . $request->origin_address . '%');
        }

        // فیلتر بر اساس مقصد
        if ($request->filled('destination_address')) {
            $query->where('destination_address', 'like', '%' . $request->destination_address . '%');
        }

        // فیلتر بر اساس وضعیت
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // فیلتر بر اساس تاریخ از (تبدیل تاریخ شمسی به میلادی)
        if ($request->filled('date_from')) {
            try {
                $persianDate = $request->date_from;
                $gregorianDate = Verta::parse($persianDate)->datetime()->format('Y-m-d');
                $query->whereDate('date', '>=', $gregorianDate);
            } catch (\Exception $e) {
                // در صورت خطا در تبدیل تاریخ، از تاریخ اصلی استفاده می‌کنیم
                $query->whereDate('date', '>=', $request->date_from);
            }
        }

        // فیلتر بر اساس تاریخ تا (تبدیل تاریخ شمسی به میلادی)
        if ($request->filled('date_to')) {
            try {
                $persianDate = $request->date_to;
                $gregorianDate = Verta::parse($persianDate)->datetime()->format('Y-m-d');
                $query->whereDate('date', '<=', $gregorianDate);
            } catch (\Exception $e) {
                // در صورت خطا در تبدیل تاریخ، از تاریخ اصلی استفاده می‌کنیم
                $query->whereDate('date', '<=', $request->date_to);
            }
        }
    }

    public function create()
    {
        $cars  = Car::pluck('title', 'id');
        $carCategories = CarCategory::pluck('title', 'id');
        $users = User::query()
            ->get(['id', 'username'])
            ->mapWithKeys(fn (User $user) => [$user->id => $user->username]);
        $options = Option::all(['id', 'name', 'type', 'fixed_price', 'per_km_price']);

        return view('reservation::admin.reservations.create',
            compact('cars', 'carCategories', 'users', 'options'));
    }

    public function store(StoreReservationRequest $request)
    {
        $data = $request->validated();
        // calculate simple total
        $data['total_price'] = $data['distance_km'] * 1000; // example base price

        $reservation = Reservation::create($data);

        // attach options if sent
        if ($request->filled('options')) {
            $reservation->options()->attach($request->input('options'));
        }

        return redirect()->route('admin.reservations.index')
            ->with('success', 'رزرو با موفقیت ثبت شد.');
    }

    public function show(Reservation $reservation)
    {
        $reservation->load(['car', 'carCategory', 'user', 'options']);

        $locations = NeshanLocation::with(['cities'])
            ->where('reservation_id', $reservation->id)
            ->orderByDesc('is_primary')
            ->orderBy('type')
            ->get();

        return view('reservation::admin.reservations.show', compact('reservation', 'locations'));
    }

    public function edit(Reservation $reservation)
    {
        $cars   = Car::pluck('title', 'id');
        $carCategories = CarCategory::pluck('title', 'id');
        $users  = User::pluck('first_name', 'id');
        $options = Option::all(['id', 'name', 'type', 'fixed_price', 'per_km_price']);

        $reservation->load('options');
        return view('reservation::admin.reservations.edit',
            compact('reservation', 'cars', 'carCategories', 'users', 'options'));
    }

    public function update(UpdateReservationRequest $request, Reservation $reservation)
    {
        $data = $request->validated();
        $data['total_price'] = $data['distance_km'] * 1000; // same example

        $reservation->update($data);

        // sync options
        $reservation->options()->sync($request->input('options', []));

        return redirect()->route('admin.reservations.index')
            ->with('success', 'رزرو به‌روزرسانی شد.');
    }

    public function destroy(Reservation $reservation)
    {
        $reservation->delete();
        return redirect()->route('admin.reservations.index')
            ->with('success', 'رزرو حذف شد.');
    }



    public function updateStatus(Request $request, Reservation $reservation)
    {
        $request->validate(['status' => 'required|in:pending,confirmed,canceled,completed']);

        $reservation->update(['status' => $request->status]);

        return response()->json(['success' => true]);
    }

    public function neshan(Reservation $reservation)
    {
        $locations = NeshanLocation::with(['cities'])
            ->where('reservation_id', $reservation->id)
            ->orderByDesc('is_primary')
            ->orderBy('type')
            ->get();

        return view('reservation::admin.reservations.neshan', compact('reservation', 'locations'));
    }





    private function toMojibake(string $value): string
    {
        return mb_convert_encoding($value, 'UTF-8', 'Windows-1252');
    }
}
