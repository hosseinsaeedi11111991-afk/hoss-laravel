<?php

namespace Modules\Reservation\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Modules\Reservation\Models\PopularRoute;
use Modules\Reservation\Http\Requests\Admin\StorePopularRouteRequest;
use Modules\Reservation\Http\Requests\Admin\UpdatePopularRouteRequest;

class PopularRouteController extends Controller
{
    public function index()
    {
        $popularRoutes = PopularRoute::paginate(15);
        return view('reservation::admin.popular-routes.index', compact('popularRoutes'));
    }

    public function create()
    {
        return view('reservation::admin.popular-routes.create');
    }

    public function store(StorePopularRouteRequest $request)
    {
        $data = $request->validated();
        $data['is_active'] = $request->boolean('is_active', true);
        $data['sort_order'] = $request->input('sort_order', 0);

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('popular-routes', 'public');
        }

        PopularRoute::create($data);
        return redirect()->route('admin.popular-routes.index')
            ->with('success', 'مسیر پرطرفدار با موفقیت ثبت شد.');
    }

    public function edit(PopularRoute $popularRoute)
    {
        return view('reservation::admin.popular-routes.edit', compact('popularRoute'));
    }

    public function update(UpdatePopularRouteRequest $request, PopularRoute $popularRoute)
    {
        $data = $request->validated();
        $data['is_active'] = $request->boolean('is_active', $popularRoute->is_active);
        if ($request->has('sort_order')) {
            $data['sort_order'] = $request->input('sort_order', 0);
        }

        if ($request->hasFile('image')) {
            if ($popularRoute->image && Storage::disk('public')->exists($popularRoute->image)) {
                Storage::disk('public')->delete($popularRoute->image);
            }
            $data['image'] = $request->file('image')->store('popular-routes', 'public');
        }

        $popularRoute->update($data);
        return redirect()->route('admin.popular-routes.index')
            ->with('success', 'مسیر پرطرفدار به‌روزرسانی شد.');
    }

    public function destroy(PopularRoute $popularRoute)
    {
        if ($popularRoute->image && Storage::disk('public')->exists($popularRoute->image)) {
            Storage::disk('public')->delete($popularRoute->image);
        }
        $popularRoute->delete();
        return redirect()->route('admin.popular-routes.index')
            ->with('success', 'مسیر پرطرفدار حذف شد.');
    }
}
