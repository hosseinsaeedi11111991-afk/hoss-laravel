<?php

namespace Modules\Reservation\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Reservation\Models\Option;
use Modules\Reservation\Http\Requests\Admin\StoreOptionRequest;
use Modules\Reservation\Http\Requests\Admin\UpdateOptionRequest;
use Modules\Cars\Models\CarCategory;

class OptionController extends Controller
{
    public function index()
    {
        $options = Option::with('carCategory')->latest()->paginate(15);
        return view('reservation::admin.options.index', compact('options'));
    }

    public function create()
    {
        $carCategories = CarCategory::all();
        return view('reservation::admin.options.create', compact('carCategories'));
    }

    public function store(StoreOptionRequest $request)
    {
        Option::create($request->validated());
        return redirect()->route('admin.options.index')
            ->with('success', 'آپشن با موفقیت ثبت شد.');
    }

    public function show(Option $option)
    {
        $option->load('carCategory');
        return view('reservation::admin.options.show', compact('option'));
    }

    public function edit(Option $option)
    {
        $carCategories = CarCategory::all();
        return view('reservation::admin.options.edit', compact('option', 'carCategories'));
    }

    public function update(UpdateOptionRequest $request, Option $option)
    {
        $option->update($request->validated());
        return redirect()->route('admin.options.index')
            ->with('success', 'آپشن به‌روزرسانی شد.');
    }

    public function destroy(Option $option)
    {
        $option->delete();
        return redirect()->route('admin.options.index')
            ->with('success', 'آپشن حذف شد.');
    }
}
