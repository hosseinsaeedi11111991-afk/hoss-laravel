<?php

namespace Modules\Reservation\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Cars\Models\CarCategory;
// use Modules\Reservation\Database\Factories\OptionFactory;

class Option extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'car_category_id',
        'fixed_price',
        'per_km_price',
        'percentage_price',
        'type',
        'pricing_type',
    ];

    const TYPE_TEXT = 'text';
    const TYPE_CHECKBOX = 'checkbox';

    const PRICING_TYPE_FIXED = 'fixed';
    const PRICING_TYPE_PER_KM = 'per_km';
    const PRICING_TYPE_PERCENTAGE = 'percentage';

    /* Relations */
    public function carCategory()
    {
        return $this->belongsTo(CarCategory::class, 'car_category_id');
    }

    public function reservations()
    {
        return $this->belongsToMany(Reservation::class, 'reservation_options')
                    ->withPivot('value')
                    ->withTimestamps();
    }
}
