<?php

namespace Modules\Reservation\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Neshan\Models\NeshanLocation;
use Modules\Neshan\Models\NeshanLocationCity;
use Modules\Reservation\Events\ReservationCreated;
use Modules\Reservation\Events\ReservationStatusChanged;

// use Modules\Reservation\Database\Factories\ReservationFactory;

class Reservation extends Model
{
    use HasFactory;

    /**
     * The "booted" method of the model.
     */
    protected static function booted(): void
    {
        static::created(function (Reservation $reservation) {
            event(new ReservationCreated($reservation));
        });

        static::updated(function (Reservation $reservation) {
            // بررسی تغییر وضعیت
            $oldStatus = $reservation->getOriginal('status');
            $newStatus = $reservation->status;

            // اگر وضعیت تغییر کرده باشد، Event فایر می‌شود
            if ($oldStatus !== $newStatus) {
                event(new ReservationStatusChanged($reservation, $oldStatus, $newStatus));
            }
        });
    }


    protected $fillable = [
        'car_id',
        'car_category_id',
        'user_id',
        'date',
        'distance_km',
        'total_price',
        'status',
        'origin_address',
        'destination_address',
        'origin',
        'destination',
        'time',
        'phone',
        'second_phone',
        'description',
        'passengers_count',
        'needs_invoice',
        'is_negotiable',
    ];

    // -------------------------
    //  Constants for Statuses
    // -------------------------
    const STATUS_PENDING   = 'pending';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_CANCELED  = 'canceled';
    const STATUS_COMPLETED = 'completed';

    /**
     * همه وضعیت‌ها
     */
    public static function statuses(): array
    {
        return [
            self::STATUS_PENDING   => 'در انتظار تایید',
            self::STATUS_CONFIRMED => 'تایید شده',
            self::STATUS_CANCELED  => 'لغو شده',
            self::STATUS_COMPLETED => 'تکمیل شده',
        ];
    }

    /**
     * نمایش وضعیت به صورت متن فارسی
     */
    public function getStatusLabelAttribute(): string
    {
        return self::statuses()[$this->status] ?? 'نامشخص';
    }

    protected $casts = [
        'distance_km' => 'decimal:2',
        'total_price' => 'decimal:2',
        'passengers_count' => 'integer',
        'needs_invoice' => 'boolean',
        'is_negotiable' => 'boolean',
        'date' => 'datetime',
    ];

    public function car()
    {
        return $this->belongsTo(\Modules\Cars\Models\Car::class);
    }

    public function carCategory()
    {
        return $this->belongsTo(\Modules\Cars\Models\CarCategory::class, 'car_category_id');
    }

    public function user()
    {
        return $this->belongsTo(\Modules\User\Models\User::class);
    }

    public function cities()
    {
        return $this->hasMany(NeshanLocationCity::class);
    }

    public function locations()
    {
        return $this->hasMany(NeshanLocation::class);
    }
    public function locationsPrimary()
    {
        return $this->hasMany(NeshanLocation::class)->where('is_primary',true);
    }

    public function primaryOriginLocation()
    {
        return $this->hasOne(NeshanLocation::class)
            ->where('type', NeshanLocation::TYPE_ORIGIN)
            ->where('is_primary', true);
    }

    public function primaryDestinationLocation()
    {
        return $this->hasOne(NeshanLocation::class)
            ->where('type', NeshanLocation::TYPE_DESTINATION)
            ->where('is_primary', true);
    }

    public function options()
    {
        return $this->belongsToMany(Option::class, 'reservation_options')
            ->withPivot('value')
            ->withTimestamps();
    }

    public function discounts()
    {
        return $this->belongsToMany(\Modules\Discount\Models\Discount::class, 'discount_reservations')
            ->withPivot('discount_amount', 'original_price', 'final_price')
            ->withTimestamps();
    }

    public function discountUsages()
    {
        return $this->hasMany(\Modules\Discount\Models\DiscountUsage::class);
    }
}
