<?php

namespace Modules\Reservation\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Reservation\Database\Factories\ReservationOptionFactory;

class ReservationOption extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    // protected static function newFactory(): ReservationOptionFactory
    // {
    //     // return ReservationOptionFactory::new();
    // }
}
