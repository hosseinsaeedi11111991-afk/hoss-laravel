<?php

namespace Modules\Reservation\Listeners;

use Modules\Reservation\Events\ReservationCreated;
use Modules\Reservation\Events\ReservationStatusChanged;
use Modules\Notification\Services\SmsService;
use Illuminate\Support\Facades\Log;
use Modules\Reservation\Models\Reservation;
use Hekmatinasser\Verta\Verta;

class SendReservationNotificationSms
{
    protected $smsService;

    /**
     * Create the event listener.
     */
    public function __construct(SmsService $smsService)
    {
        $this->smsService = $smsService;
    }

    /**
     * Handle the event.
     */
    public function handle(ReservationCreated|ReservationStatusChanged $event): void
    {
        // دریافت رزرو از هر دو نوع Event
        $reservation = $event->reservation;

        // بررسی نوع Event و وضعیت رزرو
        if ($event instanceof ReservationStatusChanged) {
            // اگر Event از نوع تغییر وضعیت است، فقط اگر به completed تغییر کرده باشد ادامه می‌دهیم
            if ($event->newStatus !== Reservation::STATUS_COMPLETED) {
                Log::info('Reservation status changed but not to completed - SMS skipped', [
                    'reservation_id' => $reservation->id,
                    'old_status' => $event->oldStatus,
                    'new_status' => $event->newStatus
                ]);
                return;
            }
        } elseif ($event instanceof ReservationCreated) {
            // رزرو تازه‌ثبت‌شده معمولا pending است، اما باید همان لحظه برای مدیر پیامک ارسال شود.
            Log::info('Reservation notification SMS processing for created reservation', [
                'reservation_id' => $reservation->id,
                'status' => $reservation->status,
            ]);
        }

        // بارگذاری روابط مورد نیاز
        $reservation->load(['user', 'car', 'carCategory', 'primaryOriginLocation', 'primaryDestinationLocation']);

        // شماره گیرنده (مدیر) و کد پترن از config
        $recipient = config('notification.sms.reservation_admin_recipient', '09388417179');
        $patternCode = config('notification.sms.reservation_admin_pattern', 'd00wxqn35y8p6yf');

        // آماده‌سازی نام مسافر
        $passengerName = 'نامشخص';
        if ($reservation->user) {
            // اول username را بررسی می‌کنیم
            if (!empty($reservation->user->username)) {
                $passengerName = $reservation->user->username;
            }
            // اگر username خالی بود، از first_name و last_name استفاده می‌کنیم
            elseif (!empty($reservation->user->first_name) || !empty($reservation->user->last_name)) {
                $passengerName = trim(($reservation->user->first_name ?? '') . ' ' . ($reservation->user->last_name ?? ''));
                // اگر بعد از trim خالی شد، به نامشخص برمی‌گردیم
                if (empty($passengerName)) {
                    $passengerName = 'نامشخص';
                }
            }
        }

        // آماده‌سازی شماره تماس مسافر (اول از user، در غیر این صورت از فیلد phone رزرو)
        $passengerPhone = 'نامشخص';
        if ($reservation->user && !empty($reservation->user->mobile)) {
            $passengerPhone = $reservation->user->mobile;
        } elseif (!empty($reservation->phone)) {
            $passengerPhone = $reservation->phone;
        }

        // آماده‌سازی آدرس مبدا
        $originAddress = 'نامشخص';
        if (!empty($reservation->origin_address)) {
            $originAddress = $reservation->origin_address;
        }

        // آماده‌سازی لینک مبدا (Google Maps)
        $originUrl = 'نامشخص';
        if ($reservation->primaryOriginLocation
            && !empty($reservation->primaryOriginLocation->latitude)
            && !empty($reservation->primaryOriginLocation->longitude)) {
            $originUrl = "https://www.google.com/maps?q={$reservation->primaryOriginLocation->latitude},{$reservation->primaryOriginLocation->longitude}";
        }

        // آماده‌سازی آدرس مقصد
        $destinationAddress = 'نامشخص';
        if (!empty($reservation->destination_address)) {
            $destinationAddress = $reservation->destination_address;
        }

        // آماده‌سازی لینک مقصد (Google Maps)
        $destinationUrl = 'نامشخص';
        if ($reservation->primaryDestinationLocation
            && !empty($reservation->primaryDestinationLocation->latitude)
            && !empty($reservation->primaryDestinationLocation->longitude)) {
            $destinationUrl = "https://www.google.com/maps?q={$reservation->primaryDestinationLocation->latitude},{$reservation->primaryDestinationLocation->longitude}";
        }

        // آماده‌سازی تعداد مسافران
        $passengerCount = '1';
        if (!empty($reservation->passengers_count) && $reservation->passengers_count > 0) {
            $passengerCount = (string) $reservation->passengers_count;
        }

        // آماده‌سازی تاریخ و زمان رزرو
        $reservationDateTime = 'نامشخص';
        if (!empty($reservation->date)) {
            try {
                $v = new Verta($reservation->date);
                $dateStr = $v->format('Y/m/d');
                $timeStr = !empty($reservation->time) ? trim($reservation->time) : '';
                $reservationDateTime = $dateStr . ($timeStr ? ' ساعت ' . $timeStr : '');
            } catch (\Exception $e) {
                // اگر خطا در تبدیل تاریخ رخ داد، از تاریخ اصلی استفاده می‌کنیم
                $reservationDateTime = $reservation->date->format('Y/m/d');
                if (!empty($reservation->time)) {
                    $reservationDateTime .= ' ساعت ' . trim($reservation->time);
                }
            }
        }

        // آماده‌سازی نام خودرو - با اولویت car و سپس carCategory
        $carName = 'تعیین نشده';
        if ($reservation->car && !empty($reservation->car->title)) {
            $carName = $reservation->car->title;
        } elseif ($reservation->carCategory && !empty($reservation->carCategory->title)) {
            $carName = $reservation->carCategory->title;
        }

        // آماده‌سازی دسته‌بندی خودرو
        $carCategory = 'تعیین نشده';
        if ($reservation->carCategory && !empty($reservation->carCategory->title)) {
            $carCategory = $reservation->carCategory->title;
        }

        // آماده‌سازی قیمت - اگر توافقی باشد، فقط "توافقی" نمایش داده می‌شود
        $priceText = 'تعیین نشده';
        if ($reservation->is_negotiable) {
            $priceText = 'توافقی';
        } elseif (!empty($reservation->total_price) && $reservation->total_price > 0) {
            $priceText = number_format($reservation->total_price, 0) . ' تومان';
        }

        // آماده‌سازی لینک مشاهده رزرو
        $showReservationUrl = '';
        try {
            $showReservationUrl = route('admin.reservations.show', $reservation->id);
        } catch (\Exception $e) {
            // اگر route پیدا نشد، از URL دستی استفاده می‌کنیم
            $showReservationUrl = url('/admin-panel/reservations/' . $reservation->id);
        }

        // تابع helper برای محدود کردن طول رشته و اطمینان از اینکه خالی نباشد
        $truncate = function($string, $length, $default = 'نامشخص') {
            if (empty($string) || trim($string) === '') {
                return $default;
            }
            $trimmed = trim($string);
            return mb_substr($trimmed, 0, $length, 'UTF-8');
        };

        // آماده‌سازی متغیرها با محدودیت طول و بررسی خالی بودن
        $variables = [
            'passenger_name' => $truncate($passengerName, 50, 'نامشخص'),
            'passenger_phone' => $truncate($passengerPhone, 20, 'نامشخص'),
            'org' => $truncate($originAddress, 100, 'تعیین نشده'),
            'org_url' => $truncate($originUrl, 200, 'نامشخص'),
            'desi' => $truncate($destinationAddress, 100, 'تعیین نشده'),
            'desi_url' => $truncate($destinationUrl, 200, 'نامشخص'),
            'passenger_count' => !empty($passengerCount) ? $passengerCount : '1',
            'reservation_date_time' => $truncate($reservationDateTime, 50, 'تعیین نشده'),
            'car' => $truncate($carName, 50, 'تعیین نشده'),
            'car_category' => $truncate($carCategory, 50, 'تعیین نشده'),
            'price' => $truncate($priceText, 50, 'تعیین نشده'),
            'show_reservation' => $truncate($showReservationUrl, 200, ''),
        ];

        // ارسال پیامک الگویی
        try {
            Log::info('SendReservationNotificationSms listener triggered for reservation', [
                'reservation_id' => $reservation->id,
                'status' => $reservation->status
            ]);

            $success = $this->smsService->sendPattern(
                $recipient,
                $patternCode,
                $variables
            );
            if ($success) {
                Log::info('Reservation notification SMS sent successfully', [
                    'reservation_id' => $reservation->id,
                    'recipient' => $recipient
                ]);
            } else {
                Log::error('Failed to send reservation notification SMS', [
                    'reservation_id' => $reservation->id,
                    'recipient' => $recipient,
                    'pattern_code' => $patternCode
                ]);

                $fallbackSent = $this->smsService->send(
                    $recipient,
                    $this->buildAdminFallbackMessage($reservation, $passengerName, $passengerPhone, $originAddress, $destinationAddress, $carCategory, $priceText)
                );

                Log::log($fallbackSent ? 'info' : 'error', 'Reservation notification fallback SMS processed', [
                    'reservation_id' => $reservation->id,
                    'recipient' => $recipient,
                    'sent' => $fallbackSent,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Exception while sending reservation notification SMS', [
                'reservation_id' => $reservation->id,
                'recipient' => $recipient,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }

        // ارسال SMS به مسافر
        $this->sendPassengerSms($reservation, $passengerName, $carCategory, $priceText);
    }

    /**
     * ارسال SMS به مسافر
     */
    protected function sendPassengerSms(Reservation $reservation, string $passengerName, string $carCategory, string $priceText): void
    {
        // بررسی اینکه مسافر شماره موبایل داشته باشد
        if (!$reservation->user || empty($reservation->user->mobile)) {
            Log::info('Passenger SMS skipped - no mobile number', [
                'reservation_id' => $reservation->id,
                'user_id' => $reservation->user_id
            ]);
            return;
        }

        $passengerMobile = $reservation->user->mobile;
        $passengerPatternCode = config('notification.sms.reservation_passenger_pattern', '1twembbnaiqkw3g');

        // تابع helper برای محدود کردن طول رشته
        $truncate = function($string, $length, $default = 'نامشخص') {
            if (empty($string) || trim($string) === '') {
                return $default;
            }
            $trimmed = trim($string);
            return mb_substr($trimmed, 0, $length, 'UTF-8');
        };

        // آماده‌سازی متغیرها برای SMS مسافر
        $passengerVariables = [
            'name' => $truncate($passengerName, 50, 'کاربر'),
            'code' => (string) $reservation->id,
            'car' => $truncate($carCategory, 50, 'تعیین نشده'),
            'price' => $truncate($priceText, 50, 'تعیین نشده'),
        ];

        // ارسال پیامک الگویی به مسافر
        try {
            Log::info('Sending passenger SMS for reservation', [
                'reservation_id' => $reservation->id,
                'passenger_mobile' => $passengerMobile
            ]);

            $success = $this->smsService->sendPattern(
                $passengerMobile,
                $passengerPatternCode,
                $passengerVariables
            );

            if ($success) {
                Log::info('Passenger SMS sent successfully', [
                    'reservation_id' => $reservation->id,
                    'passenger_mobile' => $passengerMobile
                ]);
            } else {
                Log::error('Failed to send passenger SMS', [
                    'reservation_id' => $reservation->id,
                    'passenger_mobile' => $passengerMobile,
                    'pattern_code' => $passengerPatternCode
                ]);

                $fallbackSent = $this->smsService->send(
                    $passengerMobile,
                    $this->buildPassengerFallbackMessage($reservation, $passengerName, $carCategory, $priceText)
                );

                Log::log($fallbackSent ? 'info' : 'error', 'Passenger fallback SMS processed', [
                    'reservation_id' => $reservation->id,
                    'passenger_mobile' => $passengerMobile,
                    'sent' => $fallbackSent,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Exception while sending passenger SMS', [
                'reservation_id' => $reservation->id,
                'passenger_mobile' => $passengerMobile,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    private function buildAdminFallbackMessage(
        Reservation $reservation,
        string $passengerName,
        string $passengerPhone,
        string $originAddress,
        string $destinationAddress,
        string $carCategory,
        string $priceText
    ): string {
        return implode("\n", [
            'رزرو تاکسی ثبت شد',
            "کد رزرو: {$reservation->id}",
            "مسافر: {$passengerName}",
            "موبایل: {$passengerPhone}",
            "مبدا: {$originAddress}",
            "مقصد: {$destinationAddress}",
            "خودرو: {$carCategory}",
            "قیمت: {$priceText}",
        ]);
    }

    private function buildPassengerFallbackMessage(
        Reservation $reservation,
        string $passengerName,
        string $carCategory,
        string $priceText
    ): string {
        return implode("\n", [
            "{$passengerName} عزیز، درخواست رزرو شما ثبت شد.",
            "کد رزرو: {$reservation->id}",
            "خودرو: {$carCategory}",
            "قیمت: {$priceText}",
            'همکاران ما با شما تماس می‌گیرند.',
        ]);
    }
}
