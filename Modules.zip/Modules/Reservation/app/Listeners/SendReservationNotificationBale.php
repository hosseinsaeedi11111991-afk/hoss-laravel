<?php

namespace Modules\Reservation\Listeners;

use Modules\Reservation\Events\ReservationCreated;
use Modules\Reservation\Events\ReservationStatusChanged;
use Modules\Notification\Services\BaleNotificationService;
use Illuminate\Support\Facades\Log;
use Modules\Reservation\Models\Reservation;
use Hekmatinasser\Verta\Verta;

class SendReservationNotificationBale
{
    protected $baleNotificationService;

    /**
     * Create the event listener.
     */
    public function __construct(BaleNotificationService $baleNotificationService)
    {
        $this->baleNotificationService = $baleNotificationService;
    }

    /**
     * Handle the event.
     */
    public function handle(ReservationCreated|ReservationStatusChanged $event): void
    {
        // دریافت رزرو از هر دو نوع Event
        $reservation = $event->reservation;
        if ( $reservation->status != 'completed'){
            return;
        }

        // بارگذاری روابط مورد نیاز
        $reservation->load(['user', 'car', 'carCategory', 'primaryOriginLocation', 'primaryDestinationLocation']);

        // شناسه کاربری بله - از config می‌گیریم (chat_id عددی)
        $baleChatId = config('notification.bale.admin_chat_id');

        // اطمینان از اینکه chat_id به صورت عددی ارسال شود (اگر عددی است)
        if (is_numeric($baleChatId)) {
            $baleChatId = (int) $baleChatId;
        }

        // آماده‌سازی نام مسافر
        $passengerName = 'نامشخص';
        if ($reservation->user) {
            // اول username را بررسی می‌کنیم
            if (!empty($reservation->user->username)) {
                $passengerName = $reservation->user->username;
            }
            // اگر username خالی بود، از first_name و last_name استفاده می‌کنیم
            elseif (!empty($reservation->user->first_name) || !empty($reservation->user->last_name)) {
                $passengerName = trim(($reservation->user->first_name ?? '') . ' ' . ($reservation->user->last_name ?? ''));
                // اگر بعد از trim خالی شد، به نامشخص برمی‌گردیم
                if (empty($passengerName)) {
                    $passengerName = 'نامشخص';
                }
            }
        }

        // آماده‌سازی شماره تماس مسافر
        $passengerPhone = 'نامشخص';
        if ($reservation->user && !empty($reservation->user->mobile)) {
            $passengerPhone = $reservation->user->mobile;
        }

        // آماده‌سازی آدرس مبدا
        $originAddress = 'نامشخص';
        if (!empty($reservation->origin_address)) {
            $originAddress = $reservation->origin_address;
        }

        // آماده‌سازی لینک مبدا (Google Maps)
        $originUrl = 'نامشخص';
        if ($reservation->primaryOriginLocation
            && !empty($reservation->primaryOriginLocation->latitude)
            && !empty($reservation->primaryOriginLocation->longitude)) {
            $originUrl = "https://www.google.com/maps?q={$reservation->primaryOriginLocation->latitude},{$reservation->primaryOriginLocation->longitude}";
        }

        // آماده‌سازی آدرس مقصد
        $destinationAddress = 'نامشخص';
        if (!empty($reservation->destination_address)) {
            $destinationAddress = $reservation->destination_address;
        }

        // آماده‌سازی لینک مقصد (Google Maps)
        $destinationUrl = 'نامشخص';
        if ($reservation->primaryDestinationLocation
            && !empty($reservation->primaryDestinationLocation->latitude)
            && !empty($reservation->primaryDestinationLocation->longitude)) {
            $destinationUrl = "https://www.google.com/maps?q={$reservation->primaryDestinationLocation->latitude},{$reservation->primaryDestinationLocation->longitude}";
        }

        // آماده‌سازی تعداد مسافران
        $passengerCount = '1';
        if (!empty($reservation->passengers_count) && $reservation->passengers_count > 0) {
            $passengerCount = (string) $reservation->passengers_count;
        }

        // آماده‌سازی تاریخ و زمان رزرو
        $reservationDateTime = 'نامشخص';
        if (!empty($reservation->date)) {
            try {
                $v = new Verta($reservation->date);
                $dateStr = $v->format('Y/m/d');
                $timeStr = !empty($reservation->time) ? trim($reservation->time) : '';
                $reservationDateTime = $dateStr . ($timeStr ? ' ساعت ' . $timeStr : '');
            } catch (\Exception $e) {
                // اگر خطا در تبدیل تاریخ رخ داد، از تاریخ اصلی استفاده می‌کنیم
                $reservationDateTime = $reservation->date->format('Y/m/d');
                if (!empty($reservation->time)) {
                    $reservationDateTime .= ' ساعت ' . trim($reservation->time);
                }
            }
        }

        // آماده‌سازی نام خودرو - با اولویت car و سپس carCategory
        $carName = 'تعیین نشده';
        if ($reservation->car && !empty($reservation->car->title)) {
            $carName = $reservation->car->title;
        } elseif ($reservation->carCategory && !empty($reservation->carCategory->title)) {
            $carName = $reservation->carCategory->title;
        }

        // آماده‌سازی دسته‌بندی خودرو
        $carCategory = 'تعیین نشده';
        if ($reservation->carCategory && !empty($reservation->carCategory->title)) {
            $carCategory = $reservation->carCategory->title;
        }

        // آماده‌سازی قیمت - اگر توافقی باشد، فقط "توافقی" نمایش داده می‌شود
        $priceText = 'تعیین نشده';
        if ($reservation->is_negotiable) {
            $priceText = 'توافقی';
        } elseif (!empty($reservation->total_price) && $reservation->total_price > 0) {
            $priceText = number_format($reservation->total_price, 0) . ' تومان';
        }

        // آماده‌سازی لینک مشاهده رزرو
        $showReservationUrl = '';
        try {
            $showReservationUrl = route('admin.reservations.show', $reservation->id);
        } catch (\Exception $e) {
            // اگر route پیدا نشد، از URL دستی استفاده می‌کنیم
            $showReservationUrl = url('/admin-panel/reservations/' . $reservation->id);
        }

        // ساخت پیام برای بله
        $message = $this->buildBaleMessage(
            $reservation,
            $passengerName,
            $passengerPhone,
            $originAddress,
            $originUrl,
            $destinationAddress,
            $destinationUrl,
            $passengerCount,
            $reservationDateTime,
            $carName,
            $carCategory,
            $priceText,
            $showReservationUrl
        );

        // ارسال پیام به بله
        try {


            // تست مستقیم با BaleService برای دیباگ بهتر
            $baleService = app(\Modules\Notification\Services\BaleService::class);



            // ارسال بدون parse_mode چون HTML نداریم
            $result = $baleService->sendMessage($baleChatId, $message);

        } catch (\Exception $e) {
            Log::error('Exception while sending reservation notification Bale', [
                'reservation_id' => $reservation->id,
                'bale_chat_id' => $baleChatId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'note' => 'اگر خطای 404 دریافت می‌کنید، احتمالاً کاربر با ربات چت نکرده است. باید از chat_id عددی استفاده کنید یا کاربر ابتدا با ربات چت کند.'
            ]);
        }
    }

    /**
     * ساخت پیام بله (بدون HTML، فقط emoji)
     */
    protected function buildBaleMessage(
        Reservation $reservation,
        string $passengerName,
        string $passengerPhone,
        string $originAddress,
        string $originUrl,
        string $destinationAddress,
        string $destinationUrl,
        string $passengerCount,
        string $reservationDateTime,
        string $carName,
        string $carCategory,
        string $priceText,
        string $showReservationUrl
    ): string {
        $message = "🔔 رزرو جدید ثبت شد\n\n";

        $message .= "🆔 شماره رزرو: {$reservation->id}\n";
        $message .= "👤 نام مسافر: {$passengerName}\n";
        $message .= "📱 شماره تماس: {$passengerPhone}\n\n";

        $message .= "📍 مبدا: {$originAddress}\n";
        if ($originUrl !== 'نامشخص') {
            $message .= "🔗 {$originUrl}\n";
        }

        $message .= "\n🎯 مقصد: {$destinationAddress}\n";
        if ($destinationUrl !== 'نامشخص') {
            $message .= "🔗 {$destinationUrl}\n";
        }

        $message .= "\n";
        $message .= "👥 تعداد مسافران: {$passengerCount}\n";
        $message .= "📅 تاریخ و زمان: {$reservationDateTime}\n";
        $message .= "🚗 خودرو: {$carName}\n";
        $message .= "📦 دسته‌بندی: {$carCategory}\n";
        $message .= "💰 قیمت: {$priceText}\n";

        if (!empty($showReservationUrl)) {
            $message .= "\n🔗 {$showReservationUrl}\n";
        }

        return $message;
    }
}

