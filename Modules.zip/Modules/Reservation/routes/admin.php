<?php


use Illuminate\Support\Facades\Route;
use Modules\Reservation\Http\Controllers\Admin\OptionController;
use Modules\Reservation\Http\Controllers\Admin\PopularRouteController;
use Modules\Reservation\Http\Controllers\Admin\ReservationController;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')
    ->group(function () {


    // ------------------ Reservation ------------------
    Route::controller(ReservationController::class)->prefix('reservations')->group(function () {
        Route::get('/', 'index')->name('admin.reservations.index');
        Route::get('create', 'create')->name('admin.reservations.create');
        Route::get('export', 'export')->name('admin.reservations.export');
        Route::delete('bulk-delete', 'bulkDestroy')->name('admin.reservations.bulkDestroy');
        Route::post('/', 'store')->name('admin.reservations.store');
        Route::get('{reservation}', 'show')->name('admin.reservations.show');
        Route::get('{reservation}/edit', 'edit')->name('admin.reservations.edit');
        Route::put('{reservation}', 'update')->name('admin.reservations.update');
        Route::delete('{reservation}', 'destroy')->name('admin.reservations.destroy');
        Route::patch('{reservation}/status', 'updateStatus')->name('admin.reservations.updateStatus');
        Route::get('{reservation}/neshan', 'neshan')->name('admin.reservations.neshan');
    });

    // ------------------ Options ------------------
    Route::controller(OptionController::class)->prefix('reservation-option')->group(function () {
        Route::get('/', 'index')->name('admin.options.index');
        Route::get('create', 'create')->name('admin.options.create');
        Route::post('/', 'store')->name('admin.options.store');
        Route::get('{option}', 'show')->name('admin.options.show');
        Route::get('{option}/edit', 'edit')->name('admin.options.edit');
        Route::put('{option}', 'update')->name('admin.options.update');
        Route::delete('{option}', 'destroy')->name('admin.options.destroy');
    });

    // ------------------ Popular Routes ------------------
    Route::controller(PopularRouteController::class)->prefix('popular-routes')->group(function () {
        Route::get('/', 'index')->name('admin.popular-routes.index');
        Route::get('create', 'create')->name('admin.popular-routes.create');
        Route::post('/', 'store')->name('admin.popular-routes.store');
        Route::get('{popularRoute}/edit', 'edit')->name('admin.popular-routes.edit');
        Route::put('{popularRoute}', 'update')->name('admin.popular-routes.update');
        Route::delete('{popularRoute}', 'destroy')->name('admin.popular-routes.destroy');
    });

});
