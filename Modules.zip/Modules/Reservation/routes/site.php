<?php

use Illuminate\Support\Facades\Route;
use Modules\Reservation\Http\Controllers\site\PopularRouteSiteController;
use Modules\Reservation\Http\Controllers\site\ReservationSiteController;

Route::middleware(['web'])->group(function () {
    Route::post('/popular-route/{popularRoute}/start', [PopularRouteSiteController::class, 'start'])->name('site.popular-route.start');
    Route::get('/reservation/{reservation?}', [ReservationSiteController::class, 'index'])->name('site.reservation.index');
    Route::post('/reservation', [ReservationSiteController::class, 'store'])->name('site.reservation.store');
    Route::post('/reservation/prepare', [ReservationSiteController::class, 'prepare'])->name('site.reservation.prepare');
    Route::post('/reservation/preview', [ReservationSiteController::class, 'previewSelection'])->name('site.reservation.preview');
    Route::post('/reservation/price-quote', [ReservationSiteController::class, 'getPriceQuote'])->name('site.reservation.price-quote');
});


