@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.reservations.index') }}">پنل/</a></span>
        <span class="text-muted fw-light">رزرو‌ها/</span>
        نشان رزرو #{{ $reservation->id }}
    </h4>

    <div class="card mb-3">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3"><span class="fw-bold">کاربر:</span> {{ $reservation->user->first_name ?? '-' }}</div>
                <div class="col-md-3"><span class="fw-bold">خودرو:</span> {{ $reservation->car->title ?? '-' }}</div>
                <div class="col-md-3"><span class="fw-bold">تاریخ:</span> {{ $reservation->date ? verta($reservation->date)->format('Y/m/d') : '-' }}</div>
                <div class="col-md-3"><span class="fw-bold">مسافت:</span> {{ number_format($reservation->distance_km, 2) }} km</div>
            </div>
        </div>
    </div>

    @forelse($locations as $loc)
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <span class="badge bg-{{ $loc->type === 'origin' ? 'primary' : 'info' }}">{{ $loc->type === 'origin' ? 'مبدا' : 'مقصد' }}</span>
                    @if($loc->is_primary)
                        <span class="badge bg-success">اصلی</span>
                    @endif
                </div>
                <div>
                    Lat: {{ $loc->latitude }} | Lng: {{ $loc->longitude }}
                </div>
            </div>
            <div class="card-body">
                <p class="mb-2"><span class="fw-bold">آدرس:</span> {{ $loc->address_text }}</p>

                @if($loc->cities->count())
                    <div class="table-responsive text-nowrap">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>نام شهر</th>
                                <th>کیلومتر</th>
                                <th>رزرو مرتبط</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($loc->cities as $idx => $city)
                                <tr>
                                    <td>{{ $idx + 1 }}</td>
                                    <td>{{ $city->city_name }}</td>
                                    <td>{{ number_format($city->distance_km, 2) }}</td>
                                    <td>{{ $city->reservation_id ?? '—' }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <span class="text-muted">هیچ شهری ثبت نشده است.</span>
                @endif
            </div>
        </div>
    @empty
        <div class="alert alert-info">هیچ لوکیشنی برای این رزرو ثبت نشده است.</div>
    @endforelse

    <a href="{{ route('admin.reservations.index') }}" class="btn btn-secondary mt-2">بازگشت</a>
@endsection


