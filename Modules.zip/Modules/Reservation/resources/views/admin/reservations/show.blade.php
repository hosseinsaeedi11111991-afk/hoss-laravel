@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.reservations.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.reservations.index') }}">رزرو‌ها/</a></span>
        مشاهده رزرو
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات رزرو</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>کاربر:</strong> {{ $reservation->user->full_name ?? '-' }}</li>
                        <li class="list-group-item"><strong>شماره تماس:</strong> {{ $reservation->phone ?? $reservation->user->mobile ?? '-' }}</li>
                        <li class="list-group-item"><strong>شماره دوم:</strong> {{ $reservation->second_phone ?? '-' }}</li>
                        <li class="list-group-item"><strong>دسته‌بندی ماشین:</strong> {{ $reservation->carCategory->title ?? '-' }}</li>
                        <li class="list-group-item"><strong>خودرو:</strong> {{ $reservation->car->title ?? '-' }}</li>
                        <li class="list-group-item"><strong>تعداد مسافران:</strong> {{ $reservation->passengers_count ?? 1 }} نفر</li>
                        <li class="list-group-item"><strong>تاریخ:</strong> {{ $reservation->date ? verta($reservation->date)->format('Y/m/d H:i:s') : '-' }}</li>
                        <li class="list-group-item"><strong>مسافت:</strong> {{ number_format($reservation->distance_km, 2) }} km</li>
                        <li class="list-group-item"><strong>مبلغ کل:</strong> {{ number_format($reservation->total_price) }} تومان</li>
                        <li class="list-group-item"><strong>آدرس مبدا:</strong> {{ $reservation->origin_address ?? '-' }}</li>
                        <li class="list-group-item"><strong>آدرس مقصد:</strong> {{ $reservation->destination_address ?? '-' }}</li>
                        <li class="list-group-item"><strong>مبدا:</strong> {{ $reservation->origin ?? '-' }}</li>
                        <li class="list-group-item"><strong>مقصد:</strong> {{ $reservation->destination ?? '-' }}</li>
                        <li class="list-group-item"><strong>زمان حرکت:</strong> {{ $reservation->time ?? '-' }}</li>
                        <li class="list-group-item"><strong>توضیحات:</strong> {{ $reservation->description ?? 'بدون توضیحات' }}</li>
                        <li class="list-group-item">
                            <strong>نیاز به فاکتور:</strong>
                            @if($reservation->needs_invoice)
                                <span class="badge bg-success">بله</span>
                            @else
                                <span class="badge bg-secondary">خیر</span>
                            @endif
                        </li>
                        <li class="list-group-item">
                            <strong>قیمت توافقی:</strong>
                            @if($reservation->is_negotiable)
                                <span class="badge bg-warning">بله</span>
                            @else
                                <span class="badge bg-secondary">خیر</span>
                            @endif
                        </li>
                        <li class="list-group-item">
                            <strong>آپشن‌ها:</strong>
                            @if($reservation->options->isEmpty())
                                <span class="text-muted">—</span>
                            @else
                                <ul class="mt-2">
                                    @foreach($reservation->options as $opt)
                                        <li>{{ $opt->name }}</li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                        <li class="list-group-item">
                            <strong>وضعیت:</strong>
                            <span class="badge bg-primary">{{ $reservation->status_label }}</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($reservation->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($reservation->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>

    @forelse($locations as $loc)
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <span class="badge bg-{{ $loc->type === 'origin' ? 'primary' : 'info' }}">{{ $loc->type === 'origin' ? 'مبدا' : 'مقصد' }}</span>
                    @if($loc->is_primary)
                        <span class="badge bg-success">اصلی</span>
                    @endif
                </div>
                <div>
                    <a href="https://www.google.com/maps?q={{ $loc->latitude }},{{ $loc->longitude }}" target="_blank" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-map-marker-alt"></i> مشاهده در گوگل مپ
                    </a>
                </div>
            </div>
            <div class="card-body">
                <p class="mb-2"><span class="fw-bold">آدرس:</span> {{ $loc->address_text }}</p>

                @if($loc->cities->count())
                    <div class="table-responsive text-nowrap">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>نام شهر</th>
                                <th>کیلومتر</th>
                                <th>رزرو مرتبط</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($loc->cities as $idx => $city)
                                <tr>
                                    <td>{{ $idx + 1 }}</td>
                                    <td>{{ $city->city_name }}</td>
                                    <td>{{ number_format($city->distance_km, 2) }}</td>
                                    <td>{{ $city->reservation_id ?? '—' }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <span class="text-muted">هیچ شهری ثبت نشده است.</span>
                @endif
            </div>
        </div>
    @empty
        <div class="alert alert-info">هیچ لوکیشنی برای این رزرو ثبت نشده است.</div>
    @endforelse
@endsection
