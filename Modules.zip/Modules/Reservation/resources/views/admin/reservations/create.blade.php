@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.reservations.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.reservations.index') }}">رزرو‌ها/</a></span>
        افزودن رزرو
    </h4>

    <form action="{{ route('admin.reservations.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">انتخاب کنید...</option>
                    @foreach($carCategories as $id => $title)
                        <option value="{{ $id }}" {{ old('car_category_id') == $id ? 'selected' : '' }}>{{ $title }}</option>
                    @endforeach
                </select>
                @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">خودرو</label>
                <select name="car_id" class="form-select">
                    <option value="">انتخاب کنید...</option>
                    @foreach($cars as $id => $title)
                        <option value="{{ $id }}" {{ old('car_id') == $id ? 'selected' : '' }}>{{ $title }}</option>
                    @endforeach
                </select>
                @error('car_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">کاربر <span class="text-danger">*</span></label>
                <select name="user_id" class="form-select" required>
                    <option value="">انتخاب کنید...</option>
                    @foreach($users as $id => $name)
                        <option value="{{ $id }}" {{ old('user_id') == $id ? 'selected' : '' }}>{{ $name }}</option>
                    @endforeach
                </select>
                @error('user_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">تاریخ <span class="text-danger">*</span></label>
                <input type="date" name="date" class="form-control" value="{{ old('date') }}" required>
                @error('date')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">مسافت (km) <span class="text-danger">*</span></label>
                <input type="number" step="0.01" name="distance_km" class="form-control" value="{{ old('distance_km', 0) }}" min="0" required>
                @error('distance_km')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">تعداد مسافران</label>
                <input type="number" name="passengers_count" class="form-control" value="{{ old('passengers_count', 1) }}" min="1" max="99">
                @error('passengers_count')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مبدا</label>
                <input type="text" name="origin_address" class="form-control" value="{{ old('origin_address') }}">
                @error('origin_address')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مقصد</label>
                <input type="text" name="destination_address" class="form-control" value="{{ old('destination_address') }}">
                @error('destination_address')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">مبدا (کوتاه)</label>
                <input type="text" name="origin" class="form-control" value="{{ old('origin') }}">
                @error('origin')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">مقصد (کوتاه)</label>
                <input type="text" name="destination" class="form-control" value="{{ old('destination') }}">
                @error('destination')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">زمان حرکت</label>
                <input type="text" name="time" class="form-control" maxlength="15" value="{{ old('time') }}" placeholder="مثلا 08:30">
                @error('time')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">شماره تماس</label>
                <input type="text" name="phone" class="form-control" value="{{ old('phone') }}" maxlength="20" placeholder="09123456789">
                @error('phone')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">شماره دوم</label>
                <input type="text" name="second_phone" class="form-control" value="{{ old('second_phone') }}" maxlength="20">
                @error('second_phone')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <label class="form-label">توضیحات</label>
                <textarea name="description" class="form-control" rows="3">{{ old('description') }}</textarea>
                @error('description')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <label class="form-check">
                    <input class="form-check-input" type="checkbox" name="needs_invoice" value="1" {{ old('needs_invoice') ? 'checked' : '' }}>
                    <span class="form-check-label">نیاز به فاکتور</span>
                </label>
                @error('needs_invoice')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-12 mb-3">
                <label class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_negotiable" value="1" {{ old('is_negotiable') ? 'checked' : '' }}>
                    <span class="form-check-label">قیمت توافقی</span>
                </label>
                @error('is_negotiable')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <h5 class="mt-4">آپشن‌ها</h5>
        <div class="row">
            @foreach($options as $option)
                <div class="col-md-4 mb-2">
                    <label class="form-check">
                        <input class="form-check-input" type="checkbox" name="options[]" value="{{ $option->id }}">
                        <span class="form-check-label">
                            {{ $option->name }} -
                            {{ number_format($option->fixed_price) }} تومان
                            @if($option->per_km_price)
                                + {{ number_format($option->per_km_price) }}/km
                            @endif
                        </span>
                    </label>
                </div>
            @endforeach
        </div>

        <button type="submit" class="btn btn-primary mt-3">ذخیره</button>
    </form>
@endsection
