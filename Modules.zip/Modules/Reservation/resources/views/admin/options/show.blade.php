@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">آپشن‌ها/</a></span>
        مشاهده آپشن
    </h4>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="border-bottom pb-2">اطلاعات آپشن</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>نام:</strong> {{ $option->name }}</li>
                        <li class="list-group-item">
                            <strong>دسته‌بندی ماشین:</strong>
                            @if($option->carCategory)
                                <span class="badge bg-secondary">{{ $option->carCategory->title }}</span>
                            @else
                                <span class="badge bg-info">برای همه ماشین‌ها</span>
                            @endif
                        </li>
                        <li class="list-group-item"><strong>نوع:</strong> {{ $option->type=='text' ? 'متن' : 'چک‌باکس' }}</li>
                        <li class="list-group-item">
                            <strong>نوع محاسبه:</strong>
                            @if($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_FIXED)
                                قیمت ثابت
                            @elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PER_KM)
                                به‌ازای کیلومتر
                            @elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PERCENTAGE)
                                محاسبه درصدی
                            @endif
                        </li>
                        <li class="list-group-item"><strong>قیمت ثابت:</strong> {{ $option->fixed_price ? number_format($option->fixed_price) . ' تومان' : '-' }}</li>
                        <li class="list-group-item"><strong>قیمت هر کیلومتر:</strong> {{ $option->per_km_price ? number_format($option->per_km_price) . ' تومان' : '-' }}</li>
                        <li class="list-group-item"><strong>درصد قیمت:</strong> {{ $option->percentage_price ? number_format($option->percentage_price, 2) . '%' : '-' }}</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6>تاریخ ایجاد</h6>
                    <p>{{ verta($option->created_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
            <div class="card bg-light mt-2">
                <div class="card-body">
                    <h6>آخرین ویرایش</h6>
                    <p>{{ verta($option->updated_at)->format('Y/m/d H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
