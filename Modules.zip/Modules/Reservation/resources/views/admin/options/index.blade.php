@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">آپشن‌ها/</a></span>
        لیست آپشن‌ها
    </h4>

    <a href="{{ route('admin.options.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن آپشن</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>نام</th>
                <th>دسته‌بندی ماشین</th>
                <th>نوع</th>
                <th>نوع محاسبه</th>
                <th>قیمت ثابت</th>
                <th>قیمت هر کیلومتر</th>
                <th>درصد قیمت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($options as $key => $option)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $option->name }}</td>
                    <td>
                        @if($option->carCategory)
                            <span class="badge bg-secondary">{{ $option->carCategory->title }}</span>
                        @else
                            <span class="badge bg-info">برای همه ماشین‌ها</span>
                        @endif
                    </td>
                    <td>
                        {{ $option->type=='text' ? 'متن' : 'چک‌باکس' }}
                    </td>
                    <td>
                        @if($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_FIXED)
                            قیمت ثابت
                        @elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PER_KM)
                            به‌ازای کیلومتر
                        @elseif($option->pricing_type === \Modules\Reservation\Models\Option::PRICING_TYPE_PERCENTAGE)
                            محاسبه درصدی
                        @endif
                    </td>
                    <td>{{ $option->fixed_price ? number_format($option->fixed_price) : '-' }} تومان</td>
                    <td>{{ $option->per_km_price ? number_format($option->per_km_price) : '-' }} تومان</td>
                    <td>{{ $option->percentage_price ? number_format($option->percentage_price, 2) . '%' : '-' }}</td>
                    <td>
                        <a href="{{ route('admin.options.show', $option) }}" class="btn btn-sm btn-info" title="نمایش"><i class="bx bxs-show"></i></a>
                        <a href="{{ route('admin.options.edit', $option) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.options.destroy', $option) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $options->links('pagination::bootstrap-5') }}
    </div>
@endsection
