@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.options.index') }}">آپشن‌ها/</a></span>
        افزودن آپشن
    </h4>

    <form action="{{ route('admin.options.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">نام آپشن <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
                @error('name')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">دسته‌بندی ماشین</label>
                <select name="car_category_id" class="form-select">
                    <option value="">برای همه ماشین‌ها (پیش‌فرض)</option>
                    @foreach($carCategories as $category)
                        <option value="{{ $category->id }}" {{ old('car_category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->title }}
                        </option>
                    @endforeach
                </select>
                @error('car_category_id')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">نوع <span class="text-danger">*</span></label>
                <select name="type" class="form-select" required>
                    <option value="text"     {{ old('type')=='text' ? 'selected' : '' }}>متن</option>
                    <option value="checkbox" {{ old('type')=='checkbox' ? 'selected' : '' }}>چک‌باکس</option>
                </select>
                @error('type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">نوع محاسبه <span class="text-danger">*</span></label>
                <select name="pricing_type" class="form-select" required>
                    <option value="fixed" {{ old('pricing_type','fixed')=='fixed' ? 'selected' : '' }}>قیمت ثابت</option>
                    <option value="per_km" {{ old('pricing_type')=='per_km' ? 'selected' : '' }}>به‌ازای هر کیلومتر</option>
                    <option value="percentage" {{ old('pricing_type')=='percentage' ? 'selected' : '' }}>محاسبه درصدی</option>
                </select>
                @error('pricing_type')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت ثابت (تومان)</label>
                <input type="number" step="0.01" name="fixed_price" class="form-control" value="{{ old('fixed_price', 0) }}" min="0">
                @error('fixed_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">قیمت هر کیلومتر (تومان)</label>
                <input type="number" step="0.01" name="per_km_price" class="form-control" value="{{ old('per_km_price',0) }}" min="0">
                @error('per_km_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">درصد قیمت (%)</label>
                <input type="number" step="0.01" name="percentage_price" class="form-control" value="{{ old('percentage_price', 0) }}" min="0" max="100">
                @error('percentage_price')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <button type="submit" class="btn btn-primary">ذخیره</button>
    </form>
@endsection
