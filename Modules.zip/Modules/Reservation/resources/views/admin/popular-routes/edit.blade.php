@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.popular-routes.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.popular-routes.index') }}">مسیرهای پرطرفدار/</a></span>
        ویرایش مسیر پرطرفدار
    </h4>

    <form action="{{ route('admin.popular-routes.update', $popularRoute) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="row">
            <div class="col-md-12 mb-3">
                <label class="form-label">عنوان <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" value="{{ old('title', $popularRoute->title) }}" required>
                @error('title')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_address" class="form-control" value="{{ old('origin_address', $popularRoute->origin_address) }}" required>
                @error('origin_address')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">آدرس مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_address" class="form-control" value="{{ old('destination_address', $popularRoute->destination_address) }}" required>
                @error('destination_address')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">عرض جغرافیایی مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_lat" class="form-control" value="{{ old('origin_lat', $popularRoute->origin_lat) }}" required>
                @error('origin_lat')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">طول جغرافیایی مبدا <span class="text-danger">*</span></label>
                <input type="text" name="origin_lng" class="form-control" value="{{ old('origin_lng', $popularRoute->origin_lng) }}" required>
                @error('origin_lng')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">عرض جغرافیایی مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_lat" class="form-control" value="{{ old('destination_lat', $popularRoute->destination_lat) }}" required>
                @error('destination_lat')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">طول جغرافیایی مقصد <span class="text-danger">*</span></label>
                <input type="text" name="destination_lng" class="form-control" value="{{ old('destination_lng', $popularRoute->destination_lng) }}" required>
                @error('destination_lng')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">تصویر</label>
                @if($popularRoute->image)
                    <div class="mb-2">
                        <img src="{{ Storage::url($popularRoute->image) }}" alt="{{ $popularRoute->title }}" class="img-thumbnail" style="max-height: 80px;">
                    </div>
                @endif
                <input type="file" name="image" class="form-control" accept="image/*">
                @error('image')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3">
                <label class="form-label">ترتیب نمایش</label>
                <input type="number" name="sort_order" class="form-control" value="{{ old('sort_order', $popularRoute->sort_order) }}" min="0">
                @error('sort_order')<small class="text-danger">{{ $message }}</small>@enderror
            </div>

            <div class="col-md-3 mb-3 d-flex align-items-end">
                <div class="form-check">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" class="form-check-input" value="1" id="is_active" {{ old('is_active', $popularRoute->is_active) ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_active">فعال</label>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-warning">بروزرسانی</button>
    </form>
@endsection
