@extends('Shared::layouts.admin.main')
@section('main')
    <h4 class="py-3 breadcrumb-wrapper mb-4">
        <span><a class="text-muted fw-light" href="{{ route('admin.popular-routes.index') }}">پنل/</a></span>
        <span><a class="text-muted fw-light" href="{{ route('admin.popular-routes.index') }}">مسیرهای پرطرفدار/</a></span>
        لیست مسیرهای پرطرفدار
    </h4>

    <a href="{{ route('admin.popular-routes.create') }}" class="btn btn-success rounded-pill mb-3">+ افزودن مسیر پرطرفدار</a>

    <div class="table-responsive text-nowrap">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>عنوان</th>
                <th>مبدا</th>
                <th>مقصد</th>
                <th>ترتیب</th>
                <th>وضعیت</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            @foreach($popularRoutes as $key => $route)
                <tr>
                    <td>{{ ($popularRoutes->currentPage() - 1) * $popularRoutes->perPage() + $key + 1 }}</td>
                    <td>{{ $route->title }}</td>
                    <td>{{ Str::limit($route->origin_address, 30) }}</td>
                    <td>{{ Str::limit($route->destination_address, 30) }}</td>
                    <td>{{ $route->sort_order }}</td>
                    <td>
                        @if($route->is_active)
                            <span class="badge bg-success">فعال</span>
                        @else
                            <span class="badge bg-secondary">غیرفعال</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.popular-routes.edit', $route) }}" class="btn btn-sm btn-warning" title="ویرایش"><i class="bx bx-edit-alt"></i></a>
                        <form method="POST" action="{{ route('admin.popular-routes.destroy', $route) }}" class="d-inline delete-form">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" title="حذف" type="submit" onclick="return confirm('آیا از حذف این مسیر اطمینان دارید؟');"><i class="bx bx-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $popularRoutes->links('pagination::bootstrap-5') }}
    </div>
@endsection
