<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('options', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->foreignId('car_category_id')->unsigned()->nullable()->constrained('car_categories')->nullOnDelete();
            $table->decimal('fixed_price', 20, 2)->default(0);
            $table->decimal('per_km_price', 20, 2)->default(0);
            $table->decimal('percentage_price', 5, 2)->default(0);
            $table->enum('pricing_type', ['fixed', 'per_km', 'percentage'])->default('fixed');
            $table->enum('type',['text','checkbox'])->default('text');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('options');
    }
};
