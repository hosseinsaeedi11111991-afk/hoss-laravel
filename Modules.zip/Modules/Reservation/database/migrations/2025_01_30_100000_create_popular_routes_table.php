<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('popular_routes', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('origin_address');
            $table->string('destination_address');
            $table->decimal('origin_lat', 10, 8);
            $table->decimal('origin_lng', 10, 8);
            $table->decimal('destination_lat', 10, 8);
            $table->decimal('destination_lng', 10, 8);
            $table->string('image')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('popular_routes');
    }
};
