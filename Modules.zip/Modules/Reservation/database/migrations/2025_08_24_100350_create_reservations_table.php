<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reservations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('car_id')->nullable()->unsigned()->constrained()->nullOnDelete();
            $table->foreignId('car_category_id')->nullable()->constrained('car_categories')->nullOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->dateTime('date');
            $table->decimal('distance_km', 10, 2)->default(0);
            $table->decimal('total_price', 20, 2)->default(0);
            $table->string('origin_address')->nullable();
            $table->string('destination_address')->nullable();
            $table->string('origin')->nullable();
            $table->string('destination')->nullable();
            $table->string('time',15)->nullable();
            $table->string('second_phone')->nullable(); // شماره دوم
            $table->text('description')->nullable(); // توضیحات
            $table->unsignedSmallInteger('passengers_count')->default(1); // تعداد مسافران (تا 99 نفر)
            $table->boolean('needs_invoice')->default(false); // نیاز به فاکتور
            $table->boolean('is_negotiable')->default(false); // آیا قیمت توافقی است
            $table->enum('status', ['pending', 'confirmed', 'canceled', 'completed'])->default('pending');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reservations');
    }
};
