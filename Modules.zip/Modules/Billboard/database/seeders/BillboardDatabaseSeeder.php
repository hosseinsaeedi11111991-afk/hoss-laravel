<?php

namespace Modules\Billboard\Database\Seeders;

use Illuminate\Database\Seeder;

class BillboardDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
