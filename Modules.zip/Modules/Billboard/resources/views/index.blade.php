<x-billboard::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('billboard.name') !!}</p>
</x-billboard::layouts.master>
