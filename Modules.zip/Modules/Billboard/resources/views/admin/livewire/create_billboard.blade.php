<div>
    <form wire:submit.prevent="save" enctype="multipart/form-data">
        @csrf

        {{-- نام و نوع بیلبورد --}}
        <div class="d-flex mb-3 flex-wrap">
            <div class="col-12 col-md-6 px-4">
                <label class="form-label">نام بیلبورد <span class="text-danger">*</span></label>
                <input type="text" wire:model="name" class="form-control">
                @error('name') <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 col-md-6 px-4">
                <label class="form-label">طرح بیلبورد <span class="text-danger">*</span></label>
                <select wire:model="figure" class="form-control">
                    @foreach($figures as $key => $label)
                        <option value="{{ $key }}">{{ $label }}</option>
                    @endforeach
                </select>
                @error('figure') <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 px-4 pt-4">
                <input type="checkbox" wire:model="is_active" class="form-check-input" id="is_active">
                <label class="form-check-label" for="is_active">فعال / غیر فعال</label>
            </div>
        </div>

        {{-- لیست اسلایدها --}}
        @foreach($slides as $index => $slide)
        <div class="d-flex mb-3 flex-wrap border rounded p-3 position-relative">
            {{-- دکمه حذف --}}
            <button type="button" wire:click="removeSlide({{ $index }})" class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2" title="حذف اسلاید">
                <i class="bx bx-trash"></i>
            </button>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">تصویر <span class="text-danger">*</span></label>
                <input type="file" wire:model="slides.{{ $index }}.image" class="form-control">
                @error("slides.$index.image") <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">متن جایگزین تصویر <span class="text-danger">*</span></label>
                <input type="text" wire:model="slides.{{ $index }}.image_alt" class="form-control">
                @error("slides.$index.image_alt") <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">لینک</label>
                <input type="text" wire:model="slides.{{ $index }}.link" class="form-control">
                @error("slides.$index.link") <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">کپشن</label>
                <input type="text" wire:model="slides.{{ $index }}.caption" class="form-control">
                @error("slides.$index.caption") <div class="text-danger">{{ $message }}</div> @enderror
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 mb-2">
                <label class="form-label">ترتیب نمایش</label>
                <input type="text" wire:model="slides.{{ $index }}.sort_order" class="form-control" readonly>
            </div>

            <div class="col-12 col-md-6 col-lg-4 px-2 pt-4 mb-2">
                <input type="checkbox" wire:model="slides.{{ $index }}.new_tab" class="form-check-input" id="new_tab_{{ $index }}">
                <label class="form-check-label" for="new_tab_{{ $index }}">باز شدن لینک در تب جدید</label>
            </div>
        </div>
        @endforeach

        {{-- دکمه افزودن اسلاید --}}
        <div class="col-12 px-2 mb-3">
            <button type="button" wire:click="addSlide" class="btn btn-success">
                <i class="bx bx-plus"></i> افزودن تصویر جدید
            </button>
        </div>

        <button type="submit" class="btn btn-primary rounded-pill mt-3">ذخیره بیلبورد</button>
    </form>
</div>
