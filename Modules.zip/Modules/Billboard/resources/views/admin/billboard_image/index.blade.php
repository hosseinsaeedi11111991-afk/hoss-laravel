@php use Modules\Billboard\Models\Billboard; @endphp
@extends('Shared::layouts.admin.main')

@section('title', 'عکس های بیلبورد')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.billboard.index')}}">لیست بیلبوردها/</a></span>
    <span>تصاویر {{ $billboard->name }}</span>
</h4>

<a href="{{route('admin.billboard.image.create', $billboard)}}" type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>تصویر</th>
                <th>متن جایگزین عکس</th>
                <th>کپشن</th>
                <th>لینک عکس</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($attachments->items() as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>
                    <img src="{{ asset('storage/' . $row['thumbnails']['small']) }}">
                </td>
                <td>{{$row['meta']['image_alt']}}</td>
                <td>{{$row['meta']['caption']}}</td>
                <td>{{$row['meta']['link']}}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.billboard.image.edit', ['billboard' => $billboard, 'billboard_image' => $row['attachment_id']]) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.billboard.image.destroy', ['billboard' => $billboard, 'billboard_image' => $row['attachment_id']]) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $attachments->links('pagination::bootstrap-5') }}
</div>
@endsection