<form method="POST" enctype="multipart/form-data"
    action="{{ $billboard_image 
        ? route('admin.billboard.image.update', ['billboard' => $billboard, 'billboard_image' => $billboard_image['attachment_id']]) 
        : route('admin.billboard.image.store', ['billboard' => $billboard]) }}">
    @csrf
    @if($billboard_image)
        @method('PUT')
    @endif

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-md-6 col-lg-4 px-4">
            <label class="form-label" for="image">
                تصویر شاخص <i class='bx bx-health font-size-1 text-danger mx-2'></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class='bx bx-image'></i></span>
                <input type="file" class="form-control image-upload-input" id="image" name="image" accept="image/*" style="display: none;">
                <input type="text" class="form-control image-placeholder" placeholder="تصویر انتخاب نشده" readonly>
                <button class="btn btn-outline-secondary" type="button" onclick="openImagePicker('image')">انتخاب تصویر</button>
            </div>

            {{-- پیش‌نمایش تصویر در حالت ویرایش --}}
            @if($billboard_image && isset($billboard_image['thumbnails']['small']))
                <div class="image-preview-container mt-3">
                    <img class="image-preview img-thumbnail"
                         style="max-width: 200px; max-height: 150px;"
                         src="{{ asset('storage/' . $billboard_image['thumbnails']['small']) }}">
                </div>
            @else
                <div class="image-preview-container mt-3" style="display: none;">
                    <img class="image-preview img-thumbnail" style="max-width: 200px; max-height: 150px;">
                </div>
            @endif
        </div>

        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="image_alt">
                متن جایگزین تصویر <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="image_alt" type="text" name="image_alt" class="form-control"
                       value="{{ old('image_alt', $billboard_image['meta']['image_alt'] ?? '') }}">
            </div>
            @error('image_alt')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="link">لینک</label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="link" type="text" name="link" class="form-control"
                       value="{{ old('link', $billboard_image['meta']['link'] ?? '') }}">
            </div>
            @error('link')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="caption">کپشن</label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="caption" type="text" name="caption" class="form-control"
                       value="{{ old('caption', $billboard_image['meta']['caption'] ?? '') }}">
            </div>
            @error('caption')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="sort_order">ترتیب نمایش</label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="sort_order" type="text" name="sort_order" class="form-control"
                       value="{{ old('sort_order', $billboard_image['sort_order'] ?? '') }}">
            </div>
            @error('sort_order')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-12 col-lg-4 col-md-6 px-4 pt-4">
            <input class="form-check-input" type="hidden" value="0" name="new_tab">
            <input class="form-check-input" type="checkbox" value="1" id="new_tab" name="new_tab"
                   {{ old('new_tab', $billboard_image['meta']['new_tab'] ?? 0) ? 'checked' : '' }}>
            <label class="form-check-label" for="new_tab">باز شدن لینک در صفحه جدید</label>
            @error('new_tab')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4 mt-4">ذخیره اطلاعات</button>
</form>

@section('script')
<script>
    function openImagePicker(inputId) {
        document.getElementById(inputId).click();
    }
    document.querySelectorAll('.image-upload-input').forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            const parentDiv = this.closest('.col-md-6, .col-lg-4, .col-12');
            const placeholder = parentDiv.querySelector('.image-placeholder');
            const previewContainer = parentDiv.querySelector('.image-preview-container');
            const preview = parentDiv.querySelector('.image-preview');

            if (file) {
                if (!file.type.match('image.*')) {
                    alert('لطفاً فقط تصویر انتخاب کنید');
                    return;
                }
                placeholder.value = file.name;
                const reader = new FileReader();
                reader.onload = function(event) {
                    preview.src = event.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
                placeholder.value = '';
            }
        });
    });
</script>
@endsection
