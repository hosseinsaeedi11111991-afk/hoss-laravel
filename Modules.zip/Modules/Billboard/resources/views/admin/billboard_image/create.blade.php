@extends('Shared::layouts.admin.main')

@section('title', 'افزودن تصویر جدید به بیلبورد')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.billboard.index')}}">لیست بیلبوردها/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.billboard.image.index', ['billboard' => $billboard])}}">لیست بیلبوردها/</a></span>
    <span>افزودن تصویر جدید به بیلبورد</span>
</h4>

@include('billboard::admin.billboard_image.partials.form', [
    'billboard' => $billboard,
    'billboard_image' => $billboard_image,
])

@endsection