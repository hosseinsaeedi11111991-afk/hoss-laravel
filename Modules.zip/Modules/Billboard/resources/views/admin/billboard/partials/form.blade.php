<form method="POST" enctype="multipart/form-data"
    action="@if($billboard) {{ route('admin.billboard.update', ['billboard' => $billboard]) }}
      @else {{ route('admin.billboard.store') }} @endif">
    @csrf
    @if($billboard)
    @method('PUT')
    @endif

    <div class="d-flex mb-3 flex-wrap">
        <div class="col-12 col-lg-2 col-md-6 px-4">
            <label class="form-label" for="figure">
                <span>طرح</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <select class="form-select" id="figure" name="figure">
                <option @selected(!$billboard)>لطفا انتخاب کنید</option>
                @foreach ($figures as $value => $lable)
                    <option value="{{ $value }}" @selected($billboard && $billboard->figure == $value)>
                        {{ $lable }}
                    </option>
                @endforeach
            </select>
            @error('figure')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="col-12 col-lg-4 col-md-6 px-4">
            <label class="form-label" for="name">
                <span>نام بیلبورد</span>
                <i class="bx bx-health font-size-1 text-danger mx-2"></i>
            </label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-pen"></i></span>
                <input id="name" type="text" name="name" class="form-control"
                    value="{{ old('name', $billboard ? $billboard->name : '') }}">
            </div>
            @error('name')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn rounded-pill btn-primary mx-4 mt-4">ذخیره اطلاعات</button>
</form>