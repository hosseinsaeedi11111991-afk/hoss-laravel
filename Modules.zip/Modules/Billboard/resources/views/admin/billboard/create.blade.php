@extends('Shared::layouts.admin.main')

@section('title', 'افزودن بیلبورد جدید')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.billboard.index')}}">لیست بیلبوردها/</a></span>
    <span>افزودن بیلبورد جدید</span>
</h4>

@livewire('create_billboard')

@endsection