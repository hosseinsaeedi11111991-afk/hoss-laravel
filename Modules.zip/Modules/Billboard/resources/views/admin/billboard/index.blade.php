@php use Modules\Billboard\Models\Billboard; @endphp
@extends('Shared::layouts.admin.main')

@section('title', 'لیست بیلبوردها')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span>لیست بیلبوردها</span>
</h4>

<a href="{{route('admin.billboard.create')}}" type="button" class="btn rounded-pill me-2 btn-success">افزودن آیتم جدید</a>

<div class="table-responsive text-nowrap mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>نام بیلبورد</th>
                <th>طرح بیلبورد</th>
                <th>وضعیت</th>
                <th>تارخ ویرایش</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            @foreach($items as $key => $row)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$row->name}}</td>
                <td>
                    @switch($row->figure)
                        @case(Billboard::FIGURE_HERO)
                            <span>hero</span>
                            @break
                        @case(Billboard::FIGURE_SLIDER)
                            <span>اسلایدر</span>
                            @break
                        @case(Billboard::FIGURE_BANNER)
                            <span>بنر</span>
                            @break
                        @default
                            <span>نامشخص</span>
                            @break
                    @endswitch
                </td>
                <td>
                    @if ($row->is_active)
                        <span class="text-success">فعال</span>
                    @else
                        <span class="text-danger">غیرفعال</span>
                    @endif
                </td>
                <td>{{ Verta::instance($row->updated_at)->format('Y/m/d') }}</td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="{{ route('admin.billboard.edit', $row->id) }}"
                            class="btn btn-primary btn-sm"
                            title="ویرایش">
                            <i class="bx bx-edit-alt"></i>
                        </a>
                        <a href="{{ route('admin.billboard.image.index', $row->id) }}"
                            class="btn btn-dark btn-sm"
                            title="گالری عکس">
                            <i class="bx bx-image-alt"></i>
                        </a>
                        <form method="POST"
                            action="{{ route('admin.billboard.toggle_status', $row->id) }}"
                            class="d-inline">
                            @csrf
                            @method('PUT')
                            <button type="submit"
                                class="btn btn-warning btn-sm"
                                title="تغییر وضعیت">
                                <i class="bx bx-transfer"></i>
                            </button>
                        </form>
                        <form method="POST"
                            action="{{ route('admin.billboard.destroy', $row->id) }}"
                            class="delete-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="btn btn-danger btn-sm"
                                title="حذف">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">
    {{ $items->links('pagination::bootstrap-5') }}
</div>
@endsection