@extends('Shared::layouts.admin.main')

@section('title', 'ویرایش: {{ $billboard->name }}')

@section('main')
<h4 class="py-3 breadcrumb-wrapper mb-4">
    <span><a class="text-muted fw-light" href="{{route('admin.home')}}">پنل/</a></span>
    <span><a class="text-muted fw-light" href="{{route('admin.billboard.index')}}">لیست بیلبوردها/</a></span>
    <span>ویرایش: {{ $billboard->name }}</span>
</h4>

@include('billboard::admin.billboard.partials.form', [
    'billboard' => $billboard,
    'figures' => $figures,
])

@endsection