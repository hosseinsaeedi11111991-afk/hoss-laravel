<?php

namespace Modules\Billboard\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Attachment\Models\Attachable;
use Modules\Attachment\Services\AttachmentService;
use Modules\Attachment\Traits\AttachmentTools;

/**
 * @property int $id
 * @property string $name
 * @property string $figure
 * @property boolean $new_tab
 * @property boolean $is_active
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 */
class Billboard extends Model
{
    use HasFactory, AttachmentTools;

    public const FIGURE_HERO = 'hero';
    public const FIGURE_SLIDER = 'slider';
    public const FIGURE_BANNER = 'banner';

    public const ACTIVE_TRUE = 1;
    public const ACTIVE_FALSE = 0;

    public const UPLOAD_DIRECTORY = 'billboard';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'figure',
        'new_tab',
        'is_active'
    ];

    protected static function booted()
    {
        static::deleting(function (Billboard $billboard) {
            $service = app(AttachmentService::class);

            foreach ($billboard->attachments as $attachable) {
                $service->detachOrDelete($attachable->attachment, $billboard);
            }
        });
    }

    public static function getFigures()
    {
        return [
            self::FIGURE_HERO => 'hero',
            self::FIGURE_SLIDER => 'اسلایدر',
            self::FIGURE_BANNER => 'بنر',
        ];
    }

    public function attachments()
    {
        return $this->morphMany(Attachable::class, 'attachable')
            ->with('attachment');
    }
}
