<?php

namespace Modules\Billboard\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BillboardImageRequest extends FormRequest
{
    protected function prepareForValidation()
    {
        $this->merge([
            'billboard_id' => (int) $this->route('billboard')->id,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $isUpdate = $this->isMethod('PUT') || $this->isMethod('PATCH');
        return [
            'billboard_id' => 'required|integer|exists:billboards,id',
            'image_alt'    => 'required|string',
            'link'         => 'nullable|url|max:255',
            'caption'      => 'nullable|string|max:255',
            'sort_order'   => 'required|integer|min:1',
            'new_tab'      => 'nullable|boolean',
            'image' => [
                $isUpdate ? 'nullable' : 'required',
                'image',
                'mimes:jpeg,png,jpg,gif,webp',
                'max:1024'
            ],
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function messages()
    {

return [
    'billboard_id.required' => 'شناسه بیلبورد الزامی است.',
    'billboard_id.integer'  => 'شناسه بیلبورد باید عددی صحیح باشد.',
    'billboard_id.exists'   => 'بیلبورد انتخاب‌شده معتبر نیست.',

    'image_alt.required' => 'متن جایگزین تصویر الزامی است.',
    'image_alt.string'   => 'متن جایگزین تصویر باید یک رشته متنی باشد.',

    'link.url'  => 'لینک وارد شده معتبر نیست.',
    'link.max'  => 'لینک نباید بیش از ۲۵۵ کاراکتر باشد.',

    'caption.string' => 'کپشن باید یک رشته متنی باشد.',
    'caption.max'    => 'کپشن نباید بیش از ۲۵۵ کاراکتر باشد.',

    'sort_order.required' => 'ترتیب نمایش الزامی است.',
    'sort_order.integer'  => 'ترتیب نمایش باید عددی صحیح باشد.',
    'sort_order.min'      => 'ترتیب نمایش باید حداقل 1 باشد.',

    'new_tab.boolean' => 'مقدار تب جدید نامعتبر است.',

    'image.required' => 'انتخاب تصویر الزامی است.',
    'image.image'    => 'فایل انتخاب‌شده باید یک تصویر باشد.',
    'image.mimes'    => 'فرمت تصویر باید یکی از موارد jpeg, png, jpg, gif یا webp باشد.',
    'image.max'      => 'حجم تصویر نمی‌تواند بیشتر از 1 مگابایت باشد.',
];
    }
}
