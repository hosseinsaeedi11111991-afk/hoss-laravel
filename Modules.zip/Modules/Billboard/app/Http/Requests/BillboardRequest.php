<?php

namespace Modules\Billboard\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BillboardRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'figure' => 'required|in:hero,slider,banner',
            'new_tab' => 'sometimes|boolean',
            'is_active' => 'sometimes|boolean',
        ];
    }

    /**
     * Optional: Custom messages for validation
     */
    public function messages(): array
    {
        return [
            'name.required' => 'نام باید وارد شود.',
            'figure.required' => 'نوع باید مشخص شود.',
            'figure.in' => 'نوع باید یکی از مقادیر hero, slider یا banner باشد.',
            'new_tab.boolean' => 'مقدار new_tab باید true یا false باشد.',
            'is_active.boolean' => 'مقدار is_active باید true یا false باشد.',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
