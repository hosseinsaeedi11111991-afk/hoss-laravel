<?php

namespace Modules\Billboard\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Attachment\Models\Attachable;
use Modules\Attachment\Models\Attachment;
use Modules\Attachment\Services\AttachmentService;
use Modules\Billboard\Http\Requests\BillboardImageRequest;
use Modules\Billboard\Models\Billboard;

class BillboardImageController extends Controller
{
    public function __construct(
        protected AttachmentService $attachmentService
    ) {}

    /**
     * Display a listing of the resource.
     */
    public function index(Billboard $billboard)
    {
        return view('billboard::admin.billboard_image.index', [
            'billboard' => $billboard,
            'attachments' => $billboard->formattedAttachments('', 'image', true, true, true, 12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Billboard $billboard)
    {
        return view('billboard::admin.billboard_image.create', [
            'billboard' => $billboard,
            'billboard_image' => null,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(BillboardImageRequest $request, Billboard $billboard)
    {
        $data = $request->validated();

        try {
            $attachment = $this->attachmentService->uploadFile(
                $data['image'],
                'public',
                Billboard::UPLOAD_DIRECTORY
            );

            $this->attachmentService->attachToAttachable($attachment, $billboard, 'marketing', $data['sort_order']);

            foreach (['image_alt', 'caption', 'link'] as $attr) {
                $this->attachmentService->upsertMeta($attachment, $attr, $data[$attr] ?? null);
            }
            $this->attachmentService->upsertMeta($attachment, 'new_tab', !empty($data['new_tab']) ? '1' : '0');
        } catch (\RuntimeException $e) {
            return back()->withErrors(['image' => 'خطا در پردازش تصویر.'])->withInput();
        } catch (\Exception $e) {
            return back()->withErrors(['image' => 'خطای غیرمنتظره رخ داد.'])->withInput();
        }

        return redirect()->route('admin.billboard.image.index', $billboard);
    }

    /**
     * Show the specified resource.
     */
    public function show(Billboard $billboard, $id)
    {
        return view('billboard::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Billboard $billboard, $id)
    {
        $attachable = Attachable::with(['attachment.meta', 'attachment.thumbnails'])
            ->where('attachment_id', $id)
            ->where('attachable_type', $billboard->getMorphClass())
            ->where('attachable_id', $billboard->getKey())
            ->firstOrFail();

        if (
            $attachable->attachable_type !== $billboard->getMorphClass() ||
            (int)$attachable->attachable_id !== (int)$billboard->getKey()
        ) {
            abort(404);
        }

        $attachment = $attachable->attachment;

        $billboardImage = [
            'attachment_id' => $attachment->id,
            'sort_order'    => $attachable->sort_order,
            'thumbnails'    => $attachment->thumbnails->pluck('path', 'size')->toArray(),
            'meta'          => $attachment->meta->pluck('value', 'attribute')->toArray(),
        ];

        return view('billboard::admin.billboard_image.edit', [
            'billboard' => $billboard,
            'billboard_image' => $billboardImage,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(BillboardImageRequest $request, Billboard $billboard, $id)
    {
        $data = $request->validated();
        try {
            $attachable = Attachable::with('attachment')
                ->where('attachment_id', $id)
                ->where('attachable_type', $billboard->getMorphClass())
                ->where('attachable_id', $billboard->getKey())
                ->firstOrFail();

            $newFile = $request->file('image');

            $this->attachmentService->updateAttachmentForAttachable(
                $attachable,
                [
                    'sort_order' => $data['sort_order'] ?? 0,
                    'meta'       => [
                        'image_alt' => $data['image_alt'] ?? null,
                        'caption'   => $data['caption'] ?? null,
                        'link'      => $data['link'] ?? null,
                        'new_tab'   => !empty($data['new_tab']),
                    ],
                ],
                $newFile,
                Billboard::UPLOAD_DIRECTORY
            );
        } catch (\Exception $e) {
            return back()->withErrors(['image' => 'خطا در بروزرسانی تصویر.'])->withInput();
        }

        return redirect()
            ->route('admin.billboard.image.index', $billboard)
            ->with('success', 'تصویر با موفقیت ویرایش شد.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Billboard $billboard, $id)
    {
        $attachment = Attachment::where('id', $id)->firstOrFail();
        $this->attachmentService->detachOrDelete($attachment, $billboard);

        return redirect()->route('admin.billboard.image.index', $billboard);
    }
}
