<?php

namespace Modules\Billboard\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Billboard\Http\Requests\BillboardRequest;
use Modules\Billboard\Models\Billboard;

class BillboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('billboard::admin.billboard.index', [
            'items' => Billboard::query()->orderBy('updated_at', 'desc')->paginate(12),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('billboard::admin.billboard.create', [
            'billboard' => null,
            'figures' => Billboard::getFigures(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(BillboardRequest $request)
    {
        $data = $request->validated();

        Billboard::create($data);

        return redirect()->route('admin.billboard.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Billboard $billboard)
    {
        return view('billboard::admin.billboard.edit', [
            'billboard' => $billboard,
            'figures' => Billboard::getFigures(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(BillboardRequest $request, Billboard $billboard)
    {
        $data = $request->validated();

        $billboard->update($data);

        return redirect()->route('admin.billboard.index');
    }

    public function toggleStatus(Billboard $billboard)
    {
        $active_status = ($billboard->is_active) ? Billboard::ACTIVE_FALSE : Billboard::ACTIVE_TRUE;
        $billboard->update(['is_active' => $active_status]);

        return redirect()->route('admin.billboard.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Billboard $billboard)
    {
        DB::transaction(function () use ($billboard) {
            $billboard->delete();
        });
        
        return redirect()->route('admin.billboard.index');
    }
}
