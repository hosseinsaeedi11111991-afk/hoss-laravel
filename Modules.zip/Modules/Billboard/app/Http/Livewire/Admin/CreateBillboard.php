<?php

namespace Modules\Billboard\Http\Livewire\Admin;

use Livewire\Component;
use Livewire\WithFileUploads;
use Modules\Attachment\Services\AttachmentService;
use Modules\Attachment\Models\Attachment;
use Modules\Billboard\Models\Billboard;

class CreateBillboard extends Component
{
    use WithFileUploads;

    public $billboard;
    public $name;
    public $figure;
    public $figures = [];
    public $is_active = true;

    public $slides = [];

    protected $rules = [
        'name' => 'required|string|max:255',
        'figure' => 'required|in:hero,slider,banner',
        'is_active' => 'boolean',
        'slides.*.image' => 'required|image|max:1024',
        'slides.*.image_alt' => 'required|string|max:255',
        'slides.*.link' => 'nullable|url|max:255',
        'slides.*.caption' => 'nullable|string|max:255',
        'slides.*.sort_order' => 'nullable|integer',
        'slides.*.new_tab' => 'boolean',
    ];

    protected function messages()
    {
        return [
            'name.required' => 'لطفاً نام بیلبورد را وارد کنید.',
            'name.max' => 'نام بیلبورد نباید بیش از ۲۵۵ کاراکتر باشد.',
            'figures.required' => 'لطفاً نوع بیلبورد را انتخاب کنید.',
            'figure.in' => 'نوع انتخاب شده نامعتبر است.',
            'slides.*.image.required' => 'لطفاً تصویر را انتخاب کنید.',
            'slides.*.image.image' => 'فایل انتخاب شده باید یک تصویر باشد.',
            'slides.*.image.max' => 'تصویر نمی‌تواند بزرگتر از 1 مگابایت باشد.',
            'slides.*.image_alt.required' => 'لطفاً متن جایگزین تصویر را وارد کنید.',
            'slides.*.link.url' => 'لینک وارد شده معتبر نیست.',
            'slides.*.link.max' => 'لینک نباید بیش از ۲۵۵ کاراکتر باشد.',
            'slides.*.caption.max' => 'کپشن نباید بیش از ۲۵۵ کاراکتر باشد.',
            'slides.*.sort_order.integer' => 'ترتیب نمایش باید یک عدد صحیح باشد.',
            'slides.*.new_tab.boolean' => 'مقدار باز شدن در تب جدید نامعتبر است.',
        ];
    }

    public function mount($billboard = null)
    {
        $this->billboard = $billboard;
        $this->figures = Billboard::getFigures();

        if ($billboard) {
            $this->name = $billboard->name;
            $this->figure = $billboard->figure;
            $this->is_active = $billboard->is_active;

            foreach ($billboard->images as $image) {
                $this->slides[] = [
                    'image' => null,
                    'attachment_id' => $image->attachment_id,
                    'image_alt' => $image->meta['image_alt'] ?? '',
                    'link' => $image->meta['link'] ?? '',
                    'caption' => $image->meta['caption'] ?? '',
                    'sort_order' => $image->sort_order ?? 0,
                    'new_tab' => $image->meta['new_tab'] ?? 0,
                ];
            }
        }

        if (empty($this->slides)) {
            $this->slides[] = [
                'image' => null,
                'image_alt' => '',
                'link' => '',
                'caption' => '',
                'sort_order' => 1,
                'new_tab' => 0,
            ];
        }
    }

    public function addSlide()
    {
        $this->slides[] = [
            'image' => null,
            'image_alt' => '',
            'link' => '',
            'caption' => '',
            'sort_order' => count($this->slides) + 1,
            'new_tab' => 0,
        ];
    }

    public function removeSlide($index)
    {
        unset($this->slides[$index]);
        $this->slides = array_values($this->slides);
        $this->updateSortOrders();
    }

    private function updateSortOrders()
    {
        foreach ($this->slides as $index => &$slide) {
            $slide['sort_order'] = $index + 1;
        }
        unset($slide);
    }

    public function save(AttachmentService $attachmentService)
    {
        $this->validate();

        $billboard = $this->billboard ?? new Billboard();
        $billboard->name = $this->name;
        $billboard->figure = $this->figure;
        $billboard->is_active = $this->is_active;
        $billboard->save();

        foreach ($this->slides as $slide) {
            if (!empty($slide['image'])) {
                $attachment = $attachmentService->uploadFile(
                    $slide['image'],
                    'public',
                    Billboard::UPLOAD_DIRECTORY
                );
            } else {
                $attachment = Attachment::find($slide['attachment_id']);
            }

            $attachmentService->attachToAttachable($attachment, $billboard, 'marketing', $slide['sort_order']);
            $attachmentService->upsertMeta($attachment, 'image_alt', $slide['image_alt']);
            $attachmentService->upsertMeta($attachment, 'link', $slide['link']);
            $attachmentService->upsertMeta($attachment, 'caption', $slide['caption']);
            $attachmentService->upsertMeta($attachment, 'new_tab', $slide['new_tab']);
        }

        session()->flash('success', 'بیلبورد با موفقیت ذخیره شد.');
        return redirect()->route('admin.billboard.index');
    }

    public function render()
    {
        return view('billboard::admin.livewire.create_billboard');
    }
}
