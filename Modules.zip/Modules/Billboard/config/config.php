<?php

return [
    'name' => 'Billboard',
];
