<?php

use Illuminate\Support\Facades\Route;
use Modules\Billboard\Http\Controllers\Admin\BillboardController;
use Modules\Billboard\Http\Controllers\Admin\BillboardImageController;

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {
        Route::controller(BillboardController::class)
            ->prefix('billboard')->name('billboard.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('/create', 'create')->name('create');
                Route::post('/store', 'store')->name('store');
                Route::get('{billboard}/edit', 'edit')->name('edit');
                Route::put('{billboard}/update', 'update')->name('update');
                Route::put('{billboard}/toggle-status', 'toggleStatus')->name('toggle_status');
                Route::delete('{billboard}/destroy', 'destroy')->name('destroy');
            });
    });

Route::middleware(['web', 'auth', 'role:super_user|admin|author'])
    ->prefix('admin-panel')->name('admin.')->group(function () {
        Route::controller(BillboardImageController::class)
            ->prefix('billboard/{billboard}/image')->name('billboard.image.')->group(function () {
                Route::get('/', 'index')->name('index');
                Route::get('/create', 'create')->name('create');
                Route::post('/store', 'store')->name('store');
                Route::get('{billboard_image}/edit', 'edit')->name('edit');
                Route::put('{billboard_image}/update', 'update')->name('update');
                Route::delete('{billboard_image}/destroy', 'destroy')->name('destroy');
            });
    });
